/**
 * DBSEXT テーブル列制御モジュール
 *
 * 目的: 車両情報（/vehicles）の横長テーブル問題に対処するため、
 * 普段使われない操作系5列（メンテナンス、AT管理、解錠、再配置、AT一体型車両操作）を
 * 既定で隠し、必要なときだけトグルで表示する。
 *
 * 契約 §6 の遵守:
 * - DOMノードの削除・移動は一切行わない（display: none による表示制御のみ）
 * - 操作ボタン自体には一切介入しない
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var ACTION_COLUMNS = [
    'メンテナンス',
    'AT管理',
    '解錠',
    '再配置',
    'AT一体型車両操作'
  ];

  var STORAGE_FEATURE = 'showActionCols';
  var UI_CONTAINER_ATTR = 'data-dbsext-table-columns';
  var TOGGLE_INPUT_ATTR = 'data-dbsext-action-toggle';
  var WIDTH_STYLE_ID = 'dbsext-table-columns-width';

  function getScreen() {
    if (typeof location === 'undefined' || !location.pathname) return '';
    return location.pathname;
  }

  function isVehiclesScreen() {
    var path = getScreen();
    // モック等で '/' や空の場合でも、テーブル内に該当操作列が存在すれば適用可能にするか、
    // または /vehicles を基本としつつテスト環境にも配慮
    return path.indexOf('/vehicles') >= 0 || path === '' || path === '/';
  }

  function getStorageKey(screen) {
    return 'dbsext:v1:' + (screen || '/') + ':' + STORAGE_FEATURE;
  }

  function loadToggleState(screen) {
    try {
      if (D.stateStore && typeof D.stateStore.load === 'function') {
        var val = D.stateStore.load(screen, STORAGE_FEATURE);
        if (val !== null && typeof val !== 'undefined') {
          return !!val;
        }
      }
      if (typeof localStorage !== 'undefined') {
        var raw = localStorage.getItem(getStorageKey(screen));
        if (raw !== null) {
          return raw === 'true';
        }
      }
    } catch (e) {}
    return false; // 既定は「隠す」（showActionCols = false）
  }

  function saveToggleState(screen, show) {
    try {
      if (D.stateStore && typeof D.stateStore.save === 'function') {
        D.stateStore.save(screen, STORAGE_FEATURE, show, { scope: 'local' });
      }
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(getStorageKey(screen), show ? 'true' : 'false');
      }
    } catch (e) {}
  }

  /**
   * 列の見出し名を取り出す。
   *
   * **`th.textContent` をそのまま使ってはいけない。**
   * `table-tools` が同じ th にソート矢印（`▲`）と絞り込み入力を**追加する**ため、
   * 見出しの文字列は `メンテナンス ▲` のように汚れる。
   * 素朴に完全一致で比べると**1列も一致せず、列が一つも隠れない**
   * （しかも「対象列なし」として静かに何もしないので気づけない）。
   *
   * `table-tools` は元の列名を `data-dbsext-orig-title` に控えているので、
   * まずそれを使う。無ければ自前UIを除いた文字列を組み立てる。
   * こうしておけば **モジュールの適用順に依存しない**。
   */
  function headerName(th) {
    var orig = th.getAttribute && th.getAttribute('data-dbsext-orig-title');
    if (orig) return String(orig).trim();

    if (typeof th.cloneNode === 'function') {
      var clone = th.cloneNode(true);
      var own = clone.querySelectorAll(
        '[data-dbsext-sort],[data-dbsext-filter],[data-dbsext-collapse-hint]'
      );
      for (var i = 0; i < own.length; i++) {
        if (own[i].parentNode) own[i].parentNode.removeChild(own[i]); // dbsext:own-ui
      }
      return (clone.textContent || '').trim();
    }
    return (th.textContent || '').trim();
  }

  function findActionColumnIndices(headerTable) {
    if (!headerTable) return [];
    var ths = headerTable.querySelectorAll('thead th, tr th');
    var indices = [];
    for (var i = 0; i < ths.length; i++) {
      var text = headerName(ths[i]);
      for (var k = 0; k < ACTION_COLUMNS.length; k++) {
        if (text === ACTION_COLUMNS[k]) {
          indices.push(i);
          break;
        }
      }
    }
    return indices;
  }

  function setColumnVisibility(table, indices, show) {
    if (!table || !indices || indices.length === 0) return;

    var headerTable = table.querySelector('table.el-table__header');
    var bodyTable = table.querySelector('table.el-table__body');

    var displayVal = show ? '' : 'none';
    var colWidthVal = show ? '' : '0px';

    // 1. ヘッダ colgroup & th
    if (headerTable) {
      var headerCols = headerTable.querySelectorAll('colgroup col');
      for (var c = 0; c < indices.length; c++) {
        var idx = indices[c];
        if (headerCols[idx]) {
          headerCols[idx].style.display = displayVal;
          if (!show) {
            if (!headerCols[idx].hasAttribute('data-dbsext-orig-width')) {
              headerCols[idx].setAttribute('data-dbsext-orig-width', headerCols[idx].getAttribute('width') || '');
            }
            headerCols[idx].style.width = colWidthVal;
          } else {
            // **元の値を代入し直してはいけない。**
            // 控えてある値は width 属性（例 "300"）で**単位が無い**ため、
            // `style.width = "300"` は不正な値として無視され、
            // 直前の `0px` が residual として残る。
            // 結果、「操作列を表示」にしても**列が潰れたまま**になり、
            // 中身が折り返して**見出し行が異常に高くなる**（実機で 89px → 272px）。
            // インラインの指定を消せば、元からある width 属性が効く。
            headerCols[idx].style.removeProperty('width');
          }
        }
      }

      var headerRows = headerTable.querySelectorAll('thead tr, tr');
      for (var r = 0; r < headerRows.length; r++) {
        var ths = headerRows[r].children;
        for (var h = 0; h < indices.length; h++) {
          var hIdx = indices[h];
          if (ths[hIdx]) {
            ths[hIdx].style.display = displayVal;
          }
        }
      }
    }

    // 2. ボディ colgroup & td
    if (bodyTable) {
      var bodyCols = bodyTable.querySelectorAll('colgroup col');
      for (var bc = 0; bc < indices.length; bc++) {
        var bIdx = indices[bc];
        if (bodyCols[bIdx]) {
          bodyCols[bIdx].style.display = displayVal;
          if (!show) {
            if (!bodyCols[bIdx].hasAttribute('data-dbsext-orig-width')) {
              bodyCols[bIdx].setAttribute('data-dbsext-orig-width', bodyCols[bIdx].getAttribute('width') || '');
            }
            bodyCols[bIdx].style.width = colWidthVal;
          } else {
            // ヘッダ側と同じ理由。単位の無い値を代入せず、インライン指定を消す
            bodyCols[bIdx].style.removeProperty('width');
          }
        }
      }

      var bodyRows = bodyTable.querySelectorAll('tbody tr');
      for (var br = 0; br < bodyRows.length; br++) {
        var tds = bodyRows[br].children;
        for (var d = 0; d < indices.length; d++) {
          var dIdx = indices[d];
          if (tds[dIdx]) {
            tds[dIdx].style.display = displayVal;
          }
        }
      }
    }

    shrinkTableWidth(headerTable, bodyTable, indices, show);

    // 表示列を戻すと表幅が 1944px → 3144px のように広がる。
    // 上部スクロールバーの中身も同じ幅へ再計測しないと、追加領域へ到達できない。
    if (D.tableWrap && typeof D.tableWrap.refresh === 'function') {
      D.tableWrap.refresh(table);
    }
  }

  /**
   * 隠した列のぶんだけ表の幅を詰める。
   *
   * **列を display:none にしただけでは表は狭くならない。**
   * Element Plus は `table.el-table__header` と `table.el-table__body` の両方に
   * **インラインで `width: 3144px` を固定**している（実機実測 2026-08-09）。
   * そのため列を隠しても幅はそのままで、**空白ができるだけで横スクロール量は減らない**。
   * 「操作列を隠せば横幅が減る」という狙いが、まったく実現していなかった。
   *
   * `width: auto` にすれば器の幅（1621px）まで縮むが、
   * 残る11列の指定幅の合計（約2044px）を下回るため、
   * **`table-layout: fixed` の下で各列が圧縮され、文字が切れる**。
   * 情報が見えなくなるのは本末転倒なので採らない。
   *
   * さらに **EP はウィンドウのリサイズのたびにインライン幅を書き戻す**ため、
   * JS で `style.width` を書いても消される。そこで **`!important` のスタイルシート**で
   * 指定する（`!important` の作者スタイルはインラインスタイルに優先する）。
   *
   * ここでは **元の幅から、隠した列の幅の合計を引く**。
   * 残る列の幅は変わらないので文字は切れない。
   * 横スクロールは残るが、無意味な空白ぶんは確実に減る。
   * （**列幅そのものを詰めるのは案2**。実データでの実測が要るため別途）
   */
  function shrinkTableWidth(headerTable, bodyTable, indices, show) {
    if (typeof document === 'undefined' || !document.head) return;

    var style = document.getElementById(WIDTH_STYLE_ID);

    if (show) {
      if (style && style.parentNode) style.parentNode.removeChild(style); // dbsext:own-ui
      return;
    }

    var base = 0;
    var hidden = 0;
    var cols = headerTable ? headerTable.querySelectorAll('colgroup col') : [];
    for (var i = 0; i < cols.length; i++) {
      var w = parseFloat(
        cols[i].getAttribute('data-dbsext-orig-width') || cols[i].getAttribute('width')
      );
      if (isNaN(w)) continue;
      base += w;
      for (var k = 0; k < indices.length; k++) {
        if (indices[k] === i) { hidden += w; break; }
      }
    }

    if (!(hidden > 0) || !(base - hidden > 0)) return;
    var desired = base - hidden;

    var css =
      'table.el-table__header, table.el-table__body { width: ' + desired + 'px !important; }';

    if (!style) {
      style = document.createElement('style');
      style.id = WIDTH_STYLE_ID;
      // 自前の要素なので own 扱い（core.js の ATTR_KIND 参照）
      style.setAttribute(UI_CONTAINER_ATTR, '1');
      document.head.appendChild(style);
    }
    if (style.textContent !== css) style.textContent = css;
  }

  function ensureToggleUI(table, screen, show, onToggle) {
    if (!table || !table.parentNode) return;

    var existing = table.parentNode.querySelector('[' + UI_CONTAINER_ATTR + ']');
    if (existing) {
      var input = existing.querySelector('[' + TOGGLE_INPUT_ATTR + ']');
      if (input) {
        input.checked = show;
      }
      return;
    }

    var bar = document.createElement('div');
    bar.setAttribute(UI_CONTAINER_ATTR, '1');
    bar.style.cssText = 'display:flex; align-items:center; justify-content:flex-end; padding:4px 8px; margin-bottom:4px; font-size:13px;';

    var label = document.createElement('label');
    label.style.cssText = 'display:inline-flex; align-items:center; cursor:pointer; color:#303133; font-weight:500; user-select:none;';

    var checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.setAttribute(TOGGLE_INPUT_ATTR, '1');
    checkbox.checked = show;
    checkbox.style.cssText = 'margin-right:6px; cursor:pointer; accent-color:#0b5cab; width:15px; height:15px;';

    checkbox.addEventListener('change', function () {
      var newState = checkbox.checked;
      saveToggleState(screen, newState);
      if (typeof onToggle === 'function') {
        onToggle(newState);
      }
    });

    var span = document.createElement('span');
    span.textContent = '操作列を表示';

    label.appendChild(checkbox);
    label.appendChild(span);
    bar.appendChild(label);

    table.parentNode.insertBefore(bar, table);
  }

  D.tableColumns = {
    ACTION_COLUMNS: ACTION_COLUMNS,
    STORAGE_FEATURE: STORAGE_FEATURE,

    apply: function () {
      if (typeof document === 'undefined') return;

      var screen = getScreen();
      // /vehicles 以外の明示的な他画面（例: /users, /ports 等）では何もしない
      if (screen && screen !== '/' && screen.indexOf('/vehicles') < 0) {
        return;
      }

      var tables = document.querySelectorAll('.el-table');
      if (!tables || tables.length === 0) return;

      var show = loadToggleState(screen);

      for (var t = 0; t < tables.length; t++) {
        var table = tables[t];
        var headerTable = table.querySelector('table.el-table__header');
        if (!headerTable) continue;

        var indices = findActionColumnIndices(headerTable);
        // 対象列が1つも無ければ何もしない
        if (indices.length === 0) continue;

        (function (tbl, idxs) {
          ensureToggleUI(tbl, screen, show, function (newShow) {
            setColumnVisibility(tbl, idxs, newShow);
          });
          setColumnVisibility(tbl, idxs, show);
        })(table, indices);
      }
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
