/**
 * DBSEXT テーブル列制御モジュール
 *
 * 目的: 車両情報（/vehicles）の横長テーブル問題に対処するため、
 * 普段使われない操作系5列（メンテナンス、AT管理、解錠、再配置、AT一体型車両操作）を
 * 既定で隠し、必要なときだけトグルで表示する。
 *
 * 契約 §6 の遵守:
 * - DOMノードの削除・移動は一切行わない（display: none による表示制御のみ）
 * - 操作ボタン自体には一切介入しない
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var ACTION_COLUMNS = [
    'メンテナンス',
    'AT管理',
    '解錠',
    '再配置',
    'AT一体型車両操作'
  ];

  var STORAGE_FEATURE = 'showActionCols';
  var UI_CONTAINER_ATTR = 'data-dbsext-table-columns';
  var TOGGLE_INPUT_ATTR = 'data-dbsext-action-toggle';

  function getScreen() {
    if (typeof location === 'undefined' || !location.pathname) return '';
    return location.pathname;
  }

  function isVehiclesScreen() {
    var path = getScreen();
    // モック等で '/' や空の場合でも、テーブル内に該当操作列が存在すれば適用可能にするか、
    // または /vehicles を基本としつつテスト環境にも配慮
    return path.indexOf('/vehicles') >= 0 || path === '' || path === '/';
  }

  function getStorageKey(screen) {
    return 'dbsext:v1:' + (screen || '/') + ':' + STORAGE_FEATURE;
  }

  function loadToggleState(screen) {
    try {
      if (D.stateStore && typeof D.stateStore.load === 'function') {
        var val = D.stateStore.load(screen, STORAGE_FEATURE);
        if (val !== null && typeof val !== 'undefined') {
          return !!val;
        }
      }
      if (typeof localStorage !== 'undefined') {
        var raw = localStorage.getItem(getStorageKey(screen));
        if (raw !== null) {
          return raw === 'true';
        }
      }
    } catch (e) {}
    return false; // 既定は「隠す」（showActionCols = false）
  }

  function saveToggleState(screen, show) {
    try {
      if (D.stateStore && typeof D.stateStore.save === 'function') {
        D.stateStore.save(screen, STORAGE_FEATURE, show, { scope: 'local' });
      }
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(getStorageKey(screen), show ? 'true' : 'false');
      }
    } catch (e) {}
  }

  /**
   * 列の見出し名を取り出す。
   *
   * **`th.textContent` をそのまま使ってはいけない。**
   * `table-tools` が同じ th にソート矢印（`▲`）と絞り込み入力を**追加する**ため、
   * 見出しの文字列は `メンテナンス ▲` のように汚れる。
   * 素朴に完全一致で比べると**1列も一致せず、列が一つも隠れない**
   * （しかも「対象列なし」として静かに何もしないので気づけない）。
   *
   * `table-tools` は元の列名を `data-dbsext-orig-title` に控えているので、
   * まずそれを使う。無ければ自前UIを除いた文字列を組み立てる。
   * こうしておけば **モジュールの適用順に依存しない**。
   */
  function headerName(th) {
    var orig = th.getAttribute && th.getAttribute('data-dbsext-orig-title');
    if (orig) return String(orig).trim();

    if (typeof th.cloneNode === 'function') {
      var clone = th.cloneNode(true);
      var own = clone.querySelectorAll(
        '[data-dbsext-sort],[data-dbsext-filter],[data-dbsext-collapse-hint]'
      );
      for (var i = 0; i < own.length; i++) {
        if (own[i].parentNode) own[i].parentNode.removeChild(own[i]); // dbsext:own-ui
      }
      return (clone.textContent || '').trim();
    }
    return (th.textContent || '').trim();
  }

  function findActionColumnIndices(headerTable) {
    if (!headerTable) return [];
    var ths = headerTable.querySelectorAll('thead th, tr th');
    var indices = [];
    for (var i = 0; i < ths.length; i++) {
      var text = headerName(ths[i]);
      for (var k = 0; k < ACTION_COLUMNS.length; k++) {
        if (text === ACTION_COLUMNS[k]) {
          indices.push(i);
          break;
        }
      }
    }
    return indices;
  }

  function setColumnVisibility(table, indices, show) {
    if (!table || !indices || indices.length === 0) return;

    var headerTable = table.querySelector('table.el-table__header');
    var bodyTable = table.querySelector('table.el-table__body');

    var displayVal = show ? '' : 'none';
    var colWidthVal = show ? '' : '0px';

    // 1. ヘッダ colgroup & th
    if (headerTable) {
      var headerCols = headerTable.querySelectorAll('colgroup col');
      for (var c = 0; c < indices.length; c++) {
        var idx = indices[c];
        if (headerCols[idx]) {
          headerCols[idx].style.display = displayVal;
          if (!show) {
            if (!headerCols[idx].hasAttribute('data-dbsext-orig-width')) {
              headerCols[idx].setAttribute('data-dbsext-orig-width', headerCols[idx].getAttribute('width') || '');
            }
            headerCols[idx].style.width = colWidthVal;
          } else {
            var origW = headerCols[idx].getAttribute('data-dbsext-orig-width');
            if (origW !== null) {
              headerCols[idx].style.width = origW;
            }
          }
        }
      }

      var headerRows = headerTable.querySelectorAll('thead tr, tr');
      for (var r = 0; r < headerRows.length; r++) {
        var ths = headerRows[r].children;
        for (var h = 0; h < indices.length; h++) {
          var hIdx = indices[h];
          if (ths[hIdx]) {
            ths[hIdx].style.display = displayVal;
          }
        }
      }
    }

    // 2. ボディ colgroup & td
    if (bodyTable) {
      var bodyCols = bodyTable.querySelectorAll('colgroup col');
      for (var bc = 0; bc < indices.length; bc++) {
        var bIdx = indices[bc];
        if (bodyCols[bIdx]) {
          bodyCols[bIdx].style.display = displayVal;
          if (!show) {
            if (!bodyCols[bIdx].hasAttribute('data-dbsext-orig-width')) {
              bodyCols[bIdx].setAttribute('data-dbsext-orig-width', bodyCols[bIdx].getAttribute('width') || '');
            }
            bodyCols[bIdx].style.width = colWidthVal;
          } else {
            var origBW = bodyCols[bIdx].getAttribute('data-dbsext-orig-width');
            if (origBW !== null) {
              bodyCols[bIdx].style.width = origBW;
            }
          }
        }
      }

      var bodyRows = bodyTable.querySelectorAll('tbody tr');
      for (var br = 0; br < bodyRows.length; br++) {
        var tds = bodyRows[br].children;
        for (var d = 0; d < indices.length; d++) {
          var dIdx = indices[d];
          if (tds[dIdx]) {
            tds[dIdx].style.display = displayVal;
          }
        }
      }
    }
  }

  function ensureToggleUI(table, screen, show, onToggle) {
    if (!table || !table.parentNode) return;

    var existing = table.parentNode.querySelector('[' + UI_CONTAINER_ATTR + ']');
    if (existing) {
      var input = existing.querySelector('[' + TOGGLE_INPUT_ATTR + ']');
      if (input) {
        input.checked = show;
      }
      return;
    }

    var bar = document.createElement('div');
    bar.setAttribute(UI_CONTAINER_ATTR, '1');
    bar.style.cssText = 'display:flex; align-items:center; justify-content:flex-end; padding:4px 8px; margin-bottom:4px; font-size:13px;';

    var label = document.createElement('label');
    label.style.cssText = 'display:inline-flex; align-items:center; cursor:pointer; color:#303133; font-weight:500; user-select:none;';

    var checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.setAttribute(TOGGLE_INPUT_ATTR, '1');
    checkbox.checked = show;
    checkbox.style.cssText = 'margin-right:6px; cursor:pointer; accent-color:#0b5cab; width:15px; height:15px;';

    checkbox.addEventListener('change', function () {
      var newState = checkbox.checked;
      saveToggleState(screen, newState);
      if (typeof onToggle === 'function') {
        onToggle(newState);
      }
    });

    var span = document.createElement('span');
    span.textContent = '操作列を表示';

    label.appendChild(checkbox);
    label.appendChild(span);
    bar.appendChild(label);

    table.parentNode.insertBefore(bar, table);
  }

  D.tableColumns = {
    ACTION_COLUMNS: ACTION_COLUMNS,
    STORAGE_FEATURE: STORAGE_FEATURE,

    apply: function () {
      if (typeof document === 'undefined') return;

      var screen = getScreen();
      // /vehicles 以外の明示的な他画面（例: /users, /ports 等）では何もしない
      if (screen && screen !== '/' && screen.indexOf('/vehicles') < 0) {
        return;
      }

      var tables = document.querySelectorAll('.el-table');
      if (!tables || tables.length === 0) return;

      var show = loadToggleState(screen);

      for (var t = 0; t < tables.length; t++) {
        var table = tables[t];
        var headerTable = table.querySelector('table.el-table__header');
        if (!headerTable) continue;

        var indices = findActionColumnIndices(headerTable);
        // 対象列が1つも無ければ何もしない
        if (indices.length === 0) continue;

        (function (tbl, idxs) {
          ensureToggleUI(tbl, screen, show, function (newShow) {
            setColumnVisibility(tbl, idxs, newShow);
          });
          setColumnVisibility(tbl, idxs, show);
        })(table, indices);
      }
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
