/**
 * DBSEXT Chrome拡張環境用 platform 実装 (β)
 * 契約書 06-module-contract.md §3 platform に基づく実装
 */
(function (global) {
  'use strict';

  global.DBSEXT = global.DBSEXT || {};
  var D = global.DBSEXT;

  D.platform = {
    kind: 'extension',

    /**
     * ページ再読込で消えるエフェメラル環境か
     * @returns {boolean}
     */
    isEphemeral: function () {
      return false;
    },

    /**
     * service worker 経由でエリア一覧を取得する
     * @returns {Promise<Array>}
     */
    fetchAreas: function () {
      return new Promise(function (resolve, reject) {
        chrome.runtime.sendMessage({ type: 'dbsext:areas' }, function (res) {
          var err = chrome.runtime.lastError;
          if (err) {
            return reject(new Error(err.message));
          }
          if (res && res.ok) {
            return resolve(res.areas || []);
          }
          return reject(new Error((res && res.error) || 'エリア情報の取得に失敗しました'));
        });
      });
    },

    /**
     * service worker 経由で別タブで URL を開く
     * @param {string} url
     */
    openTab: function (url) {
      chrome.runtime.sendMessage({ type: 'dbsext:openTab', url: url }, function () {
        var err = chrome.runtime.lastError;
        if (err && D.core && typeof D.core.log === 'function') {
          D.core.log('openTab エラー: ' + err.message, true);
        }
      });
    },

    /**
     * service worker 経由で Side Panel で URL を開く（失敗時は openTab にフォールバック）
     * @param {string} url
     */
    openSplit: function (url) {
      chrome.runtime.sendMessage({ type: 'dbsext:openSplit', url: url }, function (res) {
        var err = chrome.runtime.lastError;
        if (err || !res || !res.ok) {
          var errMsg = (res && res.error) || (err && err.message) || 'サイドパネルを開けませんでした';
          if (D.core && typeof D.core.log === 'function') {
            D.core.log(errMsg, true);
          }
          D.platform.openTab(url);
        }
      });
    },

    /**
     * 案内ページを別タブで開く
     * @param {string} url
     */
    openGuide: function (url) {
      D.platform.openTab(url);
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
