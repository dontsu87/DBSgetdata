/**
 * DBSEXT Chrome拡張環境用 platform 実装 (β)
 * 契約書 06-module-contract.md §3 platform に基づく実装
 */
(function (global) {
  'use strict';

  global.DBSEXT = global.DBSEXT || {};
  var D = global.DBSEXT;

  var beaconPortRequestsActive = 0;
  var beaconPortRequestQueue = [];

  /** 複数の一覧要求を跨いでも、ポート別GETの合計を最大3件に保つ。 */
  function runWithBeaconPortSlot(task) {
    return new Promise(function (resolve, reject) {
      function release() {
        beaconPortRequestsActive--;
        var next = beaconPortRequestQueue.shift();
        if (next) next();
      }

      function start() {
        beaconPortRequestsActive++;
        Promise.resolve()
          .then(task)
          .then(function (value) {
            release();
            resolve(value);
          }, function (error) {
            release();
            reject(error);
          });
      }

      if (beaconPortRequestsActive < 3) {
        start();
      } else {
        beaconPortRequestQueue.push(start);
      }
    });
  }

  D.platform = {
    kind: 'extension',

    /**
     * ページ再読込で消えるエフェメラル環境か
     * @returns {boolean}
     */
    isEphemeral: function () {
      return false;
    },

    /**
     * service worker 経由でエリア一覧を取得する
     * @returns {Promise<Array>}
     */
    fetchAreas: function () {
      return new Promise(function (resolve, reject) {
        chrome.runtime.sendMessage({ type: 'dbsext:areas' }, function (res) {
          var err = chrome.runtime.lastError;
          if (err) {
            return reject(new Error(err.message));
          }
          if (res && res.ok) {
            return resolve(res.areas || []);
          }
          return reject(new Error((res && res.error) || 'エリア情報の取得に失敗しました'));
        });
      });
    },

    /**
     * service worker 経由で別タブで URL を開く
     * @param {string} url
     */
    openTab: function (url) {
      chrome.runtime.sendMessage({ type: 'dbsext:openTab', url: url }, function () {
        var err = chrome.runtime.lastError;
        if (err && D.core && typeof D.core.log === 'function') {
          D.core.log('openTab エラー: ' + err.message, true);
        }
      });
    },

    /**
     * service worker 経由で Side Panel で URL を開く（失敗時は openTab にフォールバック）
     * @param {string} url
     */
    openSplit: function (url) {
      chrome.runtime.sendMessage({ type: 'dbsext:openSplit', url: url }, function (res) {
        var err = chrome.runtime.lastError;
        if (err || !res || !res.ok) {
          var errMsg = (res && res.error) || (err && err.message) || 'サイドパネルを開けませんでした';
          if (D.core && typeof D.core.log === 'function') {
            D.core.log(errMsg, true);
          }
          D.platform.openTab(url);
        }
      });
    },

    /**
     * 案内ページを別タブで開く
     * @param {string} url
     */
    openGuide: function (url) {
      D.platform.openTab(url);
    },

    /**
     * service worker 経由で指定エリア内のポート割当済みビーコンを取得する
     * @param {string} areaId
     * @returns {Promise<{rows: Array, portCount: number, failedPortCount: number}>}
     */
    fetchBeaconsByArea: function (areaId) {
      return new Promise(function (resolve, reject) {
        if (typeof areaId !== 'string' || !areaId || !/^[A-Za-z0-9:_-]{1,256}$/.test(areaId)) {
          return reject(new Error('無効なエリアIDです'));
        }
        chrome.runtime.sendMessage({ type: 'dbsext:beaconPortsByArea', areaId: areaId }, function (res) {
          var err = chrome.runtime.lastError;
          if (err) {
            return reject(new Error(err.message));
          }
          if (!res || !res.ok) {
            return reject(new Error((res && res.error) || 'ポート一覧の取得に失敗しました'));
          }

          var ports = res.ports || [];
          var portCount = ports.length;
          var failedPortCount = 0;
          var rows = [];

          if (portCount === 0) {
            return resolve({ rows: [], portCount: 0, failedPortCount: 0 });
          }

          var index = 0;
          var concurrency = 3;

          function processNextPort() {
            if (index >= ports.length) {
              return Promise.resolve();
            }
            var portObj = ports[index++];
            var rawPortId = '';
            if (typeof portObj === 'string') {
              rawPortId = portObj;
            } else if (portObj && (typeof portObj.portId === 'string' || typeof portObj.portId === 'number')) {
              rawPortId = String(portObj.portId);
            }

            if (!rawPortId || !/^[A-Za-z0-9:_-]{1,256}$/.test(rawPortId)) {
              failedPortCount++;
              return processNextPort();
            }

            return runWithBeaconPortSlot(function () {
              return new Promise(function (pResolve) {
                chrome.runtime.sendMessage({ type: 'dbsext:beaconsByPort', portId: rawPortId }, function (bRes) {
                  var bErr = chrome.runtime.lastError;
                  if (bErr || !bRes || !bRes.ok) {
                    failedPortCount++;
                  } else {
                    var items = bRes.beacons || [];
                    for (var i = 0; i < items.length; i++) {
                      var item = items[i] || {};
                      rows.push({
                        portBeaconId: item.portBeaconId || '',
                        portBeaconUniqueCode: item.portBeaconUniqueCode || '',
                        beaconType: item.beaconType || '',
                        portId: item.portId || rawPortId,
                        portUniqueCode: item.portUniqueCode || (portObj && portObj.portUniqueCode) || '',
                        portNameJa: item.portNameJa || (portObj && portObj.portNameJa) || '',
                        portBeaconElectricVoltage: item.portBeaconElectricVoltage !== undefined ? item.portBeaconElectricVoltage : (item.voltage !== undefined ? item.voltage : ''),
                        batteryRemainingAmount: item.batteryRemainingAmount !== undefined ? item.batteryRemainingAmount : (item.batteryRemaining !== undefined ? item.batteryRemaining : ''),
                        lastReceivedTs: item.lastReceivedTs || ''
                      });
                    }
                  }
                  pResolve();
                });
              });
            })
              .then(function () {
                return processNextPort();
              });
          }

          var workers = [];
          for (var w = 0; w < Math.min(concurrency, ports.length); w++) {
            workers.push(processNextPort());
          }

          Promise.all(workers).then(function () {
            resolve({
              rows: rows,
              portCount: portCount,
              failedPortCount: failedPortCount
            });
          });
        });
      });
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
