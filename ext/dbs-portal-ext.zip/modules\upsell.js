/**
 * DBSEXT アップセル / 案内パネルモジュール
 * 画面右下に Shadow DOM によるパネルを表示する
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  D.upsell = {
    /**
     * パネルを描画（冪等）
     */
    apply: function () {
      if (typeof document === 'undefined' || !document.body) {
        return;
      }

      if (document.querySelector('[data-dbsext-upsell="1"]')) {
        return;
      }

      var host = document.createElement('div');
      host.setAttribute('data-dbsext-upsell', '1');

      var shadow = host.attachShadow({ mode: 'open' });

      var accent = (D.CONFIG && D.CONFIG.ACCENT) ? D.CONFIG.ACCENT : '#0b5cab';
      var accentDark = (D.CONFIG && D.CONFIG.ACCENT_DARK) ? D.CONFIG.ACCENT_DARK : '#083f75';
      var guideUrl = (D.CONFIG && D.CONFIG.GUIDE_URL) ? D.CONFIG.GUIDE_URL : 'https://dontsu87.github.io/DBSgetdata/ext/';
      var version = D.VERSION || '0.1.0';

      var platform = D.platform || {};
      var isEphemeral = (typeof platform.isEphemeral === 'function') ? platform.isEphemeral() : true;
      var kindText = (platform.kind === 'extension') ? '（拡張版）' : '（ブックマークレット版）';

      var style = document.createElement('style');
      style.textContent = [
        ':host {',
        '  position: fixed;',
        '  right: 12px;',
        '  bottom: 12px;',
        '  z-index: 2147483000;',
        '  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;',
        '}',
        '.panel {',
        '  background-color: ' + accent + ';',
        '  color: #ffffff;',
        '  border-radius: 8px;',
        '  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);',
        '  width: 260px;',
        '  font-size: 12px;',
        '  line-height: 1.4;',
        '  overflow: hidden;',
        '}',
        '.header {',
        '  padding: 8px 12px;',
        '  font-weight: bold;',
        '  cursor: pointer;',
        '  display: flex;',
        '  justify-content: space-between;',
        '  align-items: center;',
        '  user-select: none;',
        '  background-color: ' + accentDark + ';',
        '}',
        '.header-title {',
        '  font-size: 12px;',
        '}',
        '.header-toggle {',
        '  font-size: 10px;',
        '  opacity: 0.8;',
        '}',
        '.body {',
        '  padding: 10px 12px;',
        '  display: flex;',
        '  flex-direction: column;',
        '  gap: 8px;',
        '}',
        '.body.collapsed {',
        '  display: none;',
        '}',
        '.notice {',
        '  font-size: 11px;',
        '  opacity: 0.95;',
        '}',
        '.btn {',
        '  display: block;',
        '  background: #ffffff;',
        '  color: ' + accentDark + ';',
        '  border: none;',
        '  border-radius: 4px;',
        '  padding: 6px 10px;',
        '  font-size: 11px;',
        '  font-weight: bold;',
        '  cursor: pointer;',
        '  text-align: center;',
        '  text-decoration: none;',
        '}',
        '.btn:hover {',
        '  background: #f0f0f0;',
        '}',
        '.link {',
        '  color: #ffffff;',
        '  text-decoration: underline;',
        '  cursor: pointer;',
        '  font-size: 11px;',
        '  text-align: right;',
        '  display: inline-block;',
        '}',
        '.link:hover {',
        '  opacity: 0.8;',
        '}'
      ].join('\n');

      shadow.appendChild(style);

      var panel = document.createElement('div');
      panel.className = 'panel';

      // ヘッダ（折りたたみ操作）
      var header = document.createElement('div');
      header.className = 'header';

      var titleSpan = document.createElement('span');
      titleSpan.className = 'header-title';
      titleSpan.textContent = 'DBS 拡張ステータス';

      var toggleSpan = document.createElement('span');
      toggleSpan.className = 'header-toggle';
      toggleSpan.textContent = '▲';

      header.appendChild(titleSpan);
      header.appendChild(toggleSpan);
      panel.appendChild(header);

      // パネル本文
      var body = document.createElement('div');
      body.className = 'body';

      // 行1: 拡張適用中 v<VERSION> (形式)
      var row1 = document.createElement('div');
      row1.textContent = '拡張適用中 ' + version + kindText;
      body.appendChild(row1);

      if (isEphemeral) {
        // 行2: 再読込注意
        var row2 = document.createElement('div');
        row2.className = 'notice';
        row2.textContent = '画面を再読込したら、もう一度ブックマークを押してください';
        body.appendChild(row2);

        // 行3: Chrome拡張の導入案内ボタン
        var row3 = document.createElement('button');
        row3.className = 'btn';
        row3.type = 'button';
        row3.textContent = '機能充実版（Chrome拡張）の導入はこちら';
        row3.addEventListener('click', function (e) {
          e.stopPropagation();
          if (D.platform && typeof D.platform.openGuide === 'function') {
            D.platform.openGuide(guideUrl);
          }
        });
        body.appendChild(row3);

        // 行4: 更新を確認リンク
        var row4Wrapper = document.createElement('div');
        row4Wrapper.style.textAlign = 'right';
        var row4 = document.createElement('a');
        row4.className = 'link';
        row4.textContent = '更新を確認';
        row4.addEventListener('click', function (e) {
          e.preventDefault();
          e.stopPropagation();
          if (D.platform && typeof D.platform.openGuide === 'function') {
            D.platform.openGuide(guideUrl);
          }
        });
        row4Wrapper.appendChild(row4);
        body.appendChild(row4Wrapper);
      }

      panel.appendChild(body);

      // 開閉トグル処理
      var isFolded = false;
      header.addEventListener('click', function () {
        isFolded = !isFolded;
        if (isFolded) {
          body.classList.add('collapsed');
          toggleSpan.textContent = '▼';
        } else {
          body.classList.remove('collapsed');
          toggleSpan.textContent = '▲';
        }
      });

      shadow.appendChild(panel);
      document.body.appendChild(host);
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);