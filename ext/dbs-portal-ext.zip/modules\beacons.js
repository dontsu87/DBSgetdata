/**
 * DBSEXT ビーコン一覧モジュール
 * エリア内ポート割当済みビーコンの一覧取得、サイドバーの「ビーコン情報」リンク追加、
 * `/beacons` 画面での拡張所有パネル描画とデータ表示を担当する。
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var CACHE_TTL_MS = 5 * 60 * 1000; // 5分
  var cacheMap = Object.create(null); // areaId -> { rows, portCount, failedPortCount, timestamp }
  var latestGenerationByArea = Object.create(null);
  var isFetching = false;
  var currentGeneration = 0;
  var activeRequest = null;

  /**
   * ポータルID（areaId, portId等）の検証
   */
  function isValidPortalId(value) {
    return typeof value === 'string' && value.length >= 1 && value.length <= 256 && /^[A-Za-z0-9:_-]+$/.test(value);
  }

  /**
   * ビーコン種別の日本語変換
   */
  function formatBeaconType(type) {
    if (type === 'BLE_BEACON') return 'BLEビーコン';
    if (type === 'BLE_BEACON_VARIABLE_OUTPUT') return 'BLEビーコン出力可変版';
    if (type === 'WEAK_BEACON') return '微弱ビーコン';
    if (type === 'IOT_BEACON') return 'OMNIビーコン';
    return type || '';
  }

  /**
   * 重複除去: portBeaconId を優先キーとし、無ければ portId + portBeaconUniqueCode
   * Set や Object.create(null) を使用し、衝突を防ぐ長さprefix付きで管理
   */
  function dedupeBeacons(rows) {
    if (!Array.isArray(rows)) return [];
    var seen = Object.create(null);
    var result = [];
    for (var i = 0; i < rows.length; i++) {
      var item = rows[i];
      if (!item) continue;
      var key = null;
      if (item.portBeaconId) {
        var bId = String(item.portBeaconId);
        key = 'id:' + bId.length + ':' + bId;
      } else if (item.portId && item.portBeaconUniqueCode) {
        var pId = String(item.portId);
        var uCode = String(item.portBeaconUniqueCode);
        key = 'fb:' + pId.length + ':' + pId + ':' + uCode.length + ':' + uCode;
      }
      if (!key) {
        result.push(item);
        continue;
      }
      if (!seen[key]) {
        seen[key] = true;
        result.push(item);
      }
    }
    return result;
  }

  /**
   * 並べ替え: ポート識別番号を数値自然順、その後ビーコン識別番号順
   */
  function sortBeacons(rows) {
    return rows.slice().sort(function (a, b) {
      var portA = String(a.portUniqueCode || '');
      var portB = String(b.portUniqueCode || '');
      var cmpPort = portA.localeCompare(portB, undefined, { numeric: true, sensitivity: 'base' });
      if (cmpPort !== 0) return cmpPort;

      var beaconA = String(a.portBeaconUniqueCode || a.portBeaconId || '');
      var beaconB = String(b.portBeaconUniqueCode || b.portBeaconId || '');
      return beaconA.localeCompare(beaconB, undefined, { numeric: true, sensitivity: 'base' });
    });
  }

  /**
   * URLからselected-area-idを取得する（例外安全な検証済みIDのみを返却）
   */
  function getSelectedAreaId() {
    if (typeof location === 'undefined' || !location.search) return null;
    var match = location.search.match(/[?&]selected-area-id=([^&]+)/);
    if (!match) return null;
    try {
      var decoded = decodeURIComponent(match[1]);
      if (isValidPortalId(decoded)) {
        return decoded;
      }
    } catch (e) {
      // 不正な percent encoding など例外時は null
    }
    return null;
  }

  /**
   * パネルがDOMに接続されており、指定areaIdの画面と一致するか検証
   */
  function isPanelConnected(panel, areaId) {
    if (typeof document === 'undefined' || !panel) return false;
    if (typeof panel.isConnected === 'boolean' && !panel.isConnected) return false;
    var root = panel;
    while (root.parentNode) root = root.parentNode;
    if (root !== document) return false;
    return getSelectedAreaId() === areaId;
  }

  /**
   * 後付けリンクをポータルのSPA遷移へ載せ、ブックマークレットを維持する。
   * 修飾キー付きクリックはブラウザ標準（別タブ等）へ委ねる。
   */
  function bindSidebarNavigation(anchor) {
    if (!anchor || anchor.__dbsextBeaconSpaBound) return;
    anchor.__dbsextBeaconSpaBound = true;

    anchor.addEventListener('click', function (event) {
      if (event && (event.button > 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey)) {
        return;
      }
      if (!global.history || typeof global.history.pushState !== 'function') return;

      var href = anchor.getAttribute('href');
      if (!href || href.charAt(0) !== '/') return;
      if (event && typeof event.preventDefault === 'function') event.preventDefault();

      global.history.pushState({}, '', href);
      if (typeof global.dispatchEvent === 'function') {
        var popEvent = null;
        try {
          if (typeof global.PopStateEvent === 'function') {
            popEvent = new global.PopStateEvent('popstate', { state: {} });
          } else if (typeof global.Event === 'function') {
            popEvent = new global.Event('popstate');
          }
        } catch (e) {
          popEvent = null;
        }
        if (popEvent) global.dispatchEvent(popEvent);
      }

      // ルーター描画は非同期のため、直後とMutationObserverの両方で再適用する。
      global.setTimeout(function () {
        if (D.beacons && typeof D.beacons.apply === 'function') D.beacons.apply();
      }, 0);
    });
  }

  /**
   * サイドバーへ「ビーコン情報」リンクを追加・更新
   */
  function injectSidebarMenu() {
    if (typeof document === 'undefined') return;

    var selectedAreaId = getSelectedAreaId();
    var targetHref = '/beacons' + (selectedAreaId ? '?selected-area-id=' + encodeURIComponent(selectedAreaId) : '');
    var isBeaconsPage = /^\/beacons(\/|$)/.test(location.pathname);

    var existing = document.querySelector('[data-dbsext-beacons-link="1"]');

    if (existing) {
      var existingAnchor = existing.querySelector('a') || existing;
      existingAnchor.setAttribute('href', targetHref);
      bindSidebarNavigation(existingAnchor);

      if (isBeaconsPage) {
        existing.classList.add('bg-primary', 'text-white');
        existing.classList.remove('text-primary');
        existingAnchor.classList.add('router-link-active', 'router-link-exact-active');
      } else {
        existing.classList.remove('bg-primary', 'text-white');
        existing.classList.add('text-primary');
        existingAnchor.classList.remove('router-link-active', 'router-link-exact-active');
      }
      return;
    }

    var portAnchor = document.querySelector('a[href="/ports"], a[href^="/ports?"]');
    if (!portAnchor) return;

    var portItem = (typeof portAnchor.closest === 'function' && portAnchor.closest('.menu > *')) ||
                   portAnchor.parentElement || portAnchor;
    if (!portItem || !portItem.parentNode) return;

    var newItem = portItem.cloneNode(false);
    newItem.setAttribute('data-dbsext-beacons-link', '1');
    if (newItem.removeAttribute) newItem.removeAttribute('id');

    var newAnchor = document.createElement('a');
    newAnchor.setAttribute('data-dbsext-beacons-link-a', '1');
    newAnchor.setAttribute('href', targetHref);
    newAnchor.textContent = 'ビーコン情報';
    bindSidebarNavigation(newAnchor);

    if (portAnchor.className) {
      newAnchor.className = portAnchor.className.replace(/router-link-[^\s]+/g, '').trim();
    }

    if (isBeaconsPage) {
      newItem.classList.add('bg-primary', 'text-white');
      newItem.classList.remove('text-primary');
      newAnchor.classList.add('router-link-active', 'router-link-exact-active');
    } else {
      newItem.classList.remove('bg-primary', 'text-white');
      newItem.classList.add('text-primary');
      newAnchor.classList.remove('router-link-active', 'router-link-exact-active');
    }

    newItem.appendChild(newAnchor);
    portItem.parentNode.insertBefore(newItem, portItem.nextSibling);
  }

  /**
   * 見出しと.el-tableの最小共通祖先（本文コンテナ）を探索し、見出しラッパーの直後を挿入位置として返す
   */
  function findInsertionPoint() {
    if (typeof document === 'undefined') return null;

    var heading = null;
    var candidates = document.querySelectorAll('p, h1, h2, h3');
    for (var i = 0; i < candidates.length; i++) {
      var txt = (candidates[i].textContent || '').replace(/[\s\u3000]+/g, ' ').trim();
      if (txt === 'ビーコン情報 一覧') {
        heading = candidates[i];
        break;
      }
    }
    if (!heading) return null;

    var portalTable = document.querySelector('.el-table:not([data-dbsext-beacons-table])');
    if (!portalTable) return null;

    var ancestorsH = [];
    var cur = heading;
    while (cur && cur !== document.body && cur !== document.documentElement) {
      ancestorsH.push(cur);
      cur = cur.parentNode;
    }

    var ancestorsT = [];
    cur = portalTable;
    while (cur && cur !== document.body && cur !== document.documentElement) {
      ancestorsT.push(cur);
      cur = cur.parentNode;
    }

    var mainContainer = null;
    var headingWrapper = null;

    for (var h = 0; h < ancestorsH.length; h++) {
      var nodeH = ancestorsH[h];
      for (var t = 0; t < ancestorsT.length; t++) {
        if (nodeH === ancestorsT[t]) {
          mainContainer = nodeH;
          headingWrapper = (h > 0) ? ancestorsH[h - 1] : heading;
          break;
        }
      }
      if (mainContainer) break;
    }

    if (!mainContainer || mainContainer === document.body || (mainContainer.id && mainContainer.id === '__nuxt')) {
      return null;
    }

    return {
      container: mainContainer,
      targetSibling: headingWrapper ? headingWrapper.nextSibling : null
    };
  }

  /**
   * `/beacons` 画面に拡張所有パネルを描画・更新
   */
  function renderPanel() {
    if (typeof document === 'undefined') return;
    if (!/^\/beacons(\/|$)/.test(location.pathname)) {
      var stalePanels = document.querySelectorAll('[data-dbsext-beacons-panel="1"]');
      if (stalePanels.length > 0) {
        currentGeneration++;
        isFetching = false;
        activeRequest = null;
      }
      for (var sp = 0; sp < stalePanels.length; sp++) {
        if (stalePanels[sp].parentNode) {
          stalePanels[sp].parentNode.removeChild(stalePanels[sp]); // dbsext:own-ui
        }
      }
      return;
    }

    var existingPanel = document.querySelector('[data-dbsext-beacons-panel="1"]');
    var selectedAreaId = getSelectedAreaId();

    // Vue が同じURLのまま本文を差し替えると、取得開始時のパネルだけが
    // DOM から外れ、新しいパネルを作り直す場合がある。切断済みパネルの
    // リクエストを現行パネルへ誤って引き継がない。
    if (!existingPanel && activeRequest &&
        !isPanelConnected(activeRequest.panel, activeRequest.areaId)) {
      currentGeneration++;
      isFetching = false;
      activeRequest = null;
    }

    if (existingPanel) {
      var prevArea = existingPanel.getAttribute('data-dbsext-beacons-area');
      var currentAreaAttr = selectedAreaId || '';
      if (prevArea !== currentAreaAttr) {
        if (selectedAreaId) {
          existingPanel.setAttribute('data-dbsext-beacons-area', selectedAreaId);
        } else {
          existingPanel.removeAttribute('data-dbsext-beacons-area');
        }
        currentGeneration++;
        isFetching = false;
        activeRequest = null;

        var statusDiv = existingPanel.querySelector('[data-dbsext-beacons-status="1"]');
        var tableWrap = existingPanel.querySelector('.dbsext-beacons-table-wrap');
        if (statusDiv) {
          while (statusDiv.firstChild) statusDiv.removeChild(statusDiv.firstChild); // dbsext:own-ui
          statusDiv.textContent = '';
          statusDiv.className = '';
        }
        if (tableWrap) {
          while (tableWrap.firstChild) tableWrap.removeChild(tableWrap.firstChild); // dbsext:own-ui
        }
      }
      updatePanelState(existingPanel, selectedAreaId);
      return;
    }

    var insertion = findInsertionPoint();
    if (!insertion || !insertion.container) return;

    var panel = document.createElement('div');
    panel.setAttribute('data-dbsext-beacons-panel', '1');
    if (selectedAreaId) {
      panel.setAttribute('data-dbsext-beacons-area', selectedAreaId);
    }

    var h2 = document.createElement('h2');
    h2.textContent = 'エリア内ビーコン一覧（拡張）';
    panel.appendChild(h2);

    var actionsDiv = document.createElement('div');
    actionsDiv.className = 'dbsext-beacons-actions';

    var btn = document.createElement('button');
    btn.setAttribute('data-dbsext-beacons-btn', '1');
    btn.className = 'dbsext-btn';
    btn.textContent = '一覧を取得';

    btn.addEventListener('click', function () {
      handleFetchClick(panel);
    });

    actionsDiv.appendChild(btn);
    panel.appendChild(actionsDiv);

    var statusDiv = document.createElement('div');
    statusDiv.setAttribute('data-dbsext-beacons-status', '1');
    panel.appendChild(statusDiv);

    var tableWrap = document.createElement('div');
    tableWrap.className = 'dbsext-beacons-table-wrap';
    panel.appendChild(tableWrap);

    if (insertion.targetSibling) {
      insertion.container.insertBefore(panel, insertion.targetSibling);
    } else {
      insertion.container.appendChild(panel);
    }

    updatePanelState(panel, selectedAreaId);
  }

  /**
   * パネルのボタン状態と状態メッセージを更新
   */
  function updatePanelState(panel, selectedAreaId) {
    var btn = panel.querySelector('[data-dbsext-beacons-btn="1"]');
    var statusDiv = panel.querySelector('[data-dbsext-beacons-status="1"]');
    if (!btn || !statusDiv) return;

    var panelIsFetching = !!(isFetching && activeRequest &&
      activeRequest.panel === panel && activeRequest.areaId === selectedAreaId);
    if (panelIsFetching) {
      btn.disabled = true;
      btn.textContent = '取得中...';
      return;
    }

    btn.textContent = '一覧を取得';
    if (!selectedAreaId) {
      btn.disabled = true;
      statusDiv.textContent = 'エリアを選択してください';
      statusDiv.className = 'dbsext-beacons-warn';
    } else {
      btn.disabled = false;
      if (statusDiv.textContent === 'エリアを選択してください') {
        statusDiv.textContent = '';
        statusDiv.className = '';
      }
    }
  }

  /**
   * 一覧取得ボタンのクリックハンドラ
   */
  function handleFetchClick(panel) {
    var selectedAreaId = getSelectedAreaId();
    if (!selectedAreaId || isFetching) return;

    currentGeneration++;
    var gen = currentGeneration;
    latestGenerationByArea[selectedAreaId] = gen;
    activeRequest = { generation: gen, areaId: selectedAreaId, panel: panel };

    var statusDiv = panel.querySelector('[data-dbsext-beacons-status="1"]');
    var tableWrap = panel.querySelector('.dbsext-beacons-table-wrap');

    isFetching = true;
    updatePanelState(panel, selectedAreaId);

    var now = Date.now();
    var cached = cacheMap[selectedAreaId];
    if (cached && (now - cached.timestamp < CACHE_TTL_MS)) {
      isFetching = false;
      activeRequest = null;
      if (gen === currentGeneration && isPanelConnected(panel, selectedAreaId)) {
        renderTableData(panel, cached.rows, cached.portCount, cached.failedPortCount);
        updatePanelState(panel, selectedAreaId);
      }
      return;
    }

    if (!D.platform || typeof D.platform.fetchBeaconsByArea !== 'function') {
      isFetching = false;
      activeRequest = null;
      if (gen === currentGeneration && isPanelConnected(panel, selectedAreaId)) {
        statusDiv.textContent = 'D.platform.fetchBeaconsByArea が利用できません';
        statusDiv.className = 'dbsext-beacons-error';
        updatePanelState(panel, selectedAreaId);
      }
      return;
    }

    D.platform.fetchBeaconsByArea(selectedAreaId)
      .then(function (result) {
        var res = result || { rows: [], portCount: 0, failedPortCount: 0 };
        // A1 → B → A2 の順に開始し、A2 より後で古い A1 が完了しても、
        // A2 の新しいキャッシュを上書きさせない。
        if (latestGenerationByArea[selectedAreaId] === gen) {
          cacheMap[selectedAreaId] = {
            rows: res.rows || [],
            portCount: res.portCount || 0,
            failedPortCount: res.failedPortCount || 0,
            timestamp: Date.now()
          };
        }
        if (activeRequest && activeRequest.generation === gen) {
          isFetching = false;
          activeRequest = null;
        }
        if (gen === currentGeneration && isPanelConnected(panel, selectedAreaId)) {
          renderTableData(panel, res.rows || [], res.portCount || 0, res.failedPortCount || 0);
          updatePanelState(panel, selectedAreaId);
        }
      })
      .catch(function (err) {
        if (activeRequest && activeRequest.generation === gen) {
          isFetching = false;
          activeRequest = null;
        }
        if (gen === currentGeneration && isPanelConnected(panel, selectedAreaId)) {
          var msg = (err && err.message) ? err.message : String(err);
          statusDiv.textContent = 'ビーコン一覧の取得に失敗しました: ' + msg;
          statusDiv.className = 'dbsext-beacons-error';
          if (tableWrap) {
            while (tableWrap.firstChild) tableWrap.removeChild(tableWrap.firstChild); // dbsext:own-ui
          }
          updatePanelState(panel, selectedAreaId);
        }
      });
  }

  /**
   * 取得結果データからテーブル・警告の表示を行う（XSS対策: textContent で挿入）
   */
  function renderTableData(panel, rawRows, portCount, failedPortCount) {
    var statusDiv = panel.querySelector('[data-dbsext-beacons-status="1"]');
    var tableWrap = panel.querySelector('.dbsext-beacons-table-wrap');
    if (!statusDiv || !tableWrap) return;

    // 前回の表示をクリア // dbsext:own-ui
    while (statusDiv.firstChild) {
      statusDiv.removeChild(statusDiv.firstChild); // dbsext:own-ui
    }
    while (tableWrap.firstChild) {
      tableWrap.removeChild(tableWrap.firstChild); // dbsext:own-ui
    }

    if (failedPortCount > 0) {
      statusDiv.textContent = '一部のポート（' + failedPortCount + '件）の取得に失敗しました。';
      statusDiv.className = 'dbsext-beacons-warn';
    } else {
      statusDiv.textContent = '';
      statusDiv.className = '';
    }

    var deduped = dedupeBeacons(rawRows);
    var sorted = sortBeacons(deduped);

    if (sorted.length === 0) {
      if (failedPortCount === 0) {
        statusDiv.textContent = '対象エリア内にポート割当済みビーコンはありません。';
        statusDiv.className = '';
      }
      return;
    }

    var table = document.createElement('table');
    table.setAttribute('data-dbsext-beacons-table', '1');

    var thead = document.createElement('thead');
    var headerRow = document.createElement('tr');
    var tbody = document.createElement('tbody');

    var columns = [
      { label: 'ビーコン識別番号', value: function (item) { return item.portBeaconUniqueCode || item.portBeaconId || ''; } },
      { label: 'ビーコン種別', value: function (item) { return formatBeaconType(item.beaconType); } },
      { label: 'ポート識別番号', value: function (item) { return item.portUniqueCode || ''; } },
      { label: 'ポート名', value: function (item) { return item.portNameJa || ''; } },
      { label: 'ビーコン電圧', value: function (item) {
        var val = item.portBeaconElectricVoltage;
        return (val !== null && val !== undefined && val !== '') ? String(val) : 'ー';
      } },
      { label: 'ビーコンバッテリー残量[%]', value: function (item) {
        var val = item.batteryRemainingAmount;
        return (val !== null && val !== undefined && val !== '') ? String(val) : 'ー';
      } },
      { label: '最終受信日時', value: function (item) { return item.lastReceivedTs || ''; } }
    ];
    var filters = [];
    var sortButtons = [];
    var sortColumn = -1;
    var sortDirection = 1;

    function updateSortLabels() {
      for (var i = 0; i < sortButtons.length; i++) {
        var suffix = '';
        if (i === sortColumn) suffix = sortDirection === 1 ? ' ▲' : ' ▼';
        sortButtons[i].textContent = columns[i].label + suffix;
      }
    }

    function renderVisibleRows() {
      while (tbody.firstChild) tbody.removeChild(tbody.firstChild); // dbsext:own-ui

      var indexed = [];
      for (var i = 0; i < sorted.length; i++) {
        var matches = true;
        for (var f = 0; f < columns.length; f++) {
          var needle = String(filters[f].value || '').toLocaleLowerCase();
          if (needle && String(columns[f].value(sorted[i])).toLocaleLowerCase().indexOf(needle) === -1) {
            matches = false;
            break;
          }
        }
        if (matches) indexed.push({ item: sorted[i], originalIndex: i });
      }

      if (sortColumn >= 0) {
        indexed.sort(function (a, b) {
          var valueA = String(columns[sortColumn].value(a.item));
          var valueB = String(columns[sortColumn].value(b.item));
          var cmp = valueA.localeCompare(valueB, undefined, { numeric: true, sensitivity: 'base' });
          if (cmp === 0) cmp = a.originalIndex - b.originalIndex;
          return cmp * sortDirection;
        });
      }

      if (indexed.length === 0) {
        var emptyRow = document.createElement('tr');
        var emptyCell = document.createElement('td');
        emptyCell.setAttribute('colspan', String(columns.length));
        emptyCell.className = 'dbsext-beacons-empty';
        emptyCell.textContent = '絞り込み条件に一致するビーコンはありません。';
        emptyRow.appendChild(emptyCell);
        tbody.appendChild(emptyRow);
        return;
      }

      for (var r = 0; r < indexed.length; r++) {
        var tr = document.createElement('tr');
        for (var c = 0; c < columns.length; c++) {
          var td = document.createElement('td');
          td.textContent = columns[c].value(indexed[r].item);
          tr.appendChild(td);
        }
        tbody.appendChild(tr);
      }
    }

    for (var h = 0; h < columns.length; h++) {
      (function (columnIndex) {
        var th = document.createElement('th');
        var sortButton = document.createElement('button');
        sortButton.setAttribute('type', 'button');
        sortButton.className = 'dbsext-beacons-sort';
        sortButton.setAttribute('title', 'クリックで並べ替え');
        sortButton.addEventListener('click', function () {
          if (sortColumn === columnIndex) {
            sortDirection = sortDirection * -1;
          } else {
            sortColumn = columnIndex;
            sortDirection = 1;
          }
          updateSortLabels();
          renderVisibleRows();
        });
        sortButtons.push(sortButton);
        th.appendChild(sortButton);

        var filterInput = document.createElement('input');
        filterInput.setAttribute('type', 'text');
        filterInput.className = 'dbsext-beacons-filter';
        filterInput.setAttribute('placeholder', '絞り込み');
        filterInput.setAttribute('aria-label', columns[columnIndex].label + 'で絞り込み');
        filterInput.addEventListener('input', function () {
          renderVisibleRows();
        });
        filters.push(filterInput);
        th.appendChild(filterInput);
        headerRow.appendChild(th);
      })(h);
    }
    updateSortLabels();
    thead.appendChild(headerRow);
    table.appendChild(thead);
    table.appendChild(tbody);
    tableWrap.appendChild(table);
    renderVisibleRows();
  }

  D.beacons = {
    apply: function () {
      if (typeof document === 'undefined' || !document.body) return;
      injectSidebarMenu();
      renderPanel();
    },

    // テスト用の内部状態アクセス
    _clearCache: function () {
      cacheMap = Object.create(null);
      latestGenerationByArea = Object.create(null);
      isFetching = false;
      currentGeneration = 0;
      activeRequest = null;
    },
    _getCache: function () {
      return cacheMap;
    },
    _isValidPortalId: isValidPortalId,
    _formatBeaconType: formatBeaconType,
    _dedupeBeacons: dedupeBeacons,
    _sortBeacons: sortBeacons
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
