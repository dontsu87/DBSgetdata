/**
 * DBSEXT 通信ステータス MAIN-world 傍受スクリプト
 *
 * ポータルが動く MAIN ワールドで fetch / XHR をラップし、
 * 通信の開始・終了を DOM カスタムイベントとして発火する。
 * ISOLATED / USER_SCRIPT ワールドの net-status.js はこれを購読して
 * 「読み込み中…」マスクの表示・非表示を行う。
 *
 * このファイルは極力薄く保ち、UI生成・タイミング制御・エラー表示は
 * すべて net-status.js 側に任せる。
 *
 * 置き場所:
 *   - manifest.json content_scripts (world: "MAIN") → 同梱版フォールバック
 *   - remote-updater.js が登録する MAIN-world user script → リモート配信版
 */
(function () {
  'use strict';

  if (typeof window === 'undefined') return;
  if (typeof document === 'undefined') return;

  var EVENT_PREFIX = 'dbsext:main-fetch';

  function dispatch(name, detail) {
    try {
      var event = new CustomEvent(EVENT_PREFIX + '-' + name, {
        detail: detail || {},
        bubbles: false
      });
      document.dispatchEvent(event);
    } catch (e) {
      // document が使えない環境では何もしない
    }
  }

  // ---- fetch のラップ ----

  if (window.fetch && !window.fetch.__dbsext_main_wrapped) {
    var _origFetch = window.fetch;

    window.fetch = function (input, init) {
      var url = '';
      try {
        if (typeof input === 'string') {
          url = input;
        } else if (input && typeof input.url === 'string') {
          url = input.url;
        }
      } catch (e) {}

      // ポータル自身（同origin）の通信だけを対象にする。
      // 拡張による chrome-extension:// や外部CDNの通信は対象外。
      var isPortal = url.indexOf('https://mg.docomo-cycle.jp/') === 0 ||
                     url.indexOf('/') === 0;

      if (isPortal) dispatch('start');

      var promise;
      try {
        promise = _origFetch.apply(this, arguments);
      } catch (err) {
        if (isPortal) dispatch('end', { status: 0, error: true });
        throw err;
      }

      return promise.then(
        function (res) {
          if (isPortal) dispatch('end', { status: res ? res.status : 0 });
          return res;
        },
        function (err) {
          if (isPortal) dispatch('end', { status: 0, error: true });
          return Promise.reject(err);
        }
      );
    };

    window.fetch.__dbsext_main_wrapped = true;
  }

  // ---- XMLHttpRequest のラップ ----

  if (typeof XMLHttpRequest !== 'undefined' &&
      XMLHttpRequest.prototype &&
      XMLHttpRequest.prototype.send &&
      !XMLHttpRequest.prototype.send.__dbsext_main_wrapped) {

    var _origSend = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.send = function () {
      var xhr = this;
      var isPortal = false;

      try {
        var rawUrl = '';
        try {
          rawUrl = (typeof xhr._dbsext_url === 'string') ? xhr._dbsext_url : '';
        } catch (e) {}
        isPortal = rawUrl.indexOf('https://mg.docomo-cycle.jp/') === 0 ||
                   (rawUrl.indexOf('/') === 0 && rawUrl.indexOf('//') !== 0);
      } catch (e) {}

      if (isPortal) dispatch('start');

      var onEnd = function () {
        xhr.removeEventListener('loadend', onEnd);
        if (isPortal) dispatch('end', { status: xhr.status });
      };
      xhr.addEventListener('loadend', onEnd);

      try {
        return _origSend.apply(this, arguments);
      } catch (err) {
        xhr.removeEventListener('loadend', onEnd);
        if (isPortal) dispatch('end', { status: 0, error: true });
        throw err;
      }
    };

    XMLHttpRequest.prototype.send.__dbsext_main_wrapped = true;

    // XHR の open() もラップして URL を保存する。
    if (XMLHttpRequest.prototype.open &&
        !XMLHttpRequest.prototype.open.__dbsext_main_wrapped) {
      var _origOpen = XMLHttpRequest.prototype.open;
      XMLHttpRequest.prototype.open = function (method, url) {
        try { this._dbsext_url = String(url || ''); } catch (e) {}
        return _origOpen.apply(this, arguments);
      };
      XMLHttpRequest.prototype.open.__dbsext_main_wrapped = true;
    }
  }
})();