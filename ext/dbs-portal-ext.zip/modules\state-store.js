/**
 * DBSEXT 入力状態キャッシュ基盤モジュール
 * localStorage / sessionStorage を用いた状態の安全な保存・復元・管理を担当
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var SCHEMA_VERSION = 1;
  var KEY_PREFIX = 'dbsext:v' + SCHEMA_VERSION + ':';
  var DEFAULT_TTL_MS = 8 * 60 * 60 * 1000; // 既定は8時間（1営業日想定: 28800000ms）
  var MAX_VALUE_BYTES = 32 * 1024; // 1キーあたり32KB上限

  function getStorage(scope) {
    if (typeof window === 'undefined') return null;
    try {
      if (scope === 'local') {
        return window.localStorage;
      }
      return window.sessionStorage;
    } catch (e) {
      return null;
    }
  }

  /**
   * screen パスの正規化
   * 例: /users/123 -> /users
   */
  function normalizeScreen(screen) {
    if (!screen || typeof screen !== 'string') {
      if (typeof location !== 'undefined' && location.pathname) {
        screen = location.pathname;
      } else {
        screen = '/';
      }
    }
    // 先頭スラッシュを付与
    if (screen.charAt(0) !== '/') {
      screen = '/' + screen;
    }
    // 連続スラッシュを単一化
    screen = screen.replace(/\/+/g, '/');
    // クエリやハッシュを除去
    screen = screen.split('?')[0].split('#')[0];
    // 末尾の数値IDやUUIDセグメントを除去 (/users/123 -> /users)
    screen = screen.replace(/\/([0-9]+|[0-9a-fA-F-]{36})$/, '');
    // 末尾スラッシュ除去（ルート '/' 単体は保持）
    if (screen.length > 1 && screen.charAt(screen.length - 1) === '/') {
      screen = screen.slice(0, -1);
    }
    return screen || '/';
  }

  function buildKey(screen, feature) {
    var normScreen = normalizeScreen(screen);
    return KEY_PREFIX + normScreen + ':' + (feature || '');
  }

  D.stateStore = {
    SCHEMA_VERSION: SCHEMA_VERSION,
    DEFAULT_TTL_MS: DEFAULT_TTL_MS,
    MAX_VALUE_BYTES: MAX_VALUE_BYTES,
    normalizeScreen: normalizeScreen,

    /**
     * 値を保存する
     * @param {string} screen 対象画面パス
     * @param {string} feature 機能・項目名
     * @param {*} value 保存する値
     * @param {Object} [opts] { scope: 'session'|'local', ttlMs: number }
     * @returns {boolean} 保存成功なら true
     */
    save: function (screen, feature, value, opts) {
      opts = opts || {};
      var scope = opts.scope || 'session'; // 既定は session
      var ttlMs = (typeof opts.ttlMs === 'number' && opts.ttlMs > 0) ? opts.ttlMs : DEFAULT_TTL_MS;
      var storage = getStorage(scope);
      if (!storage) return false;

      var key = buildKey(screen, feature);
      var record = {
        v: SCHEMA_VERSION,
        at: Date.now(),
        ttl: ttlMs,
        data: value
      };

      try {
        var json = JSON.stringify(record);
        var size = (typeof Blob !== 'undefined') ? new Blob([json]).size : json.length;
        if (size > MAX_VALUE_BYTES) {
          if (D.core && typeof D.core.log === 'function') {
            D.core.log('stateStore.save: 32KB超過のため保存をスキップしました: ' + key + ' (' + size + ' bytes)', true);
          }
          return false;
        }
        storage.setItem(key, json);
        return true;
      } catch (e) {
        if (D.core && typeof D.core.log === 'function') {
          D.core.log('stateStore.save エラー: ' + (e && e.message ? e.message : e), true);
        }
        return false;
      }
    },

    /**
     * 保存された値を読み出す（期限切れ・版違い・壊れたJSONは null を返し、キーも削除）
     * @param {string} screen 対象画面パス
     * @param {string} feature 機能・項目名
     * @returns {*} 保存された値、または null
     */
    load: function (screen, feature) {
      var key = buildKey(screen, feature);
      var storages = [getStorage('session'), getStorage('local')];

      for (var i = 0; i < storages.length; i++) {
        var storage = storages[i];
        if (!storage) continue;

        try {
          var raw = storage.getItem(key);
          if (raw === null || raw === undefined) continue;

          var obj;
          try {
            obj = JSON.parse(raw);
          } catch (jsonErr) {
            // 壊れたJSONは削除して null
            try { storage.removeItem(key); } catch (e) {}
            continue;
          }

          if (!obj || typeof obj !== 'object') {
            try { storage.removeItem(key); } catch (e) {}
            continue;
          }

          // 版違い判定
          if (obj.v !== SCHEMA_VERSION) {
            try { storage.removeItem(key); } catch (e) {}
            return null;
          }

          // 期限切れ判定
          var now = Date.now();
          var at = typeof obj.at === 'number' ? obj.at : 0;
          var ttl = typeof obj.ttl === 'number' ? obj.ttl : DEFAULT_TTL_MS;
          if (now > at + ttl) {
            try { storage.removeItem(key); } catch (e) {}
            return null;
          }

          return obj.data;
        } catch (e) {
          // ストレージ例外時は null
          return null;
        }
      }
      return null;
    },

    /**
     * 特定の画面・項目の保存内容を削除する
     */
    clear: function (screen, feature) {
      var key = buildKey(screen, feature);
      var storages = [getStorage('session'), getStorage('local')];
      for (var i = 0; i < storages.length; i++) {
        var storage = storages[i];
        if (!storage) continue;
        try {
          storage.removeItem(key);
        } catch (e) {}
      }
    },

    /**
     * dbsext: で始まるすべてのキーを削除する（他人のキーは消さない）
     */
    clearAll: function () {
      var storages = [getStorage('session'), getStorage('local')];
      for (var i = 0; i < storages.length; i++) {
        var storage = storages[i];
        if (!storage) continue;
        try {
          var keysToRemove = [];
          for (var j = 0; j < storage.length; j++) {
            var k = storage.key(j);
            if (k && k.indexOf('dbsext:') === 0) {
              keysToRemove.push(k);
            }
          }
          for (var m = 0; m < keysToRemove.length; m++) {
            storage.removeItem(keysToRemove[m]);
          }
        } catch (e) {}
      }
    },

    /**
     * 保存されている dbsext:* の全一覧を返す
     * @returns {Array<Object>}
     */
    list: function () {
      var result = [];
      var storages = [
        { name: 'session', store: getStorage('session') },
        { name: 'local', store: getStorage('local') }
      ];

      for (var i = 0; i < storages.length; i++) {
        var item = storages[i];
        var storage = item.store;
        if (!storage) continue;
        try {
          for (var j = 0; j < storage.length; j++) {
            var key = storage.key(j);
            if (key && key.indexOf('dbsext:') === 0) {
              var raw = storage.getItem(key);
              var parsed = null;
              try {
                parsed = JSON.parse(raw);
              } catch (e) {}

              var parts = key.split(':');
              var screen = parts[2] || '';
              var feature = parts.slice(3).join(':');

              result.push({
                storage: item.name,
                key: key,
                screen: screen,
                feature: feature,
                v: parsed && parsed.v !== undefined ? parsed.v : null,
                at: parsed && parsed.at !== undefined ? parsed.at : null,
                ttl: parsed && parsed.ttl !== undefined ? parsed.ttl : null,
                data: parsed && parsed.data !== undefined ? parsed.data : null
              });
            }
          }
        } catch (e) {}
      }
      return result;
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
