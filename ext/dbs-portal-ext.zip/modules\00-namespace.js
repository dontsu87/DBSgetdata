/**
 * DBSEXT 名前空間および設定定義
 * モジュール契約 §1, §2 に基づく基盤定義
 */
(function (global) {
  'use strict';

  global.DBSEXT = global.DBSEXT || {};
  var D = global.DBSEXT;

  D.VERSION = '0.1.0';

  D.CONFIG = {
    PORTAL_ORIGIN: 'https://mg.docomo-cycle.jp',
    MAP_APP_URL:   'https://dontsu87.github.io/DBSgetdata/',
    GUIDE_URL:     'https://dontsu87.github.io/DBSgetdata/ext/',
    ACCENT:        '#0b5cab',   // 拡張適用中を示す青
    ACCENT_DARK:   '#083f75',
    // マップアプリが知っている全エリア。これらを全部持っていれば ?kanriall を使う
    KNOWN_AREAS: ['金沢', '福井', '小松', '敦賀', '上田千曲広域', '出雲・松江・境港'],
    MARKER_ATTR: 'data-dbsext'   // 冪等ガードに使う body の属性
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
