/**
 * DBSEXT UI微調整モジュール
 *
 * - 戻るボタン: 隠さず、「1個前の画面へ戻る」挙動に差し替える
 * - 折りたたみセクション: 既定で閉じる（ただし ユーザ情報 `/users` は対象外）
 * - ページサイズ: 車両情報 `/vehicles` で最大（500）を自動選択する
 *
 * 契約（docs/06-module-contract.md §6）の遵守:
 *   setInterval を使わない / ポータルの既存DOMを削除・移動しない /
 *   更新系リクエストを発行しない
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  // ---------------------------------------------------------------------------
  // 画面の判定
  // ---------------------------------------------------------------------------

  /** ユーザ情報（顧客情報）配下か */
  function isUsersPage() {
    return /^\/users(\/|$)/.test(location.pathname);
  }

  /** 車両情報か */
  function isVehiclesPage() {
    return /^\/vehicles(\/|$)/.test(location.pathname);
  }

  function log(message, isError) {
    if (D.core && typeof D.core.log === 'function') D.core.log(message, isError);
  }

  // ---------------------------------------------------------------------------
  // 1. 戻るボタン — 「1個前の画面」へ戻す
  //
  // 現場の声:
  //   「お客様情報を見ている際、ひとつ前の情報を見たく『戻る』ボタンを押すと
  //     ユーザ情報の最初の画面に戻ってしまいます」
  //
  // ポータルの「戻る」は決まったルートへ飛ぶ作りになっている。そこで
  // クリックを捕まえて history.back() に置き換える。
  //
  // ただし**無条件に置き換えてはいけない**。適用直後にいきなり押されると、
  // ポータルへ来る前のページ（空タブや別サイト）へ戻ってしまう。
  // そこで「拡張を適用してから何回ポータル内を移動したか」を数え、
  // 戻れる残りがあるときだけ history.back() を使う。0 のときはポータル本来の
  // 動きに任せる（＝今までどおり）。
  // ---------------------------------------------------------------------------

  var depth = 0;          // 適用時点から何歩進んでいるか
  var pendingBack = 0;    // 自分が起こした戻りの数（数え直しを防ぐ）
  var lastHref = '';
  var backHooked = false;

  /** URLの変化を観測して depth を更新する。apply() から毎回呼ばれる */
  function noteNavigation() {
    var href = location.href;
    if (lastHref === '') { lastHref = href; return; }
    if (href === lastHref) return;
    lastHref = href;
    if (pendingBack > 0) {
      pendingBack--;
      if (depth > 0) depth--;
    } else {
      depth++;
    }
  }

  function isBackLabel(el) {
    if (!el || !el.textContent) return false;
    return el.textContent.trim() === '戻る';
  }

  /** クリック可能な祖先のうち「戻る」ボタンを探す */
  function findBackButton(start) {
    var el = start;
    for (var hop = 0; el && hop < 6; hop++) {
      var tag = el.tagName;
      var isClickable = tag === 'BUTTON' || tag === 'A' ||
        (el.getAttribute && el.getAttribute('role') === 'button');
      if (isClickable && isBackLabel(el)) return el;
      el = el.parentElement;
    }
    return null;
  }

  function hookBackButtons() {
    if (backHooked || typeof document === 'undefined') return;
    backHooked = true;

    // capture フェーズで捕まえる。ポータル自身のハンドラより先に判断するため。
    document.addEventListener('click', function (event) {
      var button = findBackButton(event.target);
      if (!button) return;
      if (depth <= 0) {
        // 戻り先の履歴が無い。ポータル本来の動きに任せる
        log('戻る: 履歴が無いため既定動作にまかせる');
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === 'function') {
        event.stopImmediatePropagation();
      }
      pendingBack++;
      log('戻る: 1個前の画面へ戻る（残り ' + depth + '）');
      history.back();
    }, true);
  }

  // ---------------------------------------------------------------------------
  // 1b. 一覧のリンクを別タブで開く
  //
  // 現場の要望:
  //   絞り込んだ表から個別の画面へ飛ぶと、戻ったときに絞り込みが消えている。
  //   一覧はそのまま残し、個別画面は別タブで開きたい。
  //
  // **対象は `<a href>` だけに限る。** 表の中には「メンテナンス」「AT管理」「解錠」
  // 「再配置」といった**操作ボタン**が並んでおり、これらを別タブ化するのは危険であるうえ
  // 意味がない。リンク（画面遷移）とボタン（操作）を混同しない。
  //
  // Vue Router の RouterLink は、要素に `target="_blank"` が付いていると
  // 自前のルーティングを行わずブラウザに任せる。したがって属性を足すだけで、
  // クリックを横取りする必要がない（二重に開く事故も起きない）。
  // ---------------------------------------------------------------------------

  function openRowLinksInNewTab() {
    if (typeof document === 'undefined') return;
    var links = document.querySelectorAll('table.el-table__body tbody td a[href]');
    for (var i = 0; i < links.length; i++) {
      var link = links[i];
      if (link.hasAttribute('data-dbsext-newtab')) continue;
      var href = link.getAttribute('href');
      // 同一オリジンの通常リンクだけ。javascript: や外部リンクは触らない
      if (!href || href.charAt(0) !== '/') continue;
      link.setAttribute('data-dbsext-newtab', '1');
      link.setAttribute('target', '_blank');
      link.setAttribute('rel', 'noopener');
      link.title = (link.title ? link.title + ' / ' : '') + '別タブで開きます（一覧は残ります）';
    }
  }

  // ---------------------------------------------------------------------------
  // 2. 折りたたみセクション — 既定で閉じる
  //
  // ユーザ情報（`/users`）では**閉じない**。現場から
  // 「表示条件のデフォルト折りたたみを解除してほしい」との要望があったため。
  // ---------------------------------------------------------------------------

  function collapseSections() {
    if (typeof document === 'undefined') return;
    if (isUsersPage()) return;

    var items = document.querySelectorAll('.el-collapse-item');
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      var header = item.querySelector('.el-collapse-item__header');
      if (!header || header.hasAttribute('data-dbsext-collapsed')) continue;
      header.setAttribute('data-dbsext-collapsed', '1');

      // 開閉できることが見て分かるようにヒントを足す
      if (!header.querySelector('[data-dbsext-collapse-hint]')) {
        var hint = document.createElement('span');
        hint.setAttribute('data-dbsext-collapse-hint', '1');
        hint.textContent = '▼';
        hint.style.cssText = 'font-size:11px;opacity:0.5;margin-left:2px';
        header.appendChild(hint);
      }

      // 開いていればネイティブのクリックで閉じる。
      // クラスを直接操作すると Element Plus の内部状態とずれるため不可。
      if (item.classList.contains('is-active')) {
        header.click();
      }
    }
  }

  // ---------------------------------------------------------------------------
  // 3. ページサイズ — SPA 遷移時に URL パラメータを注入
  //
  // 車両情報の表示件数は URL の `page-size` パラメータで制御されている。
  // 既定の 100 では少なすぎるため、`/vehicles` への遷移を捕まえて
  // `page-size=1000` を自動付与する。
  //
  // location.replace による再読込だとブックマークレットが解除されるため、
  // history.pushState / replaceState をラップして SPA 遷移の URL を
  // 書き換える方式をとる。リロード無しでブックマークレットは生きたまま。
  // ---------------------------------------------------------------------------

  var TARGET_PAGE_SIZE = 1000;
  var psHooked = false;

  function hookPageSize() {
    if (psHooked || typeof history === 'undefined') return;
    psHooked = true;

    var _push = history.pushState;
    var _replace = history.replaceState;

    function patchVehiclesUrl(url) {
      if (typeof url !== 'string') return url;
      if (!/\/vehicles(\?|$|#)/.test(url)) return url;

      var m = url.match(/[?&]page-size=(\d+)/);
      var cur = m ? parseInt(m[1], 10) : 0;

      // upgrade if missing or below target
      if (cur < TARGET_PAGE_SIZE) {
        if (m) {
          url = url.replace(/([?&])page-size=\d+/, '$1page-size=' + TARGET_PAGE_SIZE);
        } else {
          url += (url.indexOf('?') === -1 ? '?' : '&') + 'page-size=' + TARGET_PAGE_SIZE;
        }
      }

      // ensure page=1 is present (missing -> invalid -> fallback to 100)
      if (!/[?&]page=/.test(url)) {
        url += (url.indexOf('?') === -1 ? '?' : '&') + 'page=1';
      }

      return url;
    }

    history.pushState = function (state, title, url) {
      return _push.apply(this, [state, title, patchVehiclesUrl(url)]);
    };
    history.replaceState = function (state, title, url) {
      return _replace.apply(this, [state, title, patchVehiclesUrl(url)]);
    };

    // fallback: already on /vehicles with wrong page-size -> fire replaceState directly
    if (isVehiclesPage() && typeof location !== 'undefined') {
      var m = location.search.match(/[?&]page-size=(\d+)/);
      var cur = m ? parseInt(m[1], 10) : 0;
      if (cur < TARGET_PAGE_SIZE || !/[?&]page=/.test(location.search)) {
        var s = location.search;
        if (m) {
          s = s.replace(/([?&])page-size=\d+/, '$1page-size=' + TARGET_PAGE_SIZE);
        } else {
          s += (s ? '&' : '?') + 'page-size=' + TARGET_PAGE_SIZE;
        }
        if (!/[?&]page=/.test(s)) {
          s += (s ? '&' : '?') + 'page=1';
        }
        _replace.call(history, null, '', location.pathname + s + location.hash);
        log('表示件数を ' + TARGET_PAGE_SIZE + ' に変更（replaceState 直接発火）');
      }
    }
  }

  // ---------------------------------------------------------------------------

  D.uiTweaks = {
    apply: function () {
      if (typeof document === 'undefined' || !document.body) return;
      noteNavigation();
      hookBackButtons();
      openRowLinksInNewTab();
      collapseSections();
      hookPageSize();
    },

    // 検証用（テストから状態を覗くため）
    _state: function () {
      return { depth: depth, pendingBack: pendingBack };
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
