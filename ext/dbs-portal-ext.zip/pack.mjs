/**
 * DBSEXT Chrome拡張 パッケージスクリプト
 *
 * 拡張機能を CRX にパッケージし、GitHub Pages 配信用の更新定義を生成する。
 *
 * 出力:
 *   dist/extension/
 *     dbs-portal-ext.crx     — 署名済みパッケージ
 *     updates.xml            — Chrome 自動更新定義
 *     dbs-portal-ext.pem     — 秘密鍵（再配布禁止・リポジトリ非公開）
 */

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '../..');
const extDir = path.resolve(projectRoot, 'src/extension');
const distDir = path.resolve(projectRoot, 'dist/extension');

const KEY_PATH = path.resolve(projectRoot, 'dist/extension/dbs-portal-ext.pem');
const CRX_PATH = path.resolve(distDir, 'dbs-portal-ext.crx');
const UPDATES_PATH = path.resolve(distDir, 'updates.xml');
const UPDATE_URL_BASE = 'https://dontsu87.github.io/DBSgetdata/ext/';

// --- 鍵生成（初回のみ） ---
function ensureKey() {
  if (fs.existsSync(KEY_PATH)) {
    const pem = fs.readFileSync(KEY_PATH, 'utf-8');
    const privKey = crypto.createPrivateKey(pem);
    const pubKey = crypto.createPublicKey(privKey);
    return { privKey, pubKey, pem };
  }

  console.log('新しい鍵ペアを生成します...');
  const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', {
    modulusLength: 2048,
    publicKeyEncoding: { type: 'spki', format: 'der' },
    privateKeyEncoding: { type: 'pkcs8', format: 'pem' }
  });

  const pubDer = publicKey;
  const pemOut = privateKey;

  if (!fs.existsSync(distDir)) {
    fs.mkdirSync(distDir, { recursive: true });
  }
  fs.writeFileSync(KEY_PATH, pemOut, 'utf-8');
  console.log('  秘密鍵: ' + KEY_PATH);

  const privKey = crypto.createPrivateKey(pemOut);
  const pubKey = crypto.createPublicKey(privKey);
  return { privKey, pubKey, pem: pemOut };
}

// --- manifest.json に key を埋め込む ---
function injectKey(publicKeyDer) {
  const manifestPath = path.join(extDir, 'manifest.json');
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));

  // DER の公開鍵を Base64
  const keyBase64 = publicKeyDer.toString('base64');

  if (manifest.key !== keyBase64) {
    manifest.key = keyBase64;
    manifest.update_url = UPDATE_URL_BASE + 'updates.xml';
    fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + '\n', 'utf-8');
    console.log('  manifest.json に key と update_url を設定');
  } else {
    console.log('  manifest.json の key は最新です');
  }

  return manifest;
}

// --- ZIP の作成 ---
function createZip(srcDir) {
  // Node.js 標準の zip が無いため .NET System.IO.Compression.ZipFile を使う
  const tmpZip = path.join(distDir, '.tmp.zip');
  const psCmd = [
    'Add-Type -AssemblyName System.IO.Compression.FileSystem;',
    'if (Test-Path \"' + tmpZip.replace(/\\\\/g, '\\\\\\\\') + '\") { Remove-Item \"' + tmpZip.replace(/\\\\/g, '\\\\\\\\') + '\" -Force };',
    '[System.IO.Compression.ZipFile]::CreateFromDirectory(\"' + srcDir.replace(/\\\\/g, '\\\\\\\\') + '\", \"' + tmpZip.replace(/\\\\/g, '\\\\\\\\') + '\")'
  ].join(' ');
  try {
    execSync('powershell -Command "' + psCmd + '"', { stdio: 'pipe' });
  } catch (e) {
    console.error('ZIP作成エラー:', e.message);
    throw e;
  }
  const zipData = fs.readFileSync(tmpZip);
  fs.unlinkSync(tmpZip);
  return zipData;
}
// --- CRX v3 パッケージ ---
// V3 形式: protobuf ヘッダー + SHA256 署名。Chrome 114+ で必須。
// V2 は Chrome 150 で CRX_HEADER_INVALID に拒否される。
function createCrx(publicKeyDer, privateKey, zipData) {
  // CRX v3 フォーマット:
  // 4 bytes: "Cr24" magic
  // 4 bytes: version (3)
  // 4 bytes: protobuf header length
  // N bytes: protobuf header
  //   field 1 (key):        wire type 2 (length-delimited) = public key DER
  //   field 2 (signature):  wire type 2 (length-delimited) = signature
  //   field 3 (sig_version): wire type 0 (varint) = 1 (SHA256)
  // Rest: ZIP content

  const sign = crypto.createSign('RSA-SHA256');
  sign.update(zipData);
  const signature = sign.sign(privateKey);

  // protobuf エンコード（最小限の実装）
  function encodeVarint(value) {
    const bytes = [];
    while (value > 0x7f) {
      bytes.push((value & 0x7f) | 0x80);
      value >>>= 7;
    }
    bytes.push(value & 0x7f);
    return Buffer.from(bytes);
  }

  function encodeField(fieldNumber, wireType, data) {
    const tag = encodeVarint((fieldNumber << 3) | wireType);
    if (wireType === 2) {
      const length = encodeVarint(data.length);
      return Buffer.concat([tag, length, data]);
    } else if (wireType === 0) {
      return Buffer.concat([tag, encodeVarint(data)]);
    }
    throw new Error('unsupported wire type');
  }

  const protoHeader = Buffer.concat([
    encodeField(1, 2, publicKeyDer),
    encodeField(2, 2, signature),
    encodeField(3, 0, 1)
  ]);

  const header = Buffer.alloc(12 + protoHeader.length);
  let offset = 0;

  header.write('Cr24', offset, 4, 'ascii'); offset += 4;
  header.writeUInt32LE(3, offset); offset += 4;
  header.writeUInt32LE(protoHeader.length, offset); offset += 4;
  protoHeader.copy(header, offset);

  return Buffer.concat([header, zipData]);
}
// --- updates.xml の生成 ---
function getExtensionId(publicKeyDer) {
  // Chrome 拡張ID = SHA-256(pubKey)[0:16] の各バイトを a-p の文字にマッピング
  const hash = crypto.createHash('sha256').update(publicKeyDer).digest();
  const hex = 'abcdefghijklmnop';
  let id = '';
  for (let i = 0; i < 16; i++) {
    id += hex[hash[i] >> 4] + hex[hash[i] & 0x0f];
  }
  return id;
}

function writeUpdatesXml(manifest, publicKeyDer) {
  const appId = getExtensionId(publicKeyDer);

  const xml = `<?xml version='1.0' encoding='UTF-8'?>
<gupdate xmlns='http://www.google.com/update2/response' protocol='2.0'>
  <app appid='${appId}'>
    <updatecheck
      codebase='${UPDATE_URL_BASE}dbs-portal-ext.crx'
      version='${manifest.version}'
      prodversionmin='114.0'
    />
  </app>
</gupdate>
`;

  fs.writeFileSync(UPDATES_PATH, xml, 'utf-8');
  console.log('  updates.xml: ' + UPDATES_PATH);
}

// --- メイン ---
async function main() {
  console.log('=== DBSEXT Extension Packager ===\n');

  const { privKey, pubKey } = ensureKey();

  // 公開鍵を manifest.json に埋め込み
  const manifest = injectKey(pubKey.export({ type: 'spki', format: 'der' }));

  // 拡張ディレクトリを ZIP
  console.log('拡張をパッケージ中...');
  const zipData = createZip(extDir);
  console.log('  ZIP size: ' + (zipData.length / 1024).toFixed(1) + ' KB');

  // CRX を作成
  const crxData = createCrx(
    pubKey.export({ type: 'spki', format: 'der' }),
    privKey,
    zipData
  );
  fs.writeFileSync(CRX_PATH, crxData);
  console.log('  CRX  : ' + CRX_PATH + ' (' + (crxData.length / 1024).toFixed(1) + ' KB)');

  // updates.xml を生成
  writeUpdatesXml(manifest, pubKey.export({ type: 'spki', format: 'der' }));

  console.log('\n[OK] パッケージ完了');
  console.log('配信URL: ' + UPDATE_URL_BASE);
}

main().catch(e => {
  console.error('[ERROR]', e.message);
  process.exit(1);
});