/**
 * DBSEXT テーブル表示モジュール
 *
 * 目的: 一覧の見出し行を固定し、縦に長い表でも列名を見失わないようにする。
 *
 * ---------------------------------------------------------------------------
 * 実機実測でわかった Element Plus の構造（investigation/out/diag-tablewrap.json）
 * ---------------------------------------------------------------------------
 *
 *   div.el-table                     overflow:hidden      scrollW = clientW
 *     div.el-table__header-wrapper   overflow:hidden      scrollW = 3144
 *       table.el-table__header
 *     div.el-table__body-wrapper     overflow:hidden
 *       div.el-scrollbar
 *         div.el-scrollbar__wrap     overflow:auto        scrollW = 3144
 *           table.el-table__body
 *
 * 横スクロールを担っているのは .el-scrollbar__wrap であり、EP が JS で
 * ヘッダ側とスクロール位置を同期している。ここに手を入れてはいけない。
 *
 * 現在の実装は縦方向の高さを制限するだけ。EP 純正の .el-scrollbar__wrap が
 * 縦にスクロールし、その上にある .el-table__header-wrapper は動かないので、
 * sticky を使わずに見出しが固定される。横スクロールは EP のまま何も変えない。
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var SCROLL_CLASS = 'dbsext-scroll';
  var STYLE_ID = 'dbsext-table-wrap-style';
  var MAX_HEIGHT = '62vh';

  function injectStyles() {
    if (typeof document === 'undefined' || !document.head) return;
    if (document.getElementById(STYLE_ID)) return;

    var css = [
      /* 縦の高さだけを制限する。横スクロールと overflow には一切触れない。 */
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap {',
      '  max-height: ' + MAX_HEIGHT + ' !important;',
      '}',

      /* 高さ制限が効かない構造（scrollbar が無い版）への保険 */
      '.el-table.' + SCROLL_CLASS + ' > .el-table__body-wrapper:not(:has(.el-scrollbar)) {',
      '  max-height: ' + MAX_HEIGHT + ' !important;',
      '  overflow-y: auto;',
      '}',

      /* 見出しを少し目立たせる */
      '.el-table.' + SCROLL_CLASS + ' .el-table__header-wrapper {',
      '  background: #fafafa;',
      '}',

      /* スクロールバー: Element Plus はネイティブバーを display:none で隠し、
         自前の .el-scrollbar__bar を出している。これを逆転させる。 */
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar {',
      '  display: block !important;',
      '  width: 10px;',
      '  height: 10px;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar-track {',
      '  background: #e8e8e8;',
      '  border-radius: 5px;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar-thumb {',
      '  background: #a0a0a0;',
      '  border-radius: 5px;',
      '  border: 2px solid #e8e8e8;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar-thumb:hover {',
      '  background: #707070;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar-corner {',
      '  background: #e8e8e8;',
      '}',

      /* EP 自前のスクロールバー（細い・hover時のみ）を隠す */
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__bar {',
      '  display: none !important;',
      '}'
    ].join('\n');

    var style = document.createElement('style');
    style.id = STYLE_ID;
    style.setAttribute('data-dbsext-skin', '1');
    style.textContent = css;
    document.head.appendChild(style);
  }

  D.tableWrap = {
    SCROLL_CLASS: SCROLL_CLASS,

    apply: function () {
      if (typeof document === 'undefined') return;

      injectStyles();

      var tables = document.querySelectorAll('.el-table');
      if (!tables || tables.length === 0) return;

      for (var t = 0; t < tables.length; t++) {
        var table = tables[t];
        if (table.classList.contains(SCROLL_CLASS)) continue;

        var headerTable = table.querySelector('table.el-table__header');
        var bodyTable = table.querySelector('table.el-table__body');
        if (!headerTable || !bodyTable) continue;

        table.classList.add(SCROLL_CLASS);
        table.setAttribute('data-dbsext-wrap', '1');
      }
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);