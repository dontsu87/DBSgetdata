/**
 * DBSEXT テーブル表示モジュール
 *
 * 目的: 一覧の見出し行を固定し、縦に長い表でも列名を見失わないようにする。
 *
 * ---------------------------------------------------------------------------
 * 実機実測でわかった Element Plus の構造（investigation/out/diag-tablewrap.json）
 * ---------------------------------------------------------------------------
 *
 *   div.el-table                     overflow:hidden      scrollW = clientW
 *     div.el-table__header-wrapper   overflow:hidden      scrollW = 3144
 *       table.el-table__header
 *     div.el-table__body-wrapper     overflow:hidden
 *       div.el-scrollbar
 *         div.el-scrollbar__wrap     overflow:auto        scrollW = 3144
 *           table.el-table__body
 *
 * 横スクロールを担っているのは .el-scrollbar__wrap であり、EP が JS で
 * ヘッダ側とスクロール位置を同期している。**ここに手を入れてはいけない。**
 *
 * 以前の実装は .el-table 自体を overflow:auto にし、内側のラッパーの overflow を
 * visible で潰していた。その結果、ヘッダは sticky で追随するのにボディは
 * body-wrapper の幅で止まり、**右へスクロールすると右側が白いまま**になった
 * （2026-08-07 に現場から報告された症状）。
 *
 * したがって現在の実装は、縦方向の高さを制限するだけに絞ってある。
 * EP 純正の .el-scrollbar__wrap が縦にスクロールし、その上にある
 * .el-table__header-wrapper は動かないので、sticky を使わずに見出しが固定される。
 * 横スクロールは EP のまま何も変えない。
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var SCROLL_CLASS = 'dbsext-scroll';
  var STYLE_ID = 'dbsext-table-wrap-style';
  var MAX_HEIGHT = '62vh';
  var TOP_BAR_ATTR = 'data-dbsext-top-scrollbar';

  function injectStyles() {
    if (typeof document === 'undefined' || !document.head) return;
    if (document.getElementById(STYLE_ID)) return;

    var css = [
      /* 縦の高さだけを制限する。横スクロールと overflow には一切触れない。 */
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap {',
      '  max-height: ' + MAX_HEIGHT + ' !important;',
      '}',

      /* 高さ制限が効かない構造（scrollbar が無い版）への保険。こちらも縦だけ。 */
      '.el-table.' + SCROLL_CLASS + ' > .el-table__body-wrapper:not(:has(.el-scrollbar)) {',
      '  max-height: ' + MAX_HEIGHT + ' !important;',
      '  overflow-y: auto;',
      '}',

      /* 見出しを少し目立たせる（固定されていることが分かるように） */
      '.el-table.' + SCROLL_CLASS + ' .el-table__header-wrapper {',
      '  background: #fafafa;',
      '}',

      /* --- 横スクロールバーを常時見えるようにする -----------------------------
         **なぜ今まで実機で出なかったか（2026-08-09 に原因特定）**

         Element Plus は `.el-scrollbar__wrap` に **標準プロパティ
         `scrollbar-width: none`** を指定してネイティブのバーを消している。
         Chrome は**標準プロパティが指定されていると `::-webkit-scrollbar` の
         指定を丸ごと無視する**（本機は Chromium 148。`CSS.supports` で確認済み）。

         そのため `::-webkit-scrollbar { height: 10px }` だけを書いても効かない。
         モックには `scrollbar-width: none` が無かったので、
         **モックでは出るのに実機では出ない**という食い違いになっていた。

         対処: **標準プロパティで上書きする。** webkit 側は古い環境への保険として残す。

         なぜ常時表示が要るか: 画面幅は利用者ごとに違う。
         ポータルの body には `min-width: 1900px` が入っており、
         1900px 未満の画面では**ページ全体が横スクロールする**（実測）。
         狭い画面の利用者にとって、横スクロールは日常的な操作である。
         「自分の画面で収まったから不要」と判断してはいけない。
      ------------------------------------------------------------------------ */
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap {',
      '  scrollbar-width: auto !important;',      /* none を打ち消す。これが本命 */
      '  scrollbar-color: #8a9099 #e8e8e8 !important;',  /* つまみ / 溝 */
      '}',
      /* 以下は標準プロパティ非対応の環境向けの保険 */
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar {',
      '  display: block !important;',
      '  width: 12px;',
      '  height: 12px;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar-track {',
      '  background: #e8e8e8;',
      '  border-radius: 5px;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar-thumb {',
      '  background: #a0a0a0;',
      '  border-radius: 5px;',
      '  border: 2px solid #e8e8e8;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar-thumb:hover {',
      '  background: #707070;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar-corner {',
      '  background: #e8e8e8;',
      '}',

      /* 見出しの上に置く操作用の帯。常に見える横スクロールバー */
      '.el-table.' + SCROLL_CLASS + ' .dbsext-top-scrollbar {',
      '  overflow-x: auto;',
      '  overflow-y: hidden;',
      '  scrollbar-width: auto;',
      '  scrollbar-color: #8a9099 #e8e8e8;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .dbsext-top-scrollbar > div {',
      '  height: 1px;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .dbsext-top-scrollbar::-webkit-scrollbar {',
      '  display: block !important;',
      '  height: 12px;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .dbsext-top-scrollbar::-webkit-scrollbar-track {',
      '  background: #e8e8e8;',
      '  border-radius: 6px;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .dbsext-top-scrollbar::-webkit-scrollbar-thumb {',
      '  background: #8a9099;',
      '  border-radius: 6px;',
      '}',

      /* EP 自前のスクロールバー（細い・hover時のみ）を隠す */
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__bar {',
      '  display: none !important;',
      '}'
    ].join('\n');

    var style = document.createElement('style');
    style.id = STYLE_ID;
    style.setAttribute('data-dbsext-skin', '1');
    style.textContent = css;
    document.head.appendChild(style);
  }

  
  // ローディングオーバーレイによるクラス消失を防止

  /**
   * 見出しの**上**に横スクロールバーを置く。
   *
   * 現場からの指摘:
   *   「横スクロールバーが、表の一番下まで到達しないと見えない。常に見えるようにしてほしい。
   *     見出し列の上につけれればいいかも」
   *
   * そのとおりで、EP のスクロールバーは**スクロール領域の下端**にある。
   * 表は縦にも長く高さを 62vh に制限しているため、
   * **縦に一番下まで送らないと横バーが視界に入らない**。
   * 横に隠れた列があること自体に気づけない。
   *
   * 対処: 見出しの上に「操作用の細い帯」を置き、本体と**双方向に同期**させる。
   * 帯の中身は幅を合わせただけの空要素で、これを横に送ると本体も動く。
   *
   * **本体側の overflow には触らない**（触ると右側が描画されなくなる。table-wrap 冒頭の説明）。
   */
  function ensureTopScrollbar(table) {
    if (typeof document === 'undefined') return;

    var wrap = table.querySelector('.el-scrollbar__wrap');
    var headerWrapper = table.querySelector('.el-table__header-wrapper');
    if (!wrap || !headerWrapper || !headerWrapper.parentNode) return;

    var bar = table.querySelector('[' + TOP_BAR_ATTR + ']');
    if (!bar) {
      bar = document.createElement('div');
      bar.setAttribute(TOP_BAR_ATTR, '1');
      bar.className = 'dbsext-top-scrollbar';
      var inner = document.createElement('div');
      inner.setAttribute('data-dbsext-top-scrollbar-inner', '1');
      bar.appendChild(inner);
      headerWrapper.parentNode.insertBefore(bar, headerWrapper);
    }

    var inner2 = bar.firstChild;
    if (!inner2) return;

    // 中身の幅を本体に合わせる（本体が広いときだけ帯が意味を持つ）
    var needed = wrap.scrollWidth;
    if (inner2.style.width !== needed + 'px') inner2.style.width = needed + 'px';
    bar.style.display = (needed > wrap.clientWidth) ? 'block' : 'none';

    // 表示列の切替やSPA再描画で wrap 自体が差し替わることがある。
    // 最初に見つけた wrap をクロージャへ固定すると、以後は古い領域しか動かせない。
    // bar 側から「現在の wrap」を参照し、差し替え後も同じ帯を使い続けられるようにする。
    bar.__dbsextWrap = wrap;
    bar.__dbsextHeaderWrapper = headerWrapper;

    if (!bar.__dbsextScrollHooked) {
      bar.__dbsextScrollHooked = true;
      bar.setAttribute('data-dbsext-synced', '1');
      bar.addEventListener('scroll', function () {
        var currentWrap = bar.__dbsextWrap;
        if (!currentWrap || bar.__dbsextSyncing) return;
        bar.__dbsextSyncing = true;
        currentWrap.scrollLeft = bar.scrollLeft;
        var currentHeader = bar.__dbsextHeaderWrapper;
        if (currentHeader) currentHeader.scrollLeft = bar.scrollLeft;
        bar.__dbsextSyncing = false;
      });
    }

    if (wrap.__dbsextTopBar !== bar) {
      wrap.__dbsextTopBar = bar;
      wrap.addEventListener('scroll', function () {
        if (bar.__dbsextSyncing) return;
        bar.__dbsextSyncing = true;
        bar.scrollLeft = wrap.scrollLeft;
        var currentHeader = bar.__dbsextHeaderWrapper;
        if (currentHeader) currentHeader.scrollLeft = wrap.scrollLeft;
        bar.__dbsextSyncing = false;
      });
    }

    headerWrapper.scrollLeft = wrap.scrollLeft;
  }

  /**
   * 列幅変更後に上部バーを再計測する。
   * CSSの追加・削除は同期的でも、Element Plus が同じターンの後で幅を書き戻すため、
   * 直後と次のタスクの2回測る。
   */
  function refreshTopScrollbar(table) {
    if (!table) return;
    ensureTopScrollbar(table);
    if (typeof setTimeout === 'function') {
      setTimeout(function () { ensureTopScrollbar(table); }, 0);
    }
  }

  function observeTableClass(table) {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
          if (!table.classList.contains(SCROLL_CLASS)) {
            table.classList.add(SCROLL_CLASS);
          }
        }
      });
    });

    // core.js と同じ理由の防御（別タブで開いたときに実機で確認された例外）。
    // ここが失敗しても致命的ではない。すでに SCROLL_CLASS は付与済みなので
    // 見た目はそのまま出る。**クラス監視だけを諦める。**
    try {
      observer.observe(table, { attributes: true, attributeFilter: ['class'] });
    } catch (e) {
      if (D.core && typeof D.core.log === 'function') {
        D.core.log('table-wrap: クラス監視の開始に失敗: ' + (e && e.message ? e.message : e), true);
      }
    }
  }

  D.tableWrap = {
    SCROLL_CLASS: SCROLL_CLASS,

    refresh: refreshTopScrollbar,

    apply: function () {
      if (typeof document === 'undefined') return;

      injectStyles();

      var tables = document.querySelectorAll('.el-table');
      if (!tables || tables.length === 0) return;

      for (var t = 0; t < tables.length; t++) {
        var table = tables[t];

        // 幅は列の出し入れやリサイズで変わるので、**毎回**合わせ直す
        refreshTopScrollbar(table);

        if (table.classList.contains(SCROLL_CLASS)) continue;

        var headerTable = table.querySelector('table.el-table__header');
        var bodyTable = table.querySelector('table.el-table__body');
        if (!headerTable || !bodyTable) continue;

        table.classList.add(SCROLL_CLASS);
        observeTableClass(table);
        table.setAttribute('data-dbsext-wrap', '1');
      }
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
