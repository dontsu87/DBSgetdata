﻿/**
 * DBSEXT 繝・・繝悶Ν陦ｨ遉ｺ繝｢繧ｸ繝･繝ｼ繝ｫ
 *
 * 逶ｮ逧・ 荳隕ｧ縺ｮ隕句・縺苓｡後ｒ蝗ｺ螳壹＠縲∫ｸｦ縺ｫ髟ｷ縺・｡ｨ縺ｧ繧ょ・蜷阪ｒ隕句､ｱ繧上↑縺・ｈ縺・↓縺吶ｋ縲・ *
 * ---------------------------------------------------------------------------
 * 螳滓ｩ溷ｮ滓ｸｬ縺ｧ繧上°縺｣縺・Element Plus 縺ｮ讒矩・・nvestigation/out/diag-tablewrap.json・・ * ---------------------------------------------------------------------------
 *
 *   div.el-table                     overflow:hidden      scrollW = clientW
 *     div.el-table__header-wrapper   overflow:hidden      scrollW = 3144
 *       table.el-table__header
 *     div.el-table__body-wrapper     overflow:hidden
 *       div.el-scrollbar
 *         div.el-scrollbar__wrap     overflow:auto        scrollW = 3144
 *           table.el-table__body
 *
 * 讓ｪ繧ｹ繧ｯ繝ｭ繝ｼ繝ｫ繧呈球縺｣縺ｦ縺・ｋ縺ｮ縺ｯ .el-scrollbar__wrap 縺ｧ縺ゅｊ縲・P 縺・JS 縺ｧ
 * 繝倥ャ繝蛛ｴ縺ｨ繧ｹ繧ｯ繝ｭ繝ｼ繝ｫ菴咲ｽｮ繧貞酔譛溘＠縺ｦ縺・ｋ縲ゅ％縺薙↓謇九ｒ蜈･繧後※縺ｯ縺・￠縺ｪ縺・・ *
 * 迴ｾ蝨ｨ縺ｮ螳溯｣・・邵ｦ譁ｹ蜷代・鬮倥＆繧貞宛髯舌☆繧九□縺代・P 邏疲ｭ｣縺ｮ .el-scrollbar__wrap 縺・ * 邵ｦ縺ｫ繧ｹ繧ｯ繝ｭ繝ｼ繝ｫ縺励√◎縺ｮ荳翫↓縺ゅｋ .el-table__header-wrapper 縺ｯ蜍輔°縺ｪ縺・・縺ｧ縲・ * sticky 繧剃ｽｿ繧上★縺ｫ隕句・縺励′蝗ｺ螳壹＆繧後ｋ縲よｨｪ繧ｹ繧ｯ繝ｭ繝ｼ繝ｫ縺ｯ EP 縺ｮ縺ｾ縺ｾ菴輔ｂ螟峨∴縺ｪ縺・・ */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var SCROLL_CLASS = 'dbsext-scroll';
  var STYLE_ID = 'dbsext-table-wrap-style';
  var MAX_HEIGHT = '62vh';

  function injectStyles() {
    if (typeof document === 'undefined' || !document.head) return;
    if (document.getElementById(STYLE_ID)) return;

    var css = [
      /* 邵ｦ縺ｮ鬮倥＆縺縺代ｒ蛻ｶ髯舌☆繧九よｨｪ繧ｹ繧ｯ繝ｭ繝ｼ繝ｫ縺ｨ overflow 縺ｫ縺ｯ荳蛻・ｧｦ繧後↑縺・・*/
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap {',
      '  max-height: ' + MAX_HEIGHT + ' !important;',
      '}',

      /* 鬮倥＆蛻ｶ髯舌′蜉ｹ縺九↑縺・ｧ矩・・crollbar 縺檎┌縺・沿・峨∈縺ｮ菫晞匱 */
      '.el-table.' + SCROLL_CLASS + ' > .el-table__body-wrapper:not(:has(.el-scrollbar)) {',
      '  max-height: ' + MAX_HEIGHT + ' !important;',
      '  overflow-y: auto;',
      '}',

      /* 隕句・縺励ｒ蟆代＠逶ｮ遶九◆縺帙ｋ */
      '.el-table.' + SCROLL_CLASS + ' .el-table__header-wrapper {',
      '  background: #fafafa;',
      '}',

      /* 繧ｹ繧ｯ繝ｭ繝ｼ繝ｫ繝舌・: Element Plus 縺ｯ繝阪う繝・ぅ繝悶ヰ繝ｼ繧・display:none 縺ｧ髫縺励・         閾ｪ蜑阪・ .el-scrollbar__bar 繧貞・縺励※縺・ｋ縲ゅ％繧後ｒ騾・ｻ｢縺輔○繧九・*/
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar {',
      '  width: 10px;',
      '  height: 10px;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar-track {',
      '  background: #e8e8e8;',
      '  border-radius: 5px;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar-thumb {',
      '  background: #a0a0a0;',
      '  border-radius: 5px;',
      '  border: 2px solid #e8e8e8;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar-thumb:hover {',
      '  background: #707070;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar-corner {',
      '  background: #e8e8e8;',
      '}',

      /* EP 閾ｪ蜑阪・繧ｹ繧ｯ繝ｭ繝ｼ繝ｫ繝舌・・育ｴｰ縺・・hover譎ゅ・縺ｿ・峨ｒ髫縺・*/
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__bar {',
      '  display: none !important;',
      '}'
    ].join('\n');

    var style = document.createElement('style');
    style.id = STYLE_ID;
    style.setAttribute('data-dbsext-skin', '1');
    style.textContent = css;
    document.head.appendChild(style);
  }

  
  // ローディングオーバーレイによるクラス消失を防止
  function observeTableClass(table) {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
          if (!table.classList.contains(SCROLL_CLASS)) {
            table.classList.add(SCROLL_CLASS);
          }
        }
      });
    });
    
    observer.observe(table, { attributes: true, attributeFilter: ['class'] });
  }

  D.tableWrap = {
    SCROLL_CLASS: SCROLL_CLASS,

    apply: function () {
      if (typeof document === 'undefined') return;

      injectStyles();

      var tables = document.querySelectorAll('.el-table');
      if (!tables || tables.length === 0) return;

      for (var t = 0; t < tables.length; t++) {
        var table = tables[t];
        if (table.classList.contains(SCROLL_CLASS)) continue;

        var headerTable = table.querySelector('table.el-table__header');
        var bodyTable = table.querySelector('table.el-table__body');
        if (!headerTable || !bodyTable) continue;

        table.classList.add(SCROLL_CLASS);
        observeTableClass(table);
        table.setAttribute('data-dbsext-wrap', '1');
      }
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);