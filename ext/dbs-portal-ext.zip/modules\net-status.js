/**
 * DBSEXT 通信ステータスモジュール
 * 通信監視、読み込み中マスク表示、エラー・セッション切れ通知を担当
 *
 * ---------------------------------------------------------------------------
 * **既知の制約: Chrome拡張版（β）およびリモート配信版（USER_SCRIPT world）では、この機能はポータルの通信を捉えられない。**
 *
 * content script および user script は隔離ワールド（ISOLATED / USER_SCRIPT）で動くため、ここで差し替えるのは
 * 「隔離ワールドの `window.fetch` / `XMLHttpRequest`」であって、
 * ポータル本体（Nuxt）が呼ぶ MAIN ワールドの同名APIではない。
 * したがって β（拡張版・リモート配信版）では読み込み中マスク・通信エラー・セッション切れが**出ない**。
 *
 * **ブックマークレット版（α）はページのメインワールドで動くため、正しく機能する。**
 * 現在の配布の主軸は α なので、当面はこの制約を受け入れる。
 *
 * β で有効にするには `manifest.json` の content_scripts を2つに分ける必要がある:
 *   - 隔離ワールド: platform-extension.js（`chrome.*` を使うため MAIN では動かない）
 *   - MAIN ワールド: net-status.js（`"world": "MAIN"` を指定）
 * ただし両ワールドで `DBSEXT` 名前空間が別々になるため、
 * boot の流れと状態の持ち方を設計し直す必要がある。**安易に world を足さないこと。**
 *
 * 出典: 独立監査 T-20260808-AUDIT 指摘5 / T-20260809-REMOTE-AUDIT R-07。HANDOFF.md にも記録済み。
 * ---------------------------------------------------------------------------
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var LOADING_DELAY_MS = 250;
  var OVERLAY_ATTR = 'data-dbsext-loading-mask';
  var TOP_INDICATOR_ATTR = 'data-dbsext-top-indicator';
  var BANNER_ATTR = 'data-dbsext-error-banner';
  var HOST_ATTR = 'data-dbsext-net-status';

  var activeRequests = 0;
  var silentDepth = 0;
  var delayTimer = null;
  var elapsedTimer = null;
  var requestStartTime = 0;
  var isMaskVisible = false;

  function updateLoadingText(elapsedSec) {
    var text = '読み込み中…';
    if (elapsedSec >= 1) {
      text = '読み込み中… ' + elapsedSec + '秒';
    }

    if (typeof document === 'undefined') return;

    var texts = document.querySelectorAll('[' + HOST_ATTR + '] .dbsext-loading-text');
    for (var i = 0; i < texts.length; i++) {
      texts[i].textContent = text;
    }
  }

  function scheduleElapsedTimer() {
    if (elapsedTimer) {
      clearTimeout(elapsedTimer);
      elapsedTimer = null;
    }
    elapsedTimer = setTimeout(function () {
      elapsedTimer = null;
      if (activeRequests > 0) {
        var elapsedSec = Math.floor((Date.now() - requestStartTime) / 1000);
        updateLoadingText(elapsedSec);
        scheduleElapsedTimer();
      }
    }, 500);
  }

  function createTableOverlay() {
    var overlay = document.createElement('div');
    overlay.setAttribute(OVERLAY_ATTR, '1');
    overlay.setAttribute(HOST_ATTR, '1');
    overlay.style.cssText = [
      'position: absolute',
      'top: 0',
      'left: 0',
      'width: 100%',
      'height: 100%',
      'min-height: 80px',
      'background-color: rgba(255, 255, 255, 0.75)',
      'z-index: 2000',
      'display: flex',
      'flex-direction: column',
      'align-items: center',
      'justify-content: center',
      'pointer-events: auto'
    ].join(';');

    var content = document.createElement('div');
    content.style.cssText = [
      'background: rgba(0, 0, 0, 0.75)',
      'color: #ffffff',
      'padding: 8px 16px',
      'border-radius: 4px',
      'font-size: 13px',
      'font-weight: bold',
      'display: flex',
      'align-items: center',
      'gap: 8px',
      'box-shadow: 0 2px 8px rgba(0,0,0,0.2)'
    ].join(';');

    var textSpan = document.createElement('span');
    textSpan.className = 'dbsext-loading-text';
    textSpan.textContent = '読み込み中…';

    content.appendChild(textSpan);
    overlay.appendChild(content);
    return overlay;
  }

  function createTopIndicator() {
    var indicator = document.createElement('div');
    indicator.setAttribute(TOP_INDICATOR_ATTR, '1');
    indicator.setAttribute(HOST_ATTR, '1');
    indicator.style.cssText = [
      'position: fixed',
      'top: 12px',
      'right: 12px',
      'z-index: 2147483000',
      'background: rgba(0, 0, 0, 0.75)',
      'color: #ffffff',
      'padding: 6px 12px',
      'border-radius: 4px',
      'font-size: 12px',
      'font-weight: bold',
      'box-shadow: 0 2px 8px rgba(0,0,0,0.2)',
      'pointer-events: none'
    ].join(';');

    var textSpan = document.createElement('span');
    textSpan.className = 'dbsext-loading-text';
    textSpan.textContent = '読み込み中…';

    indicator.appendChild(textSpan);
    return indicator;
  }

  function renderMask() {
    if (typeof document === 'undefined' || !document.body) return;

    var tables = document.querySelectorAll('.el-table');
    if (tables && tables.length > 0) {
      for (var i = 0; i < tables.length; i++) {
        var table = tables[i];
        if (!table.querySelector('[' + OVERLAY_ATTR + ']')) {
          var position = (typeof window !== 'undefined' && window.getComputedStyle) ? window.getComputedStyle(table).position : table.style.position;
          if (position !== 'relative' && position !== 'absolute' && position !== 'fixed') {
            table.style.position = 'relative';
          }
          table.appendChild(createTableOverlay());
        }
      }
    } else {
      if (!document.querySelector('[' + TOP_INDICATOR_ATTR + ']')) {
        document.body.appendChild(createTopIndicator());
      }
    }
  }

  function showLoadingUI() {
    isMaskVisible = true;
    renderMask();
    var elapsedSec = Math.floor((Date.now() - requestStartTime) / 1000);
    updateLoadingText(elapsedSec);
  }

  function hideLoadingUI() {
    isMaskVisible = false;
    if (delayTimer) {
      clearTimeout(delayTimer);
      delayTimer = null;
    }
    if (elapsedTimer) {
      clearTimeout(elapsedTimer);
      elapsedTimer = null;
    }

    if (typeof document === 'undefined' || !document.body) return;

    var overlays = document.querySelectorAll('[' + OVERLAY_ATTR + ']');
    for (var i = 0; i < overlays.length; i++) {
      if (overlays[i].parentNode) {
        overlays[i].parentNode.removeChild(overlays[i]); // dbsext:own-ui
      }
    }

    var indicators = document.querySelectorAll('[' + TOP_INDICATOR_ATTR + ']');
    for (var j = 0; j < indicators.length; j++) {
      if (indicators[j].parentNode) {
        indicators[j].parentNode.removeChild(indicators[j]); // dbsext:own-ui
      }
    }
  }

  function onRequestStart() {
    activeRequests++;
    if (activeRequests === 1) {
      requestStartTime = Date.now();
      if (delayTimer) clearTimeout(delayTimer);
      delayTimer = setTimeout(function () {
        delayTimer = null;
        if (activeRequests > 0) {
          showLoadingUI();
          scheduleElapsedTimer();
        }
      }, LOADING_DELAY_MS);
    }
  }

  function onRequestEnd() {
    activeRequests = Math.max(0, activeRequests - 1);
    if (activeRequests === 0) {
      hideLoadingUI();
    }
  }

  function showBanner(message, isAuthError) {
    if (typeof document === 'undefined' || !document.body) return;

    // 既存バナーがあれば更新（同時に1枚まで）
    var existing = document.querySelector('[' + BANNER_ATTR + ']');
    if (existing) {
      var msgSpan = existing.querySelector('.dbsext-banner-text');
      if (msgSpan) msgSpan.textContent = message;
      existing.style.backgroundColor = isAuthError ? '#c0392b' : '#d9534f';
      return;
    }

    var banner = document.createElement('div');
    banner.setAttribute(BANNER_ATTR, '1');
    banner.setAttribute(HOST_ATTR, '1');
    banner.style.cssText = [
      'position: fixed',
      'top: 12px',
      'left: 50%',
      'transform: translateX(-50%)',
      'z-index: 2147483001',
      'background-color: ' + (isAuthError ? '#c0392b' : '#d9534f'),
      'color: #ffffff',
      'padding: 8px 16px',
      'border-radius: 6px',
      'font-size: 13px',
      'font-weight: bold',
      'box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25)',
      'display: flex',
      'align-items: center',
      'gap: 12px'
    ].join(';');

    var textSpan = document.createElement('span');
    textSpan.className = 'dbsext-banner-text';
    textSpan.textContent = message;
    banner.appendChild(textSpan);

    var closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.textContent = '✕';
    closeBtn.style.cssText = [
      'background: none',
      'border: none',
      'color: #ffffff',
      'font-size: 14px',
      'font-weight: bold',
      'cursor: pointer',
      'padding: 0 4px',
      'line-height: 1'
    ].join(';');
    closeBtn.addEventListener('click', function () {
      if (banner.parentNode) {
        banner.parentNode.removeChild(banner); // dbsext:own-ui
      }
    });
    banner.appendChild(closeBtn);

    document.body.appendChild(banner);
  }

  function handleResponseStatus(status) {
    if (status === 401 || status === 403) {
      showBanner('ログインが切れました。再度ログインしてください', true);
    } else if (status >= 400) {
      showBanner('通信に失敗しました（HTTP ' + status + '）。再読込してください', false);
    }
  }

  function handleGenericError() {
    showBanner('通信に失敗しました。再読込してください', false);
  }

  /**
   * 中断されただけの通信か。
   *
   * ポータルは「同じエンドポイントへ新しい要求が来たら古い方を中断する」作りになっており、
   * 画面を操作しているだけで AbortError が日常的に発生する。**これは異常ではない。**
   * 利用者が中断した場合（画面遷移など）も同じ。**どちらも警告を出してはいけない。**
   */
  function isAbortError(err) {
    if (!err) return false;
    if (err.name === 'AbortError') return true;
    // 環境によっては DOMException の code だけが手がかりになる
    return err.code === 20;
  }

  function wrapFetch() {
    if (typeof window === 'undefined' || !window.fetch) return;
    if (window.fetch.__dbsext_wrapped) return;

    var origFetch = window.fetch;
    var newFetch = function (input, init) {
      var isSilent = silentDepth > 0;
      if (!isSilent) {
        onRequestStart();
      }

      var promise;
      try {
        promise = origFetch.apply(this, arguments);
      } catch (err) {
        if (!isSilent) {
          onRequestEnd();
          handleGenericError();
        }
        throw err;
      }

      return promise.then(
        function (res) {
          if (!isSilent) {
            onRequestEnd();
            if (res && !res.ok) {
              handleResponseStatus(res.status);
            }
          }
          return res;
        },
        function (err) {
          if (!isSilent) {
            onRequestEnd();
            // **中断は失敗ではない。**
            // ポータルは同じエンドポイントへの重複リクエストを意図的に中断する
            // （実測: AbortError「Request aborted as another request to the same
            //   endpoint was initiated.」が /api/auth/me や /api/areas で常時発生）。
            // これを失敗として扱うと、通信が正常でも
            // **「通信に失敗しました」が出っぱなしになる**（現場から報告された不具合）。
            // XHR 側では abort を除外していたのに、fetch 側で同じ誤りを残していた。
            if (!isAbortError(err)) handleGenericError();
          }
          return Promise.reject(err);
        }
      );
    };

    newFetch.__dbsext_wrapped = true;
    window.fetch = newFetch;
  }

  function wrapXHR() {
    if (typeof XMLHttpRequest === 'undefined' || !XMLHttpRequest.prototype || !XMLHttpRequest.prototype.send) return;
    if (XMLHttpRequest.prototype.send.__dbsext_wrapped) return;

    var origSend = XMLHttpRequest.prototype.send;
    var newSend = function () {
      var xhr = this;
      var isSilent = silentDepth > 0;

      if (!isSilent) {
        onRequestStart();
        // 通信そのものが失敗した場合（回線断・タイムアウト）。
        // **`status === 0` で判定してはいけない。** abort も 0 になるため、
        // ポータルが遷移時にリクエストを中断しただけで
        // 「通信に失敗しました」と出てしまう。`error` / `timeout` だけを拾う。
        var failed = false;
        var onFail = function () { failed = true; };
        xhr.addEventListener('error', onFail);
        xhr.addEventListener('timeout', onFail);

        var onEnd = function () {
          xhr.removeEventListener('loadend', onEnd);
          xhr.removeEventListener('error', onFail);
          xhr.removeEventListener('timeout', onFail);
          onRequestEnd();
          var status = xhr.status;
          if (status === 401 || status === 403) {
            showBanner('ログインが切れました。再度ログインしてください', true);
          } else if (status >= 400) {
            showBanner('通信に失敗しました（HTTP ' + status + '）。再読込してください', false);
          } else if (failed) {
            handleGenericError();
          }
        };
        xhr.addEventListener('loadend', onEnd);

        // **send() が同期的に例外を投げる場合がある**（InvalidStateError など）。
        // そのとき loadend は一度も来ないため、ここで戻さないと
        // カウンタが増えたまま戻らず、**マスクが永久に出っぱなしになる**。
        try {
          return origSend.apply(this, arguments);
        } catch (err) {
          xhr.removeEventListener('loadend', onEnd);
          onRequestEnd();
          handleGenericError();
          throw err;   // ポータルの挙動を変えないよう、例外はそのまま通す
        }
      }

      return origSend.apply(this, arguments);
    };

    newSend.__dbsext_wrapped = true;
    XMLHttpRequest.prototype.send = newSend;
  }

  D.netStatus = {
    LOADING_DELAY_MS: LOADING_DELAY_MS,

    apply: function () {
      wrapFetch();
      wrapXHR();

      if (isMaskVisible && activeRequests > 0) {
        renderMask();
      }
    },

    silent: function (fn) {
      if (typeof fn !== 'function') return;
      silentDepth++;
      try {
        return fn();
      } finally {
        silentDepth--;
      }
    },

    _getActiveRequests: function () {
      return activeRequests;
    },
    _isMaskVisible: function () {
      return isMaskVisible;
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
