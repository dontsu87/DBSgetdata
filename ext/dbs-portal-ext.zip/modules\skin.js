/**
 * DBSEXT スキンモジュール
 * 赤色ベースの標準ポータルテーマを拡張適用中の青色テーマへ変更する
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  D.skin = {
    styleId: 'dbsext-skin',

    /**
     * テーマスタイルを document.head に挿入する（冪等）
     */
    apply: function () {
      if (typeof document === 'undefined' || !document.head) {
        return;
      }

      if (document.getElementById(D.skin.styleId)) {
        return;
      }

      var accent = (D.CONFIG && D.CONFIG.ACCENT) ? D.CONFIG.ACCENT : '#0b5cab';

      var css = [
        ':root {',
        '  --primary: ' + accent + ' !important;',
        '  --el-color-text: ' + accent + ' !important;',
        '  --el-color-primary-hover: ' + accent + ' !important;',
        '}',
        '.bg-primary { background-color: ' + accent + ' !important; }',
        '.text-primary { color: ' + accent + ' !important; }',
        '.border-primary { border-color: ' + accent + ' !important; }'
      ].join('\n');

      var styleEl = document.createElement('style');
      styleEl.id = D.skin.styleId;
      styleEl.setAttribute('data-dbsext-skin', '1');
      styleEl.textContent = css;

      document.head.appendChild(styleEl);
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
