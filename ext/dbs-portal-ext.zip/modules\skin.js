/**
 * DBSEXT スキンモジュール
 * 赤色ベースの標準ポータルテーマを拡張適用中の青色テーマへ変更し、
 * コントラスト改善（案A）、日本語フォント明示（案B）、サイドバー縮小（案C）、
 * 行の視認性向上（案E）、先頭列固定（案3）のCSSを document.head の1枚の <style> に集約する。
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  /**
   * WCAG 2.1 AA コントラスト比検証用の宣言表
   * テスト（test_skin_contrast.js）で機械照合する
   */
  var CONTRAST_PAIRS = [
    { name: '表ヘッダ', fg: '#2f3438', bg: '#d9d9d9' },
    { name: 'データなし', fg: '#5a5e66', bg: '#ffffff' },
    { name: '見出し（画面タイトル）', fg: '#303133', bg: '#ffffff' }
  ];

  D.skin = {
    styleId: 'dbsext-skin',
    CONTRAST_PAIRS: CONTRAST_PAIRS,

    /**
     * テーマスタイルを document.head に挿入する（冪等）
     */
    apply: function () {
      if (typeof document === 'undefined' || !document.head) {
        return;
      }

      if (document.getElementById(D.skin.styleId)) {
        return;
      }

      var accent = (D.CONFIG && D.CONFIG.ACCENT) ? D.CONFIG.ACCENT : '#0b5cab';

      var css = [
        ':root {',
        '  --primary: ' + accent + ' !important;',
        '  --el-color-text: ' + accent + ' !important;',
        '  --el-color-primary-hover: ' + accent + ' !important;',
        '  font-family: "BIZ UDPGothic", "Meiryo", "Yu Gothic UI", system-ui, sans-serif !important;',
        '}',
        '',
        'body {',
        '  font-family: "BIZ UDPGothic", "Meiryo", "Yu Gothic UI", system-ui, sans-serif !important;',
        '}',
        '',
        '/* 案B: 表のセル数字を等幅にして縦比較しやすくする */',
        '.el-table th,',
        '.el-table td {',
        '  font-variant-numeric: tabular-nums !important;',
        '}',
        '',
        '/* Tailwind ユーティリティの保険 */',
        '.bg-primary { background-color: ' + accent + ' !important; }',
        '.text-primary { color: ' + accent + ' !important; }',
        '.border-primary { border-color: ' + accent + ' !important; }',
        '',
        '/* 案A: コントラスト改善（実測値に基づく WCAG 2.1 AA 適合） */',
        '/* 表ヘッダ文字色 (WCAG AA 8.91) */',
        'table.el-table__header th,',
        '.el-table__header-wrapper th,',
        '.el-table th {',
        '  color: #2f3438 !important;',
        '  background-color: #d9d9d9 !important;',
        '  font-weight: 600 !important;',
        '  border-bottom: 1px solid #c8ccd4 !important;',
        '}',
        '',
        '/* 「データなし」文字色 (WCAG AA 6.51) */',
        '.el-table__empty-text {',
        '  color: #5a5e66 !important;',
        '  background-color: #ffffff !important;',
        '}',
        '',
        '/* 画面タイトル見出し (WCAG AA 13.02) */',
        'h1.page-title,',
        '.main h1,',
        'main h1 {',
        '  color: #303133 !important;',
        '  font-weight: 600 !important;',
        '}',
        '',
        '/* 表の罫線コントラスト */',
        'table.el-table__header th,',
        'table.el-table__body td,',
        '.el-table td,',
        '.el-table th.is-leaf {',
        '  border-bottom: 1px solid #c8ccd4 !important;',
        '  border-color: #c8ccd4 !important;',
        '}',
        '',
        '/* 案C: サイドバー縮小 (280px -> 180px) */',
        '.sidebar,',
        '.w-\\[280px\\],',
        '[class*="w-[280px]"] {',
        '  width: 180px !important;',
        '  flex: 0 0 180px !important;',
        '  min-width: 180px !important;',
        '  max-width: 180px !important;',
        '}',
        '',
        '.sidebar .menu-item > a,',
        '.sidebar .menu a,',
        '.sidebar a,',
        '[class*="w-[280px]"] a.block.w-full,',
        'a.block.w-full.p-2 {',
        '  font-size: 14px !important;',
        '  padding: 6px 8px !important;',
        '  height: 34px !important;',
        '  line-height: 22px !important;',
        '}',
        '',
        '.sidebar-head,',
        '[class*="w-[280px]"] > div:first-child,',
        '.sidebar .brand {',
        '  font-size: 13px !important;',
        '  padding: 10px 8px !important;',
        '}',
        '',
        '/* 案E: ゼブラとホバー強調 */',
        '.el-table__body tr:nth-child(odd) td {',
        '  background-color: #ffffff !important;',
        '}',
        '.el-table__body tr:nth-child(even) td {',
        '  background-color: #f7f9fc !important;',
        '}',
        '.el-table__body tr:hover td,',
        '.el-table__body tr.hover-row td {',
        '  background-color: #e8f1fb !important;',
        '}',
        '',
        '/* 案3: 先頭列（チェックボックス・車両識別番号）の sticky 固定 */',
        'table.el-table__header th:first-child {',
        '  position: sticky !important;',
        '  left: 0 !important;',
        '  z-index: 5 !important;',
        '  background-color: #d9d9d9 !important;',
        '}',
        'table.el-table__header th:nth-child(2) {',
        '  position: sticky !important;',
        '  left: 44px !important;',
        '  z-index: 5 !important;',
        '  background-color: #d9d9d9 !important;',
        '  box-shadow: 2px 0 4px -2px rgba(0,0,0,0.12);',
        '}',
        'table.el-table__body td:first-child {',
        '  position: sticky !important;',
        '  left: 0 !important;',
        '  z-index: 2 !important;',
        '}',
        'table.el-table__body td:nth-child(2) {',
        '  position: sticky !important;',
        '  left: 44px !important;',
        '  z-index: 2 !important;',
        '  box-shadow: 2px 0 4px -2px rgba(0,0,0,0.12);',
        '}',
        '.el-table__body tr:nth-child(odd) td:first-child,',
        '.el-table__body tr:nth-child(odd) td:nth-child(2) {',
        '  background-color: #ffffff !important;',
        '}',
        '.el-table__body tr:nth-child(even) td:first-child,',
        '.el-table__body tr:nth-child(even) td:nth-child(2) {',
        '  background-color: #f7f9fc !important;',
        '}',
        '.el-table__body tr:hover td:first-child,',
        '.el-table__body tr:hover td:nth-child(2),',
        '.el-table__body tr.hover-row td:first-child,',
        '.el-table__body tr.hover-row td:nth-child(2) {',
        '  background-color: #e8f1fb !important;',
        '}'
      ].join('\n');

      var styleEl = document.createElement('style');
      styleEl.id = D.skin.styleId;
      styleEl.setAttribute('data-dbsext-skin', '1');
      styleEl.textContent = css;

      document.head.appendChild(styleEl);
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
