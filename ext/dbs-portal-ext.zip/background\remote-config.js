(function (global) {
  'use strict';

  var DBSEXT_REMOTE_CONFIG = {
    // ECDSA P-256 (SPKI base64) 公開鍵。manifest.json の key とは別物。
    PUBLIC_KEY_SPKI_B64: 'MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEeE0kYEv9aumreoYMw/0Ascm6PhfhWvfCmd5wjcgzdU80YwHgU2Sm4+RratZRsj/rwWMskqEILFoyYCGPjA7lCg==',
    LATEST_URL: 'https://dontsu87.github.io/DBSgetdata/ext/remote/latest.json',
    BASE_URL: 'https://dontsu87.github.io/DBSgetdata/ext/remote/',
    USER_SCRIPT_ID: 'dbsext-remote',
    USER_SCRIPT_MATCHES: ['https://mg.docomo-cycle.jp/*']
  };

  global.DBSEXT_REMOTE_CONFIG = DBSEXT_REMOTE_CONFIG;
})(typeof globalThis !== 'undefined' ? globalThis : self);
