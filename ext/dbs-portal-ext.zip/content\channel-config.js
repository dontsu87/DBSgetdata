(function(global){'use strict';global.DBSEXT_CHANNEL=Object.freeze({"name":"production","label":""});})(typeof globalThis!=='undefined'?globalThis:self);
