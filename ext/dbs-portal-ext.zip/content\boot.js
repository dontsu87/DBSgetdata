/**
 * 起動役。**content script 版と user script 版で共有している。**
 *
 * ---------------------------------------------------------------------------
 * なぜ「問い合わせ」で起動を決めるのか（2026-08-10 実機で判明した不具合）
 * ---------------------------------------------------------------------------
 *
 * 配信版（user script）と同梱版（content script）を安全のため併走させていたが、
 * **content_scripts は静的登録で必ず先に走る**ため、次の順序になっていた。
 *
 *   1. 同梱版が先に boot() し、`document.body` に `data-dbsext` の印を立てる
 *   2. 後から動く配信版は `isApplied()` が真になり、**何もせず終わる**
 *
 * 結果、**配信されたコードが一度も使われない**。
 * 実機では取得・署名検証・登録がすべて成功していたのに、動いていたのは同梱版だった。
 * 自動テストは全部通っていた。実機で1回動かすまで分からなかった。
 *
 * **タイミングの競争に任せてはいけない。** どちらが起動するかを明示的に決める。
 *
 *   - user script 版 … 常に即起動する（こちらが本命）
 *   - content script 版 … user script が登録済みなら**起動しない**。
 *                          登録されていなければ起動する（安全網）
 *
 * **答えが返らないときは起動する。** service worker が寝ている・失敗した場合に
 * 画面に何も出ないのが最悪であるため、迷ったら「動かす」側へ倒す。
 * 二重適用は `core.boot()` の冪等ガードが防ぐ。
 */
(function (global) {
  'use strict';

  var D = global.DBSEXT;
  if (!D || !D.core) return;

  // service worker の応答を待つ上限。これを過ぎたら起動する
  var ASK_TIMEOUT_MS = 1500;

  function boot() {
    try {
      D.core.boot();
    } catch (e) {
      if (D.core && typeof D.core.log === 'function') {
        D.core.log('boot 失敗: ' + (e && e.message ? e.message : e), true);
      }
    }
  }

  // user script 版はこの印を持つ（platform-userscript.js が付ける）。
  // 本命なので待たずに起動する。
  if (D.platform && D.platform.isUserScript) {
    boot();
    return;
  }

  // ここから下は content script 版。
  // 配信版が登録されているなら、こちらは起動しない。
  if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
    boot();
    return;
  }

  var settled = false;
  function decide(shouldBoot) {
    if (settled) return;
    settled = true;
    if (shouldBoot) {
      boot();
    } else if (D.core && typeof D.core.log === 'function') {
      D.core.log('配信版（user script）が登録済みのため、同梱版は起動しません');
    }
  }

  // 応答が無いまま放置されないよう、必ず打ち切る
  setTimeout(function () { decide(true); }, ASK_TIMEOUT_MS);

  try {
    chrome.runtime.sendMessage({ type: 'dbsext:shouldContentBoot' }, function (res) {
      // 応答が取れなければ（拡張が寝ている等）起動側へ倒す
      if (chrome.runtime.lastError || !res || typeof res.shouldBoot !== 'boolean') {
        decide(true);
        return;
      }
      decide(res.shouldBoot);
    });
  } catch (e) {
    decide(true);
  }
})(typeof globalThis !== 'undefined' ? globalThis : window);
