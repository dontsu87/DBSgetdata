(function (global) {
  'use strict';
  if (global.DBSEXT && global.DBSEXT.core) {
    global.DBSEXT.core.boot();
  }
})(typeof globalThis !== 'undefined' ? globalThis : window);
