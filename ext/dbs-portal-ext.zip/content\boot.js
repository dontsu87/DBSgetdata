/**
 * 起動役。**content script 版と user script 版で共有している。**
 *
 * ---------------------------------------------------------------------------
 * どちらが起動するかの決め方（2026-08-10 実機で2回失敗して確定した形）
 * ---------------------------------------------------------------------------
 *
 * 【1回目の失敗】両方を無条件に起動させていた
 *   content_scripts は静的登録で必ず先に走るため、同梱版が先に印を立て、
 *   配信版は「適用済み」と判断して何もせず終わる。
 *   → **配信されたコードが一度も実行されなかった。**
 *
 * 【2回目の失敗】service worker に「配信版が登録済みか」を問い合わせた
 *   登録が残っているのに実際には注入されない状態だと、
 *   同梱版が遠慮したまま配信版も動かず、**画面が素のポータルのままになった。**
 *   「登録されている」ことと「実際に動いた」ことは別物である。
 *
 * 【現在の形】**実際に起動したかどうかだけを見る**
 *   - user script 版 … 常に即起動する（こちらが本命）
 *   - content script 版 … 少し待ち、**まだ誰も起動していなければ**起動する
 *
 * 登録情報のような間接的な根拠に頼らない。`core.isApplied()` は
 * `document.body` の印を見るので、**実際に起動したときだけ真になる**。
 * これなら配信版が動かなくても、同梱版が必ず引き受ける。
 *
 * 待ち時間ぶん表示が遅れるが、**画面に何も出ないことに比べれば軽い**。
 */
(function (global) {
  'use strict';

  var D = global.DBSEXT;
  if (!D || !D.core) return;

  // 配信版（user script）の起動を待つ時間。
  // 両方とも document_idle で走るが、配信版の注入がわずかに遅れることがある。
  var WAIT_FOR_USER_SCRIPT_MS = 600;

  function boot() {
    try {
      D.core.boot();
    } catch (e) {
      if (typeof D.core.log === 'function') {
        D.core.log('boot 失敗: ' + (e && e.message ? e.message : e), true);
      }
    }
  }

  // user script 版はこの印を持つ（platform-userscript.js が付ける）。
  // 本命なので待たずに起動する。
  if (D.platform && D.platform.isUserScript) {
    boot();
    return;
  }

  // ここから下は content script 版（同梱）。
  // 配信版が先に起動していれば、こちらは何もしない。
  if (typeof setTimeout !== 'function') {
    boot();
    return;
  }

  setTimeout(function () {
    var applied = false;
    try {
      applied = D.core.isApplied();
    } catch (e) {
      applied = false;
    }

    if (applied) {
      if (typeof D.core.log === 'function') {
        D.core.log('配信版が起動済みのため、同梱版は起動しません');
      }
      return;
    }
    boot();
  }, WAIT_FOR_USER_SCRIPT_MS);
})(typeof globalThis !== 'undefined' ? globalThis : window);
