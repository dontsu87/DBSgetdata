(function () {
  'use strict';

  // 開いてよいURLの許可リスト。
  // content script からのメッセージしか届かない想定だが、URLをそのまま
  // chrome.tabs.create / storage へ渡すのは避ける（多層防御）。
  // sidepanel.js の ALLOWED_PREFIX と同じ値を保つこと。
  var ALLOWED_PREFIX = 'https://dontsu87.github.io/';

  function isAllowedUrl(url) {
    return typeof url === 'string' && url.indexOf(ALLOWED_PREFIX) === 0;
  }

  function initSidePanelBehavior() {
    if (chrome.sidePanel && typeof chrome.sidePanel.setPanelBehavior === 'function') {
      try {
        chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(function () {});
      } catch (e) {
        // Safe fallback if API is not supported in environment
      }
    }
  }

  chrome.runtime.onInstalled.addListener(function () {
    initSidePanelBehavior();
  });

  initSidePanelBehavior();

  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (!message || typeof message.type !== 'string') {
      return false;
    }

    if (message.type === 'dbsext:areas') {
      fetch('https://mg.docomo-cycle.jp/api/areas', { credentials: 'include' })
        .then(function (res) {
          if (!res.ok) {
            throw new Error('HTTP ' + res.status);
          }
          return res.json();
        })
        .then(function (body) {
          var areas = [];
          if (Array.isArray(body)) {
            areas = body;
          } else if (body && Array.isArray(body.dataList)) {
            areas = body.dataList;
          } else if (body && Array.isArray(body.items)) {
            areas = body.items;
          } else if (body && Array.isArray(body.data)) {
            areas = body.data;
          }
          sendResponse({ ok: true, areas: areas });
        })
        .catch(function (err) {
          sendResponse({ ok: false, error: err.message || String(err) });
        });
      return true;
    }

    if (message.type === 'dbsext:openTab') {
      if (!isAllowedUrl(message.url)) {
        sendResponse({ ok: false, error: '許可されていないURLです' });
        return true;
      }
      chrome.tabs.create({ url: message.url }, function () {
        sendResponse({ ok: true });
      });
      return true;
    }

    if (message.type === 'dbsext:openSplit') {
      if (!isAllowedUrl(message.url)) {
        sendResponse({ ok: false, error: '許可されていないURLです' });
        return true;
      }
      var windowId = (sender && sender.tab) ? sender.tab.windowId : undefined;
      chrome.storage.session.set({ dbsextMapUrl: message.url })
        .then(function () {
          if (windowId !== undefined && chrome.sidePanel && typeof chrome.sidePanel.open === 'function') {
            return chrome.sidePanel.open({ windowId: windowId });
          } else {
            throw new Error('No windowId');
          }
        })
        .then(function () {
          sendResponse({ ok: true });
        })
        .catch(function () {
          sendResponse({
            ok: false,
            error: 'サイドパネルを開けませんでした。拡張機能のアイコンをクリックしてください'
          });
        });
      return true;
    }

    return false;
  });
})();
