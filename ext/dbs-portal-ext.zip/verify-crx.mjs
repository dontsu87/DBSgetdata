import fs from 'node:fs';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '../..');
const KEY_PATH = path.resolve(projectRoot, 'dist/extension/dbs-portal-ext.pem');

function verifyCrx(crxPath) {
  console.log('=== CRX V3 検証 ===\n');
  console.log('ファイル:', crxPath);
  
  const data = fs.readFileSync(crxPath);
  console.log('ファイルサイズ:', data.length, 'bytes\n');
  
  // ヘッダー解析
  const magic = data.slice(0, 4).toString('ascii');
  const version = data.readUInt32LE(4);
  const headerLen = data.readUInt32LE(8);
  
  console.log('マジック:', magic, magic === 'Cr24' ? '✓' : '✗');
  console.log('バージョン:', version, version === 3 ? '✓' : '✗');
  console.log('protobuf長:', headerLen, 'bytes\n');
  
  if (magic !== 'Cr24') {
    console.error('エラー: マジックが正しくありません');
    return false;
  }
  if (version !== 3) {
    console.error('エラー: V3形式ではありません');
    return false;
  }
  
  // protobuf解析
  const protoData = data.slice(12, 12 + headerLen);
  const zipData = data.slice(12 + headerLen);
  
  console.log('ZIPサイズ:', zipData.length, 'bytes\n');
  
  // protobufデコード
  let offset = 0;
  let publicKey = null;
  let signature = null;
  let sigVersion = null;
  
  function decodeVarint(data, offset) {
    let value = 0;
    let shift = 0;
    while (offset < data.length) {
      const byte = data[offset];
      value |= (byte & 0x7f) << shift;
      offset++;
      if ((byte & 0x80) === 0) break;
      shift += 7;
    }
    return { value, offset };
  }
  
  function decodeField(data, offset) {
    const { value: tag, offset: newOffset } = decodeVarint(data, offset);
    const fieldNumber = tag >> 3;
    const wireType = tag & 0x07;
    
    if (wireType === 2) {
      // length-delimited
      const { value: length, offset: lenOffset } = decodeVarint(data, newOffset);
      const fieldData = data.slice(lenOffset, lenOffset + length);
      return { fieldNumber, wireType, data: fieldData, offset: lenOffset + length };
    } else if (wireType === 0) {
      // varint
      const { value, offset: newOffset2 } = decodeVarint(data, newOffset);
      return { fieldNumber, wireType, value, offset: newOffset2 };
    }
    
    throw new Error('Unknown wire type: ' + wireType);
  }
  
  while (offset < protoData.length) {
    try {
      const field = decodeField(protoData, offset);
      offset = field.offset;
      
      if (field.fieldNumber === 1 && field.wireType === 2) {
        publicKey = field.data;
        console.log('フィールド 1 (public key):', publicKey.length, 'bytes');
      } else if (field.fieldNumber === 2 && field.wireType === 2) {
        signature = field.data;
        console.log('フィールド 2 (signature):', signature.length, 'bytes');
      } else if (field.fieldNumber === 3 && field.wireType === 0) {
        sigVersion = field.value;
        console.log('フィールド 3 (signature_version):', sigVersion);
      } else {
        console.log('不明なフィールド:', field.fieldNumber, 'wire type:', field.wireType);
      }
    } catch (e) {
      console.error('protobufデコードエラー:', e.message);
      break;
    }
  }
  
  console.log();
  
  // 検証
  let valid = true;
  
  if (!publicKey) {
    console.error('✗ public key が見つかりません');
    valid = false;
  } else {
    console.log('✓ public key あり');
  }
  
  if (!signature) {
    console.error('✗ signature が見つかりません');
    valid = false;
  } else {
    console.log('✓ signature あり');
  }
  
  if (sigVersion !== 1) {
    console.error('✗ signature_version が 1 ではありません:', sigVersion);
    valid = false;
  } else {
    console.log('✓ signature_version = 1 (SHA256)');
  }
  
  // 署名検証
  if (publicKey && signature) {
    console.log('\n=== 署名検証 ===\n');
    
    // 鍵を読み込む
    if (!fs.existsSync(KEY_PATH)) {
      console.error('秘密鍵が見つかりません:', KEY_PATH);
      return false;
    }
    
    const pem = fs.readFileSync(KEY_PATH, 'utf-8');
    const privKey = crypto.createPrivateKey(pem);
    const pubKey = crypto.createPublicKey(privKey);
    const expectedPubKey = pubKey.export({ type: 'spki', format: 'der' });
    
    // 公開鍵の一致確認
    const pubKeyMatch = publicKey.equals(expectedPubKey);
    console.log('公開鍵の一致:', pubKeyMatch ? '✓' : '✗');
    if (!pubKeyMatch) {
      console.error('  CRX内の公開鍵と秘密鍵から生成される公開鍵が一致しません');
      valid = false;
    }
    
    // 署名検証
    const verify = crypto.createVerify('RSA-SHA256');
    verify.update(zipData);
    const sigValid = verify.verify(pubKey, signature);
    console.log('署名の検証:', sigValid ? '✓' : '✗');
    if (!sigValid) {
      console.error('  ZIPデータの署名が正しくありません');
      valid = false;
    }
  }
  
  console.log('\n=== 結果 ===\n');
  if (valid) {
    console.log('✓ CRX V3 形式は正しいです');
  } else {
    console.error('✗ CRX V3 形式に問題があります');
  }
  
  return valid;
}

const crxPath = process.argv[2];
if (!crxPath) {
  console.error('使用法: node verify-crx.mjs <crxファイルパス>');
  process.exit(1);
}

const valid = verifyCrx(crxPath);
process.exit(valid ? 0 : 1);