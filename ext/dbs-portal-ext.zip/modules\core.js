/**
 * DBSEXT コアモジュール
 * ライフサイクル管理、冪等性制御、DOM変更監視、ログ出力を担当
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var observer = null;
  var contentCallbacks = [];
  var debounceTimer = null;
  // 自前のDOM操作中は監視を止めるための入れ子カウンタ
  var applying = 0;

  // **自前のUIそのもの**だけを列挙する。
  // ここに `[data-dbsext]`(bodyの適用済みマーカー)や `[data-dbsext-tabled]`
  // (ポータルのテーブルに目印を付けただけのもの)を入れてはいけない。
  // 入れると、その配下で起きるポータル由来の変化まで「自分の変更」と誤判定し、
  // SPA遷移後に table-tools が二度と再適用されなくなる。
  var OWN_UI_SELECTOR = [
    '[data-dbsext-upsell]',
    '[data-dbsext-launcher]',
    '[data-dbsext-launcher-panel]',
    '[data-dbsext-skin]'
  ].join(',');

  function hasOwnAttribute(node) {
    if (!node || node.nodeType !== 1 || !node.attributes) return false;
    for (var i = 0; i < node.attributes.length; i++) {
      var name = node.attributes[i].name;
      // 末尾のハイフンが要る。`data-dbsext`(bodyのマーカー)は自前UIではない
      if (name.indexOf('data-dbsext-') === 0) return true;
    }
    return false;
  }

  /** その要素が自前UIの一部か。祖先は自前UIのホストまでしか遡らない。 */
  function isOwnUi(node) {
    if (!node || node.nodeType !== 1) return false;
    if (hasOwnAttribute(node)) return true;
    return typeof node.closest === 'function' && !!node.closest(OWN_UI_SELECTOR);
  }

  /** その変化が自分の仕業か。追加・削除されたノードが全部自前UIなら自分の仕業とみなす。 */
  function isOwnMutation(mutation) {
    if (isOwnUi(mutation.target)) return true;
    var added = mutation.addedNodes || [];
    var removed = mutation.removedNodes || [];
    if (added.length === 0 && removed.length === 0) return false;
    for (var i = 0; i < added.length; i++) {
      if (added[i].nodeType === 1 && !isOwnUi(added[i])) return false;
    }
    for (var j = 0; j < removed.length; j++) {
      if (removed[j].nodeType === 1 && !isOwnUi(removed[j])) return false;
    }
    return true;
  }

  /**
   * 自前のDOM操作を包む。
   * 操作中に発生した変化は takeRecords() で捨て、監視ループに戻さない。
   * これが無いと table-tools の並べ替えが自分自身を再発火させ続ける。
   */
  function runSuppressed(name, fn) {
    applying++;
    try {
      fn();
    } catch (e) {
      D.core.log(name + ' エラー: ' + (e && e.message ? e.message : e), true);
    } finally {
      if (observer && typeof observer.takeRecords === 'function') {
        observer.takeRecords();
      }
      applying--;
    }
  }

  D.core = {
    /**
     * 統一ログ出力
     * @param {string} message ログメッセージ
     * @param {boolean} [isError] エラーまたは警告の場合はtrue
     */
    log: function (message, isError) {
      var formatted = '[dbsext] ' + message;
      if (isError) {
        console.warn(formatted);
      } else {
        console.log(formatted);
      }
    },

    /**
     * すでに拡張が適用済みか確認
     * @returns {boolean}
     */
    isApplied: function () {
      if (typeof document === 'undefined' || !document.body) {
        return false;
      }
      return document.body.hasAttribute(D.CONFIG.MARKER_ATTR);
    },

    /**
     * 拡張の起動（冪等）
     */
    boot: function () {
      if (D.core.isApplied()) {
        D.core.log('既に適用済み');
        return;
      }

      if (typeof document !== 'undefined' && document.body) {
        document.body.setAttribute(D.CONFIG.MARKER_ATTR, D.VERSION);
      }

      // 各モジュールの順次適用（失敗しても個別catchで後続を継続）
      var moduleOrder = [
        { name: 'skin', target: function () { return D.skin; } },
        { name: 'tableWrap', target: function () { return D.tableWrap; } },
        { name: 'uiTweaks', target: function () { return D.uiTweaks; } },
        { name: 'upsell', target: function () { return D.upsell; } },
        { name: 'mapLauncher', target: function () { return D.mapLauncher; } },
        { name: 'tableTools', target: function () { return D.tableTools; } }
      ];

      // 先に監視を張ってから適用する。適用中の変化は runSuppressed が捨てる
      D.core.onContentChange(function () {
        if (D.tableWrap && typeof D.tableWrap.apply === 'function') {
          runSuppressed('tableWrap.apply 再適用', function () { D.tableWrap.apply(); });
        }
      });
      D.core.onContentChange(function () {
        if (D.uiTweaks && typeof D.uiTweaks.apply === 'function') {
          runSuppressed('uiTweaks.apply 再適用', function () { D.uiTweaks.apply(); });
        }
      });
      D.core.onContentChange(function () {
        if (D.tableTools && typeof D.tableTools.apply === 'function') {
          runSuppressed('tableTools.apply 再適用', function () { D.tableTools.apply(); });
        }
      });

      for (var i = 0; i < moduleOrder.length; i++) {
        var item = moduleOrder[i];
        var mod = item.target();
        if (mod && typeof mod.apply === 'function') {
          (function (name, target) {
            runSuppressed(name + '.apply', function () { target.apply(); });
          })(item.name, mod);
        }
      }
    },

    /**
     * コンテンツ領域の変更監視（200ms デバウンス、自前要素の変化は除外）
     * @param {function} callback
     */
    onContentChange: function (callback) {
      if (typeof callback === 'function') {
        contentCallbacks.push(callback);
      }

      if (observer || typeof MutationObserver === 'undefined' || typeof document === 'undefined' || !document.body) {
        return;
      }

      observer = new MutationObserver(function (mutations) {
        // 自前のDOM操作の最中に来た通知は無視する
        if (applying > 0) {
          return;
        }

        var hasExternalChange = false;
        for (var i = 0; i < mutations.length; i++) {
          if (!isOwnMutation(mutations[i])) {
            hasExternalChange = true;
            break;
          }
        }

        if (!hasExternalChange) {
          return;
        }

        if (debounceTimer) {
          clearTimeout(debounceTimer);
        }
        debounceTimer = setTimeout(function () {
          debounceTimer = null;
          for (var k = 0; k < contentCallbacks.length; k++) {
            try {
              contentCallbacks[k]();
            } catch (e) {
              D.core.log('onContentChange コールバックエラー: ' + (e && e.message ? e.message : e), true);
            }
          }
        }, 200);
      });

      observer.observe(document.body, { childList: true, subtree: true });
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);