/**
 * DBSEXT コアモジュール
 * ライフサイクル管理、冪等性制御、DOM変更監視、ログ出力を担当
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var observer = null;
  var contentCallbacks = [];
  var debounceTimer = null;
  // 自前のDOM操作中は監視を止めるための入れ子カウンタ
  var applying = 0;

  // **自前のUIそのもの**だけを列挙する。
  // ここに `[data-dbsext]`(bodyの適用済みマーカー)や `[data-dbsext-tabled]`
  // (ポータルのテーブルに目印を付けただけのもの)を入れてはいけない。
  // 入れると、その配下で起きるポータル由来の変化まで「自分の変更」と誤判定し、
  // SPA遷移後に table-tools が二度と再適用されなくなる。
  var OWN_UI_SELECTOR = [
    '[data-dbsext-upsell]',
    '[data-dbsext-launcher]',
    '[data-dbsext-launcher-panel]',
    '[data-dbsext-skin]',
    '[data-dbsext-net-status]',
    '[data-dbsext-state-forms]',
    '[data-dbsext-table-columns]'
  ].join(',');

  // **ポータルの要素に付けた「目印」**。自前UIではない。
  //
  // 拡張は自分が作った要素にも、ポータルの既存要素にも `data-dbsext-*` を付ける。
  // 前者は自前UI（その中の変化は自分の仕業）だが、**後者はポータルの要素であり、
  // その中で起きる変化は外部の変化である**。
  //
  // ここを区別せず「`data-dbsext-` で始まる属性があれば自前UI」と判定すると、
  // `.el-table`（`data-dbsext-tabled` / `data-dbsext-wrap` が付く）を対象にした
  // MutationRecord が全部「自分の仕業」になり、**SPAが表を差し替えても
  // table-tools が再適用されない**。過去に同じ性質の欠陥を1件出している
  // （`isDbsextNode` が祖先を遡り、body配下すべてを自前と誤判定していた）。
  // **`data-dbsext-*` 属性の分類表。新しい属性を足したら、必ずここに登録する。**
  //
  //   'own'    … 拡張が作った要素に付ける（その中の変化は自分の仕業）
  //   'mark'   … **ポータルの既存要素**に付ける目印（中の変化は外部の変化）
  //
  // 登録漏れは `verify.mjs` が落とす。分類を間違えると、
  // 「SPAで表が差し替わっても再適用されない」または「自己発火で無限ループ」になる。
  var ATTR_KIND = {
    // --- 自前UI ---
    'data-dbsext-upsell': 'own',
    'data-dbsext-launcher': 'own',
    'data-dbsext-launcher-panel': 'own',
    'data-dbsext-skin': 'own',
    'data-dbsext-net-status': 'own',
    'data-dbsext-loading-mask': 'own',
    'data-dbsext-top-indicator': 'own',
    'data-dbsext-error-banner': 'own',
    'data-dbsext-state-forms': 'own',
    'data-dbsext-table-columns': 'own',
    'data-dbsext-action-toggle': 'own',
    'data-dbsext-sort': 'own',
    'data-dbsext-filter': 'own',
    'data-dbsext-collapse-hint': 'own',

    // --- ポータル要素に付けた目印（自前UIではない） ---
    'data-dbsext-tabled': 'mark',      // table-tools が .el-table に付ける
    'data-dbsext-wrap': 'mark',        // table-wrap が .el-table に付ける
    'data-dbsext-orig-title': 'mark',  // table-tools が th に控える元の列名
    'data-dbsext-orig-width': 'mark',        // table-columns が col に控える元の幅
    'data-dbsext-orig-table-width': 'mark',  // table-columns が表に控える元の幅
    'data-dbsext-newtab': 'mark',      // ui-tweaks が一覧の a に付ける処理済み印
    'data-dbsext-collapsed': 'mark'    // ui-tweaks が折りたたみ見出しに付ける処理済み印
  };

  function hasOwnAttribute(node) {
    if (!node || node.nodeType !== 1 || !node.attributes) return false;
    for (var i = 0; i < node.attributes.length; i++) {
      var name = node.attributes[i].name;
      // 末尾のハイフンが要る。`data-dbsext`(bodyのマーカー)は自前UIではない
      if (name.indexOf('data-dbsext-') !== 0) continue;
      // ポータル要素に付けた目印は「自前UIである」根拠にならない
      if (ATTR_KIND[name] === 'mark') continue;
      return true;
    }
    return false;
  }

  /** その要素が自前UIの一部か。祖先は自前UIのホストまでしか遡らない。 */
  function isOwnUi(node) {
    if (!node || node.nodeType !== 1) return false;
    if (hasOwnAttribute(node)) return true;
    return typeof node.closest === 'function' && !!node.closest(OWN_UI_SELECTOR);
  }

  /** その変化が自分の仕業か。追加・削除されたノードが全部自前UIなら自分の仕業とみなす。 */
  function isOwnMutation(mutation) {
    if (isOwnUi(mutation.target)) return true;
    var added = mutation.addedNodes || [];
    var removed = mutation.removedNodes || [];
    if (added.length === 0 && removed.length === 0) return false;

    // **要素ノードを1つも見なかったときに「自分の仕業」と言ってはいけない。**
    // テキストノードだけが差し替わる変化（ポータルが textContent を更新した等）は
    // 外部の変化である。ここで true を返すと、その変化を契機にした再適用が走らない。
    var sawElement = false;
    for (var i = 0; i < added.length; i++) {
      if (added[i].nodeType !== 1) continue;
      sawElement = true;
      if (!isOwnUi(added[i])) return false;
    }
    for (var j = 0; j < removed.length; j++) {
      if (removed[j].nodeType !== 1) continue;
      sawElement = true;
      if (!isOwnUi(removed[j])) return false;
    }
    return sawElement;
  }

  /**
   * 自前のDOM操作を包む。
   * 操作中に発生した変化は takeRecords() で捨て、監視ループに戻さない。
   * これが無いと table-tools の並べ替えが自分自身を再発火させ続ける。
   */
  function runSuppressed(name, fn) {
    applying++;
    try {
      fn();
    } catch (e) {
      D.core.log(name + ' エラー: ' + (e && e.message ? e.message : e), true);
    } finally {
      if (observer && typeof observer.takeRecords === 'function') {
        observer.takeRecords();
      }
      applying--;
    }
  }

  D.core = {
    /**
     * 統一ログ出力
     * @param {string} message ログメッセージ
     * @param {boolean} [isError] エラーまたは警告の場合はtrue
     */
    log: function (message, isError) {
      var formatted = '[dbsext] ' + message;
      if (isError) {
        console.warn(formatted);
      } else {
        console.log(formatted);
      }
    },

    /**
     * すでに拡張が適用済みか確認
     * @returns {boolean}
     */
    isApplied: function () {
      if (typeof document === 'undefined' || !document.body) {
        return false;
      }
      return document.body.hasAttribute(D.CONFIG.MARKER_ATTR);
    },

    /**
     * 拡張の起動（冪等）
     */
    boot: function () {
      if (D.core.isApplied()) {
        D.core.log('既に適用済み');
        return;
      }

      if (typeof document !== 'undefined' && document.body) {
        document.body.setAttribute(D.CONFIG.MARKER_ATTR, D.VERSION);
      }

      // 各モジュールの順次適用（失敗しても個別catchで後続を継続）
      var moduleOrder = [
        { name: 'skin', target: function () { return D.skin; } },
        { name: 'stateStore', target: function () { return D.stateStore; } },
        { name: 'stateForms', target: function () { return D.stateForms; } },
        { name: 'netStatus', target: function () { return D.netStatus; } },
        { name: 'tableWrap', target: function () { return D.tableWrap; } },
        { name: 'uiTweaks', target: function () { return D.uiTweaks; } },
        { name: 'upsell', target: function () { return D.upsell; } },
        { name: 'mapLauncher', target: function () { return D.mapLauncher; } },
        { name: 'tableColumns', target: function () { return D.tableColumns; } },
        { name: 'tableTools', target: function () { return D.tableTools; } }
      ];

      // 先に監視を張ってから適用する。適用中の変化は runSuppressed が捨てる
      D.core.onContentChange(function () {
        if (D.stateForms && typeof D.stateForms.apply === 'function') {
          runSuppressed('stateForms.apply 再適用', function () { D.stateForms.apply(); });
        }
      });
      D.core.onContentChange(function () {
        if (D.netStatus && typeof D.netStatus.apply === 'function') {
          runSuppressed('netStatus.apply 再適用', function () { D.netStatus.apply(); });
        }
      });
      D.core.onContentChange(function () {
        if (D.tableWrap && typeof D.tableWrap.apply === 'function') {
          runSuppressed('tableWrap.apply 再適用', function () { D.tableWrap.apply(); });
        }
      });
      D.core.onContentChange(function () {
        if (D.uiTweaks && typeof D.uiTweaks.apply === 'function') {
          runSuppressed('uiTweaks.apply 再適用', function () { D.uiTweaks.apply(); });
        }
      });
      // body直下の固定要素（消えないはず）だが、冪等なので保険として再適用しておく。
      // 「boot時1回だけ」がボタン消失の原因だったため、同じ落とし穴を残さない。
      D.core.onContentChange(function () {
        if (D.mapLauncher && typeof D.mapLauncher.apply === 'function') {
          runSuppressed('mapLauncher.apply 再適用', function () { D.mapLauncher.apply(); });
        }
        if (D.upsell && typeof D.upsell.apply === 'function') {
          runSuppressed('upsell.apply 再適用', function () { D.upsell.apply(); });
        }
      });
      D.core.onContentChange(function () {
        if (D.tableColumns && typeof D.tableColumns.apply === 'function') {
          runSuppressed('tableColumns.apply 再適用', function () { D.tableColumns.apply(); });
        }
      });
      D.core.onContentChange(function () {
        if (D.tableTools && typeof D.tableTools.apply === 'function') {
          runSuppressed('tableTools.apply 再適用', function () { D.tableTools.apply(); });
        }
      });

      for (var i = 0; i < moduleOrder.length; i++) {
        var item = moduleOrder[i];
        var mod = item.target();
        if (mod && typeof mod.apply === 'function') {
          (function (name, target) {
            runSuppressed(name + '.apply', function () { target.apply(); });
          })(item.name, mod);
        }
      }
    },

    /**
     * コンテンツ領域の変更監視（200ms デバウンス、自前要素の変化は除外）
     * @param {function} callback
     */
    onContentChange: function (callback) {
      if (typeof callback === 'function') {
        contentCallbacks.push(callback);
      }

      if (observer || typeof MutationObserver === 'undefined' || typeof document === 'undefined' || !document.body) {
        return;
      }

      observer = new MutationObserver(function (mutations) {
        // 自前のDOM操作の最中に来た通知は無視する
        if (applying > 0) {
          return;
        }

        var hasExternalChange = false;
        for (var i = 0; i < mutations.length; i++) {
          if (!isOwnMutation(mutations[i])) {
            hasExternalChange = true;
            break;
          }
        }

        if (!hasExternalChange) {
          return;
        }

        if (debounceTimer) {
          clearTimeout(debounceTimer);
        }
        debounceTimer = setTimeout(function () {
          debounceTimer = null;
          for (var k = 0; k < contentCallbacks.length; k++) {
            try {
              contentCallbacks[k]();
            } catch (e) {
              D.core.log('onContentChange コールバックエラー: ' + (e && e.message ? e.message : e), true);
            }
          }
        }, 200);
      });

      observer.observe(document.body, { childList: true, subtree: true });
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);