/**
 * DBSEXT テーブルツール（並べ替え・絞り込み）モジュール
 * Element Plus el-table のヘッダに操作UIを追加し、並べ替え・絞り込みを行う
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var tableStates = {};

  function comparePortKeys(keyA, keyB) {
    if (keyA[0] !== keyB[0]) return keyA[0] - keyB[0];
    if (keyA[1] !== keyB[1]) return keyA[1].localeCompare(keyB[1]);
    if (keyA[2] !== keyB[2]) return keyA[2] - keyB[2];
    return keyA[3].localeCompare(keyB[3], undefined, { numeric: true, sensitivity: 'base' });
  }

  function portSortKey(name) {
    if (name === null || name === undefined) {
      return [1, '', 0, ''];
    }
    var str = String(name);
    var trimmed = str.trim();
    var m = trimmed.match(/^\s*([A-Za-z]*)-?(\d+)/);
    if (m) {
      var letters = m[1].toUpperCase();
      var num = Number(m[2]);
      return [0, letters, num, str];
    } else {
      return [1, '', 0, str];
    }
  }

  function applyFilterAndSort(table, state, ths) {
    var bodyTable = table.querySelector('table.el-table__body');
    if (!bodyTable) return;

    var tbody = bodyTable.querySelector('tbody');
    if (!tbody) return;

    var trs = bodyTable.querySelectorAll('tbody tr');
    if (trs.length === 0) return;

    var trArray = Array.prototype.slice.call(trs);

    // 1. 絞り込み処理
    var hasActiveFilter = false;
    for (var fCol in state.filterValues) {
      if (state.filterValues[fCol] && state.filterValues[fCol].length > 0) {
        hasActiveFilter = true;
        break;
      }
    }

    for (var i = 0; i < trArray.length; i++) {
      var tr = trArray[i];
      var show = true;
      if (hasActiveFilter) {
        var cells = tr.children;
        for (var colIdxStr in state.filterValues) {
          var filterVal = state.filterValues[colIdxStr];
          if (filterVal && filterVal.length > 0) {
            var colIdx = Number(colIdxStr);
            var cell = cells[colIdx];
            var cellText = cell ? cell.textContent.trim() : '';
            if (cellText.toLowerCase().indexOf(filterVal.toLowerCase()) === -1) {
              show = false;
              break;
            }
          }
        }
      }
      tr.style.display = show ? '' : 'none';
    }

    // 2. 並べ替え処理
    if (state.sortColIndex !== null && state.sortColIndex !== undefined) {
      var sortCol = state.sortColIndex;
      var sortOrder = state.sortOrder || 'asc';
      var th = ths[sortCol];
      var colTitle = th ? (th.getAttribute('data-dbsext-orig-title') || th.textContent.trim()) : '';

      var isPortCol = (colTitle === 'ポート名' || colTitle === 'ポート');

      var isAllNumeric = true;
      if (!isPortCol) {
        var validCount = 0;
        for (var j = 0; j < trArray.length; j++) {
          var tdNode = trArray[j].children[sortCol];
          var txt = tdNode ? tdNode.textContent.trim() : '';
          if (txt !== '') {
            validCount++;
            if (isNaN(Number(txt))) {
              isAllNumeric = false;
              break;
            }
          }
        }
        if (validCount === 0) {
          isAllNumeric = false;
        }
      }

      trArray.sort(function (trA, trB) {
        var tdA = trA.children[sortCol];
        var tdB = trB.children[sortCol];
        var textA = tdA ? tdA.textContent.trim() : '';
        var textB = tdB ? tdB.textContent.trim() : '';

        var res = 0;
        if (isPortCol) {
          var keyA = portSortKey(textA);
          var keyB = portSortKey(textB);
          res = comparePortKeys(keyA, keyB);
        } else if (isAllNumeric) {
          var numA = textA === '' ? -Infinity : Number(textA);
          var numB = textB === '' ? -Infinity : Number(textB);
          res = numA - numB;
        } else {
          res = textA.localeCompare(textB, undefined, { numeric: true, sensitivity: 'base' });
        }

        return sortOrder === 'desc' ? -res : res;
      });

      for (var k = 0; k < trArray.length; k++) {
        tbody.appendChild(trArray[k]);
      }
    }
  }

  function updateHeaderUI(ths, state) {
    for (var c = 0; c < ths.length; c++) {
      var th = ths[c];

      // ソート表示更新
      var sortSpan = th.querySelector('[data-dbsext-sort]');
      if (sortSpan) {
        if (state.sortColIndex === c) {
          sortSpan.textContent = state.sortOrder === 'asc' ? ' ▲' : ' ▼';
          sortSpan.style.opacity = '1';
        } else {
          sortSpan.textContent = ' ▲';
          sortSpan.style.opacity = '0.3';
        }
      }

      // 絞り込み入力値同期
      var filterInput = th.querySelector('[data-dbsext-filter]');
      if (filterInput) {
        var savedVal = state.filterValues[c] || '';
        if (filterInput.value !== savedVal) {
          filterInput.value = savedVal;
        }
      }
    }
  }

  D.tableTools = {
    portSortKey: portSortKey,

    apply: function () {
      if (typeof document === 'undefined') return;

      var tables = document.querySelectorAll('.el-table');
      if (!tables || tables.length === 0) return;

      var pathname = (typeof location !== 'undefined') ? location.pathname : '';

      for (var t = 0; t < tables.length; t++) {
        var table = tables[t];
        var headerTable = table.querySelector('table.el-table__header');
        var bodyTable = table.querySelector('table.el-table__body');
        if (!headerTable || !bodyTable) continue;

        var ths = headerTable.querySelectorAll('thead th, th');
        // **行数は見ない。** 行が0件でも列UIはヘッダに付ける。
        // 「先に絞り込み条件を入れてから検索したい」場面で使えないと不便であり、
        // 実機では検索するまで表が空なので、行を待つと一度もUIが付かない。
        if (ths.length === 0) continue;

        var stateKey = pathname + '#' + t;
        if (!tableStates[stateKey]) {
          tableStates[stateKey] = {
            sortColIndex: null,
            sortOrder: null,
            filterValues: {}
          };

          // 初回既定の並べ替え: ポート名またはポートの列があれば昇順1回
          for (var i = 0; i < ths.length; i++) {
            var title = ths[i].getAttribute('data-dbsext-orig-title') || ths[i].textContent.trim();
            if (title === 'ポート名' || title === 'ポート') {
              tableStates[stateKey].sortColIndex = i;
              tableStates[stateKey].sortOrder = 'asc';
              break;
            }
          }
        }

        var state = tableStates[stateKey];
        var isFirstUIBuild = !table.hasAttribute('data-dbsext-tabled');

        if (isFirstUIBuild) {
          table.setAttribute('data-dbsext-tabled', '1');

          for (var c = 0; c < ths.length; c++) {
            (function (colIndex) {
              var th = ths[colIndex];
              var origTitle = th.textContent.trim();
              th.setAttribute('data-dbsext-orig-title', origTitle);

              // ソートトリガー
              var sortSpan = document.createElement('span');
              sortSpan.setAttribute('data-dbsext-sort', '1');
              sortSpan.style.cursor = 'pointer';
              sortSpan.style.userSelect = 'none';
              sortSpan.style.marginLeft = '4px';
              sortSpan.style.fontSize = '11px';
              sortSpan.textContent = ' ▲';
              sortSpan.style.opacity = '0.3';

              sortSpan.addEventListener('click', function (e) {
                e.stopPropagation();
                if (state.sortColIndex === colIndex) {
                  state.sortOrder = (state.sortOrder === 'asc') ? 'desc' : 'asc';
                } else {
                  state.sortColIndex = colIndex;
                  state.sortOrder = 'asc';
                }
                updateHeaderUI(ths, state);
                applyFilterAndSort(table, state, ths);
              });

              // 絞り込み入力
              var filterDiv = document.createElement('div');
              filterDiv.style.marginTop = '4px';

              var filterInput = document.createElement('input');
              filterInput.type = 'text';
              filterInput.setAttribute('data-dbsext-filter', '1');
              filterInput.placeholder = '絞り込み';
              filterInput.style.width = '90%';
              filterInput.style.padding = '2px 4px';
              filterInput.style.fontSize = '11px';
              filterInput.style.border = '1px solid #ccc';
              filterInput.style.borderRadius = '3px';
              filterInput.style.boxSizing = 'border-box';

              filterInput.addEventListener('click', function (e) {
                e.stopPropagation();
              });
              filterInput.addEventListener('keydown', function (e) {
                e.stopPropagation();
              });
              filterInput.addEventListener('input', function () {
                state.filterValues[colIndex] = filterInput.value;
                applyFilterAndSort(table, state, ths);
              });

              th.appendChild(sortSpan);
              filterDiv.appendChild(filterInput);
              th.appendChild(filterDiv);
            })(c);
          }
        }

        updateHeaderUI(ths, state);
        applyFilterAndSort(table, state, ths);
      }
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
