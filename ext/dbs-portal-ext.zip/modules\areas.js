/**
 * DBSEXT エリア・マップURL構築モジュール
 * エリア取得 API 結果からマップアプリのパラメータ付きURLを生成する
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  D.areas = {
    /**
     * エリアリストからマップアプリのURLを組み立てる（同期・純粋関数）
     *
     * **空・null・エリア名を1つも取り出せない場合は null を返す。**
     * ここで `?kanriall`（全エリア）へ落とすと、権限を確認できていない状態で
     * 全エリアの車両を表示してしまう。マップアプリのデータは公開バケット由来で
     * サーバ側の権限フィルタが無いため、これは表示範囲の逸脱になる。
     * 呼び出し側は null を受けたら手動選択を必須にすること。
     *
     * @param {Array<Object|string>|null} areaList
     * @returns {string|null} マップアプリのURL。組み立てられない場合は null
     */
    buildMapUrl: function (areaList) {
      var baseUrl = (D.CONFIG && D.CONFIG.MAP_APP_URL)
        ? D.CONFIG.MAP_APP_URL
        : 'https://dontsu87.github.io/DBSgetdata/';

      var knownAreas = (D.CONFIG && D.CONFIG.KNOWN_AREAS)
        ? D.CONFIG.KNOWN_AREAS
        : ['金沢', '福井', '小松', '敦賀', '上田千曲広域', '出雲・松江・境港'];

      if (!areaList || !Array.isArray(areaList) || areaList.length === 0) {
        return null;
      }

      // エリア名の抽出と重複除去
      var names = [];
      for (var i = 0; i < areaList.length; i++) {
        var item = areaList[i];
        var name = '';
        if (typeof item === 'string') {
          name = item;
        } else if (item && typeof item.areaName === 'string') {
          name = item.areaName;
        }
        if (name && names.indexOf(name) === -1) {
          names.push(name);
        }
      }

      if (names.length === 0) {
        return null;
      }

      // KNOWN_AREAS を全件含んでいるかチェック
      var hasAllKnown = true;
      for (var j = 0; j < knownAreas.length; j++) {
        if (names.indexOf(knownAreas[j]) === -1) {
          hasAllKnown = false;
          break;
        }
      }

      if (hasAllKnown) {
        return baseUrl + '?kanriall';
      }

      // 順序の正規化（KNOWN_AREASの並び順に揃える）
      names.sort(function (a, b) {
        var idxA = knownAreas.indexOf(a);
        var idxB = knownAreas.indexOf(b);
        if (idxA !== -1 && idxB !== -1) return idxA - idxB;
        if (idxA !== -1) return -1;
        if (idxB !== -1) return 1;
        return a.localeCompare(b);
      });

      if (names.length === 1) {
        return baseUrl + '?area=' + encodeURIComponent(names[0]);
      }

      var encodedParams = [];
      for (var k = 0; k < names.length; k++) {
        encodedParams.push(encodeURIComponent(names[k]));
      }

      return baseUrl + '?areas=' + encodedParams.join(',');
    },

    /**
     * D.platform.fetchAreas を呼び出し、エリア情報とURLを返す
     * @returns {Promise<{ok: boolean, areas: Array, url: string, error?: string}>}
     */
    load: function () {
      // 取得できなかったときに全エリアURLへ落とさない（権限未確認で全件を開かない）
      if (!D.platform || typeof D.platform.fetchAreas !== 'function') {
        return Promise.resolve({
          ok: false,
          error: 'D.platform.fetchAreas が利用できません',
          areas: [],
          url: null
        });
      }

      var run = (D.netStatus && D.netStatus.silent) ? D.netStatus.silent : function (f) { return f(); };

      return Promise.resolve()
        .then(function () {
          return run(function () {
            return D.platform.fetchAreas();
          });
        })
        .then(function (areas) {
          var areaArray = Array.isArray(areas) ? areas : [];
          return {
            ok: true,
            areas: areaArray,
            url: D.areas.buildMapUrl(areaArray)
          };
        })
        .catch(function (err) {
          var msg = (err && err.message) ? err.message : String(err);
          return {
            ok: false,
            error: msg,
            areas: [],
            url: null
          };
        });
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
