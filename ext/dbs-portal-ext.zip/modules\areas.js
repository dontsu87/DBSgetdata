/**
 * DBSEXT エリア・マップURL構築モジュール
 * エリア取得 API 結果からマップアプリのパラメータ付きURLを生成する
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  D.areas = {
    /**
     * エリアリストからマップアプリのURLを組み立てる（同期・純粋関数）
     *
     * **空・null・エリア名を1つも取り出せない場合は null を返す。**
     * ここで `?kanriall`（全エリア）へ落とすと、権限を確認できていない状態で
     * 全エリアの車両を表示してしまう。マップアプリのデータは公開バケット由来で
     * サーバ側の権限フィルタが無いため、これは表示範囲の逸脱になる。
     * 呼び出し側は null を受けたら手動選択を必須にすること。
     *
     * @param {Array<Object|string>|null} areaList
     * @returns {string|null} マップアプリのURL。組み立てられない場合は null
     */
    buildMapUrl: function (areaList) {
      var baseUrl = (D.CONFIG && D.CONFIG.MAP_APP_URL)
        ? D.CONFIG.MAP_APP_URL
        : 'https://dontsu87.github.io/DBSgetdata/';

      var knownCodes = (D.CONFIG && D.CONFIG.KNOWN_AREA_CODES)
        ? D.CONFIG.KNOWN_AREA_CODES
        : ['FKI', 'KMT', 'KNZ', 'SNN', 'SPS', 'TRG'];

      if (!areaList || !Array.isArray(areaList) || areaList.length === 0) {
        return null;
      }

      // エリアコードの抽出と重複除去（areaCode 優先、なければ areaName でフォールバック）
      // コードは3文字のASCIIなので encodeURIComponent 不要 → QRコードがシンプルになる
      var nameToCode = (D.CONFIG && D.CONFIG.NAME_TO_CODE)
        ? D.CONFIG.NAME_TO_CODE
        : { '福井': 'FKI', '小松': 'KMT', '金沢': 'KNZ', '上田千曲広域': 'SNN', '出雲・松江・境港': 'SPS', '敦賀': 'TRG' };

      var codes = [];
      for (var i = 0; i < areaList.length; i++) {
        var item = areaList[i];
        var code = '';
        if (typeof item === 'string') {
          // 文字列が渡された場合: コードそのものか、名前からコードへ逆引き
          code = nameToCode[item] || item;
        } else if (item && typeof item.areaCode === 'string' && item.areaCode.length > 0) {
          code = item.areaCode;
        } else if (item && typeof item.areaName === 'string') {
          code = nameToCode[item.areaName] || item.areaName;
        }
        if (code && codes.indexOf(code) === -1) {
          codes.push(code);
        }
      }

      if (codes.length === 0) {
        return null;
      }

      // knownCodes を全件含んでいるかチェック
      var hasAllKnown = true;
      for (var j = 0; j < knownCodes.length; j++) {
        if (codes.indexOf(knownCodes[j]) === -1) {
          hasAllKnown = false;
          break;
        }
      }

      if (hasAllKnown) {
        return baseUrl + '?kanriall';
      }

      // 順序の正規化（knownCodesの並び順に揃える）
      codes.sort(function (a, b) {
        var idxA = knownCodes.indexOf(a);
        var idxB = knownCodes.indexOf(b);
        if (idxA !== -1 && idxB !== -1) return idxA - idxB;
        if (idxA !== -1) return -1;
        if (idxB !== -1) return 1;
        return a.localeCompare(b);
      });

      if (codes.length === 1) {
        return baseUrl + '?area=' + codes[0];
      }

      return baseUrl + '?areas=' + codes.join(',');
    },

    /**
     * D.platform.fetchAreas を呼び出し、エリア情報とURLを返す
     * @returns {Promise<{ok: boolean, areas: Array, url: string, error?: string}>}
     */
    load: function () {
      // 取得できなかったときに全エリアURLへ落とさない（権限未確認で全件を開かない）
      if (!D.platform || typeof D.platform.fetchAreas !== 'function') {
        return Promise.resolve({
          ok: false,
          error: 'D.platform.fetchAreas が利用できません',
          areas: [],
          url: null
        });
      }

      var run = (D.netStatus && D.netStatus.silent) ? D.netStatus.silent : function (f) { return f(); };

      return Promise.resolve()
        .then(function () {
          return run(function () {
            return D.platform.fetchAreas();
          });
        })
        .then(function (areas) {
          var areaArray = Array.isArray(areas) ? areas : [];
          return {
            ok: true,
            areas: areaArray,
            url: D.areas.buildMapUrl(areaArray)
          };
        })
        .catch(function (err) {
          var msg = (err && err.message) ? err.message : String(err);
          return {
            ok: false,
            error: msg,
            areas: [],
            url: null
          };
        });
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
