/**
 * DBSEXT マップ導線モジュール
 * 左メニューにバッテリーマップ起動ボタンを追加し、画面中央にモーダルパネル（Shadow DOM）を開く
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var currentPanelHost = null;

  function closePanel() {
    if (currentPanelHost && currentPanelHost.parentNode) {
      currentPanelHost.parentNode.removeChild(currentPanelHost);
    }
    currentPanelHost = null;
  }

  function createLauncherPanel() {
    closePanel();

    var host = document.createElement('div');
    host.setAttribute('data-dbsext-launcher-panel', '1');
    currentPanelHost = host;

    var shadow = host.attachShadow ? host.attachShadow({ mode: 'open' }) : host;

    // オーバーレイ背景
    var overlay = document.createElement('div');
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100vw';
    overlay.style.height = '100vh';
    overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
    overlay.style.zIndex = '999999';
    overlay.style.display = 'flex';
    overlay.style.alignItems = 'center';
    overlay.style.justifyContent = 'center';
    overlay.style.boxSizing = 'border-box';
    overlay.style.padding = '16px';

    // モーダルカード
    var card = document.createElement('div');
    card.style.backgroundColor = '#ffffff';
    card.style.borderRadius = '8px';
    card.style.padding = '24px';
    card.style.maxWidth = '480px';
    card.style.width = '100%';
    card.style.boxShadow = '0 10px 25px rgba(0, 0, 0, 0.2)';
    card.style.fontFamily = 'sans-serif';
    card.style.color = '#333333';
    card.style.boxSizing = 'border-box';

    // カードクリックでオーバーレイ閉じるイベントを発火させない
    card.addEventListener('click', function (e) {
      e.stopPropagation();
    });

    // オーバーレイのクリックで閉じる
    overlay.addEventListener('click', function () {
      closePanel();
    });

    // ヘッダー
    var header = document.createElement('div');
    header.style.display = 'flex';
    header.style.justifyContent = 'space-between';
    header.style.alignItems = 'center';
    header.style.marginBottom = '16px';

    var title = document.createElement('h3');
    title.textContent = 'バッテリーマップ';
    title.style.margin = '0';
    title.style.fontSize = '18px';
    title.style.fontWeight = 'bold';
    title.style.color = (D.CONFIG && D.CONFIG.ACCENT) || '#0b5cab';

    var closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.textContent = '✕';
    closeBtn.style.background = 'none';
    closeBtn.style.border = 'none';
    closeBtn.style.fontSize = '18px';
    closeBtn.style.cursor = 'pointer';
    closeBtn.style.color = '#666666';
    closeBtn.addEventListener('click', closePanel);

    header.appendChild(title);
    header.appendChild(closeBtn);
    card.appendChild(header);

    // エリア表示セクション
    var areaSection = document.createElement('div');
    areaSection.style.marginBottom = '20px';
    areaSection.style.padding = '12px';
    areaSection.style.backgroundColor = '#f5f7fa';
    areaSection.style.borderRadius = '6px';
    areaSection.style.fontSize = '14px';

    var areaText = document.createElement('div');
    areaText.textContent = 'エリアを判定中…';
    areaSection.appendChild(areaText);

    var manualAreaContainer = document.createElement('div');
    manualAreaContainer.style.marginTop = '10px';
    manualAreaContainer.style.display = 'none';
    areaSection.appendChild(manualAreaContainer);

    card.appendChild(areaSection);

    // 表示タイプ3ボタンセクション（横並び）
    var btnContainer = document.createElement('div');
    btnContainer.style.display = 'flex';
    btnContainer.style.gap = '8px';
    btnContainer.style.marginBottom = '20px';

    var tabBtn = document.createElement('button');
    tabBtn.type = 'button';
    tabBtn.textContent = '別タブで開く';
    styleActionButton(tabBtn);

    var splitBtn = document.createElement('button');
    splitBtn.type = 'button';
    splitBtn.textContent = '横に並べて表示';
    styleActionButton(splitBtn);

    var qrBtn = document.createElement('button');
    qrBtn.type = 'button';
    qrBtn.textContent = 'スマホ・タブレットで開く';
    styleActionButton(qrBtn);

    btnContainer.appendChild(tabBtn);
    btnContainer.appendChild(splitBtn);
    btnContainer.appendChild(qrBtn);
    card.appendChild(btnContainer);

    // QR表示セクション
    var qrSection = document.createElement('div');
    qrSection.style.display = 'none';
    qrSection.style.textAlign = 'center';
    qrSection.style.padding = '12px';
    qrSection.style.borderTop = '1px solid #eeeeee';

    var qrImg = document.createElement('img');
    qrImg.style.width = '220px';
    qrImg.style.height = '220px';
    qrImg.style.display = 'block';
    qrImg.style.margin = '0 auto 8px auto';
    qrImg.alt = 'QR Code';

    var qrErrorText = document.createElement('div');
    qrErrorText.style.color = '#d9534f';
    qrErrorText.style.fontSize = '13px';
    qrErrorText.style.marginBottom = '8px';
    qrErrorText.style.display = 'none';

    var urlText = document.createElement('div');
    urlText.style.fontSize = '12px';
    urlText.style.color = '#666666';
    urlText.style.wordBreak = 'break-all';

    qrSection.appendChild(qrImg);
    qrSection.appendChild(qrErrorText);
    qrSection.appendChild(urlText);
    card.appendChild(qrSection);

    overlay.appendChild(card);
    shadow.appendChild(overlay);

    document.body.appendChild(host);

    // Escape キーでのパネル閉じ
    function onKeyDown(e) {
      if (e.key === 'Escape' || e.keyCode === 27) {
        closePanel();
        window.removeEventListener('keydown', onKeyDown);
      }
    }
    window.addEventListener('keydown', onKeyDown);

    // 現在のターゲットURL保持
    var currentMapUrl = (D.areas && typeof D.areas.buildMapUrl === 'function')
      ? D.areas.buildMapUrl([])
      : ((D.CONFIG && D.CONFIG.MAP_APP_URL) || 'https://dontsu87.github.io/DBSgetdata/');

    function updateUrlAndQr(url) {
      currentMapUrl = url;

      // url が null＝表示範囲が確定していない。
      // 権限を確認できていない状態で全エリアを開かせないため、3つのボタンを無効にする。
      var ready = typeof url === 'string' && url.length > 0;
      setActionsEnabled(ready);

      if (!ready) {
        urlText.textContent = 'エリアを選ぶとURLが決まります';
        qrImg.style.display = 'none';
        qrErrorText.textContent = 'エリアを選んでください';
        qrErrorText.style.display = 'block';
        return;
      }

      urlText.textContent = url;

      if (D.qr && typeof D.qr.toDataUrl === 'function') {
        var dataUrl = D.qr.toDataUrl(url, 220);
        if (dataUrl) {
          qrImg.src = dataUrl;
          qrImg.style.display = 'block';
          qrErrorText.style.display = 'none';
        } else {
          qrImg.style.display = 'none';
          qrErrorText.textContent = 'QRコードを生成できませんでした';
          qrErrorText.style.display = 'block';
        }
      } else {
        qrImg.style.display = 'none';
        qrErrorText.textContent = 'QRコードを生成できませんでした';
        qrErrorText.style.display = 'block';
      }
    }

    /** 表示範囲が確定していないあいだ、3つのボタンを押せなくする */
    function setActionsEnabled(enabled) {
      var buttons = [tabBtn, splitBtn, qrBtn];
      for (var i = 0; i < buttons.length; i++) {
        buttons[i].disabled = !enabled;
        buttons[i].style.opacity = enabled ? '1' : '0.45';
        buttons[i].style.cursor = enabled ? 'pointer' : 'not-allowed';
        buttons[i].title = enabled ? '' : 'エリアを選ぶと押せます';
      }
    }

    /** URLが未確定なら何もしない（権限未確認で全エリアを開かせない） */
    function hasUrl() {
      return typeof currentMapUrl === 'string' && currentMapUrl.length > 0;
    }

    // ボタンのイベントハンドラ
    tabBtn.addEventListener('click', function () {
      if (!hasUrl()) return;
      if (D.platform && typeof D.platform.openTab === 'function') {
        D.platform.openTab(currentMapUrl);
      }
      closePanel();
    });

    splitBtn.addEventListener('click', function () {
      if (!hasUrl()) return;
      if (D.platform && typeof D.platform.openSplit === 'function') {
        D.platform.openSplit(currentMapUrl);
      }
      closePanel();
    });

    qrBtn.addEventListener('click', function () {
      if (!hasUrl()) return;
      qrSection.style.display = 'block';
    });

    // 非同期でエリア情報をロード
    if (D.areas && typeof D.areas.load === 'function') {
      D.areas.load().then(function (res) {
        if (!currentPanelHost) return; // ロード完了前に閉じた場合

        if (res && res.ok) {
          var targetUrl = res.url || D.areas.buildMapUrl(res.areas);
          if (!targetUrl) {
            // 取得は成功したがエリア名が1つも取れなかった場合も手動選択にする
            showManualAreaSelection();
            return;
          }
          updateUrlAndQr(targetUrl);

          if (targetUrl.indexOf('?kanriall') !== -1) {
            areaText.textContent = '表示範囲: 全エリア';
          } else if (res.areas && res.areas.length > 0) {
            var names = [];
            for (var i = 0; i < res.areas.length; i++) {
              var a = res.areas[i];
              var name = typeof a === 'string' ? a : (a && a.areaName ? a.areaName : '');
              if (name && names.indexOf(name) === -1) {
                names.push(name);
              }
            }
            areaText.textContent = '表示範囲: ' + names.join(', ');
          } else {
            showManualAreaSelection();
          }
        } else {
          showManualAreaSelection();
        }
      }).catch(function () {
        if (currentPanelHost) {
          showManualAreaSelection();
        }
      });
    } else {
      showManualAreaSelection();
    }

    function showManualAreaSelection() {
      areaText.textContent = 'エリアを自動判定できませんでした。手動で選んでください';
      manualAreaContainer.innerHTML = '';
      manualAreaContainer.style.display = 'block';

      var knownAreas = (D.CONFIG && D.CONFIG.KNOWN_AREAS)
        ? D.CONFIG.KNOWN_AREAS
        : ['金沢', '福井', '小松', '敦賀', '上田千曲広域', '出雲・松江・境港'];

      var selectedMap = {};

      var checkboxesDiv = document.createElement('div');
      checkboxesDiv.style.display = 'flex';
      checkboxesDiv.style.flexWrap = 'wrap';
      checkboxesDiv.style.gap = '8px';
      checkboxesDiv.style.marginTop = '8px';

      for (var j = 0; j < knownAreas.length; j++) {
        (function (areaName) {
          var label = document.createElement('label');
          label.style.fontSize = '13px';
          label.style.cursor = 'pointer';
          label.style.display = 'inline-flex';
          label.style.alignItems = 'center';
          label.style.gap = '4px';

          var chk = document.createElement('input');
          chk.type = 'checkbox';
          chk.value = areaName;
          chk.addEventListener('change', function () {
            if (chk.checked) {
              selectedMap[areaName] = true;
            } else {
              delete selectedMap[areaName];
            }
            var selectedList = [];
            for (var k = 0; k < knownAreas.length; k++) {
              if (selectedMap[knownAreas[k]]) {
                selectedList.push(knownAreas[k]);
              }
            }
            var newUrl = D.areas.buildMapUrl(selectedList);
            updateUrlAndQr(newUrl);
          });

          label.appendChild(chk);
          label.appendChild(document.createTextNode(areaName));
          checkboxesDiv.appendChild(label);
        })(knownAreas[j]);
      }

      manualAreaContainer.appendChild(checkboxesDiv);
      // 何も選ばれていない状態では URL を確定させない（buildMapUrl([]) は null を返す）。
      // 全エリアへ落とすと、権限未確認のまま全件を開いてしまう。
      updateUrlAndQr(D.areas.buildMapUrl([]));
    }
  }

  function styleActionButton(btn) {
    btn.style.flex = '1';
    btn.style.padding = '8px 12px';
    btn.style.backgroundColor = '#ffffff';
    btn.style.color = (D.CONFIG && D.CONFIG.ACCENT) || '#0b5cab';
    btn.style.border = '1px solid ' + ((D.CONFIG && D.CONFIG.ACCENT) || '#0b5cab');
    btn.style.borderRadius = '4px';
    btn.style.fontSize = '12px';
    btn.style.fontWeight = 'bold';
    btn.style.cursor = 'pointer';
    btn.style.transition = 'all 0.2s ease';

    btn.addEventListener('mouseenter', function () {
      btn.style.backgroundColor = (D.CONFIG && D.CONFIG.ACCENT) || '#0b5cab';
      btn.style.color = '#ffffff';
    });
    btn.addEventListener('mouseleave', function () {
      btn.style.backgroundColor = '#ffffff';
      btn.style.color = (D.CONFIG && D.CONFIG.ACCENT) || '#0b5cab';
    });
  }

  D.mapLauncher = {
    apply: function () {
      if (typeof document === 'undefined') return;

      var anchor = document.querySelector('a[href="/vehicles"]');
      if (!anchor || !anchor.parentElement) return;

      // **`anchor.parentElement` をメニューとみなしてはいけない。**
      // 実機（2026-08-07 契約テストで発覚）では各項目が div でラップされている:
      //
      //   div.flex.grow.flex-col            ← 13項目を並べるコンテナ（ここの最下段に入れる）
      //     div.cursor-pointer.border-1…    ← 項目ごとのラッパー（子は1個）
      //       a.block.w-full.p-2 href="/vehicles"
      //
      // 親を直接使うと「車両情報」の項目の中にボタンが入ってしまう。
      // メニューリンクを複数持つ最も内側の祖先まで登ることで、
      // ラップが1段でも2段でも、将来増えても正しい位置に入る。
      var menu = null;
      var node = anchor.parentElement;
      for (var hop = 0; hop < 6 && node; hop++) {
        if (node.querySelectorAll('a[href^="/"]').length >= 5) { menu = node; break; }
        node = node.parentElement;
      }
      if (!menu) return;
      if (menu.querySelector('[data-dbsext-launcher]')) return;

      var launcherDiv = document.createElement('div');
      launcherDiv.setAttribute('data-dbsext-launcher', '1');
      launcherDiv.style.marginTop = '8px';
      launcherDiv.style.padding = '0 8px';

      var btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = '🔋 バッテリーマップを開く';
      btn.style.width = '100%';
      btn.style.padding = '10px 12px';
      btn.style.backgroundColor = (D.CONFIG && D.CONFIG.ACCENT) || '#0b5cab';
      btn.style.color = '#ffffff';
      btn.style.fontWeight = 'bold';
      btn.style.border = 'none';
      btn.style.borderRadius = '4px';
      btn.style.cursor = 'pointer';
      btn.style.fontSize = '14px';
      btn.style.boxSizing = 'border-box';
      btn.style.display = 'block';

      btn.addEventListener('click', function () {
        createLauncherPanel();
      });

      launcherDiv.appendChild(btn);
      menu.appendChild(launcherDiv);
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
