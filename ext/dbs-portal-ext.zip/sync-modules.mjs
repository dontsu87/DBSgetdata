import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import { orderForExtension, orderForRemote } from '../module-order.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const srcModulesDir = path.resolve(__dirname, '../modules');
const destModulesDir = path.resolve(__dirname, 'modules');
const manifestJsonPath = path.resolve(__dirname, 'manifest.json');

if (!fs.existsSync(srcModulesDir)) {
  console.error(`Error: Source directory not found: ${srcModulesDir}`);
  process.exit(1);
}

if (!fs.existsSync(destModulesDir)) {
  fs.mkdirSync(destModulesDir, { recursive: true });
}

const files = fs.readdirSync(srcModulesDir).filter(file => file.endsWith('.js'));
const manifestLines = [];

console.log('Syncing modules from src/modules to src/extension/modules...');

for (const file of files) {
  const srcPath = path.join(srcModulesDir, file);
  const destPath = path.join(destModulesDir, file);

  const content = fs.readFileSync(srcPath);
  fs.writeFileSync(destPath, content);

  const hash = crypto.createHash('sha256').update(content).digest('hex');
  manifestLines.push(`${hash}  ${file}`);

  console.log(`Copied: ${file} (SHA-256: ${hash})`);
}

const manifestPath = path.join(destModulesDir, 'MANIFEST.sha256');
fs.writeFileSync(manifestPath, manifestLines.join('\n') + '\n');
console.log(`Manifest created at: ${manifestPath}`);

// 同梱フォールバック用バンドルの自動生成 (orderForRemote() を使用)
const remoteFallbackDir = path.resolve(__dirname, 'remote-fallback');
if (!fs.existsSync(remoteFallbackDir)) {
  fs.mkdirSync(remoteFallbackDir, { recursive: true });
}

const remoteInputFiles = orderForRemote();
const remoteContents = [];
const missingFallbackFiles = [];
for (const relPath of remoteInputFiles) {
  const absPath = path.resolve(__dirname, '../../', relPath);
  if (fs.existsSync(absPath)) {
    remoteContents.push(fs.readFileSync(absPath, 'utf-8'));
  } else {
    missingFallbackFiles.push(relPath);
    console.error(`[ERROR] フォールバックバンドル生成に必要なファイルが見つかりません: ${relPath}`);
  }
}
if (missingFallbackFiles.length > 0) {
  console.error(`[FATAL] フォールバックバンドルのファイル欠落のため中止します (${missingFallbackFiles.length}件)。`);
  process.exit(1);
}
const fallbackBundlePath = path.join(remoteFallbackDir, 'bundle.js');
fs.writeFileSync(fallbackBundlePath, remoteContents.join('\n\n') + '\n', 'utf-8');
console.log(`Fallback bundle generated at: ${fallbackBundlePath}`);

// signature.js の同期 (src/remote/signature.js -> src/extension/background/signature.js)
const srcSignaturePath = path.resolve(__dirname, '../remote/signature.js');
const destSignaturePath = path.resolve(__dirname, 'background/signature.js');
if (fs.existsSync(srcSignaturePath)) {
  fs.copyFileSync(srcSignaturePath, destSignaturePath);
  console.log(`signature.js synced to: ${destSignaturePath}`);
}

// manifest.json の content_scripts の js リストを自動同期
if (fs.existsSync(manifestJsonPath)) {
  const manifest = JSON.parse(fs.readFileSync(manifestJsonPath, 'utf-8'));
  if (manifest.content_scripts && manifest.content_scripts.length > 0) {
    // **順序の正本は src/module-order.mjs。** ここで独自に並べ直さない。
    // 以前はここに順序表のコピーがあり、build.mjs にだけモジュールを足すと
    // manifest.json から静かに脱落する状態だった。
    manifest.content_scripts[0].js = orderForExtension();
    fs.writeFileSync(manifestJsonPath, JSON.stringify(manifest, null, 2) + '\n', 'utf-8');
    console.log('manifest.json content_scripts updated.');
  }
}

