import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const srcModulesDir = path.resolve(__dirname, '../modules');
const destModulesDir = path.resolve(__dirname, 'modules');

if (!fs.existsSync(srcModulesDir)) {
  console.error(`Error: Source directory not found: ${srcModulesDir}`);
  process.exit(1);
}

if (!fs.existsSync(destModulesDir)) {
  fs.mkdirSync(destModulesDir, { recursive: true });
}

const files = fs.readdirSync(srcModulesDir).filter(file => file.endsWith('.js'));
const manifestLines = [];

console.log('Syncing modules from src/modules to src/extension/modules...');

for (const file of files) {
  const srcPath = path.join(srcModulesDir, file);
  const destPath = path.join(destModulesDir, file);

  const content = fs.readFileSync(srcPath);
  fs.writeFileSync(destPath, content);

  const hash = crypto.createHash('sha256').update(content).digest('hex');
  manifestLines.push(`${hash}  ${file}`);

  console.log(`Copied: ${file} (SHA-256: ${hash})`);
}

const manifestPath = path.join(destModulesDir, 'MANIFEST.sha256');
fs.writeFileSync(manifestPath, manifestLines.join('\n') + '\n');
console.log(`Manifest created at: ${manifestPath}`);
