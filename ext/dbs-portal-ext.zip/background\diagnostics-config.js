(function (global) {
  'use strict';
  global.DBSEXT_DIAGNOSTICS_CONFIG = Object.freeze({
    enabled: false,
    killSwitch: true,
    channel: 'production',
    endpoint: ''
  });
})(typeof globalThis !== 'undefined' ? globalThis : self);
