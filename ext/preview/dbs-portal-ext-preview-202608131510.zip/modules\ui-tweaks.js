/**
 * DBSEXT UI微調整モジュール
 *
 * - 戻るボタン: 隠さず、「1個前の画面へ戻る」挙動に差し替える
 * - 折りたたみセクション: 操作系は既定で閉じる（表示条件・検索条件等は開いたまま）
 * - ページサイズ: 車両情報 `/vehicles` で最大（1000）を自動選択する
 *
 * 契約（docs/06-module-contract.md §6）の遵守:
 *   setInterval を使わない / ポータルの既存DOMを削除・移動しない /
 *   更新系リクエストを発行しない
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  // ---------------------------------------------------------------------------
  // 画面の判定
  // ---------------------------------------------------------------------------

  /** 車両情報か */
  function isVehiclesPage() {
    return /^\/vehicles(\/|$)/.test(location.pathname);
  }

  /** ユーザ情報か（ここだけは検索前に表示条件を使うため開いておく） */
  function isUsersPage() {
    return /^\/users(\/|$)/.test(location.pathname);
  }

  function log(message, isError) {
    if (D.core && typeof D.core.log === 'function') D.core.log(message, isError);
  }

  // ---------------------------------------------------------------------------
  // 1. 戻るボタン — 「1個前の画面」へ戻す
  //
  // 現場の声:
  //   「お客様情報を見ている際、ひとつ前の情報を見たく『戻る』ボタンを押すと
  //     ユーザ情報の最初の画面に戻ってしまいます」
  //
  // ポータルの「戻る」は決まったルートへ飛ぶ作りになっている。そこで
  // クリックを捕まえて history.back() に置き換える。
  //
  // ただし**無条件に置き換えてはいけない**。適用直後にいきなり押されると、
  // ポータルへ来る前のページ（空タブや別サイト）へ戻ってしまう。
  // そこで「拡張を適用してから何回ポータル内を移動したか」を数え、
  // 戻れる残りがあるときだけ history.back() を使う。0 のときはポータル本来の
  // 動きに任せる（＝今までどおり）。
  // ---------------------------------------------------------------------------

  var depth = 0;          // 適用時点から何歩進んでいるか
  var pendingBack = 0;    // 自分が起こした戻りの数（数え直しを防ぐ）
  var lastHref = '';
  var backHooked = false;

  /** URLの変化を観測して depth を更新する。apply() から毎回呼ばれる */
  function noteNavigation() {
    var href = location.href;
    if (lastHref === '') { lastHref = href; return; }
    if (href === lastHref) return;
    lastHref = href;
    if (pendingBack > 0) {
      pendingBack--;
      if (depth > 0) depth--;
    } else {
      depth++;
    }
  }

  function isBackLabel(el) {
    if (!el || !el.textContent) return false;
    return el.textContent.trim() === '戻る';
  }

  /** クリック可能な祖先のうち「戻る」ボタンを探す */
  function findBackButton(start) {
    var el = start;
    for (var hop = 0; el && hop < 6; hop++) {
      var tag = el.tagName;
      var isClickable = tag === 'BUTTON' || tag === 'A' ||
        (el.getAttribute && el.getAttribute('role') === 'button');
      if (isClickable && isBackLabel(el)) return el;
      el = el.parentElement;
    }
    return null;
  }

  function hookBackButtons() {
    if (backHooked || typeof document === 'undefined') return;
    backHooked = true;

    // capture フェーズで捕まえる。ポータル自身のハンドラより先に判断するため。
    document.addEventListener('click', function (event) {
      var button = findBackButton(event.target);
      if (!button) return;
      if (depth <= 0) {
        // 戻り先の履歴が無い。ポータル本来の動きに任せる
        log('戻る: 履歴が無いため既定動作にまかせる');
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === 'function') {
        event.stopImmediatePropagation();
      }
      pendingBack++;
      log('戻る: 1個前の画面へ戻る（残り ' + depth + '）');
      history.back();
    }, true);
  }

  // ---------------------------------------------------------------------------
  // 1b. 一覧のリンクを別タブで開く
  //
  // 現場の要望:
  //   絞り込んだ表から個別の画面へ飛ぶと、戻ったときに絞り込みが消えている。
  //   一覧はそのまま残し、個別画面は別タブで開きたい。
  //
  // **対象は `<a href>` だけに限る。** 表の中には「メンテナンス」「AT管理」「解錠」
  // 「再配置」といった**操作ボタン**が並んでおり、これらを別タブ化するのは危険であるうえ
  // 意味がない。リンク（画面遷移）とボタン（操作）を混同しない。
  //
  // Vue Router の RouterLink は、要素に `target="_blank"` が付いていると
  // 自前のルーティングを行わずブラウザに任せる。したがって属性を足すだけで、
  // クリックを横取りする必要がない（二重に開く事故も起きない）。
  // ---------------------------------------------------------------------------

  function openRowLinksInNewTab() {
    if (typeof document === 'undefined') return;
    var links = document.querySelectorAll('table.el-table__body tbody td a[href]');
    for (var i = 0; i < links.length; i++) {
      var link = links[i];
      if (link.hasAttribute('data-dbsext-newtab') || isUserLinkAnchor(link)) continue;
      var href = link.getAttribute('href');
      // 同一オリジンの通常リンクだけ。javascript: や外部リンクは触らない
      if (!href || href.charAt(0) !== '/') continue;
      link.setAttribute('data-dbsext-newtab', '1');
      link.setAttribute('target', '_blank');
      link.setAttribute('rel', 'noopener');
      link.title = (link.title ? link.title + ' / ' : '') + '別タブで開きます（一覧は残ります）';
    }
  }

  // ---------------------------------------------------------------------------
  // 1c. ユーザ識別番号のリンク化
  //
  // 車両情報 `/vehicles` の一覧で、「ユーザ識別番号」セルの値をクリックすると
  // 対応するユーザ詳細画面を別タブで開く。
  // ---------------------------------------------------------------------------

  function isValidUserId(id) {
    if (!id || typeof id !== 'string') return false;
    return /^USER:[A-Za-z0-9:_-]{1,256}$/.test(id);
  }

  function extractUserId(text) {
    if (!text || typeof text !== 'string') return null;
    var trimmed = text.trim();
    return isValidUserId(trimmed) ? trimmed : null;
  }

  function isValidAreaId(id) {
    if (!id || typeof id !== 'string') return false;
    return /^AREA:[A-Za-z0-9:_-]{1,256}$/.test(id);
  }

  function getSelectedAreaId() {
    if (typeof location === 'undefined') return null;
    var search = location.search;
    if (!search && location.href) {
      var qIdx = location.href.indexOf('?');
      if (qIdx !== -1) {
        search = location.href.substring(qIdx);
        var hIdx = search.indexOf('#');
        if (hIdx !== -1) search = search.substring(0, hIdx);
      }
    }
    if (!search) return null;
    var match = /[?&]selected-area-id=([^&#]*)/.exec(search);
    if (!match) return null;
    var decoded = '';
    try {
      decoded = decodeURIComponent(match[1]);
    } catch (e) {
      return null;
    }
    return isValidAreaId(decoded) ? decoded : null;
  }

  function getHeaderTitle(th) {
    if (!th) return '';
    if (th.hasAttribute && th.hasAttribute('data-dbsext-orig-title')) {
      return th.getAttribute('data-dbsext-orig-title');
    }
    var fullText = (th.textContent || '').trim();
    if (th.querySelectorAll) {
      var customEls = th.querySelectorAll('[data-dbsext-collapse-hint], [data-dbsext-sort], [data-dbsext-filter]');
      if (customEls.length > 0) {
        var customText = '';
        for (var i = 0; i < customEls.length; i++) {
          customText += customEls[i].textContent || '';
        }
        if (customText) {
          fullText = fullText.replace(customText.trim(), '').trim();
        }
      }
    }
    return fullText;
  }

  function openUserLink(href) {
    if (!href) return;
    var targetWindow = typeof window !== 'undefined' ? window : global;
    if (targetWindow && typeof targetWindow.open === 'function') {
      var win = targetWindow.open(href, '_blank', 'noopener,noreferrer');
      if (win) {
        try { win.opener = null; } catch (e) {}
      }
    }
  }

  function handleUserLinkClick(event) {
    var href = event.currentTarget ? event.currentTarget._dbsextHref : null;
    if (!href) return;
    if (typeof event.preventDefault === 'function') event.preventDefault();
    if (typeof event.stopPropagation === 'function') event.stopPropagation();
    openUserLink(href);
  }

  function handleUserLinkKeydown(event) {
    if (event.key === 'Enter' || event.keyCode === 13) {
      var href = event.currentTarget ? event.currentTarget._dbsextHref : null;
      if (!href) return;
      if (typeof event.preventDefault === 'function') event.preventDefault();
      if (typeof event.stopPropagation === 'function') event.stopPropagation();
      openUserLink(href);
    }
  }

  var trackedCells = [];
  var trackedAnchors = [];

  function isUserLinkCell(el) {
    return !!el && trackedCells.indexOf(el) !== -1;
  }

  function isUserLinkAnchor(el) {
    return !!el && trackedAnchors.indexOf(el) !== -1;
  }

  function cleanupCell(cell) {
    if (!cell || !isUserLinkCell(cell)) return;

    delete cell._dbsextHref;
    if (cell._dbsextUserLinkBound) {
      cell._dbsextUserLinkBound = false;
      if (typeof cell.removeEventListener === 'function') {
        cell.removeEventListener('click', handleUserLinkClick);
        cell.removeEventListener('keydown', handleUserLinkKeydown);
      }
    }

    if (cell._dbsextOrigRole) {
      if (cell._dbsextOrigRole.has) {
        cell.setAttribute('role', cell._dbsextOrigRole.val);
      } else {
        cell.removeAttribute('role');
      }
      delete cell._dbsextOrigRole;
    } else {
      cell.removeAttribute('role');
    }

    if (cell._dbsextOrigTabindex) {
      if (cell._dbsextOrigTabindex.has) {
        cell.setAttribute('tabindex', cell._dbsextOrigTabindex.val);
      } else {
        cell.removeAttribute('tabindex');
      }
      delete cell._dbsextOrigTabindex;
    } else {
      cell.removeAttribute('tabindex');
    }

    if (cell._dbsextOrigTitle) {
      if (cell._dbsextOrigTitle.has) {
        cell.setAttribute('title', cell._dbsextOrigTitle.val);
        cell.title = cell._dbsextOrigTitle.val;
      } else {
        cell.removeAttribute('title');
        cell.title = '';
      }
      delete cell._dbsextOrigTitle;
    } else {
      cell.removeAttribute('title');
      cell.title = '';
    }

    if (cell.style) {
      if (cell._dbsextOrigCursor) {
        if (cell._dbsextOrigCursor.set) {
          if (typeof cell.style.setProperty === 'function') {
            cell.style.setProperty('cursor', cell._dbsextOrigCursor.val, cell._dbsextOrigCursor.prio || '');
          } else {
            cell.style.cursor = cell._dbsextOrigCursor.val;
          }
        } else {
          if (typeof cell.style.removeProperty === 'function') {
            cell.style.removeProperty('cursor');
          }
          cell.style.cursor = '';
        }
        delete cell._dbsextOrigCursor;
      } else {
        if (typeof cell.style.removeProperty === 'function') {
          cell.style.removeProperty('cursor');
        }
        cell.style.cursor = '';
      }

      if (cell._dbsextOrigTextDec) {
        if (cell._dbsextOrigTextDec.set) {
          if (typeof cell.style.setProperty === 'function') {
            cell.style.setProperty('text-decoration', cell._dbsextOrigTextDec.val, cell._dbsextOrigTextDec.prio || '');
          } else {
            cell.style.textDecoration = cell._dbsextOrigTextDec.val;
          }
        } else {
          if (typeof cell.style.removeProperty === 'function') {
            cell.style.removeProperty('text-decoration');
          }
          cell.style.textDecoration = '';
        }
        delete cell._dbsextOrigTextDec;
      } else {
        if (typeof cell.style.removeProperty === 'function') {
          cell.style.removeProperty('text-decoration');
        }
        cell.style.textDecoration = '';
      }
    }

    var idx = trackedCells.indexOf(cell);
    if (idx !== -1) {
      trackedCells.splice(idx, 1);
    }
  }

  function cleanupAnchor(anchor) {
    if (!anchor || !isUserLinkAnchor(anchor)) return;

    if (anchor._dbsextOrigHref) {
      if (anchor._dbsextOrigHref.has) {
        anchor.setAttribute('href', anchor._dbsextOrigHref.val);
      } else {
        anchor.removeAttribute('href');
      }
      delete anchor._dbsextOrigHref;
    }

    if (anchor._dbsextOrigTarget) {
      if (anchor._dbsextOrigTarget.has) {
        anchor.setAttribute('target', anchor._dbsextOrigTarget.val);
      } else {
        anchor.removeAttribute('target');
      }
      delete anchor._dbsextOrigTarget;
    }

    if (anchor._dbsextOrigRel) {
      if (anchor._dbsextOrigRel.has) {
        anchor.setAttribute('rel', anchor._dbsextOrigRel.val);
      } else {
        anchor.removeAttribute('rel');
      }
      delete anchor._dbsextOrigRel;
    }

    if (anchor._dbsextOrigTitle) {
      if (anchor._dbsextOrigTitle.has) {
        anchor.setAttribute('title', anchor._dbsextOrigTitle.val);
        anchor.title = anchor._dbsextOrigTitle.val;
      } else {
        anchor.removeAttribute('title');
        anchor.title = '';
      }
      delete anchor._dbsextOrigTitle;
    }

    delete anchor._dbsextCleaned;

    var idx = trackedAnchors.indexOf(anchor);
    if (idx !== -1) {
      trackedAnchors.splice(idx, 1);
    }
  }

  function linkifyUserIds() {
    if (typeof document === 'undefined') return;

    var areaId = getSelectedAreaId();
    var isEligible = isVehiclesPage() && !!areaId;

    var activeCells = [];
    var activeAnchors = [];

    if (isEligible) {
      var tables = document.querySelectorAll('.el-table');
      for (var t = 0; t < tables.length; t++) {
        var container = tables[t];
        var headerTable = container.querySelector('table.el-table__header');
        var bodyTable = container.querySelector('table.el-table__body');

        if (!headerTable && container.classList && container.classList.contains('el-table__header')) {
          headerTable = container;
        }
        if (!bodyTable && container.classList && container.classList.contains('el-table__body')) {
          bodyTable = container;
        }

        if (!headerTable || !bodyTable) continue;

        var ths = headerTable.querySelectorAll('th');
        var targetColIndex = -1;
        for (var i = 0; i < ths.length; i++) {
          if (getHeaderTitle(ths[i]) === 'ユーザ識別番号') {
            targetColIndex = i;
            break;
          }
        }

        if (targetColIndex === -1) continue;

        var rows = bodyTable.querySelectorAll('tbody tr');
        if (!rows || rows.length === 0) {
          rows = bodyTable.querySelectorAll('tr');
        }
        for (var r = 0; r < rows.length; r++) {
          var row = rows[r];
          var tds = row.children;
          if (!tds || tds.length === 0) {
            tds = row.querySelectorAll('td');
          }
          if (targetColIndex >= tds.length) continue;
          var cell = tds[targetColIndex];

          var existingLink = cell.querySelector('a');
          if (existingLink) {
            var linkUserId = extractUserId(existingLink.textContent);
            if (linkUserId) {
              if (isUserLinkCell(cell)) {
                cleanupCell(cell);
              }
              delete existingLink._dbsextCleaned;
              if (!isUserLinkAnchor(existingLink)) {
                existingLink._dbsextOrigHref = { has: existingLink.hasAttribute('href'), val: existingLink.getAttribute('href') };
                existingLink._dbsextOrigTarget = { has: existingLink.hasAttribute('target'), val: existingLink.getAttribute('target') };
                existingLink._dbsextOrigRel = { has: existingLink.hasAttribute('rel'), val: existingLink.getAttribute('rel') };
                existingLink._dbsextOrigTitle = { has: existingLink.hasAttribute('title'), val: existingLink.title || existingLink.getAttribute('title') };
                if (trackedAnchors.indexOf(existingLink) === -1) {
                  trackedAnchors.push(existingLink);
                }
              }
              var expectedHref = '/users/general/' + encodeURIComponent(linkUserId) + '?selected-area-id=' + encodeURIComponent(areaId);
              existingLink.setAttribute('href', expectedHref);
              existingLink.setAttribute('target', '_blank');
              existingLink.setAttribute('rel', 'noopener noreferrer');
              existingLink.title = 'ユーザー詳細を別タブで開きます';
              if (activeAnchors.indexOf(existingLink) === -1) {
                activeAnchors.push(existingLink);
              }
            }
          } else {
            var cellUserId = extractUserId(cell.textContent);
            if (cellUserId) {
              if (!isUserLinkCell(cell)) {
                cell._dbsextOrigRole = { has: cell.hasAttribute('role'), val: cell.getAttribute('role') };
                cell._dbsextOrigTabindex = { has: cell.hasAttribute('tabindex'), val: cell.getAttribute('tabindex') };
                cell._dbsextOrigTitle = { has: cell.hasAttribute('title'), val: cell.title || cell.getAttribute('title') };
                var hasStyle = !!cell.style;
                var getPropVal = function (prop) {
                  if (!hasStyle) return '';
                  if (typeof cell.style.getPropertyValue === 'function') {
                    return cell.style.getPropertyValue(prop);
                  }
                  var camel = prop === 'text-decoration' ? 'textDecoration' : prop;
                  return cell.style[camel] || '';
                };
                var getPropPrio = function (prop) {
                  if (!hasStyle) return '';
                  if (typeof cell.style.getPropertyPriority === 'function') {
                    return cell.style.getPropertyPriority(prop) || '';
                  }
                  return '';
                };

                var curVal = getPropVal('cursor');
                var curPrio = getPropPrio('cursor');
                cell._dbsextOrigCursor = {
                  set: curVal !== '' || curPrio !== '',
                  val: curVal,
                  prio: curPrio
                };

                var decVal = getPropVal('text-decoration');
                var decPrio = getPropPrio('text-decoration');
                cell._dbsextOrigTextDec = {
                  set: decVal !== '' || decPrio !== '',
                  val: decVal,
                  prio: decPrio
                };
                if (trackedCells.indexOf(cell) === -1) {
                  trackedCells.push(cell);
                }
              }
              var href = '/users/general/' + encodeURIComponent(cellUserId) + '?selected-area-id=' + encodeURIComponent(areaId);
              cell._dbsextHref = href;
              cell.setAttribute('role', 'link');
              cell.setAttribute('tabindex', '0');
              cell.title = 'ユーザー詳細を別タブで開きます';
              cell.style.cursor = 'pointer';
              cell.style.textDecoration = 'underline';

              if (!cell._dbsextUserLinkBound) {
                cell._dbsextUserLinkBound = true;
                if (typeof cell.addEventListener === 'function') {
                  cell.addEventListener('click', handleUserLinkClick);
                  cell.addEventListener('keydown', handleUserLinkKeydown);
                }
              }
              if (activeCells.indexOf(cell) === -1) {
                activeCells.push(cell);
              }
            }
          }
        }
      }
    }

    for (var m = trackedCells.length - 1; m >= 0; m--) {
      var trackedCell = trackedCells[m];
      if (activeCells.indexOf(trackedCell) === -1) {
        cleanupCell(trackedCell);
      }
    }
    for (var n = trackedAnchors.length - 1; n >= 0; n--) {
      var trackedAnchor = trackedAnchors[n];
      if (activeAnchors.indexOf(trackedAnchor) === -1) {
        cleanupAnchor(trackedAnchor);
      }
    }
  }

  // ---------------------------------------------------------------------------
  // 2. 折りたたみセクション — ユーザ情報の表示条件だけ開いておく
  //
  // 現場確認により、ユーザ情報以外は「表示条件」も既定で閉じる。
  // ユーザ情報は検索しないと表が出ないため、入力に必要な表示条件だけ開いておく。
  // ---------------------------------------------------------------------------

  function shouldKeepSectionOpen(headerText) {
    if (!headerText) return false;
    if (!isUsersPage()) return false;
    return headerText.indexOf('表示条件') !== -1 ||
           headerText.indexOf('検索条件') !== -1 ||
           headerText.indexOf('絞り込み条件') !== -1;
  }

  function collapseSections() {
    if (typeof document === 'undefined') return;

    var items = document.querySelectorAll('.el-collapse-item');
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      var header = item.querySelector('.el-collapse-item__header');
      if (!header || header.hasAttribute('data-dbsext-collapsed')) continue;
      header.setAttribute('data-dbsext-collapsed', '1');

      var headerText = (header.textContent || '').trim();
      var keepOpen = shouldKeepSectionOpen(headerText);

      // 開閉できることが見て分かるようにヒントを足す
      if (!header.querySelector('[data-dbsext-collapse-hint]')) {
        var hint = document.createElement('span');
        hint.setAttribute('data-dbsext-collapse-hint', '1');
        hint.textContent = '▼';
        hint.style.cssText = 'font-size:11px;opacity:0.5;margin-left:2px';
        header.appendChild(hint);
      }

      // 開いていればネイティブのクリックで閉じる。
      // クラスを直接操作すると Element Plus の内部状態とずれるため不可。
      if (!keepOpen && item.classList.contains('is-active')) {
        header.click();
      }
    }
  }

  // ---------------------------------------------------------------------------
  // 3. ページサイズ最大化（車両情報）
  //
  // Element Plus のサイズ選択は el-select で、ドロップダウンは teleport で
  // body 直下へ描画される。前回の実装が動かなかった原因として次を想定し、
  // すべて潰してある。
  //   - クリック対象が `.el-select` のルートだった（開くのは内側の wrapper/input）
  //   - 待ち時間が短く、teleport 描画前に諦めていた
  //   - document 全体から `.el-select-dropdown__item` を拾い、別のドロップダウンを
  //     掴む可能性があった → **クリック後に現れた・表示されているものだけ**を見る
  //   - 一度失敗すると印を付けて二度と再挑戦しなかった → 成功するまで印を付けない
  // ---------------------------------------------------------------------------

  var TARGET_PAGE_SIZE = 1000;
  var sizeDoneFor = {};   // pathname ごとに一度だけ実行する
  var sizeRunning = false;

  /**
   * ドロップダウンの中身が「表示件数」のものか。
   * **項目が全部ただの数字**であることを条件にする。
   */
  function isSizeDropdown(node) {
    if (!node) return false;
    var items = node.querySelectorAll('.el-select-dropdown__item');
    if (items.length < 2) return false;
    for (var i = 0; i < items.length; i++) {
      if (!/^\d+$/.test((items[i].textContent || '').trim())) return false;
    }
    return true;
  }

  function dropdownById(id) {
    if (!id) return null;
    var el = document.getElementById(id);
    if (!el) return null;
    // popper が dropdown を包んでいる場合と、dropdown 自身が返る場合の両方に対応
    return (typeof el.closest === 'function' && el.closest('.el-select-dropdown')) || el;
  }

  /**
   * 表示件数のドロップダウンを引き当てる。
   *
   * **ここが2回失敗した箇所。** 実測（2026-08-07 `investigation/out/diag-sizes.json`）で分かったこと:
   *
   *   `.el-pagination__sizes` の select は
   *     aria-controls    = el-id-1024-72 → 中身は「更新しない / 15分」← **無関係**
   *     aria-describedby = el-id-1024-76 → 中身は「50 / 100 / 200 / 500」← **正解**
   *
   * Element Plus のこの版では `aria-controls` が隣のセレクタの id を指しており、
   * これを信じると自動更新間隔のドロップダウンを掴んでしまう
   * （実機ログ: `[dbsext] 表示件数を 15分 に変更`）。
   *
   * そこで **id を信用せず、中身で確かめる**。候補を順に試し、
   * 「項目が全部数字」のものだけを採用する。
   */
  function findSizeDropdown(select) {
    var wrapper = select.querySelector('.el-select__wrapper');
    var combobox = select.querySelector('[aria-controls]');
    var candidates = [
      dropdownById(wrapper && wrapper.getAttribute('aria-describedby')),
      dropdownById(combobox && combobox.getAttribute('aria-controls'))
    ];
    for (var i = 0; i < candidates.length; i++) {
      if (isSizeDropdown(candidates[i])) return candidates[i];
    }
    // それでも決まらなければ、画面全体から「数字だけ」のものを探す
    return numericOnlyDropdown();
  }

  /** 開いているか。Element Plus は aria-expanded を更新する */
  function isExpanded(select) {
    var combobox = select.querySelector('[aria-expanded]');
    return !!combobox && combobox.getAttribute('aria-expanded') === 'true';
  }

  /**
   * `aria-controls` が取れない版への退避。
   * **選択肢が全部ただの数字**のドロップダウンだけを候補にする。
   * 実測では他のドロップダウンは「更新しない/15分」「全て表示/閾値以下」「昇順/降順」等で、
   * 数字だけのものはページサイズ（50/100/200/500）に限られていた。
   */
  function numericOnlyDropdown() {
    var list = document.querySelectorAll('.el-select-dropdown');
    for (var i = 0; i < list.length; i++) {
      if (isSizeDropdown(list[i])) return list[i];
    }
    return null;
  }

  /**
   * 1000 があればそれ、無ければ最大値を返す。
   *
   * **選択肢は「数字だけ」のものに限る。** 実機で `\d+` の部分一致にしていたため、
   * 自動更新間隔の「15分」から 15 を拾って選んでしまった
   * （2026-08-07 実測ログ: `[dbsext] 表示件数を 15分 に変更`）。
   */
  function pickLargestOption(dropdown) {
    var items = dropdown.querySelectorAll('.el-select-dropdown__item');
    var best = null;
    var bestValue = -1;
    var exact = null;
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      if (item.classList.contains('is-disabled')) continue;
      var text = (item.textContent || '').trim();
      if (!/^\d+$/.test(text)) continue;        // 「15分」「更新しない」は候補にしない
      var value = parseInt(text, 10);
      if (value === TARGET_PAGE_SIZE) exact = item;
      if (value > bestValue) { bestValue = value; best = item; }
    }
    return exact || best;
  }

  function currentPageSize(select) {
    // 実測の構造:
    //   .el-select__selected-item.el-select__input-wrapper.is-hidden > input(value="")
    //   .el-select__selected-item.el-select__placeholder > span "100"   ← 表示中の値はこちら
    // 先に placeholder を見ないと、隠しinputの空値を拾って NaN になる。
    var text = '';
    var display = select.querySelector('.el-select__placeholder');
    if (display) text = display.textContent || '';
    if (!text) {
      var input = select.querySelector('input');
      if (input) text = input.value || input.getAttribute('value') || '';
    }
    var matched = String(text).match(/\d+/);
    return matched ? parseInt(matched[0], 10) : NaN;
  }

  /** el-select を開くための実クリック対象。Element Plus の版差を吸収する */
  function selectTrigger(select) {
    return select.querySelector('.el-select__wrapper') ||
      select.querySelector('.el-input__inner') ||
      select.querySelector('.el-input__wrapper') ||
      select;
  }

  function maximizePageSize() {
    if (typeof document === 'undefined') return;
    if (!isVehiclesPage()) return;
    // 拡張版では vehicle-pagesize.js が「1000件表示（実ページ遷移方式）」を
    // 別途担う。ここでのドロップダウン操作（最大500）は**ブックマークレット版
    // 専用の代替手段**として残す。両方を同時に走らせると、ドロップダウンを
    // 500へ変えている最中に vehicle-pagesize.js が遷移を起こす、といった
    // 競合の余地が生まれるため、拡張版ではここを止める。
    if (D.platform && (D.platform.kind === 'extension' || D.platform.isUserScript)) return;
    if (sizeRunning || sizeDoneFor[location.pathname]) return;

    // **`.el-pagination__sizes` の中の select だけを対象にする。**
    // 以前は見つからないとき `pagination.querySelector('.el-select')` へ退避していたが、
    // ページャの中には自動更新間隔など別の select も居るため誤爆した。
    // 見つからないときは何もせず、次の再適用にゆだねる（印を付けないので再挑戦される）。
    var sizesHost = document.querySelector('.el-pagination__sizes');
    if (!sizesHost) return;
    var select = sizesHost.querySelector('.el-select');
    if (!select) return;

    var current = currentPageSize(select);
    if (current >= TARGET_PAGE_SIZE) {
      sizeDoneFor[location.pathname] = true;
      return;
    }

    sizeRunning = true;
    selectTrigger(select).click();

    // teleport + アニメーションを待つ。setInterval は契約で禁止のため再帰 setTimeout。
    var attempts = 0;
    (function waitForDropdown() {
      attempts++;

      // 開いたことを aria-expanded で確認してから中身を読む
      var opened = null;
      if (isExpanded(select)) {
        opened = findSizeDropdown(select);
      }

      if (opened) {
        var option = pickLargestOption(opened);
        if (option) {
          var label = (option.textContent || '').trim();
          option.click();
          sizeDoneFor[location.pathname] = true;
          // 本当に反映されたかを確かめる。掴む相手を間違えると
          // 「選んだのに変わらない」という静かな失敗になるため。
          setTimeout(function () {
            var now = currentPageSize(select);
            if (String(now) === label) {
              log('表示件数を ' + label + ' に変更');
            } else {
              log('表示件数を ' + label + ' に変えたが表示は ' + now + ' のまま', true);
              sizeDoneFor[location.pathname] = false;
            }
          }, 400);
        } else {
          log('表示件数の選択肢（数字のみ）が見つからない', true);
        }
        sizeRunning = false;
        return;
      }

      if (attempts >= 30) {   // 100ms × 30 = 約3秒
        log('表示件数のドロップダウンを特定できない（aria-controls も数字専用も不発）', true);
        sizeRunning = false;
        return;
      }
      setTimeout(waitForDropdown, 100);
    })();
  }

  // ---------------------------------------------------------------------------

  D.uiTweaks = {
    apply: function () {
      if (typeof document === 'undefined' || !document.body) return;
      noteNavigation();
      hookBackButtons();
      linkifyUserIds();
      openRowLinksInNewTab();
      collapseSections();
      maximizePageSize();
    },

    // 検証用（テストから状態を覗くため）
    _state: function () {
      return { depth: depth, pendingBack: pendingBack, sizeDoneFor: sizeDoneFor };
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
