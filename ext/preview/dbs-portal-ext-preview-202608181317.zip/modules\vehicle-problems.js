/**
 * DBSEXT 車両詳細問題申告モジュール
 *
 * /vehicles/{vehicleId} 画面で、ポータル標準の問題申告表を非表示にし、
 * API レスポンスの problemOccurrences を1行1件に展開した
 * 自前テーブルに差し替える。
 *
 * 自前テーブルの機能:
 *   - ヘッダ固定（sticky）
 *   - 列ごとの文字列フィルタ
 *   - 列ごとの昇順／降順並び替え
 *   - 画面表示時に自動取得
 *
 * 安全性:
 *   - ポータルへの書き込み・更新系リクエストは一切発行しない
 *   - 元の表は display:none で隠すのみ（DOMから除去しない）
 *   - 自前UIは data-dbsext-vehicle-problems 属性で識別
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var CACHE_TTL_MS = 2 * 60 * 1000; // 2分
  var PROBLEM_HEADER_SIGNATURE = '問題申告日時'; // 見出し判定用の特徴語
  var PANEL_ATTR = 'data-dbsext-vehicle-problems';
  var TABLE_ATTR = 'data-dbsext-vp-table';

  var cacheMap = Object.create(null); // vehicleId -> { rows, timestamp }
  var isFetching = false;
  var currentVehicleId = null;
  var currentGeneration = 0;
  var activeGeneration = 0;

  /**
   * URLから車両IDを取得
   */
  function getVehicleIdFromUrl() {
    if (typeof location === 'undefined') return null;
    var m = location.pathname.match(/^\/vehicles\/([A-Za-z0-9:_-]+)$/);
    return m ? m[1] : null;
  }

  /**
   * 問題申告の表を探す（見出しに「問題申告日時」を含む .el-table）
   */
  function findProblemTable() {
    if (typeof document === 'undefined') return null;
    var tables = document.querySelectorAll('.el-table');
    for (var i = 0; i < tables.length; i++) {
      var hdr = tables[i].querySelector('table.el-table__header');
      if (!hdr) continue;
      var ths = hdr.querySelectorAll('thead th');
      for (var j = 0; j < ths.length; j++) {
        if ((ths[j].textContent || '').indexOf(PROBLEM_HEADER_SIGNATURE) !== -1) {
          return tables[i];
        }
      }
    }
    return null;
  }

  /**
   * 表の祖先で、非表示にしても画面レイアウトを壊さない適切なラッパーを探す
   */
  function findTableWrapper(table) {
    if (!table) return null;
    // .el-table の親をたどり、適切な区切りを探す
    var cur = table.parentNode;
    while (cur && cur !== document.body && cur !== document.documentElement) {
      // Element Plus のテーブルは通常 mb-4 などのクラスを持つラッパー内
      if (cur.classList && (cur.classList.contains('mb-4') || cur.classList.contains('py-4'))) {
        return cur;
      }
      // .el-table の直接の親がなければ el-table 自身を返す
      if (cur === table.parentNode && cur.childNodes.length === 1) {
        cur = cur.parentNode;
        continue;
      }
      cur = cur.parentNode;
    }
    return table;
  }

  /**
   * 元の表を非表示にする
   */
  function hideOriginalTable() {
    var table = findProblemTable();
    if (!table) return false;
    if (table.hasAttribute(PANEL_ATTR + '-hidden')) return true; // 既に非表示

    var wrapper = findTableWrapper(table);
    if (wrapper) {
      wrapper.setAttribute(PANEL_ATTR + '-hidden', '1');
      wrapper.style.display = 'none';
    }
    table.setAttribute(PANEL_ATTR + '-hidden', '1');
    return true;
  }

  /**
   * 元の表を再表示する
   */
  function showOriginalTable() {
    var hidden = document.querySelectorAll('[' + PANEL_ATTR + '-hidden="1"]');
    for (var i = 0; i < hidden.length; i++) {
      hidden[i].style.display = '';
      hidden[i].removeAttribute(PANEL_ATTR + '-hidden');
    }
  }

  /**
   * 自前パネルの挿入位置を探す（元の表の wrapper の後）
   */
  function findInsertionPoint() {
    var table = findProblemTable();
    if (!table) return null;
    var wrapper = findTableWrapper(table);
    if (wrapper && wrapper.parentNode) {
      return { container: wrapper.parentNode, targetSibling: wrapper.nextSibling };
    }
    if (table.parentNode) {
      return { container: table.parentNode, targetSibling: table.nextSibling };
    }
    return null;
  }

  /**
   * 自前パネルが既にDOMに存在し、かつ現在の車両IDと一致しているか
   */
  function isPanelValid(panel, vehicleId) {
    if (!panel || !vehicleId) return false;
    if (typeof panel.isConnected === 'boolean' && !panel.isConnected) return false;
    var root = panel;
    while (root.parentNode) root = root.parentNode;
    if (root !== document) return false;
    return panel.getAttribute(PANEL_ATTR + '-vid') === vehicleId;
  }

  /**
   * データ取得と表示
   */
  function fetchAndRender(panel, vehicleId) {
    if (!vehicleId || isFetching) return;

    currentGeneration++;
    var gen = currentGeneration;
    activeGeneration = gen;
    isFetching = true;
    currentVehicleId = vehicleId;

    var statusDiv = panel.querySelector('[' + PANEL_ATTR + '-status]');
    if (statusDiv) {
      statusDiv.textContent = '読み込み中…';
      statusDiv.className = 'dbsext-vp-status';
    }

    // キャッシュ確認
    var now = Date.now();
    var cached = cacheMap[vehicleId];
    if (cached && (now - cached.timestamp < CACHE_TTL_MS)) {
      isFetching = false;
      currentVehicleId = null;
      if (gen === currentGeneration && isPanelValid(panel, vehicleId)) {
        renderTable(panel, cached.rows);
      }
      return;
    }

    // APIから取得
    var url = '/api/vehicles/' + vehicleId + '/problems';
    fetch(url, { credentials: 'include' })
      .then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.json();
      })
      .then(function (items) {
        if (!Array.isArray(items)) items = [];
        // problemOccurrences を展開してフラットな行配列にする
        var rows = [];
        for (var i = 0; i < items.length; i++) {
          var item = items[i];
          var occs = item.problemOccurrences || [];
          for (var j = 0; j < occs.length; j++) {
            rows.push({
              problemReportTs: item.problemReportTs || '',
              userUniqueCode: item.userUniqueCode || '',
              importanceCategory: occs[j].importanceCategory || '',
              partNameJa: occs[j].partNameJa || '',
              partCode: occs[j].partCode || '',
              occurrenceNameJa: occs[j].occurrenceNameJa || '',
              occurrenceCode: occs[j].occurrenceCode || '',
              collectionStatus: item.collectionStatus || '',
              collectionCompleteExecutionTs: item.collectionCompleteExecutionTs || ''
            });
          }
        }

        cacheMap[vehicleId] = { rows: rows, timestamp: Date.now() };

        if (gen === currentGeneration && isPanelValid(panel, vehicleId)) {
          isFetching = false;
          currentVehicleId = null;
          renderTable(panel, rows);
        } else {
          isFetching = false;
          currentVehicleId = null;
        }
      })
      .catch(function (err) {
        if (gen === currentGeneration && isPanelValid(panel, vehicleId)) {
          isFetching = false;
          currentVehicleId = null;
          if (statusDiv) {
            statusDiv.textContent = '問題申告の取得に失敗しました: ' + (err && err.message ? err.message : String(err));
            statusDiv.className = 'dbsext-vp-error';
          }
        } else {
          isFetching = false;
          currentVehicleId = null;
        }
      });
  }

  /**
   * テーブルを描画
   */
  function renderTable(panel, rows) {
    var statusDiv = panel.querySelector('[' + PANEL_ATTR + '-status]');
    var tableWrap = panel.querySelector('[' + PANEL_ATTR + '-wrap]');
    if (!tableWrap) return;

    // 前回の表示をクリア
    while (tableWrap.firstChild) tableWrap.removeChild(tableWrap.firstChild); // dbsext:own-ui

    if (!rows || rows.length === 0) {
      if (statusDiv) {
        statusDiv.textContent = 'この車両の問題申告はありません。';
        statusDiv.className = 'dbsext-vp-status';
      }
      return;
    }

    if (statusDiv) {
      statusDiv.textContent = '全 ' + rows.length + ' 件（部位×事象を展開）';
      statusDiv.className = 'dbsext-vp-status';
    }

    var columns = [
      { label: '問題申告日時',    value: function (r) { return r.problemReportTs; } },
      {
        label: 'ユーザ識別番号',
        value: function (r) { return r.userUniqueCode; },
        render: function (td, r) {
          var a = document.createElement('a');
          a.setAttribute('href', '/users/' + (r.userUniqueCode || ''));
          a.textContent = r.userUniqueCode || '';
          a.className = 'dbsext-cell-link';
          td.appendChild(a);
        }
      },
      { label: '重要度',          value: function (r) { return r.importanceCategory; } },
      { label: '部位',            value: function (r) { return r.partNameJa; } },
      { label: '事象',            value: function (r) { return r.occurrenceNameJa; } },
      { label: '回収状況',        value: function (r) { return r.collectionStatus; } },
      { label: '回収完了日時',    value: function (r) { return r.collectionCompleteExecutionTs; } }
    ];

    // 描画・並べ替え・絞り込みは custom-table が担う。
    // 以前はここに約110行の自前実装があり、ビーコン一覧とほぼ同じものだった。
    D.customTable.render({
      container: tableWrap,
      rows: rows,
      columns: columns,
      // 初期表示は「最新申告日時」が先頭になるよう降順にする。
      // ヘッダをクリックした場合は custom-table 側の通常のトグルへ戻る。
      initialSort: { columnIndex: 0, direction: 'desc' },
      tableAttrs: (function () { var a = {}; a[TABLE_ATTR] = '1'; return a; })(),
      emptyText: '絞り込み条件に一致する申告はありません。'
    });
  }

  /**
   * 自前パネルを構築
   */
  function buildPanel(vehicleId) {
    if (typeof document === 'undefined') return null;

    var existing = document.querySelector('[' + PANEL_ATTR + '="1"]');
    if (existing) {
      // 車両が変わったら破棄して作り直す
      if (existing.getAttribute(PANEL_ATTR + '-vid') !== vehicleId) {
        if (existing.parentNode) existing.parentNode.removeChild(existing); // dbsext:own-ui
        currentGeneration++;
        isFetching = false;
        currentVehicleId = null;
      } else {
        return existing;
      }
    }

    var insertion = findInsertionPoint();
    if (!insertion || !insertion.container) return null;

    var panel = document.createElement('div');
    panel.setAttribute(PANEL_ATTR, '1');
    panel.setAttribute(PANEL_ATTR + '-vid', vehicleId);

    var header = document.createElement('div');
    header.className = 'dbsext-vp-header';

    var h2 = document.createElement('h3');
    h2.textContent = '問題申告一覧（拡張）';
    header.appendChild(h2);

    var statusDiv = document.createElement('div');
    statusDiv.setAttribute(PANEL_ATTR + '-status', '1');
    header.appendChild(statusDiv);

    panel.appendChild(header);

    var tableWrap = document.createElement('div');
    tableWrap.setAttribute(PANEL_ATTR + '-wrap', '1');
    tableWrap.className = 'dbsext-vp-table-wrap';
    // 横スクロールバーの見た目は table-wrap.js が共通で与える
    tableWrap.setAttribute('data-dbsext-table-scroll', '1');
    panel.appendChild(tableWrap);

    if (insertion.targetSibling) {
      insertion.container.insertBefore(panel, insertion.targetSibling);
    } else {
      insertion.container.appendChild(panel);
    }

    return panel;
  }

  /**
   * 画面離脱時の後片付け
   */
  function teardown() {
    showOriginalTable();
    var panel = document.querySelector('[' + PANEL_ATTR + '="1"]');
    if (panel && panel.parentNode) {
      panel.parentNode.removeChild(panel); // dbsext:own-ui
    }
    currentGeneration++;
    isFetching = false;
    currentVehicleId = null;
  }

  D.vehicleProblems = {
    apply: function () {
      if (typeof document === 'undefined' || !document.body) return;

      var vehicleId = getVehicleIdFromUrl();

      // 車両詳細画面以外では元の表を表示し自前パネルを撤去
      if (!vehicleId) {
        var panel = document.querySelector('[' + PANEL_ATTR + '="1"]');
        if (panel) teardown();
        return;
      }

      // 車両詳細画面: 元の表を隠し自前パネルを表示
      if (!hideOriginalTable()) return; // 表が見つからなければ何もしない

      var panel = buildPanel(vehicleId);
      if (!panel) return;

      fetchAndRender(panel, vehicleId);
    },

    /**
     * 「オリジナルに戻す」表示専用。自前パネルは（own-root として）別途隠れる前提で、
     * 隠していたポータル標準の表だけを一時的に見せる。
     */
    peekShowAll: function () {
      showOriginalTable();
    },

    /** 「オリジナルに戻す」を解除し、標準の表を再び隠して自前パネルへ戻す */
    peekRestore: function () {
      if (getVehicleIdFromUrl()) hideOriginalTable();
    },

    // テスト用
    _clearCache: function () {
      cacheMap = Object.create(null);
      currentGeneration++;
      isFetching = false;
      currentVehicleId = null;
    },
    _getVehicleIdFromUrl: getVehicleIdFromUrl,
    _findProblemTable: findProblemTable
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
