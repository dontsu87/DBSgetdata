/**
 * DBSEXT 「オリジナルに戻す」トグル
 *
 * なんらかの事情で拡張を適用していない素のポータル画面を見たい利用者のために、
 * 拡張の見た目・追加UIを**一時的に**丸ごと隠すボタンを用意する。
 *
 * ---------------------------------------------------------------------------
 * 設計方針
 * ---------------------------------------------------------------------------
 * ポータルのDOMは一切削除・移動しない（契約§6）。やることは2つだけ:
 *
 *   1. 拡張が挿入した <style> を無効化する（sticky・配色・サイドバー幅などが消える）
 *   2. 拡張が作った要素（own-root / own-leaf、`core.js` の ATTR_KIND から機械的に
 *      導く）を一括で非表示にする
 *
 * さらに、拡張が**隠していたポータル本来の表示**（車両詳細の標準表、たたんだ操作列、
 * 絞り込みで隠れた行）は、隠す側のモジュール自身に「覗く／戻す」を持たせてある
 * （`vehicleProblems.peekShowAll/peekRestore` 等）。ここから呼ぶだけで、
 * **保存済みの利用者設定（列のたたみ状態など）には一切触れない**。
 *
 * 状態は保存しない。**ページを開き直せば必ず拡張適用に戻る。**
 * 「オフにしたことを忘れて、拡張が壊れたと思われる」事故を避けるため。
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var HOST_ATTR = 'data-dbsext-original-view';
  var BTN_ATTR = 'data-dbsext-original-view-btn';
  var STYLE_IDS = ['dbsext-skin', 'dbsext-table-wrap-style', 'dbsext-table-columns-width'];

  var active = false;

  function setStylesEnabled(enabled) {
    if (typeof document === 'undefined') return;
    for (var i = 0; i < STYLE_IDS.length; i++) {
      var el = document.getElementById(STYLE_IDS[i]);
      if (el) el.disabled = !enabled;
    }
  }

  /** 自前UI（root+leaf）を一括で隠す／戻す。トグルボタン自身は対象から外す */
  function setOwnUiHidden(hidden) {
    if (typeof document === 'undefined' || !D.core || !D.core.OWN_UI_SELECTOR_ALL) return;
    var nodes = document.querySelectorAll(D.core.OWN_UI_SELECTOR_ALL);
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      // トグルボタン自身（とその中身）は常に見えている必要がある
      if (typeof node.closest === 'function' && node.closest('[' + HOST_ATTR + ']')) continue;
      node.style.display = hidden ? 'none' : '';
    }
  }

  /** 拡張が隠している「本来ポータルに見えるはずのもの」を覗く／戻す */
  function peekEachModule(show) {
    var method = show ? 'peekShowAll' : 'peekRestore';
    var targets = [D.vehicleProblems, D.tableColumns, D.tableTools, D.portBulkActions];
    for (var i = 0; i < targets.length; i++) {
      var mod = targets[i];
      if (mod && typeof mod[method] === 'function') {
        try { mod[method](); } catch (e) {
          D.core.log('original-view: ' + method + ' 失敗: ' + (e && e.message ? e.message : e), true);
        }
      }
    }
  }

  function updateButtonLabel(btn) {
    btn.textContent = active ? '拡張表示に戻す' : 'オリジナル表示';
    btn.title = active
      ? 'クリックすると拡張の見た目・追加機能に戻ります'
      : 'クリックすると拡張の変更前（素のポータル）を一時的に見られます';
  }

  function toggle(btn) {
    active = !active;
    setStylesEnabled(!active);
    setOwnUiHidden(active);
    peekEachModule(active);

    if (!active) {
      // オフに戻した直後は、次のDOM変化を待たずに拡張側の表示を即座に復元する
      // （並べ替え・絞り込みの再適用、固定ボタン類の再配置など）
      if (D.core && typeof D.core.reapplyAll === 'function') {
        D.core.reapplyAll();
      }
    }

    updateButtonLabel(btn);
  }

  function ensureButton() {
    if (typeof document === 'undefined' || !document.body) return;
    if (document.querySelector('[' + HOST_ATTR + ']')) return;

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.setAttribute(HOST_ATTR, '1');
    btn.setAttribute(BTN_ATTR, '1');
    btn.style.cssText = [
      'position: fixed',
      'right: 12px',
      'bottom: 12px',
      'z-index: 2147483000',
      'background: rgba(0, 0, 0, 0.75)',
      'color: #ffffff',
      'border: none',
      'border-radius: 20px',
      'padding: 8px 16px',
      'font-size: 12px',
      'font-weight: bold',
      'cursor: pointer',
      'box-shadow: 0 2px 8px rgba(0,0,0,0.25)'
    ].join(';');

    updateButtonLabel(btn);
    btn.addEventListener('click', function () { toggle(btn); });
    document.body.appendChild(btn);
  }

  D.originalView = {
    apply: function () {
      ensureButton();
    },

    // テスト・診断用
    _isActive: function () { return active; },
    _reset: function () { active = false; }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
