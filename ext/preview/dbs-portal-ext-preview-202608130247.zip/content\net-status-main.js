/**
 * DBSEXT 通信ステータス MAIN-world 傍受スクリプト
 *
 * ポータルが動く MAIN ワールドで fetch / XHR をラップし、
 * 通信の開始・終了を DOM カスタムイベントとして発火する。
 * ISOLATED / USER_SCRIPT ワールドの net-status.js はこれを購読して
 * 「読み込み中…」マスクの表示・非表示を行う。
 *
 * このファイルは極力薄く保ち、UI生成・タイミング制御・エラー表示は
 * すべて net-status.js 側に任せる。
 *
 * 置き場所:
 *   - manifest.json content_scripts (world: "MAIN") → 同梱版フォールバック
 *   - remote-updater.js が登録する MAIN-world user script → リモート配信版
 */
(function () {
  'use strict';

  if (typeof window === 'undefined') return;
  if (typeof document === 'undefined') return;

  var EVENT_PREFIX = 'dbsext:main-fetch';

  if (typeof window.__dbsext_main_active_requests !== 'number') {
    window.__dbsext_main_active_requests = 0;
  }

  function getActiveRequests() {
    return Math.max(0, window.__dbsext_main_active_requests || 0);
  }

  function incrementActive() {
    window.__dbsext_main_active_requests = getActiveRequests() + 1;
  }

  function decrementActive() {
    window.__dbsext_main_active_requests = Math.max(0, getActiveRequests() - 1);
  }

  function dispatch(name, detail) {
    try {
      var event = new CustomEvent(EVENT_PREFIX + '-' + name, {
        detail: detail || {},
        bubbles: false
      });
      document.dispatchEvent(event);
    } catch (e) {
      // document が使えない環境では何もしない
    }
  }

  function dispatchSnapshot() {
    dispatch('snapshot', { activeRequests: getActiveRequests() });
  }

  if (!window.__dbsext_main_query_listener_installed) {
    window.__dbsext_main_query_listener_installed = true;
    document.addEventListener('dbsext:main-fetch-query', function () {
      dispatchSnapshot();
    });
  }

  // ---- fetch のラップ ----

  if (window.fetch && !window.fetch.__dbsext_main_wrapped) {
    var _origFetch = window.fetch;

    window.fetch = function (input, init) {
      var url = '';
      try {
        if (typeof input === 'string') {
          url = input;
        } else if (input && typeof input.url === 'string') {
          url = input.url;
        } else if (input && typeof input.href === 'string') {
          url = input.href;
        }
      } catch (e) {}

      var isPortal = url.indexOf('https://mg.docomo-cycle.jp/') === 0 ||
                     (url.indexOf('/') === 0 && url.indexOf('//') !== 0);

      if (isPortal) {
        incrementActive();
        dispatch('start', { activeRequests: getActiveRequests() });
      }

      var promise;
      try {
        promise = _origFetch.apply(this, arguments);
      } catch (err) {
        if (isPortal) {
          decrementActive();
          dispatch('end', { status: 0, error: true, activeRequests: getActiveRequests() });
        }
        throw err;
      }

      return promise.then(
        function (res) {
          if (isPortal) {
            decrementActive();
            dispatch('end', { status: res ? res.status : 0, activeRequests: getActiveRequests() });
          }
          return res;
        },
        function (err) {
          if (isPortal) {
            decrementActive();
            dispatch('end', { status: 0, error: true, activeRequests: getActiveRequests() });
          }
          return Promise.reject(err);
        }
      );
    };

    window.fetch.__dbsext_main_wrapped = true;
  }

  // ---- XMLHttpRequest のラップ ----

  if (typeof XMLHttpRequest !== 'undefined' &&
      XMLHttpRequest.prototype &&
      XMLHttpRequest.prototype.send &&
      !XMLHttpRequest.prototype.send.__dbsext_main_wrapped) {

    var _origSend = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.send = function () {
      var xhr = this;
      var isPortal = false;

      try {
        var rawUrl = '';
        try {
          rawUrl = (typeof xhr._dbsext_url === 'string') ? xhr._dbsext_url : '';
        } catch (e) {}
        isPortal = rawUrl.indexOf('https://mg.docomo-cycle.jp/') === 0 ||
                   (rawUrl.indexOf('/') === 0 && rawUrl.indexOf('//') !== 0);
      } catch (e) {}

      if (isPortal) {
        incrementActive();
        dispatch('start', { activeRequests: getActiveRequests() });
      }

      var onEnd = function () {
        xhr.removeEventListener('loadend', onEnd);
        if (isPortal) {
          decrementActive();
          dispatch('end', { status: xhr.status, activeRequests: getActiveRequests() });
        }
      };
      xhr.addEventListener('loadend', onEnd);

      try {
        return _origSend.apply(this, arguments);
      } catch (err) {
        xhr.removeEventListener('loadend', onEnd);
        if (isPortal) {
          decrementActive();
          dispatch('end', { status: 0, error: true, activeRequests: getActiveRequests() });
        }
        throw err;
      }
    };

    XMLHttpRequest.prototype.send.__dbsext_main_wrapped = true;

    // XHR の open() もラップして URL を保存する。
    if (XMLHttpRequest.prototype.open &&
        !XMLHttpRequest.prototype.open.__dbsext_main_wrapped) {
      var _origOpen = XMLHttpRequest.prototype.open;
      XMLHttpRequest.prototype.open = function (method, url) {
        try { this._dbsext_url = String(url || ''); } catch (e) {}
        return _origOpen.apply(this, arguments);
      };
      XMLHttpRequest.prototype.open.__dbsext_main_wrapped = true;
    }
  }

  dispatchSnapshot();
})();
