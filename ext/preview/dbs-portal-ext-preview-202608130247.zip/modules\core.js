/**
 * DBSEXT コアモジュール
 * ライフサイクル管理、冪等性制御、DOM変更監視、ログ出力を担当
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var observer = null;
  var contentCallbacks = [];
  var debounceTimer = null;
  // 自前のDOM操作中は監視を止めるための入れ子カウンタ
  var applying = 0;

  var RECONNECT_DELAYS = [50, 150, 400, 1000];
  var reconnectTimer = null;
  var reconnectIndex = 0;
  var isConnecting = false;
  var pageshowRegistered = false;

  function getObserverTarget() {
    if (typeof document === 'undefined') return null;
    var target = document.documentElement || document.body;
    if (!target || target.nodeType !== 1) return null;
    if (target.ownerDocument && target.ownerDocument !== document) return null;
    return target;
  }

  function beginCoreReadiness() {
    if (D && D.netStatus && typeof D.netStatus.beginReadiness === 'function') {
      try { D.netStatus.beginReadiness('core-reapply'); } catch (e) {}
    }
  }

  function endCoreReadiness() {
    if (D && D.netStatus && typeof D.netStatus.endReadiness === 'function') {
      try { D.netStatus.endReadiness('core-reapply'); } catch (e) {}
    }
  }

  function invokeCallbacks() {
    try {
      for (var k = 0; k < contentCallbacks.length; k++) {
        try {
          contentCallbacks[k]();
        } catch (e) {
          D.core.log('onContentChange コールバックエラー: ' + (e && e.message ? e.message : e), true);
        }
      }
    } finally {
      endCoreReadiness();
    }
  }

  function stopObserverState() {
    if (debounceTimer) {
      clearTimeout(debounceTimer);
      debounceTimer = null;
      endCoreReadiness();
    }
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
    if (observer) {
      try { observer.disconnect(); } catch (e) {}
      observer = null;
    }
  }

  function tryConnect(isRecoveryAttempt) {
    if (observer) return true;
    if (isConnecting) return false;
    if (reconnectTimer && !isRecoveryAttempt) return false;
    isConnecting = true;

    var target = getObserverTarget();
    var candidate = null;
    var success = false;

    if (target && typeof MutationObserver !== 'undefined') {
      try {
        candidate = new MutationObserver(function (mutations) {
          if (applying > 0) return;
          var hasExternalChange = false;
          for (var i = 0; i < mutations.length; i++) {
            if (!isOwnMutation(mutations[i])) {
              hasExternalChange = true;
              break;
            }
          }
          if (!hasExternalChange) return;

          beginCoreReadiness();

          if (debounceTimer) clearTimeout(debounceTimer);
          debounceTimer = setTimeout(function () {
            debounceTimer = null;
            invokeCallbacks();
          }, 200);
        });

        candidate.observe(target, { childList: true, subtree: true });
        observer = candidate;
        success = true;
      } catch (e) {
        if (candidate && typeof candidate.disconnect === 'function') {
          try { candidate.disconnect(); } catch (ex) {}
        }
        candidate = null;
        // **実機で確認された例外への防御。**
        // 「一覧から別タブで開く」で新しいタブを開いたとき、`observe()` が例外を投げることがある
        // （Chromeのプリレンダー/BFCache採用時、別レルムで作られた古いNode参照を渡してしまうと起きる既知の症状と推測）。
        // ここを素通しにすると、その1行の例外だけで拡張カードに「エラー」が付き、以後の再適用が全部止まる。
        // 失敗時は observer を確定させず、後から onContentChange が再び呼ばれれば取り直せるようにしておく。
        D.core.log('onContentChange の監視開始に失敗: ' + (e && e.message ? e.message : e), true);
      }
    } else {
      D.core.log('onContentChange の監視開始に失敗: ターゲット無効または MutationObserver 未サポート', true);
    }

    isConnecting = false;

    if (success) {
      reconnectIndex = 0;
      if (reconnectTimer) {
        clearTimeout(reconnectTimer);
        reconnectTimer = null;
      }
      if (isRecoveryAttempt) {
        beginCoreReadiness();
        invokeCallbacks();
      }
      return true;
    }

    if (reconnectIndex < RECONNECT_DELAYS.length) {
      var delay = RECONNECT_DELAYS[reconnectIndex];
      reconnectIndex++;
      reconnectTimer = setTimeout(function () {
        reconnectTimer = null;
        tryConnect(true);
      }, delay);
    }
    return false;
  }

  function setupPageshowListener() {
    if (pageshowRegistered || typeof window === 'undefined' || typeof window.addEventListener !== 'function') return;
    pageshowRegistered = true;
    window.addEventListener('pageshow', function () {
      stopObserverState();
      reconnectIndex = 0;
      tryConnect(true);
    });
  }

  // **`data-dbsext-*` 属性の分類表。新しい属性を足したら、必ずここに登録する。**
  //
  //   'own-root' … 拡張が作った**入れ物**。中に注釈の無い子孫（tbody/tr/td 等）を持つ。
  //                `closest()` の対象になる（＝子孫の変化も自分の仕業と判定できる）
  //   'own-leaf' … 拡張が作った要素だが、中に自前の子孫構造を持たない（印・入力欄など）
  //   'mark'     … **ポータルの既存要素**に付ける目印（中の変化は外部の変化）
  //
  // 分類を間違えると、
  // 「SPAで表が差し替わっても再適用されない」または「自己発火で無限ループ」になる。
  //
  // ここを区別せず「`data-dbsext-` で始まる属性があれば自前UI」と判定すると、
  // `.el-table`（`data-dbsext-tabled` / `data-dbsext-wrap` が付く）を対象にした
  // MutationRecord が全部「自分の仕業」になり、**SPAが表を差し替えても
  // table-tools が再適用されない**。過去に同じ性質の欠陥を1件出している
  // （`isDbsextNode` が祖先を遡り、body配下すべてを自前と誤判定していた）。
  //
  // 逆に **`own-root` の登録を忘れると**、その入れ物の中で自分が起こした変化が
  // 「外部の変化」と誤判定され、**キーを1文字打つたびに全モジュールの再適用が走る**。
  // 実際に `data-dbsext-vehicle-problems` でこれが起きていた（2026-08-10 実測で検出）。
  // 原因は、この表と `OWN_UI_SELECTOR` を**手で二重管理**していたこと。
  // そこで **`OWN_UI_SELECTOR` はこの表から生成する**（下）。もう片方だけ直すことはできない。
  var ATTR_KIND = {
    // --- 自前UIの入れ物（closest の対象） ---
    'data-dbsext-upsell': 'own-root',
    'data-dbsext-launcher': 'own-root',
    'data-dbsext-launcher-panel': 'own-root',
    'data-dbsext-net-status': 'own-root',
    'data-dbsext-loading-mask': 'own-root',
    'data-dbsext-top-indicator': 'own-root',
    'data-dbsext-error-banner': 'own-root',
    'data-dbsext-state-forms': 'own-root',
    'data-dbsext-table-columns': 'own-root',
    'data-dbsext-top-scrollbar': 'own-root',   // 見出しの上に置く横スクロールバー
    'data-dbsext-beacons-panel': 'own-root',
    // **ポータルの標準表を包む**入れ物。中身はポータルのDOMだが、
    // モーダル表示中はこちらが主導権を持つため own として扱う（従来からの挙動）。
    'data-dbsext-beacons-native-modal': 'own-root',
    'data-dbsext-beacons-link': 'own-root',
    'data-dbsext-beacons-table': 'own-root',
    'data-dbsext-beacons-status': 'own-root',
    'data-dbsext-vehicle-problems': 'own-root',
    'data-dbsext-vp-table': 'own-root',
    // 「オリジナルに戻す」トグルボタン。own-root にする理由: 自前UI一括非表示の際、
    // このボタン自身とその中身だけは closest() で除外して常に見えるようにする
    'data-dbsext-original-view': 'own-root',
    // ポート一括操作（契約§6の限定例外。AGENTS.md参照）
    'data-dbsext-port-bulk-panel': 'own-root',

    // --- 自前UIだが入れ物ではないもの ---
    'data-dbsext-skin': 'own-leaf',            // <style> 要素そのもの
    'data-dbsext-action-toggle': 'own-leaf',
    'data-dbsext-sort': 'own-leaf',
    'data-dbsext-filter': 'own-leaf',
    'data-dbsext-filter-min': 'own-leaf',      // 数値絞り込みの「以上」
    'data-dbsext-filter-max': 'own-leaf',      // 数値絞り込みの「以下」
    'data-dbsext-collapse-hint': 'own-leaf',
    'data-dbsext-top-scrollbar-inner': 'own-leaf',
    'data-dbsext-synced': 'own-leaf',          // 同期の登録済み印（自前要素に付く）
    'data-dbsext-beacons-area': 'own-leaf',
    'data-dbsext-beacons-link-a': 'own-leaf',
    'data-dbsext-beacons-btn': 'own-leaf',
    'data-dbsext-original-view-btn': 'own-leaf',
    'data-dbsext-port-bulk-table': 'own-leaf',

    // --- ポータル要素に付けた目印（自前UIではない） ---
    'data-dbsext-tabled': 'mark',      // table-tools が .el-table に付ける
    'data-dbsext-wrap': 'mark',        // table-wrap が .el-table に付ける
    'data-dbsext-orig-title': 'mark',  // table-tools が th に控える元の列名
    'data-dbsext-orig-width': 'mark',        // table-columns が col に控える元の幅
    'data-dbsext-orig-table-width': 'mark',  // table-columns が表に控える元の幅
    'data-dbsext-newtab': 'mark',      // ui-tweaks が一覧の a に付ける処理済み印
    'data-dbsext-collapsed': 'mark',   // ui-tweaks が折りたたみ見出しに付ける処理済み印
    // 全家族共通の表マーカー（値は portal / custom）。見た目のCSSはすべてこれを見る。
    // **`own` にしてはいけない。** ポータルが描画した表にも付けるため、own に分類すると
    // ポータル表を対象にした変化が全部「自分の仕業」になり、
    // **SPAが表を差し替えても再適用されなくなる**（core の冒頭に書いた事故そのもの）。
    'data-dbsext-table': 'mark',
    // 自前表を包むスクロール領域。自前UIにしか付かないが、
    // 中身（自前表）は own-root を持つので closest の対象にする必要は無い。
    'data-dbsext-table-scroll': 'own-leaf',
    // 配信版（user script）が document_start で documentElement に置く合図。
    // **ポータルの要素に付ける印**なので own ではない。
    // これを own に分類すると、documentElement を対象にした変化が
    // すべて「自分の仕業」として捨てられる。
    'data-dbsext-remote-claim': 'mark'
  };

  // **`ATTR_KIND` から生成する。手で書かない。**
  // ここに `[data-dbsext]`(bodyの適用済みマーカー)や `[data-dbsext-tabled]`
  // (ポータルのテーブルに目印を付けただけのもの)が入ってはいけない。
  // 入ると、その配下で起きるポータル由来の変化まで「自分の変更」と誤判定し、
  // SPA遷移後に table-tools が二度と再適用されなくなる。
  var OWN_UI_SELECTOR = (function () {
    var list = [];
    for (var name in ATTR_KIND) {
      if (ATTR_KIND[name] === 'own-root') list.push('[' + name + ']');
    }
    return list.join(',');
  })();

  // 自前UI**全部**（root + leaf）を指すセレクタ。
  // 「オリジナルに戻す」表示（original-view.js）が、拡張の作った要素を
  // 一括で隠すために使う。ここも `ATTR_KIND` から生成し、手書きの一覧を作らない。
  var OWN_UI_SELECTOR_ALL = (function () {
    var list = [];
    for (var name in ATTR_KIND) {
      if (ATTR_KIND[name] === 'own-root' || ATTR_KIND[name] === 'own-leaf') list.push('[' + name + ']');
    }
    return list.join(',');
  })();

  function hasOwnAttribute(node) {
    if (!node || node.nodeType !== 1 || !node.attributes) return false;
    for (var i = 0; i < node.attributes.length; i++) {
      var name = node.attributes[i].name;
      // 末尾のハイフンが要る。`data-dbsext`(bodyのマーカー)は自前UIではない
      if (name.indexOf('data-dbsext-') !== 0) continue;
      // ポータル要素に付けた目印は「自前UIである」根拠にならない
      if (ATTR_KIND[name] === 'mark') continue;
      return true;
    }
    return false;
  }

  /** その要素が自前UIの一部か。祖先は自前UIのホストまでしか遡らない。 */
  function isOwnUi(node) {
    if (!node || node.nodeType !== 1) return false;
    if (hasOwnAttribute(node)) return true;
    return typeof node.closest === 'function' && !!node.closest(OWN_UI_SELECTOR);
  }

  /** その変化が自分の仕業か。追加・削除されたノードが全部自前UIなら自分の仕業とみなす。 */
  /**
   * Vue がポータル側の親要素から拡張UIのルートだけを外した場合は外部変化。
   * 拡張自身の同期DOM操作は runSuppressed() が takeRecords() で捨てるため、
   * ここで無視すると、消されたパネルやメニューを再適用できなくなる。
   */
  function isExternallyRemovedOwnRoot(mutation) {
    if (!mutation || isOwnUi(mutation.target)) return false;
    var removed = mutation.removedNodes || [];
    for (var i = 0; i < removed.length; i++) {
      var node = removed[i];
      if (!node || node.nodeType !== 1 || typeof node.hasAttribute !== 'function') continue;
      if (node.hasAttribute('data-dbsext-beacons-panel') ||
          node.hasAttribute('data-dbsext-beacons-link')) {
        return true;
      }
    }
    return false;
  }
  function isOwnMutation(mutation) {
    if (isExternallyRemovedOwnRoot(mutation)) return false;
    if (isOwnUi(mutation.target)) return true;
    var added = mutation.addedNodes || [];
    var removed = mutation.removedNodes || [];
    if (added.length === 0 && removed.length === 0) return false;

    // **要素ノードを1つも見なかったときに「自分の仕業」と言ってはいけない。**
    // テキストノードだけが差し替わる変化（ポータルが textContent を更新した等）は
    // 外部の変化である。ここで true を返すと、その変化を契機にした再適用が走らない。
    var sawElement = false;
    for (var i = 0; i < added.length; i++) {
      if (added[i].nodeType !== 1) continue;
      sawElement = true;
      if (!isOwnUi(added[i])) return false;
    }
    for (var j = 0; j < removed.length; j++) {
      if (removed[j].nodeType !== 1) continue;
      sawElement = true;
      if (!isOwnUi(removed[j])) return false;
    }
    return sawElement;
  }

  /**
   * 自前のDOM操作を包む。
   * 操作中に発生した変化は takeRecords() で捨て、監視ループに戻さない。
   * これが無いと table-tools の並べ替えが自分自身を再発火させ続ける。
   */
  function runSuppressed(name, fn) {
    applying++;
    try {
      fn();
    } catch (e) {
      D.core.log(name + ' エラー: ' + (e && e.message ? e.message : e), true);
    } finally {
      if (observer && typeof observer.takeRecords === 'function') {
        observer.takeRecords();
      }
      applying--;
    }
  }

  // 適用の順序と、変化のたびに再適用するかどうか。
  //
  // **モジュールを1本足すときに直すのは、ここ1行と `module-order.mjs` だけ。**
  // 以前は「この一覧」と「onContentChange の登録」を別々に書いていたため、
  // 片方に足し忘れると **SPA遷移で二度と再適用されない**（しかも初回は動くので
  // 気づけない）という壊れ方をした。両方をこの表から導く。
  //
  //   reapply: true  … ポータルの再描画で消える／画面ごとに要否が変わる
  //   reapply: false … 一度きりでよい（head へのCSS挿入、保存領域の初期化）
  var MODULES = [
    { name: 'skin', reapply: false, get: function () { return D.skin; } },
    { name: 'stateStore', reapply: false, get: function () { return D.stateStore; } },
    { name: 'stateForms', reapply: true, get: function () { return D.stateForms; } },
    // 車種情報はSPA遷移で入る画面。boot時には存在しない
    { name: 'vehicleKinds', reapply: true, get: function () { return D.vehicleKinds; } },
    { name: 'netStatus', reapply: true, get: function () { return D.netStatus; } },
    { name: 'tableWrap', reapply: true, get: function () { return D.tableWrap; } },
    { name: 'uiTweaks', reapply: true, get: function () { return D.uiTweaks; } },
    // 車両情報1000件表示（拡張版限定・実ページ遷移方式）。
    // エリア確定を待つ必要があるため reapply:true
    { name: 'vehiclePageSize', reapply: true, get: function () { return D.vehiclePageSize; } },
    // body直下の固定要素（消えないはず）だが、冪等なので保険として再適用する。
    // 「boot時1回だけ」がボタン消失の原因だったため、同じ落とし穴を残さない。
    { name: 'upsell', reapply: true, get: function () { return D.upsell; } },
    { name: 'mapLauncher', reapply: true, get: function () { return D.mapLauncher; } },
    { name: 'beacons', reapply: true, get: function () { return D.beacons; } },
    { name: 'vehicleProblems', reapply: true, get: function () { return D.vehicleProblems; } },
    // 契約§6の限定例外（AGENTS.md参照）。/ports 限定。ポータル再描画のたびに
    // 再確認が必要（エリア切替・SPA遷移で一覧が変わるため）reapply:true
    { name: 'portBulkActions', reapply: true, get: function () { return D.portBulkActions; } },
    { name: 'tableColumns', reapply: true, get: function () { return D.tableColumns; } },
    { name: 'tableTools', reapply: true, get: function () { return D.tableTools; } },
    // 「オリジナルに戻す」トグルボタン。body直下の固定要素
    { name: 'originalView', reapply: true, get: function () { return D.originalView; } }
  ];

  function applyOne(entry, label) {
    var mod = entry.get();
    if (!mod || typeof mod.apply !== 'function') return;
    runSuppressed(entry.name + '.apply' + label, function () { mod.apply(); });
  }

  D.core = {
    // 「オリジナルに戻す」表示（original-view.js）が使う。自前UI全部を指すセレクタ
    OWN_UI_SELECTOR_ALL: OWN_UI_SELECTOR_ALL,

    /**
     * 統一ログ出力
     * @param {string} message ログメッセージ
     * @param {boolean} [isError] エラーまたは警告の場合はtrue
     */
    log: function (message, isError) {
      var formatted = '[dbsext] ' + message;
      if (isError) {
        console.warn(formatted);
      } else {
        console.log(formatted);
      }
    },

    /**
     * すでに拡張が適用済みか確認
     *
     * **この判定は、ブックマークレット（α）と拡張（β）が同じページに
     * 重なった場合の安全装置としても働く。** 実測で確認済み（2026-08-10、
     * `tests/test_bookmarklet_over_extension.js`）。
     *
     * ブックマークレットはページのMAINワールドで、拡張はISOLATED/USER_SCRIPT
     * ワールドで動く。`window.DBSEXT` はワールドごとに別物だが、
     * **`document`（DOM）だけは共有される。** この関数が見ているのは
     * `document.body` の属性であり、どちらの世界から呼んでも同じ答えになる。
     *
     * そのため「拡張が適用済みの画面でブックマークレットを押す」
     * （またはその逆）としても、後から来た側は `boot()` の入口で即座に
     * 戻り、モジュールの `apply()` は一切呼ばれない
     * （各モジュール自身の冪等性チェックに頼らず、ここで止まる）。
     * 先着した側の版（`D.VERSION`）を上書きすることもない。
     *
     * @returns {boolean}
     */
    isApplied: function () {
      if (typeof document === 'undefined' || !document.body) {
        return false;
      }
      return document.body.hasAttribute(D.CONFIG.MARKER_ATTR);
    },

    /**
     * 拡張の起動（冪等）
     */
    boot: function () {
      if (D.core.isApplied()) {
        D.core.log('既に適用済み');
        return;
      }

      if (typeof document !== 'undefined' && document.body) {
        document.body.setAttribute(D.CONFIG.MARKER_ATTR, D.VERSION);
      }

      // **先に監視を張ってから適用する。** 適用中の変化は runSuppressed が捨てる。
      // 再適用は表の順序どおりに回す（適用順に依存する組み合わせがあるため）。
      D.core.onContentChange(function () {
        for (var r = 0; r < MODULES.length; r++) {
          if (MODULES[r].reapply) applyOne(MODULES[r], ' 再適用');
        }
      });

      for (var i = 0; i < MODULES.length; i++) {
        applyOne(MODULES[i], '');
      }
    },

    /**
     * reapply:true の全モジュールを、待たずにいますぐ再適用する。
     *
     * 通常はポータルのDOM変化を200msデバウンスで検知してから再適用するが、
     * 「オリジナルに戻す」を解除した直後のように、**変化のきっかけがDOM変異
     * ではなく自分の操作**である場面では、次の変化を待たずに即座に元へ戻したい。
     */
    reapplyAll: function () {
      for (var r = 0; r < MODULES.length; r++) {
        if (MODULES[r].reapply) applyOne(MODULES[r], ' reapplyAll');
      }
    },

    /**
     * コンテンツ領域の変更監視（200ms デバウンス、自前要素の変化は除外）
     * @param {function} callback
     */
    onContentChange: function (callback) {
      setupPageshowListener();

      var restartingExhaustedCycle = !observer && !reconnectTimer && !isConnecting &&
        reconnectIndex >= RECONNECT_DELAYS.length;

      if (typeof callback === 'function') {
        contentCallbacks.push(callback);
      }

      if (restartingExhaustedCycle) {
        reconnectIndex = 0;
      }

      // 枯渇後の明示的な再開も recovery である。即時接続に成功した場合も、
      // retry 経由の成功と同様に登録済み callback を正確に1バッチ実行する。
      tryConnect(restartingExhaustedCycle);
    },

    _getObserver: function () {
      return observer;
    },
    _getReconnectIndex: function () {
      return reconnectIndex;
    },
    _resetStateForTest: function () {
      stopObserverState();
      contentCallbacks = [];
      reconnectIndex = 0;
      isConnecting = false;
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
