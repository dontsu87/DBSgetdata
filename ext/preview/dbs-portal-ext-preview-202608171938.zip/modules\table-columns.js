/**
 * DBSEXT テーブル列制御モジュール（列幅オートフィット + 列幅の持ち主の一本化）
 *
 * 目的:
 * 1. 車両情報（/vehicles）の横長テーブル問題に対処するため、
 *    操作系5列（メンテナンス、AT管理、解錠、再配置、AT一体型車両操作）を
 *    トグルで隠せるようにする（既定は表示）。
 * 2. デフォルトの一律200px等の広すぎる列幅に対し、列名および表示行の実データ長から
 *    機械的に最適な列幅を算出・適用する「実行時オートフィット」を提供する（既定はON）。
 * 3. 列幅および表幅の決定・再計算ロジックを本モジュールに一本化する。
 *
 * 契約 §6 の遵守:
 * - DOMノードの削除・移動は一切行わない（display: none による表示制御、および col width / style 設定のみ）
 * - 操作ボタン自体には一切介入しない
 * - 通信は一切行わない（DOM・フォント測定のみ）
 * - setInterval / eval / new Function を使わない
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var ACTION_COLUMNS = [
    'メンテナンス',
    'AT管理',
    '解錠',
    '再配置',
    'AT一体型車両操作'
  ];

  // ---------------------------------------------------------------------------
  // 実行時オートフィットの停止スイッチ（2026-08-17 現場報告により無効化）
  //
  // **`false` の間、保存値が `true` でもオートフィットは動かない。**
  // 既定値だけを反転しても、過去に有効化した画面では localStorage に `true` が
  // 残っているため症状が続いた（現場実機で再現）。
  //
  // 無効化の理由（実機計測で確定）:
  //   `colgroup col` の `width` 属性への書き込みは **Element Plus のレイアウト機構に
  //   上書きされる**。いっぽう表の `style.width` は `!important` のため生き残るので、
  //   「列の合計3144px」と「表の幅2639px」が矛盾した状態が残る。この不整合が
  //   ちらつき・右端寄り・上スクロールバーの消失・先頭列固定の破綻を招いた。
  //
  // 恒久対応は「実測に基づく推奨幅を **CSSの `!important`** で当てる」方式
  // （属性ではなくCSSならEPに上書きされない。表全体の幅は自分で設定しない）。
  // 置き換えが済んだらこのスイッチと関連コードを撤去する。
  var AUTOFIT_ENABLED = false;

  var STORAGE_FEATURE = 'showActionCols';
  var STORAGE_FEATURE_AUTOFIT = 'autoFitCols';
  var UI_CONTAINER_ATTR = 'data-dbsext-table-columns';
  var TOGGLE_INPUT_ATTR = 'data-dbsext-action-toggle';
  var AUTOFIT_TOGGLE_ATTR = 'data-dbsext-autofit-toggle';
  var AUTOFIT_TITLE_ATTR = 'data-dbsext-autofit-title';
  var AUTOFIT_ORIG_TITLE_ATTR = 'data-dbsext-autofit-orig-title';
  var AUTOFIT_ELLIPSIS_ATTR = 'data-dbsext-autofit-ellipsis';
  var AUTOFIT_ORIG_STYLE_ATTR = 'data-dbsext-autofit-orig-style';
  var AUTOFIT_SKIPPED_ATTR = 'data-dbsext-autofit-skipped';

  var MIN_COL_WIDTH = 56;
  var MAX_COL_WIDTH = 280;
  var HEADER_EXTRA_PX = 18; // 並べ替え矢印・絞り込みUIのぶん

  function getScreen() {
    if (typeof location === 'undefined' || !location.pathname) return '';
    return location.pathname;
  }

  function getStorageKey(screen, feature) {
    return 'dbsext:v1:' + (screen || '/') + ':' + feature;
  }

  function loadToggleState(screen) {
    try {
      if (D.stateStore && typeof D.stateStore.load === 'function') {
        var val = D.stateStore.load(screen, STORAGE_FEATURE);
        if (val !== null && typeof val !== 'undefined') {
          return !!val;
        }
      }
      if (typeof localStorage !== 'undefined') {
        var raw = localStorage.getItem(getStorageKey(screen, STORAGE_FEATURE));
        if (raw !== null) {
          return raw === 'true';
        }
      }
    } catch (e) {}
    return true; // 既定は「表示」（showActionCols = true）
  }

  function saveToggleState(screen, show) {
    try {
      if (D.stateStore && typeof D.stateStore.save === 'function') {
        D.stateStore.save(screen, STORAGE_FEATURE, show, { scope: 'local' });
      }
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(getStorageKey(screen, STORAGE_FEATURE), show ? 'true' : 'false');
      }
    } catch (e) {}
  }

  function loadAutoFitState(screen) {
    // 停止スイッチが優先。保存値（過去に有効化した画面の `true`）を無視する
    if (!AUTOFIT_ENABLED) return false;
    try {
      if (D.stateStore && typeof D.stateStore.load === 'function') {
        var val = D.stateStore.load(screen, STORAGE_FEATURE_AUTOFIT);
        if (val !== null && typeof val !== 'undefined') {
          return !!val;
        }
      }
      if (typeof localStorage !== 'undefined') {
        var raw = localStorage.getItem(getStorageKey(screen, STORAGE_FEATURE_AUTOFIT));
        if (raw !== null) {
          return raw === 'true';
        }
      }
    } catch (e) {}
    // **既定はOFF（2026-08-17 ホットフィックス）。**
    // 実行時オートフィットは、自分が設定した寸法を測り直す正のフィードバックを2本持つため
    // 表が振動した（現場報告）:
    //   (1) 余りの配分で合計を wrap.clientWidth に一致させる → 縦スクロールバーの出入りで
    //       clientWidth が変わり、次の適用で幅が変わる
    //   (2) 操作列を btn.offsetWidth（レイアウト後の実寸）で測る → 列幅を変えると実寸が変わる
    // widthSignature のガードは「入力が同じなら書かない」しか保証せず、入力自体が
    // 自分の出力で変わるこの構造では止まらない。**推奨幅の静的表へ置き換える**まで既定OFF。
    return false;
  }

  function saveAutoFitState(screen, enabled) {
    try {
      if (D.stateStore && typeof D.stateStore.save === 'function') {
        D.stateStore.save(screen, STORAGE_FEATURE_AUTOFIT, enabled, { scope: 'local' });
      }
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(getStorageKey(screen, STORAGE_FEATURE_AUTOFIT), enabled ? 'true' : 'false');
      }
    } catch (e) {}
  }

  /**
   * 列の見出し名を取り出す。
   * table-tools の自前UIが付加されている場合でも元の見出し名を取得する。
   */
  function headerName(th) {
    if (!th) return '';
    var orig = th.getAttribute && th.getAttribute('data-dbsext-orig-title');
    if (orig) return String(orig).trim();

    if (typeof th.cloneNode === 'function') {
      var clone = th.cloneNode(true);
      var own = clone.querySelectorAll(
        '[data-dbsext-sort],[data-dbsext-filter],[data-dbsext-collapse-hint]'
      );
      for (var i = 0; i < own.length; i++) {
        if (own[i].parentNode) own[i].parentNode.removeChild(own[i]); // dbsext:own-ui
      }
      return (clone.textContent || '').trim();
    }
    return (th.textContent || '').trim();
  }

  function findActionColumnIndices(headerTable) {
    if (!headerTable) return [];
    var ths = headerTable.querySelectorAll('thead th, tr th');
    var indices = [];
    for (var i = 0; i < ths.length; i++) {
      var text = headerName(ths[i]);
      for (var k = 0; k < ACTION_COLUMNS.length; k++) {
        if (text === ACTION_COLUMNS[k]) {
          indices.push(i);
          break;
        }
      }
    }
    return indices;
  }

  // --- 描画幅測定ヘルパー ---
  var sharedCanvas = null;
  var sharedCtx = null;

  function getFont(el) {
    if (typeof getComputedStyle === 'undefined' || !el) return '';
    try {
      var cs = getComputedStyle(el);
      if (!cs) return '';
      return (
        (cs.fontStyle || 'normal') + ' ' +
        (cs.fontWeight || 'normal') + ' ' +
        (cs.fontSize || '13px') + ' ' +
        (cs.fontFamily || 'sans-serif')
      );
    } catch (e) {
      return '';
    }
  }

  function getHorizontalPadding(el, defaultPadding) {
    if (typeof getComputedStyle === 'undefined' || !el) return defaultPadding;
    try {
      var cs = getComputedStyle(el);
      if (!cs) return defaultPadding;
      var pl = parseFloat(cs.paddingLeft);
      var pr = parseFloat(cs.paddingRight);
      if (isNaN(pl) && isNaN(pr)) return defaultPadding;
      var bl = parseFloat(cs.borderLeftWidth) || 0;
      var br = parseFloat(cs.borderRightWidth) || 0;
      var pad = (isNaN(pl) ? 0 : pl) + (isNaN(pr) ? 0 : pr) + bl + br;
      return pad;
    } catch (e) {
      return defaultPadding;
    }
  }

  function isMultiRowOrSpanHeader(headerTable) {
    if (!headerTable) return false;
    var thead = headerTable.querySelector('thead');
    var rows = thead ? thead.querySelectorAll('tr') : headerTable.querySelectorAll('tr');
    if (rows.length > 1) return true;
    var ths = headerTable.querySelectorAll('th');
    for (var i = 0; i < ths.length; i++) {
      var th = ths[i];
      var cs = parseInt(th.getAttribute('colspan') || '1', 10);
      var rs = parseInt(th.getAttribute('rowspan') || '1', 10);
      if ((!isNaN(cs) && cs > 1) || (!isNaN(rs) && rs > 1)) {
        return true;
      }
    }
    return false;
  }

  function measureTextWidth(text, font, isHeader) {
    if (D.tableColumns && typeof D.tableColumns._measureText === 'function') {
      return D.tableColumns._measureText(text, font, isHeader);
    }
    if (!text) return 0;
    try {
      if (typeof document !== 'undefined' && (!sharedCanvas || !sharedCtx)) {
        sharedCanvas = document.createElement('canvas');
        if (sharedCanvas && typeof sharedCanvas.getContext === 'function') {
          sharedCtx = sharedCanvas.getContext('2d');
        }
      }
      if (sharedCtx) {
        if (font) sharedCtx.font = font;
        var metrics = sharedCtx.measureText(text);
        if (metrics && typeof metrics.width === 'number') {
          return metrics.width;
        }
      }
    } catch (e) {}

    // Canvas 非対応・テスト環境等でのフォールバック概算
    var str = String(text);
    var width = 0;
    for (var i = 0; i < str.length; i++) {
      var code = str.charCodeAt(i);
      // 全角判定
      if ((code >= 0x3000 && code <= 0x9fff) || (code >= 0xff01 && code <= 0xff60)) {
        width += 14;
      } else {
        width += 8;
      }
    }
    return width;
  }

  function isRowVisible(tr) {
    if (!tr) return false;
    if (tr.style && tr.style.display === 'none') return false;
    if (tr.hasAttribute && (tr.hasAttribute('hidden') || tr.getAttribute('aria-hidden') === 'true')) return false;
    if (typeof getComputedStyle !== 'undefined') {
      try {
        var cs = getComputedStyle(tr);
        if (cs && cs.display === 'none') return false;
      } catch (e) {}
    }
    return true;
  }

  /**
   * 単一テーブルの列幅と表幅の計算・適用（一本化された正本）
   */
  function applyTableWidths(table, actionIndices, showActionCols, autoFitEnabled) {
    if (!table) return;

    var headerTable = table.querySelector('table.el-table__header');
    var bodyTable = table.querySelector('table.el-table__body');
    if (!headerTable && !bodyTable) return;

    var headerCols = headerTable ? headerTable.querySelectorAll('colgroup col') : [];
    var bodyCols = bodyTable ? bodyTable.querySelectorAll('colgroup col') : [];
    var colCount = Math.max(headerCols.length, bodyCols.length);
    if (colCount === 0) return;

    // 多段ヘッダのフェイルセーフ判定（0件テーブルでもスキップ印が付くよう早期リターン前に評価）
    var isMultiHeader = isMultiRowOrSpanHeader(headerTable);
    if (isMultiHeader) {
      table.setAttribute(AUTOFIT_SKIPPED_ATTR, 'multi-row-header');
    } else if (table.hasAttribute(AUTOFIT_SKIPPED_ATTR)) {
      table.removeAttribute(AUTOFIT_SKIPPED_ATTR);
    }

    var headerRows = headerTable ? headerTable.querySelectorAll('thead tr, tr') : [];
    var headerThs = headerRows.length > 0 ? headerRows[0].children : [];
    var allBodyRows = bodyTable ? bodyTable.querySelectorAll('tbody tr') : [];

    // 表示中の行のみを抽出（フィルタリング等で display:none になった行は除外）
    var visibleBodyRows = [];
    for (var r = 0; r < allBodyRows.length; r++) {
      if (isRowVisible(allBodyRows[r])) {
        visibleBodyRows.push(allBodyRows[r]);
      }
    }
    var visibleRowCount = visibleBodyRows.length;

    // 行が0件のときは何もしない（見出しだけで幅を決めない。行が出てから測る / no-op）
    if (visibleRowCount === 0) {
      return;
    }

    var isActionHidden = function (idx) {
      if (showActionCols) return false;
      for (var k = 0; k < actionIndices.length; k++) {
        if (actionIndices[k] === idx) return true;
      }
      return false;
    };

    // 1. 元の幅属性を退避
    for (var c = 0; c < colCount; c++) {
      if (headerCols[c] && !headerCols[c].hasAttribute('data-dbsext-orig-width')) {
        headerCols[c].setAttribute(
          'data-dbsext-orig-width',
          headerCols[c].getAttribute('width') || ''
        );
      }
      if (bodyCols[c] && !bodyCols[c].hasAttribute('data-dbsext-orig-width')) {
        bodyCols[c].setAttribute(
          'data-dbsext-orig-width',
          bodyCols[c].getAttribute('width') || ''
        );
      }
    }

    if (headerTable && !headerTable.hasAttribute('data-dbsext-orig-table-width')) {
      headerTable.setAttribute('data-dbsext-orig-table-width', (headerTable.style && headerTable.style.width) || headerTable.getAttribute('width') || '');
    }
    if (bodyTable && !bodyTable.hasAttribute('data-dbsext-orig-table-width')) {
      bodyTable.setAttribute('data-dbsext-orig-table-width', (bodyTable.style && bodyTable.style.width) || bodyTable.getAttribute('width') || '');
    }

    // 2. 操作列の display: none 制御
    var displayVal = function (idx) { return isActionHidden(idx) ? 'none' : ''; };
    var colDisplayWidthVal = function (idx) { return isActionHidden(idx) ? '0px' : ''; };

    for (var i = 0; i < colCount; i++) {
      var dVal = displayVal(i);
      var hidden = isActionHidden(i);

      if (headerCols[i]) {
        headerCols[i].style.display = dVal;
        if (hidden) {
          headerCols[i].style.width = colDisplayWidthVal(i);
        } else {
          headerCols[i].style.removeProperty('width');
        }
      }
      if (bodyCols[i]) {
        bodyCols[i].style.display = dVal;
        if (hidden) {
          bodyCols[i].style.width = colDisplayWidthVal(i);
        } else {
          bodyCols[i].style.removeProperty('width');
        }
      }
      if (headerThs[i]) {
        headerThs[i].style.display = dVal;
      }
      for (var vr = 0; vr < allBodyRows.length; vr++) {
        if (allBodyRows[vr].children[i]) {
          allBodyRows[vr].children[i].style.display = dVal;
        }
      }
    }

    // 3. オートフィットの計算または元の幅の復元
    var calculatedWidths = [];
    var maxBodyWidths = [];
    var hitMaxFlags = [];

    var canAutoFit = autoFitEnabled && visibleRowCount > 0 && !isMultiHeader;

    if (canAutoFit) {
      // 測定
      var sampleCell = visibleBodyRows.length > 0 ? visibleBodyRows[0].querySelector('.cell') || visibleBodyRows[0].querySelector('td') : null;
      var cellFont = getFont(sampleCell);
      var sampleTh = headerThs.length > 0 ? headerThs[0].querySelector('.cell') || headerThs[0] : null;
      var thFont = getFont(sampleTh);

      for (var colIdx = 0; colIdx < colCount; colIdx++) {
        if (isActionHidden(colIdx)) {
          calculatedWidths.push(0);
          maxBodyWidths.push(0);
          hitMaxFlags.push(false);
          continue;
        }

        var th = headerThs[colIdx];
        var thName = headerName(th);
        var thTextWidth = measureTextWidth(thName, thFont, true);
        var thPadding = getHorizontalPadding(th ? (th.querySelector('.cell') || th) : null, 24);
        var headerTargetWidth = thTextWidth + HEADER_EXTRA_PX;

        var maxBodyWidth = 0;

        for (var rowIdx = 0; rowIdx < visibleRowCount; rowIdx++) {
          var td = visibleBodyRows[rowIdx].children[colIdx];
          if (!td) continue;

          var cellButtons = td.querySelectorAll('button, .el-button, input[type="button"], a.el-button');
          var cellContentWidth = 0;

          if (cellButtons && cellButtons.length > 0) {
            var btnTotalWidth = 0;
            for (var b = 0; b < cellButtons.length; b++) {
              var btn = cellButtons[b];
              var btnW = 0;
              if (typeof btn.offsetWidth === 'number' && btn.offsetWidth > 0) {
                btnW = btn.offsetWidth;
              } else if (typeof btn.getBoundingClientRect === 'function') {
                var rect = btn.getBoundingClientRect();
                if (rect && rect.width > 0) btnW = rect.width;
              }
              if (btnW === 0) {
                var btnText = (btn.textContent || '').trim();
                var btnFont = getFont(btn) || cellFont;
                btnW = measureTextWidth(btnText, btnFont, false) + getHorizontalPadding(btn, 16);
              }
              btnTotalWidth += btnW;
              if (b > 0) btnTotalWidth += 8; // ボタン間マージン・ギャップ
            }
            cellContentWidth = btnTotalWidth;
          } else {
            var text = (td.textContent || '').replace(/\s+/g, ' ').trim();
            cellContentWidth = measureTextWidth(text, cellFont, false);
          }

          if (cellContentWidth > maxBodyWidth) {
            maxBodyWidth = cellContentWidth;
          }
        }

        maxBodyWidths.push(maxBodyWidth);

        var cellPadding = 24;
        if (visibleBodyRows.length > 0 && visibleBodyRows[0].children[colIdx]) {
          var targetCell = visibleBodyRows[0].children[colIdx];
          cellPadding = getHorizontalPadding(targetCell.querySelector('.cell') || targetCell, 24);
        }

        var effPadding = Math.max(cellPadding, thPadding);
        var rawTarget = Math.max(maxBodyWidth, headerTargetWidth) + effPadding;
        var isHitMax = rawTarget >= MAX_COL_WIDTH;
        var target = Math.min(Math.max(Math.ceil(rawTarget), MIN_COL_WIDTH), MAX_COL_WIDTH);

        calculatedWidths.push(target);
        hitMaxFlags.push(isHitMax);
      }

      // 余りの配分（表示領域幅より合計が狭い場合、本文最大描画幅が最大の列に足す）
      var sumTarget = 0;
      for (var s = 0; s < calculatedWidths.length; s++) {
        sumTarget += calculatedWidths[s];
      }

      var wrap = table.closest ? table.closest('.el-scrollbar__wrap') : null;
      if (!wrap && table.parentNode) {
        wrap = table.parentNode.querySelector('.el-scrollbar__wrap') || table.parentNode;
      }
      var containerWidth = wrap && typeof wrap.clientWidth === 'number' && wrap.clientWidth > 0
        ? wrap.clientWidth
        : 0;

      if (containerWidth > sumTarget) {
        var extra = containerWidth - sumTarget;
        var maxBodyIdx = -1;
        var maxBodyVal = -1;
        for (var m = 0; m < colCount; m++) {
          if (isActionHidden(m)) continue;
          if (maxBodyWidths[m] > maxBodyVal) {
            maxBodyVal = maxBodyWidths[m];
            maxBodyIdx = m;
          }
        }
        if (maxBodyIdx >= 0) {
          calculatedWidths[maxBodyIdx] += extra;
        }
      }

      // 上限到達列の ellipsis & title 制御
      for (var col = 0; col < colCount; col++) {
        var hit = hitMaxFlags[col] && !isActionHidden(col);
        for (var rIdx = 0; rIdx < visibleRowCount; rIdx++) {
          var rTd = visibleBodyRows[rIdx].children[col];
          if (!rTd) continue;
          var innerCell = rTd.querySelector('.cell') || rTd;

          if (hit) {
            var fullText = (rTd.textContent || '').trim();
            if (!rTd.hasAttribute(AUTOFIT_TITLE_ATTR)) {
              if (rTd.hasAttribute('title')) {
                rTd.setAttribute(AUTOFIT_ORIG_TITLE_ATTR, rTd.getAttribute('title') || '');
              }
              rTd.setAttribute(AUTOFIT_TITLE_ATTR, '1');
            }
            rTd.setAttribute('title', fullText);

            if (!innerCell.hasAttribute(AUTOFIT_ELLIPSIS_ATTR)) {
              // 元のインラインスタイルを退避
              var origStyleObj = {
                overflow: (innerCell.style && innerCell.style.overflow) || '',
                textOverflow: (innerCell.style && innerCell.style.textOverflow) || '',
                whiteSpace: (innerCell.style && innerCell.style.whiteSpace) || ''
              };
              innerCell.setAttribute(AUTOFIT_ORIG_STYLE_ATTR, JSON.stringify(origStyleObj));
              innerCell.style.overflow = 'hidden';
              innerCell.style.textOverflow = 'ellipsis';
              innerCell.style.whiteSpace = 'nowrap';
              innerCell.setAttribute(AUTOFIT_ELLIPSIS_ATTR, '1');
            }
          } else {
            if (rTd.hasAttribute(AUTOFIT_TITLE_ATTR)) {
              if (rTd.hasAttribute(AUTOFIT_ORIG_TITLE_ATTR)) {
                rTd.setAttribute('title', rTd.getAttribute(AUTOFIT_ORIG_TITLE_ATTR));
                rTd.removeAttribute(AUTOFIT_ORIG_TITLE_ATTR);
              } else {
                rTd.removeAttribute('title');
              }
              rTd.removeAttribute(AUTOFIT_TITLE_ATTR);
            }
            if (innerCell.hasAttribute(AUTOFIT_ELLIPSIS_ATTR)) {
              var origSaved = innerCell.getAttribute(AUTOFIT_ORIG_STYLE_ATTR);
              if (origSaved) {
                try {
                  var parsed = JSON.parse(origSaved);
                  if (parsed.overflow) innerCell.style.overflow = parsed.overflow;
                  else innerCell.style.removeProperty('overflow');
                  if (parsed.textOverflow) innerCell.style.textOverflow = parsed.textOverflow;
                  else innerCell.style.removeProperty('text-overflow');
                  if (parsed.whiteSpace) innerCell.style.whiteSpace = parsed.whiteSpace;
                  else innerCell.style.removeProperty('white-space');
                } catch (e) {
                  innerCell.style.removeProperty('overflow');
                  innerCell.style.removeProperty('text-overflow');
                  innerCell.style.removeProperty('white-space');
                }
                innerCell.removeAttribute(AUTOFIT_ORIG_STYLE_ATTR);
              } else {
                innerCell.style.removeProperty('overflow');
                innerCell.style.removeProperty('text-overflow');
                innerCell.style.removeProperty('white-space');
              }
              innerCell.removeAttribute(AUTOFIT_ELLIPSIS_ATTR);
            }
          }
        }
      }
    } else {
      // オートフィット OFF: 元の幅に戻す
      for (var origIdx = 0; origIdx < colCount; origIdx++) {
        if (isActionHidden(origIdx)) {
          calculatedWidths.push(0);
          continue;
        }
        var origW = 200;
        if (headerCols[origIdx]) {
          var stored = parseFloat(headerCols[origIdx].getAttribute('data-dbsext-orig-width'));
          if (!isNaN(stored)) origW = stored;
        }
        calculatedWidths.push(origW);
      }

      // 上限マークが残っていれば元のスタイルに完全復元
      var titledEls = table.querySelectorAll('[' + AUTOFIT_TITLE_ATTR + ']');
      for (var t = 0; t < titledEls.length; t++) {
        var tEl = titledEls[t];
        if (tEl.hasAttribute(AUTOFIT_ORIG_TITLE_ATTR)) {
          tEl.setAttribute('title', tEl.getAttribute(AUTOFIT_ORIG_TITLE_ATTR));
          tEl.removeAttribute(AUTOFIT_ORIG_TITLE_ATTR);
        } else {
          tEl.removeAttribute('title');
        }
        tEl.removeAttribute(AUTOFIT_TITLE_ATTR);
      }
      var ellipsisEls = table.querySelectorAll('[' + AUTOFIT_ELLIPSIS_ATTR + ']');
      for (var elIdx = 0; elIdx < ellipsisEls.length; elIdx++) {
        var elNode = ellipsisEls[elIdx];
        var origSavedStyle = elNode.getAttribute(AUTOFIT_ORIG_STYLE_ATTR);
        if (origSavedStyle) {
          try {
            var stObj = JSON.parse(origSavedStyle);
            if (stObj.overflow) elNode.style.overflow = stObj.overflow;
            else elNode.style.removeProperty('overflow');
            if (stObj.textOverflow) elNode.style.textOverflow = stObj.textOverflow;
            else elNode.style.removeProperty('text-overflow');
            if (stObj.whiteSpace) elNode.style.whiteSpace = stObj.whiteSpace;
            else elNode.style.removeProperty('white-space');
          } catch (e) {
            elNode.style.removeProperty('overflow');
            elNode.style.removeProperty('text-overflow');
            elNode.style.removeProperty('white-space');
          }
          elNode.removeAttribute(AUTOFIT_ORIG_STYLE_ATTR);
        } else {
          elNode.style.removeProperty('overflow');
          elNode.style.removeProperty('text-overflow');
          elNode.style.removeProperty('white-space');
        }
        elNode.removeAttribute(AUTOFIT_ELLIPSIS_ATTR);
      }
    }

    // 4. ループ防止 & SPA再描画対応
    var totalTableWidth = 0;
    for (var tw = 0; tw < calculatedWidths.length; tw++) {
      totalTableWidth += calculatedWidths[tw];
    }

    var widthSignature = calculatedWidths.join(',') + '|show:' + showActionCols + '|fit:' + autoFitEnabled + '|rows:' + visibleRowCount + '|w:' + totalTableWidth;

    // 内部テーブルが再生成されているか（参照が一致しない）か、各 col の現在の width 属性が一致していない場合はスキップしない
    var isDomUpToDate =
      table._dbsextLastHeaderTable === headerTable &&
      table._dbsextLastBodyTable === bodyTable &&
      table._dbsextLastWidthSignature === widthSignature;

    if (isDomUpToDate) {
      var allMatch = true;
      for (var chk = 0; chk < colCount; chk++) {
        var expectedW = String(calculatedWidths[chk]);
        if (canAutoFit) {
          if (!isActionHidden(chk)) {
            if (headerCols[chk] && headerCols[chk].getAttribute('width') !== expectedW) { allMatch = false; break; }
            if (bodyCols[chk] && bodyCols[chk].getAttribute('width') !== expectedW) { allMatch = false; break; }
          }
        }
      }
      if (allMatch) {
        return;
      }
    }

    table._dbsextLastHeaderTable = headerTable;
    table._dbsextLastBodyTable = bodyTable;
    table._dbsextLastWidthSignature = widthSignature;

    // 5. col width の適用
    for (var wIdx = 0; wIdx < colCount; wIdx++) {
      var wVal = String(calculatedWidths[wIdx]);
      if (canAutoFit) {
        if (!isActionHidden(wIdx)) {
          if (headerCols[wIdx] && headerCols[wIdx].getAttribute('width') !== wVal) {
            headerCols[wIdx].setAttribute('width', wVal);
          }
          if (bodyCols[wIdx] && bodyCols[wIdx].getAttribute('width') !== wVal) {
            bodyCols[wIdx].setAttribute('width', wVal);
          }
        }
      } else {
        // オートフィットOFF時は元の幅属性に戻す
        if (headerCols[wIdx]) {
          var hOrig = headerCols[wIdx].getAttribute('data-dbsext-orig-width');
          if (hOrig && headerCols[wIdx].getAttribute('width') !== hOrig) {
            headerCols[wIdx].setAttribute('width', hOrig);
          }
        }
        if (bodyCols[wIdx]) {
          var bOrig = bodyCols[wIdx].getAttribute('data-dbsext-orig-width');
          if (bOrig && bodyCols[wIdx].getAttribute('width') !== bOrig) {
            bodyCols[wIdx].setAttribute('width', bOrig);
          }
        }
      }
    }

    // 6. 表全体の幅設定（各テーブル個別にスコープして適用）
    var needsCustomWidth = canAutoFit || !showActionCols;
    applyScopedTableWidth(headerTable, bodyTable, totalTableWidth, needsCustomWidth);
  }

  function applyScopedTableWidth(headerTable, bodyTable, desiredWidth, needsCustom) {
    var applyTo = function (tbl) {
      if (!tbl) return;
      if (needsCustom && desiredWidth > 0) {
        var wStr = desiredWidth + 'px';
        if (tbl.style) {
          if (typeof tbl.style.setProperty === 'function') {
            tbl.style.setProperty('width', wStr, 'important');
          } else {
            tbl.style.width = wStr;
          }
        }
        if (tbl.setAttribute) {
          tbl.setAttribute('width', String(desiredWidth));
        }
      } else {
        // 元のテーブル幅へ戻す
        var origW = tbl.getAttribute && tbl.getAttribute('data-dbsext-orig-table-width');
        if (tbl.style) {
          if (origW) {
            if (typeof tbl.style.setProperty === 'function') {
              tbl.style.setProperty('width', origW.indexOf('px') >= 0 ? origW : origW + 'px');
            } else {
              tbl.style.width = origW;
            }
          } else {
            if (typeof tbl.style.removeProperty === 'function') {
              tbl.style.removeProperty('width');
            } else {
              delete tbl.style.width;
            }
          }
        }
        if (origW && tbl.setAttribute) {
          tbl.setAttribute('width', origW.replace(/px$/, ''));
        }
      }
    };

    applyTo(headerTable);
    applyTo(bodyTable);
  }

  function findExistingToggleUI(table) {
    if (!table) return null;
    if (table._dbsextToggleUI && table._dbsextToggleUI.parentNode) {
      return table._dbsextToggleUI;
    }
    if (table.previousElementSibling && table.previousElementSibling.hasAttribute && table.previousElementSibling.hasAttribute(UI_CONTAINER_ATTR)) {
      return table.previousElementSibling;
    }
    if (table.parentNode && table.parentNode.children) {
      var children = table.parentNode.children;
      var idx = children.indexOf ? children.indexOf(table) : -1;
      if (idx === -1) {
        for (var c = 0; c < children.length; c++) {
          if (children[c] === table) { idx = c; break; }
        }
      }
      if (idx > 0 && children[idx - 1].hasAttribute && children[idx - 1].hasAttribute(UI_CONTAINER_ATTR)) {
        return children[idx - 1];
      }
    }
    return null;
  }

  /**
   * 表上部にトグルバー（操作列たたむ / 列幅自動調整）を設置
   */
  function ensureToggleUI(table, showActionCols, autoFitEnabled, hasActionCols) {
    if (!table || !table.parentNode) return;

    var existing = findExistingToggleUI(table);
    if (existing) {
      var actionInput = existing.querySelector('[' + TOGGLE_INPUT_ATTR + ']');
      if (actionInput) {
        actionInput.checked = !showActionCols; // チェック = たたむ
      }
      var autoFitInput = existing.querySelector('[' + AUTOFIT_TOGGLE_ATTR + ']');
      if (autoFitInput) {
        autoFitInput.checked = !!autoFitEnabled;
      }
      return;
    }

    var bar = document.createElement('div');
    bar.setAttribute(UI_CONTAINER_ATTR, '1');
    bar.style.cssText =
      'display:flex; align-items:center; justify-content:flex-end; gap:16px; padding:4px 8px; margin-bottom:4px; font-size:13px;';

    // 1. 列幅自動調整トグル（既定ON）
    var autoFitLabel = document.createElement('label');
    autoFitLabel.style.cssText =
      'display:inline-flex; align-items:center; cursor:pointer; color:#303133; font-weight:500; user-select:none;';

    var autoFitCheckbox = document.createElement('input');
    autoFitCheckbox.type = 'checkbox';
    autoFitCheckbox.setAttribute(AUTOFIT_TOGGLE_ATTR, '1');
    autoFitCheckbox.checked = !!autoFitEnabled;
    autoFitCheckbox.style.cssText =
      'margin-right:6px; cursor:pointer; accent-color:#0b5cab; width:15px; height:15px;';

    autoFitCheckbox.addEventListener('change', function () {
      var currentScreen = getScreen();
      var newAutoFit = autoFitCheckbox.checked;
      saveAutoFitState(currentScreen, newAutoFit);
      var currentShow = loadToggleState(currentScreen);
      reapplyCurrentScreen(currentShow, newAutoFit);
    });

    var autoFitSpan = document.createElement('span');
    autoFitSpan.textContent = '列幅を自動調整';

    autoFitLabel.appendChild(autoFitCheckbox);
    autoFitLabel.appendChild(autoFitSpan);
    // 停止中は操作できるトグルを出さない（押しても効かないUIを残さないため）
    if (AUTOFIT_ENABLED) bar.appendChild(autoFitLabel);

    // 2. 操作列トグル（操作列がある場合のみ表示）
    if (hasActionCols) {
      var actionLabel = document.createElement('label');
      actionLabel.style.cssText =
        'display:inline-flex; align-items:center; cursor:pointer; color:#303133; font-weight:500; user-select:none;';

      var actionCheckbox = document.createElement('input');
      actionCheckbox.type = 'checkbox';
      actionCheckbox.setAttribute(TOGGLE_INPUT_ATTR, '1');
      actionCheckbox.checked = !showActionCols; // チェック = たたむ
      actionCheckbox.style.cssText =
        'margin-right:6px; cursor:pointer; accent-color:#0b5cab; width:15px; height:15px;';

      actionCheckbox.addEventListener('change', function () {
        var currentScreen = getScreen();
        var newShow = !actionCheckbox.checked;
        saveToggleState(currentScreen, newShow);
        var currentAutoFit = loadAutoFitState(currentScreen);
        reapplyCurrentScreen(newShow, currentAutoFit);
      });

      var actionSpan = document.createElement('span');
      actionSpan.textContent = '操作列をたたむ';

      actionLabel.appendChild(actionCheckbox);
      actionLabel.appendChild(actionSpan);
      bar.appendChild(actionLabel);
    }

    table._dbsextToggleUI = bar;
    table.parentNode.insertBefore(bar, table);
  }

  function reapplyCurrentScreen(overrideShow, overrideAutoFit) {
    if (typeof document === 'undefined') return;
    var currentScreen = getScreen();
    var show = (typeof overrideShow === 'boolean') ? overrideShow : loadToggleState(currentScreen);
    var fit = (typeof overrideAutoFit === 'boolean') ? overrideAutoFit : loadAutoFitState(currentScreen);

    var tables = document.querySelectorAll('.el-table');
    if (!tables || tables.length === 0) return;

    for (var t = 0; t < tables.length; t++) {
      var table = tables[t];
      if (table.getAttribute('data-dbsext-table') === 'custom' ||
          table.getAttribute('data-dbsext-vp-table') ||
          table.getAttribute('data-dbsext-beacons-table')) {
        continue;
      }

      var headerTable = table.querySelector('table.el-table__header');
      var bodyTable = table.querySelector('table.el-table__body');
      if (!headerTable && !bodyTable) continue;

      var actionIndices = findActionColumnIndices(headerTable);

      var uiBar = findExistingToggleUI(table);
      if (uiBar) {
        var aIn = uiBar.querySelector('[' + TOGGLE_INPUT_ATTR + ']');
        if (aIn) aIn.checked = !show;
        var afIn = uiBar.querySelector('[' + AUTOFIT_TOGGLE_ATTR + ']');
        if (afIn) afIn.checked = !!fit;
      }

      applyTableWidths(table, actionIndices, show, fit);
      if (D.tableWrap && typeof D.tableWrap.refresh === 'function') {
        D.tableWrap.refresh(table);
      }
    }
  }

  var isApplying = false;

  D.tableColumns = {
    ACTION_COLUMNS: ACTION_COLUMNS,
    STORAGE_FEATURE: STORAGE_FEATURE,
    STORAGE_FEATURE_AUTOFIT: STORAGE_FEATURE_AUTOFIT,
    _measureText: null,

    /**
     * テスト専用: 実行時オートフィットの停止スイッチを切り替える。
     * 本番コードからは呼ばない（配信物では常に無効のまま）。
     */
    _setAutoFitEnabled: function (enabled) { AUTOFIT_ENABLED = !!enabled; },
    _isAutoFitEnabled: function () { return AUTOFIT_ENABLED; },

    apply: function () {
      if (typeof document === 'undefined') return;
      if (isApplying) return;
      isApplying = true;

      try {
        var screen = getScreen();
        var tables = document.querySelectorAll('.el-table');
        if (!tables || tables.length === 0) return;

        var showActionCols = loadToggleState(screen);
        var autoFitEnabled = loadAutoFitState(screen);

        for (var t = 0; t < tables.length; t++) {
          var table = tables[t];
          // 自前表（ビーコン一覧・問題申告一覧）は対象外
          if (table.getAttribute('data-dbsext-table') === 'custom' ||
              table.getAttribute('data-dbsext-vp-table') ||
              table.getAttribute('data-dbsext-beacons-table')) {
            continue;
          }

          var headerTable = table.querySelector('table.el-table__header');
          var bodyTable = table.querySelector('table.el-table__body');
          if (!headerTable && !bodyTable) continue;

          var actionIndices = findActionColumnIndices(headerTable);
          var hasActionCols = actionIndices.length > 0;

          ensureToggleUI(
            table,
            showActionCols,
            autoFitEnabled,
            hasActionCols
          );

          applyTableWidths(table, actionIndices, showActionCols, autoFitEnabled);
          if (D.tableWrap && typeof D.tableWrap.refresh === 'function') {
            D.tableWrap.refresh(table);
          }
        }
      } finally {
        isApplying = false;
      }
    },

    /**
     * 「オリジナルに戻す」表示専用。保存済みの表示設定は変えず、
     * 一時的に全列表示・オートフィットOFFの純正状態へ戻す。
     */
    peekShowAll: function () {
      if (typeof document === 'undefined') return;
      var tables = document.querySelectorAll ? document.querySelectorAll('.el-table') : [];
      for (var i = 0; i < tables.length; i++) {
        var table = tables[i];
        if (table.getAttribute('data-dbsext-table') === 'custom' ||
            table.getAttribute('data-dbsext-vp-table') ||
            table.getAttribute('data-dbsext-beacons-table')) {
          continue;
        }
        var headerTable = table.querySelector('table.el-table__header');
        var actionIndices = findActionColumnIndices(headerTable);
        applyTableWidths(table, actionIndices, true, false);
      }
    },

    /** 「オリジナルに戻す」を解除し、保存済みの最新表示設定へ戻す */
    peekRestore: function () {
      reapplyCurrentScreen();
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
