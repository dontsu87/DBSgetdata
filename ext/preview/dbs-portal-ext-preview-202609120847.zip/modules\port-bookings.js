/** ポート詳細画面に、現在の更新予約を読み取り専用で表示する。 */
(function (global) {
  'use strict';
  var D = global.DBSEXT = global.DBSEXT || {};
  var PANEL_ATTR = 'data-dbsext-port-bookings';
  var STYLE_ATTR = 'data-dbsext-port-bookings-style';
  var activePortId = null;
  var fetching = false;
  var generation = 0;

  function getPortIdFromUrl() {
    if (typeof location === 'undefined') return null;
    var match = /^\/ports\/(PORT:[A-Za-z0-9:_-]{1,256})\/?$/.exec(location.pathname || '');
    return match ? match[1] : null;
  }

  function normalizeBookings(value) {
    if (!Array.isArray(value)) return null;
    var rows = [];
    for (var i = 0; i < value.length; i++) {
      var item = value[i];
      if (!item || typeof item !== 'object' ||
          typeof item.updateReflectionDateTime !== 'string' ||
          typeof item.serviceState !== 'string' ||
          typeof item.publishFlag !== 'boolean' ||
          typeof item.parkingQuantityLimitationFlag !== 'boolean') return null;
      rows.push({
        updateReflectionDateTime: item.updateReflectionDateTime,
        serviceState: item.serviceState,
        publishFlag: item.publishFlag,
        parkingQuantityLimitationFlag: item.parkingQuantityLimitationFlag,
        parkingQuantityLimit: item.parkingQuantityLimit
      });
    }
    rows.sort(function (a, b) { return a.updateReflectionDateTime.localeCompare(b.updateReflectionDateTime); });
    return rows;
  }

  function removePanel() {
    if (typeof document === 'undefined') return;
    var panel = document.querySelector('[' + PANEL_ATTR + '="1"]');
    if (panel && panel.parentNode) panel.parentNode.removeChild(panel); // dbsext:own-ui
  }

  function findInsertionPoint() {
    if (typeof document === 'undefined') return null;
    var forms = document.querySelectorAll('form');
    for (var i = 0; i < forms.length; i++) {
      var content = String(forms[i].textContent || '').replace(/\s+/g, ' ');
      if (content.indexOf('更新日時') !== -1 && content.indexOf('運用状態') !== -1 &&
          (content.indexOf('予約登録') !== -1 || content.indexOf('削除') !== -1)) {
        return { container: forms[i].parentNode, sibling: forms[i] };
      }
    }
    return null;
  }

  function ensureStyle() {
    if (typeof document === 'undefined' || document.querySelector('[' + STYLE_ATTR + ']')) return;
    var style = document.createElement('style');
    style.setAttribute(STYLE_ATTR, '1');
    style.textContent =
      '[' + PANEL_ATTR + ']{margin:20px 0;padding:18px 20px;border:1px solid #b9d3e8;border-left:5px solid #0b5cab;border-radius:8px;background:#f7fbff;color:#263442}' +
      '[' + PANEL_ATTR + '] .dbsext-pb-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:12px}' +
      '[' + PANEL_ATTR + '] h3{margin:0;font-size:18px}' +
      '[' + PANEL_ATTR + '] button{border:1px solid #0b5cab;border-radius:6px;padding:6px 10px;background:#fff;color:#0b5cab;cursor:pointer}' +
      '[' + PANEL_ATTR + '] .dbsext-pb-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}' +
      '[' + PANEL_ATTR + '] .dbsext-pb-item{padding:12px;border:1px solid #d9e5ef;border-radius:6px;background:#fff}' +
      '[' + PANEL_ATTR + '] .dbsext-pb-time{margin:0 0 7px;font-weight:700}' +
      '[' + PANEL_ATTR + '] .dbsext-pb-state{margin:3px 0;font-size:13px}' +
      '@media(max-width:700px){[' + PANEL_ATTR + '] .dbsext-pb-grid{grid-template-columns:1fr}}';
    (document.head || document.documentElement).appendChild(style);
  }

  function formatDate(value) {
    var date = new Date(value);
    if (isNaN(date.getTime())) return value;
    return new Intl.DateTimeFormat('ja-JP', {
      timeZone: 'Asia/Tokyo', year: 'numeric', month: '2-digit', day: '2-digit',
      weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false
    }).format(date);
  }

  function addText(parent, className, value) {
    var p = document.createElement('p'); p.className = className; p.textContent = value; parent.appendChild(p);
  }

  function render(portId, rows) {
    removePanel();
    if (!rows.length || portId !== getPortIdFromUrl()) return;
    var insertion = findInsertionPoint();
    if (!insertion || !insertion.container) return;
    ensureStyle();
    var panel = document.createElement('section'); panel.setAttribute(PANEL_ATTR, '1'); panel.setAttribute(PANEL_ATTR + '-port', portId);
    var head = document.createElement('div'); head.className = 'dbsext-pb-head';
    var title = document.createElement('h3'); title.textContent = '更新予約（拡張表示）'; head.appendChild(title);
    var button = document.createElement('button'); button.type = 'button'; button.textContent = '再読込';
    button.addEventListener('click', function () { fetchAndRender(portId, true); }); head.appendChild(button); panel.appendChild(head);
    var grid = document.createElement('div'); grid.className = 'dbsext-pb-grid';
    rows.forEach(function (item, index) {
      var card = document.createElement('div'); card.className = 'dbsext-pb-item';
      addText(card, 'dbsext-pb-time', '予約' + (index + 1) + '　' + formatDate(item.updateReflectionDateTime));
      addText(card, 'dbsext-pb-state', '運用状態: ' + item.serviceState);
      addText(card, 'dbsext-pb-state', '公開: ' + (item.publishFlag ? '公開' : '非公開'));
      addText(card, 'dbsext-pb-state', '駐輪台数制限: ' + (item.parkingQuantityLimitationFlag ? '有効' : '無効') +
        (item.parkingQuantityLimitationFlag ? '（上限' + item.parkingQuantityLimit + '台）' : ''));
      grid.appendChild(card);
    });
    panel.appendChild(grid);
    insertion.container.insertBefore(panel, insertion.sibling);
  }

  function fetchAndRender(portId, force) {
    if (fetching && !force) return;
    fetching = true; var ownGeneration = ++generation;
    fetch('/api/ports/' + portId + '/bookings', { credentials: 'include' })
      .then(function (response) { if (!response.ok) throw new Error('HTTP ' + response.status); return response.json(); })
      .then(function (body) {
        var rows = normalizeBookings(body);
        if (rows === null) throw new Error('予約応答の形式が不正です');
        if (ownGeneration === generation) render(portId, rows);
      })
      .catch(function (error) {
        if (D.core && typeof D.core.log === 'function') D.core.log('更新予約の取得に失敗: ' + error.message, true);
      })
      .finally(function () { if (ownGeneration === generation) fetching = false; });
  }

  D.portBookings = {
    apply: function () {
      var portId = getPortIdFromUrl();
      if (!portId) { activePortId = null; generation++; fetching = false; removePanel(); return; }
      if (activePortId === portId) return;
      activePortId = portId; removePanel(); fetchAndRender(portId, false);
    },
    _getPortIdFromUrl: getPortIdFromUrl,
    _normalizeBookings: normalizeBookings,
    _resetForTest: function () { activePortId = null; generation = 0; fetching = false; }
  };
}(typeof globalThis !== 'undefined' ? globalThis : window));
