/**
 * DBSEXT テーブル列制御モジュール（静的推奨幅 + 操作列制御）
 *
 * 目的:
 * 1. 車両情報（/vehicles）の横長テーブル問題に対処するため、
 *    操作系5列（メンテナンス、AT管理、解錠、再配置、AT一体型車両操作）を
 *    トグルで隠せるようにする（既定は表示）。
 * 2. デフォルトの一律200px等の広すぎる列幅に対し、画面パスとヘッダ文言の
 *    安定入力に基づき、レイアウト自己帰還のない「静的推奨幅」を CSS !important で
 *    各列・セルへ適用する（既定はON）。
 * 3. 画面レイアウト結果（clientWidth / offsetWidth / scrollWidth / Canvas / getComputedStyle 等）
 *    は一切入力として使用しない。
 * 4. <table> や wrapper 全体の幅は設定せず、Element Plus 自身の表レイアウトに任せる。
 * 5. 多段ヘッダ、未知画面、未知表形状、行数0件では安全に fail-closed (no-op) とする。
 * 6. 操作列は危険な狭幅で上書きせず、静的推奨幅の適用対象から除外する。
 *
 * 契約 §6 の遵守:
 * - DOMノードの削除・移動は一切行わない（display: none による表示制御、および col/th/td style 設定のみ）
 * - 操作ボタン自体には一切介入しない
 * - 通信は一切行わない
 * - setInterval / eval / new Function を使わない
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var ACTION_COLUMNS = [
    'メンテナンス',
    'AT管理',
    '解錠',
    '再配置',
    'AT一体型車両操作'
  ];

  /**
   * 画面パスおよび列名に基づく静的推奨幅テーブル（px）
   * docs/17 実測値および docs/18 教訓に基づく。
   * 操作列は危険な狭幅を強制せず除外。
   * レイアウト読取（clientWidth, offsetWidth, Canvas, getComputedStyle 等）は一切使わない。
   */
  var STATIC_COLUMN_RECOMMENDATIONS = {
    '/users': {
      'ユーザ識別番号': 260,
      'ユーザID': 130,
      '氏名 姓': 90,
      '氏名 名': 90,
      'ユーザ種別': 120,
      'ユーザ登録状態': 110,
      '車両利用状態': 110,
      '最新利用開始日時': 160,
      '決済状態': 90,
      '強制停止状態': 90,
      '利用明細': 90
    },
    '/vehicles': {
      '': 44, // チェックボックス
      '車両識別番号': 140,
      '車両情報': 100,
      '車両状態': 100,
      'ポート名': 200,
      'ユーザ識別番号': 260,
      'AT種別': 90,
      'バッテリー': 90,
      '貸出日時': 160,
      'AT通知受信日時': 160,
      'AT識別番号': 140
    }
  };

  var EXPECTED_USERS_COLUMNS = [
    'ユーザ識別番号',
    'ユーザID',
    '氏名 姓',
    '氏名 名',
    'ユーザ種別',
    'ユーザ登録状態',
    '車両利用状態',
    '最新利用開始日時',
    '決済状態',
    '強制停止状態',
    '利用明細'
  ];

  var EXPECTED_VEHICLES_COLUMNS = [
    '',
    '車両識別番号',
    '車両情報',
    '車両状態',
    'ポート名',
    'ユーザ識別番号',
    'AT種別',
    'バッテリー',
    '貸出日時',
    'AT通知受信日時',
    'メンテナンス',
    'AT管理',
    '解錠',
    '再配置',
    'AT識別番号',
    'AT一体型車両操作'
  ];

  var STORAGE_FEATURE = 'showActionCols';
  var STORAGE_FEATURE_AUTOFIT = 'autoFitCols';
  var FALLBACK_STORAGE_PREFIX = 'dbsext:fallback:table-cols:';
  var UI_CONTAINER_ATTR = 'data-dbsext-table-columns';
  var TOGGLE_INPUT_ATTR = 'data-dbsext-action-toggle';
  var AUTOFIT_TOGGLE_ATTR = 'data-dbsext-autofit-toggle';

  function getScreen() {
    if (typeof location === 'undefined' || !location.pathname) return '';
    return location.pathname;
  }

  function normalizePath(screen) {
    if (!screen || typeof screen !== 'string') {
      if (typeof location !== 'undefined' && location.pathname) {
        screen = location.pathname;
      } else {
        screen = '/';
      }
    }
    if (screen.charAt(0) !== '/') screen = '/' + screen;
    screen = screen.replace(/\/+/g, '/');
    screen = screen.split('?')[0].split('#')[0];
    if (screen.length > 1 && screen.charAt(screen.length - 1) === '/') {
      screen = screen.slice(0, -1);
    }
    return screen || '/';
  }

  function getStaticRecommendations(screen) {
    if (!screen) return null;
    var normScreen = normalizePath(screen).toLowerCase();
    // 一覧ルートのみ厳密に限定（詳細画面 /users/general/... や /vehicles/.../histories 等は null）
    if (normScreen === '/users') {
      return STATIC_COLUMN_RECOMMENDATIONS['/users'];
    }
    if (normScreen === '/vehicles') {
      return STATIC_COLUMN_RECOMMENDATIONS['/vehicles'];
    }
    return null;
  }

  function getFallbackStorageKey(screen, feature) {
    return FALLBACK_STORAGE_PREFIX + normalizePath(screen) + ':' + feature;
  }

  function loadToggleState(screen) {
    try {
      var normScreen = normalizePath(screen);
      var legacyKey = 'dbsext:v1:' + normScreen + ':' + STORAGE_FEATURE;
      var fbKey = getFallbackStorageKey(screen, STORAGE_FEATURE);

      // REMARK-M6-STATE: 1. レガシー生文字列 ('true' / 'false') の救出とマイグレーション
      // stateStore.load より先にチェックし、誤って非オブジェクトとして削除されるのを防ぐ
      if (typeof localStorage !== 'undefined') {
        var legacyRaw = localStorage.getItem(legacyKey);
        if (legacyRaw === 'true' || legacyRaw === 'false') {
          var valLegacy = legacyRaw === 'true';
          if (D.stateStore && typeof D.stateStore.save === 'function') {
            var savedLegacy = false;
            try {
              savedLegacy = D.stateStore.save(screen, STORAGE_FEATURE, valLegacy, { scope: 'local' });
            } catch (e) {
              savedLegacy = false;
            }
            if (savedLegacy === true) {
              try { localStorage.removeItem(fbKey); } catch (e) {}
            } else {
              localStorage.setItem(fbKey, valLegacy ? 'true' : 'false');
              try { localStorage.removeItem(legacyKey); } catch (e) {}
            }
          } else {
            localStorage.setItem(fbKey, valLegacy ? 'true' : 'false');
            try { localStorage.removeItem(legacyKey); } catch (e) {}
          }
          return valLegacy;
        }
      }

      // 2. stateStore の正規レコード読み込み
      if (D.stateStore && typeof D.stateStore.load === 'function') {
        var val = D.stateStore.load(screen, STORAGE_FEATURE);
        if (val !== null && typeof val !== 'undefined') {
          if (typeof localStorage !== 'undefined') {
            try { localStorage.removeItem(fbKey); } catch (e) {}
          }
          return !!val;
        }
      }

      // 3. フォールバックストレージの読み込み
      if (typeof localStorage !== 'undefined') {
        var rawFallback = localStorage.getItem(fbKey);
        if (rawFallback === 'true' || rawFallback === 'false') {
          var valFb = rawFallback === 'true';
          if (D.stateStore && typeof D.stateStore.save === 'function') {
            var savedFb = false;
            try {
              savedFb = D.stateStore.save(screen, STORAGE_FEATURE, valFb, { scope: 'local' });
            } catch (e) {
              savedFb = false;
            }
            if (savedFb === true) {
              try { localStorage.removeItem(fbKey); } catch (e) {}
            }
          }
          return valFb;
        }
      }
    } catch (e) {}
    return true; // 既定は「表示」（showActionCols = true）
  }

  function saveToggleState(screen, show) {
    try {
      var normScreen = normalizePath(screen);
      var fbKey = getFallbackStorageKey(screen, STORAGE_FEATURE);
      var legacyKey = 'dbsext:v1:' + normScreen + ':' + STORAGE_FEATURE;
      var saved = false;
      if (D.stateStore && typeof D.stateStore.save === 'function') {
        try {
          saved = D.stateStore.save(screen, STORAGE_FEATURE, !!show, { scope: 'local' });
        } catch (e) {
          saved = false;
        }
      }
      if (saved === true) {
        if (typeof localStorage !== 'undefined') {
          try { localStorage.removeItem(fbKey); } catch (e) {}
        }
      } else if (typeof localStorage !== 'undefined') {
        localStorage.setItem(fbKey, show ? 'true' : 'false');
        try { localStorage.removeItem(legacyKey); } catch (e) {}
      }
    } catch (e) {}
  }

  function loadAutoFitState(screen) {
    try {
      var normScreen = normalizePath(screen);
      var legacyKey = 'dbsext:v1:' + normScreen + ':' + STORAGE_FEATURE_AUTOFIT;
      var fbKey = getFallbackStorageKey(screen, STORAGE_FEATURE_AUTOFIT);

      // REMARK-M6-STATE: 1. レガシー生文字列 ('true' / 'false') の救出とマイグレーション
      // stateStore.load より先にチェックし、誤って非オブジェクトとして削除されるのを防ぐ
      if (typeof localStorage !== 'undefined') {
        var legacyRaw = localStorage.getItem(legacyKey);
        if (legacyRaw === 'true' || legacyRaw === 'false') {
          var valLegacy = legacyRaw === 'true';
          if (D.stateStore && typeof D.stateStore.save === 'function') {
            var savedLegacy = false;
            try {
              savedLegacy = D.stateStore.save(screen, STORAGE_FEATURE_AUTOFIT, valLegacy, { scope: 'local' });
            } catch (e) {
              savedLegacy = false;
            }
            if (savedLegacy === true) {
              try { localStorage.removeItem(fbKey); } catch (e) {}
            } else {
              localStorage.setItem(fbKey, valLegacy ? 'true' : 'false');
              try { localStorage.removeItem(legacyKey); } catch (e) {}
            }
          } else {
            localStorage.setItem(fbKey, valLegacy ? 'true' : 'false');
            try { localStorage.removeItem(legacyKey); } catch (e) {}
          }
          return valLegacy;
        }
      }

      // 2. stateStore の正規レコード読み込み
      if (D.stateStore && typeof D.stateStore.load === 'function') {
        var val = D.stateStore.load(screen, STORAGE_FEATURE_AUTOFIT);
        if (val !== null && typeof val !== 'undefined') {
          if (typeof localStorage !== 'undefined') {
            try { localStorage.removeItem(fbKey); } catch (e) {}
          }
          return !!val;
        }
      }

      // 3. フォールバックストレージの読み込み
      if (typeof localStorage !== 'undefined') {
        var rawFallback = localStorage.getItem(fbKey);
        if (rawFallback === 'true' || rawFallback === 'false') {
          var valFb = rawFallback === 'true';
          if (D.stateStore && typeof D.stateStore.save === 'function') {
            var savedFb = false;
            try {
              savedFb = D.stateStore.save(screen, STORAGE_FEATURE_AUTOFIT, valFb, { scope: 'local' });
            } catch (e) {
              savedFb = false;
            }
            if (savedFb === true) {
              try { localStorage.removeItem(fbKey); } catch (e) {}
            }
          }
          return valFb;
        }
      }
    } catch (e) {}
    return true; // 既定は有効（静的CSS方式のため安全）
  }

  function saveAutoFitState(screen, enabled) {
    try {
      var normScreen = normalizePath(screen);
      var fbKey = getFallbackStorageKey(screen, STORAGE_FEATURE_AUTOFIT);
      var legacyKey = 'dbsext:v1:' + normScreen + ':' + STORAGE_FEATURE_AUTOFIT;
      var saved = false;
      if (D.stateStore && typeof D.stateStore.save === 'function') {
        try {
          saved = D.stateStore.save(screen, STORAGE_FEATURE_AUTOFIT, !!enabled, { scope: 'local' });
        } catch (e) {
          saved = false;
        }
      }
      if (saved === true) {
        if (typeof localStorage !== 'undefined') {
          try { localStorage.removeItem(fbKey); } catch (e) {}
        }
      } else if (typeof localStorage !== 'undefined') {
        localStorage.setItem(fbKey, enabled ? 'true' : 'false');
        try { localStorage.removeItem(legacyKey); } catch (e) {}
      }
    } catch (e) {}
  }

  /**
   * 列の見出し名を取り出す。
   * table-tools の自前UIが付加されている場合でも元の見出し名を取得する。
   * SPA での DOM 再利用時に古い data-dbsext-orig-title 属性が残っていても、
   * 自前UIを除外した最新の可視テキストを優先して取得する。
   */
  function headerName(th) {
    if (!th) return '';

    if (typeof th.cloneNode === 'function') {
      var clone = th.cloneNode(true);
      var own = clone.querySelectorAll(
        '[data-dbsext-sort],[data-dbsext-filter],[data-dbsext-filter-select],[data-dbsext-filter-min],[data-dbsext-filter-max],[data-dbsext-collapse-hint],.dbsext-th-sort,.dbsext-th-filters,.dbsext-own-ui'
      );
      for (var i = 0; i < own.length; i++) {
        if (own[i].parentNode) own[i].parentNode.removeChild(own[i]); // dbsext:own-ui
      }
      return (clone.textContent || '').trim();
    }
    return (th.textContent || '').trim();
  }

  function findActionColumnIndices(headerTable) {
    if (!headerTable) return [];
    var ths = headerTable.querySelectorAll('thead th, tr th');
    var indices = [];
    for (var i = 0; i < ths.length; i++) {
      var text = headerName(ths[i]);
      for (var k = 0; k < ACTION_COLUMNS.length; k++) {
        if (text === ACTION_COLUMNS[k]) {
          indices.push(i);
          break;
        }
      }
    }
    return indices;
  }

  function isMultiRowOrSpanHeader(headerTable) {
    if (!headerTable) return false;
    var thead = headerTable.querySelector('thead');
    var rows = thead ? thead.querySelectorAll('tr') : headerTable.querySelectorAll('tr');
    if (rows.length > 1) return true;
    var ths = headerTable.querySelectorAll('th');
    for (var i = 0; i < ths.length; i++) {
      var th = ths[i];
      var cs = parseInt(th.getAttribute('colspan') || '1', 10);
      var rs = parseInt(th.getAttribute('rowspan') || '1', 10);
      if ((!isNaN(cs) && cs > 1) || (!isNaN(rs) && rs > 1)) {
        return true;
      }
    }
    return false;
  }

  /**
   * チェックボックス要素またはクラスを持つか判定 (REMARK-TABLE-02)
   */
  function hasCheckboxLike(cell) {
    if (!cell) return false;
    if (cell.querySelector && cell.querySelector('input[type="checkbox"], .el-checkbox, .el-checkbox__input')) {
      return true;
    }
    if (cell.classList && (cell.classList.contains('el-table-column--selection') || cell.classList.contains('el-checkbox') || cell.classList.contains('el-checkbox__input'))) {
      return true;
    }
    return false;
  }

  /**
   * 対象テーブルの形状・列構成を厳密に検証する (REMARK-TABLE-02)
   */
  function validateTargetTable(table, screen, headerTable, bodyTable) {
    if (!table || !headerTable || !bodyTable) return false;
    var normScreen = normalizePath(screen).toLowerCase();
    if (normScreen !== '/users' && normScreen !== '/vehicles') {
      return false;
    }

    // 自前テーブルは除外
    if (table.getAttribute('data-dbsext-table') === 'custom' ||
        table.getAttribute('data-dbsext-vp-table') ||
        table.getAttribute('data-dbsext-beacons-table')) {
      return false;
    }

    // header / body の colgroup がそれぞれちょうど1つ存在すること (REMARK-TABLE-02)
    var headerColgroups = headerTable.querySelectorAll('colgroup');
    var bodyColgroups = bodyTable.querySelectorAll('colgroup');
    if (headerColgroups.length !== 1 || bodyColgroups.length !== 1) {
      return false;
    }

    var headerRows = headerTable.querySelectorAll('thead tr, tr');
    if (headerRows.length !== 1) return false;
    var headerThs = headerRows[0].children;
    var colCount = headerThs.length;
    if (colCount === 0) return false;

    var headerCols = headerTable.querySelectorAll('colgroup col');
    var bodyCols = bodyTable.querySelectorAll('colgroup col');
    if (headerCols.length !== colCount || bodyCols.length !== colCount) {
      return false; // colgroup の欠落・不一致・重複
    }

    var allBodyRows = bodyTable.querySelectorAll('tbody tr');
    // 行数0件は未定義・適用対象外として拒否 (REMARK-TABLE-01: 真の no-op)
    if (allBodyRows.length === 0) {
      return false;
    }
    // 全 body 行の列数を検証（途中の行の不一致も拒否）
    for (var r = 0; r < allBodyRows.length; r++) {
      if (allBodyRows[r].children.length !== colCount) {
        return false;
      }
    }

    var headerTitles = [];
    var emptyHeaderCount = 0;
    for (var i = 0; i < colCount; i++) {
      var title = headerName(headerThs[i]);
      headerTitles.push(title);
      if (title === '') {
        emptyHeaderCount++;
      }
    }

    if (normScreen === '/users') {
      if (colCount !== EXPECTED_USERS_COLUMNS.length) return false;
      if (emptyHeaderCount !== 0) return false; // /users はチェックボックス列なし・空見出しなし
      // チェックボックス要素・クラスが header / body に一切存在しないこと
      for (var uTh = 0; uTh < colCount; uTh++) {
        if (hasCheckboxLike(headerThs[uTh])) return false;
      }
      for (var uRow = 0; uRow < allBodyRows.length; uRow++) {
        for (var uTd = 0; uTd < colCount; uTd++) {
          if (hasCheckboxLike(allBodyRows[uRow].children[uTd])) return false;
        }
      }
      // 期待列の照合
      for (var u = 0; u < EXPECTED_USERS_COLUMNS.length; u++) {
        if (headerTitles[u] !== EXPECTED_USERS_COLUMNS[u]) return false;
      }
      return true;
    }

    if (normScreen === '/vehicles') {
      if (colCount !== EXPECTED_VEHICLES_COLUMNS.length) return false;
      if (emptyHeaderCount !== 1 || headerTitles[0] !== '') return false; // /vehicles は先頭にチェックボックス1列のみ空見出し
      var firstThCb = hasCheckboxLike(headerThs[0]);
      if (!firstThCb) return false;
      // 全ての body 行の先頭列に実チェックボックスが存在すること (REMARK-TABLE-02)
      for (var vRow0 = 0; vRow0 < allBodyRows.length; vRow0++) {
        if (!hasCheckboxLike(allBodyRows[vRow0].children[0])) {
          return false;
        }
      }
      // 2列目以降にチェックボックスが存在しないこと (REMARK-TABLE-02)
      for (var vTh = 1; vTh < colCount; vTh++) {
        if (hasCheckboxLike(headerThs[vTh])) return false;
      }
      for (var vRow = 0; vRow < allBodyRows.length; vRow++) {
        for (var vTd = 1; vTd < colCount; vTd++) {
          if (hasCheckboxLike(allBodyRows[vRow].children[vTd])) return false;
        }
      }
      // 期待列の照合
      for (var v = 1; v < EXPECTED_VEHICLES_COLUMNS.length; v++) {
        if (headerTitles[v] !== EXPECTED_VEHICLES_COLUMNS[v]) return false;
      }
      return true;
    }

    return false;
  }

  function getRecommendedColWidth(screen, colIndex, headerTitle) {
    var recs = getStaticRecommendations(screen);
    if (!recs) return null;
    if (headerTitle && typeof recs[headerTitle] === 'number') {
      return recs[headerTitle];
    }
    if (colIndex === 0 && typeof recs[''] === 'number') {
      return recs[''];
    }
    return null;
  }

  /**
   * 明示された幅だけを安全に数値化する。
   * clientWidth / offsetWidth / getComputedStyle 等のレイアウト測定APIは一切使用しない。
   * 300junk や 300% は元幅として採用せず、読めない場合は null（fail-closed）にする。
   */
  function parseExplicitWidth(value, allowUnitless) {
    if (typeof value === 'number') {
      return isFinite(value) && value > 0 ? value : null;
    }
    if (value === undefined || value === null) return null;
    var text = String(value).trim();
    var match = /^([0-9]+(?:\.[0-9]+)?)(px)?$/i.exec(text);
    if (!match || (!match[2] && !allowUnitless)) return null;
    var number = Number(match[1]);
    return isFinite(number) && number > 0 ? number : null;
  }

  function readExplicitWidth(el) {
    if (!el) return null;

    if (el._dbsextOrigStyles && el._dbsextOrigStyles['width']) {
      var backedUp = parseExplicitWidth(el._dbsextOrigStyles['width'].val, false);
      if (backedUp !== null) return backedUp;
    }

    if (typeof el.getAttribute === 'function') {
      var originalAttr = parseExplicitWidth(el.getAttribute('data-dbsext-orig-width'), true);
      if (originalAttr !== null) return originalAttr;

      // HTML の width 属性は単位なし数値または px を受け入れる。% は除外する。
      var widthAttr = parseExplicitWidth(el.getAttribute('width'), true);
      if (widthAttr !== null) return widthAttr;
    }

    if (el.style) {
      var styleWidth = '';
      if (typeof el.style.getPropertyValue === 'function') {
        styleWidth = el.style.getPropertyValue('width') || '';
      } else {
        styleWidth = el.style.width || '';
      }
      var explicitStyle = parseExplicitWidth(styleWidth, false);
      if (explicitStyle !== null) return explicitStyle;
    }

    return null;
  }

  /**
   * col または th から明示された元幅（px数値）を読む。
   * col を優先し、列幅が無い場合だけ th の明示幅へフォールバックする。
   */
  function getExplicitColWidth(col, th) {
    var colWidth = readExplicitWidth(col);
    return colWidth !== null ? colWidth : readExplicitWidth(th);
  }

  function backupOriginalStyle(el, prop) {
    if (!el || !el.style) return;
    if (!el._dbsextOrigStyles) el._dbsextOrigStyles = {};
    if (el._dbsextOrigStyles[prop] === undefined) {
      var val = '';
      var prio = '';
      if (typeof el.style.getPropertyValue === 'function') {
        val = el.style.getPropertyValue(prop) || '';
      } else {
        var camel = prop === 'min-width' ? 'minWidth' : (prop === 'max-width' ? 'maxWidth' : prop);
        val = el.style[camel] || '';
      }
      if (typeof el.style.getPropertyPriority === 'function') {
        prio = el.style.getPropertyPriority(prop) || '';
      }
      el._dbsextOrigStyles[prop] = { val: val, prio: prio };
    }
  }

  function restoreOriginalStyle(el, prop) {
    if (!el || !el.style || !el._dbsextOrigStyles) return;
    var orig = el._dbsextOrigStyles[prop];
    if (orig) {
      if (orig.val) {
        if (typeof el.style.setProperty === 'function') {
          el.style.setProperty(prop, orig.val, orig.prio);
        } else {
          var camel = prop === 'min-width' ? 'minWidth' : (prop === 'max-width' ? 'maxWidth' : prop);
          el.style[camel] = orig.val;
        }
      } else {
        if (typeof el.style.removeProperty === 'function') {
          el.style.removeProperty(prop);
        } else {
          var cName = prop === 'min-width' ? 'minWidth' : (prop === 'max-width' ? 'maxWidth' : prop);
          delete el.style[cName];
        }
      }
      delete el._dbsextOrigStyles[prop];
    }
  }

  function restoreWidthStyles(el) {
    if (!el) return;
    restoreOriginalStyle(el, 'width');
    restoreOriginalStyle(el, 'min-width');
    restoreOriginalStyle(el, 'max-width');
  }

  /**
   * 推奨幅を、対象要素自身の明示元幅が推奨値より大きい場合だけ適用する。
   * 要素自身の元幅が不明、同値、または小さい場合は元スタイルへ戻すため、
   * どの要素にも幅を広げる書き込みをしない。
   */
  function applyShrinkOnlyWidth(el, targetWidth, inheritedColumnWidth) {
    if (!el || !el.style || !(targetWidth > 0)) return;
    var explicitWidth = readExplicitWidth(el);
    // th/td に個別の幅指定が無い場合は、同じ列の col 幅を元幅として扱う。
    // 逆に col 幅も不明なら fail-closed とし、要素へ幅を書き込まない。
    if (explicitWidth === null && inheritedColumnWidth !== null && inheritedColumnWidth !== undefined) {
      explicitWidth = inheritedColumnWidth;
    }
    if (explicitWidth === null || explicitWidth <= targetWidth) {
      restoreWidthStyles(el);
      return;
    }

    var widthString = targetWidth + 'px';
    backupOriginalStyle(el, 'width');
    backupOriginalStyle(el, 'min-width');
    backupOriginalStyle(el, 'max-width');
    el.style.setProperty('width', widthString, 'important');
    el.style.setProperty('min-width', widthString, 'important');
    el.style.setProperty('max-width', widthString, 'important');
  }

  /**
   * 単一テーブルの列幅・操作列表示の適用（静的CSS方式・表全体幅設定なし・真のno-op・縮小専用）
   */
  function applyTableWidths(table, actionIndices, showActionCols, autoFitEnabled) {
    if (!table) return;

    var headerTable = table.querySelector('table.el-table__header');
    var bodyTable = table.querySelector('table.el-table__body');
    if (!headerTable || !bodyTable) return;

    var screen = getScreen();
    var isMultiHeader = isMultiRowOrSpanHeader(headerTable);
    if (isMultiHeader) return;

    var isValidTarget = validateTargetTable(table, screen, headerTable, bodyTable);
    var hasExistingStaticWidths = !!table._dbsextStaticWidthsApplied;
    var allBodyRows = bodyTable.querySelectorAll('tbody tr');
    var isRowCountValid = allBodyRows.length > 0;

    // 未知表・不正形状・0行・未適用表には一切触らない（真の no-op: REMARK-TABLE-01）
    if (!isValidTarget) {
      return;
    }

    var headerCols = headerTable.querySelectorAll('colgroup col');
    var bodyCols = bodyTable.querySelectorAll('colgroup col');
    var headerRows = headerTable.querySelectorAll('thead tr, tr');
    var headerThs = headerRows.length > 0 ? headerRows[0].children : [];
    var colCount = headerCols.length;
    if (colCount === 0) return;

    var canApplyStaticWidths = autoFitEnabled && isValidTarget && isRowCountValid;

    // 1. 操作列の表示/非表示 (display: none) および旧オートフィット幅の安全な解除 (REMARK-M2-MIGRATION)
    if (isValidTarget) {
      var isActionHidden = function (idx) {
        if (showActionCols) return false;
        for (var k = 0; k < actionIndices.length; k++) {
          if (actionIndices[k] === idx) return true;
        }
        return false;
      };

      for (var i = 0; i < colCount; i++) {
        var isActionCol = false;
        for (var a = 0; a < actionIndices.length; a++) {
          if (actionIndices[a] === i) {
            isActionCol = true;
            break;
          }
        }

        var hidden = isActionHidden(i);

        if (headerCols[i]) {
          if (hidden) {
            headerCols[i].style.setProperty('display', 'none', 'important');
          } else if (headerCols[i].style && headerCols[i].style.display === 'none') {
            headerCols[i].style.removeProperty('display');
          }
          // REMARK-M2-MIGRATION: 由来が判定できる旧オートフィットの幅のみを復元・解除
          if (isActionCol && !hidden) {
            if (headerCols[i].hasAttribute && headerCols[i].hasAttribute('data-dbsext-orig-width')) {
              var origW = headerCols[i].getAttribute('data-dbsext-orig-width');
              if (origW) {
                headerCols[i].setAttribute('width', origW);
                if (headerCols[i].style) headerCols[i].style.width = origW;
              } else {
                headerCols[i].removeAttribute('width');
                if (headerCols[i].style) headerCols[i].style.removeProperty('width');
              }
              headerCols[i].removeAttribute('data-dbsext-orig-width');
            } else if (headerCols[i].hasAttribute && headerCols[i].hasAttribute('data-dbsext-autofit-orig-style')) {
              headerCols[i].removeAttribute('width');
              if (headerCols[i].style) headerCols[i].style.removeProperty('width');
              headerCols[i].removeAttribute('data-dbsext-autofit-orig-style');
            }
          }
        }

        if (bodyCols[i]) {
          if (hidden) {
            bodyCols[i].style.setProperty('display', 'none', 'important');
          } else if (bodyCols[i].style && bodyCols[i].style.display === 'none') {
            bodyCols[i].style.removeProperty('display');
          }
          if (isActionCol && !hidden) {
            if (bodyCols[i].hasAttribute && bodyCols[i].hasAttribute('data-dbsext-orig-width')) {
              var origBw = bodyCols[i].getAttribute('data-dbsext-orig-width');
              if (origBw) {
                bodyCols[i].setAttribute('width', origBw);
                if (bodyCols[i].style) bodyCols[i].style.width = origBw;
              } else {
                bodyCols[i].removeAttribute('width');
                if (bodyCols[i].style) bodyCols[i].style.removeProperty('width');
              }
              bodyCols[i].removeAttribute('data-dbsext-orig-width');
            } else if (bodyCols[i].hasAttribute && bodyCols[i].hasAttribute('data-dbsext-autofit-orig-style')) {
              bodyCols[i].removeAttribute('width');
              if (bodyCols[i].style) bodyCols[i].style.removeProperty('width');
              bodyCols[i].removeAttribute('data-dbsext-autofit-orig-style');
            }
          }
        }

        if (headerThs[i]) {
          if (hidden) {
            headerThs[i].style.setProperty('display', 'none', 'important');
          } else if (headerThs[i].style && headerThs[i].style.display === 'none') {
            headerThs[i].style.removeProperty('display');
          }
        }

        for (var vr = 0; vr < allBodyRows.length; vr++) {
          var td = allBodyRows[vr].children[i];
          if (td) {
            if (hidden) {
              td.style.setProperty('display', 'none', 'important');
            } else if (td.style && td.style.display === 'none') {
              td.style.removeProperty('display');
            }
          }
        }
      }
    }

    // 2. 静的推奨幅の適用（明示された元幅より狭める場合のみ縮小）または元値復元
    if (canApplyStaticWidths) {
      table._dbsextStaticWidthsApplied = true;

      for (var c = 0; c < colCount; c++) {
        if (actionIndices.indexOf(c) !== -1 && !showActionCols) {
          continue;
        }

        var th = headerThs[c];
        var thTitle = headerName(th);
        var targetWidth = getRecommendedColWidth(screen, c, thTitle);
        // 推奨値は各要素自身の明示元幅と比較する。col だけでなく body col / th / td
        // も個別に判定し、元幅が推奨値以下の要素を targetWidth へ広げない。
        if (targetWidth !== null && targetWidth > 0) {
          var headerColumnWidth = getExplicitColWidth(headerCols[c], th);
          var bodyColumnWidth = readExplicitWidth(bodyCols[c]);
          applyShrinkOnlyWidth(headerCols[c], targetWidth);
          applyShrinkOnlyWidth(bodyCols[c], targetWidth);
          applyShrinkOnlyWidth(th, targetWidth, headerColumnWidth);
          for (var cellIdx = 0; cellIdx < allBodyRows.length; cellIdx++) {
            applyShrinkOnlyWidth(allBodyRows[cellIdx].children[c], targetWidth, bodyColumnWidth);
          }
        }
      }
    } else if (hasExistingStaticWidths && !autoFitEnabled) {
      // 過去に本モジュールが適用した表で、推奨幅がOFFにされた場合のみ元値へ復元 (REMARK-TABLE-01)
      table._dbsextStaticWidthsApplied = false;

      for (var rIdx = 0; rIdx < colCount; rIdx++) {
        if (headerCols[rIdx]) {
          restoreOriginalStyle(headerCols[rIdx], 'width');
          restoreOriginalStyle(headerCols[rIdx], 'min-width');
          restoreOriginalStyle(headerCols[rIdx], 'max-width');
        }
        if (bodyCols[rIdx]) {
          restoreOriginalStyle(bodyCols[rIdx], 'width');
          restoreOriginalStyle(bodyCols[rIdx], 'min-width');
          restoreOriginalStyle(bodyCols[rIdx], 'max-width');
        }
        if (headerThs[rIdx]) {
          restoreOriginalStyle(headerThs[rIdx], 'width');
          restoreOriginalStyle(headerThs[rIdx], 'min-width');
          restoreOriginalStyle(headerThs[rIdx], 'max-width');
        }
        for (var clrIdxAll = 0; clrIdxAll < allBodyRows.length; clrIdxAll++) {
          var clrTdAll = allBodyRows[clrIdxAll].children[rIdx];
          if (clrTdAll) {
            restoreOriginalStyle(clrTdAll, 'width');
            restoreOriginalStyle(clrTdAll, 'min-width');
            restoreOriginalStyle(clrTdAll, 'max-width');
          }
        }
      }
    }
  }

  function findExistingToggleUI(table) {
    if (!table) return null;
    if (table._dbsextToggleUI && table._dbsextToggleUI.parentNode) {
      return table._dbsextToggleUI;
    }
    if (table.previousElementSibling && table.previousElementSibling.hasAttribute && table.previousElementSibling.hasAttribute(UI_CONTAINER_ATTR)) {
      return table.previousElementSibling;
    }
    if (table.parentNode && table.parentNode.children) {
      var children = table.parentNode.children;
      var idx = children.indexOf ? children.indexOf(table) : -1;
      if (idx === -1) {
        for (var c = 0; c < children.length; c++) {
          if (children[c] === table) { idx = c; break; }
        }
      }
      if (idx > 0 && children[idx - 1].hasAttribute && children[idx - 1].hasAttribute(UI_CONTAINER_ATTR)) {
        return children[idx - 1];
      }
    }
    return null;
  }

  /**
   * 表上部にトグルバー（操作列たたむ / 推奨列幅）を設置
   */
  function ensureToggleUI(table, showActionCols, autoFitEnabled, hasActionCols, isTargetScreen) {
    if (!table || !table.parentNode) return;

    var existing = findExistingToggleUI(table);
    if (existing) {
      var actionInput = existing.querySelector('[' + TOGGLE_INPUT_ATTR + ']');
      if (actionInput) {
        actionInput.checked = !showActionCols; // チェック = たたむ
      }
      var autoFitInput = existing.querySelector('[' + AUTOFIT_TOGGLE_ATTR + ']');
      if (autoFitInput) {
        autoFitInput.checked = !!autoFitEnabled;
      }
      return;
    }

    // 対象画面でない、かつ操作列もない場合はトグルバー自体を不要とする
    if (!isTargetScreen && !hasActionCols) return;

    var bar = document.createElement('div');
    bar.setAttribute(UI_CONTAINER_ATTR, '1');
    bar.style.cssText =
      'display:flex; align-items:center; justify-content:flex-end; gap:16px; padding:4px 8px; margin-bottom:4px; font-size:13px;';

    // 1. 推奨列幅トグル（対象画面のみ表示）
    if (isTargetScreen) {
      var autoFitLabel = document.createElement('label');
      autoFitLabel.style.cssText =
        'display:inline-flex; align-items:center; cursor:pointer; color:#303133; font-weight:500; user-select:none;';

      var autoFitCheckbox = document.createElement('input');
      autoFitCheckbox.type = 'checkbox';
      autoFitCheckbox.setAttribute(AUTOFIT_TOGGLE_ATTR, '1');
      autoFitCheckbox.checked = !!autoFitEnabled;
      autoFitCheckbox.style.cssText =
        'margin-right:6px; cursor:pointer; accent-color:#0b5cab; width:15px; height:15px;';

      autoFitCheckbox.addEventListener('change', function () {
        var currentScreen = getScreen();
        var newAutoFit = autoFitCheckbox.checked;
        saveAutoFitState(currentScreen, newAutoFit);
        var currentShow = loadToggleState(currentScreen);
        reapplyCurrentScreen(currentShow, newAutoFit);
      });

      var autoFitSpan = document.createElement('span');
      autoFitSpan.textContent = '推奨列幅';

      autoFitLabel.appendChild(autoFitCheckbox);
      autoFitLabel.appendChild(autoFitSpan);
      bar.appendChild(autoFitLabel);
    }

    // 2. 操作列トグル（操作列がある場合のみ表示）
    if (hasActionCols) {
      var actionLabel = document.createElement('label');
      actionLabel.style.cssText =
        'display:inline-flex; align-items:center; cursor:pointer; color:#303133; font-weight:500; user-select:none;';

      var actionCheckbox = document.createElement('input');
      actionCheckbox.type = 'checkbox';
      actionCheckbox.setAttribute(TOGGLE_INPUT_ATTR, '1');
      actionCheckbox.checked = !showActionCols; // チェック = たたむ
      actionCheckbox.style.cssText =
        'margin-right:6px; cursor:pointer; accent-color:#0b5cab; width:15px; height:15px;';

      actionCheckbox.addEventListener('change', function () {
        var currentScreen = getScreen();
        var newShow = !actionCheckbox.checked;
        saveToggleState(currentScreen, newShow);
        var currentAutoFit = loadAutoFitState(currentScreen);
        reapplyCurrentScreen(newShow, currentAutoFit);
      });

      var actionSpan = document.createElement('span');
      actionSpan.textContent = '操作列をたたむ';

      actionLabel.appendChild(actionCheckbox);
      actionLabel.appendChild(actionSpan);
      bar.appendChild(actionLabel);
    }

    table._dbsextToggleUI = bar;
    table.parentNode.insertBefore(bar, table);
  }

  /**
   * 拡張が付与した dbsext-sticky-right クラスを安全に除去する。
   * ポータル自身が最初から持っていたクラスは触らず、拡張自身が付与した要素（所有権記録）のみ除去する。
   * 未知の表（一度も sticky を付与していない表）に対しては DOM を一切触らない（真の no-op: REMARK-W2R2-02）。
   */
  function cleanupStickyRight(table) {
    if (!table) return;
    if (table._dbsextStickyOwnedElements) {
      var owned = table._dbsextStickyOwnedElements;
      for (var i = 0; i < owned.length; i++) {
        var el = owned[i];
        if (el && el.classList && typeof el.classList.remove === 'function') {
          el.classList.remove('dbsext-sticky-right');
        }
      }
    }
    delete table._dbsextStickyOwnedElements;
    delete table._dbsextStickyElements;
    delete table._dbsextStickyApplied;
  }

  function clearSelectionMarker(table) {
    if (!table) return;
    if (table.classList && typeof table.classList.remove === 'function') {
      table.classList.remove('dbsext-has-selection');
    }
    if (typeof table.removeAttribute === 'function') {
      table.removeAttribute('data-dbsext-has-selection');
    }
  }

  function setSelectionMarker(table, hasSelectionCol) {
    if (!table) return;
    if (hasSelectionCol) {
      if (table.classList && typeof table.classList.add === 'function') {
        table.classList.add('dbsext-has-selection');
      }
      if (typeof table.setAttribute === 'function') {
        table.setAttribute('data-dbsext-has-selection', '1');
      }
    } else {
      clearSelectionMarker(table);
    }
  }

  function processSingleTable(table, show, fit) {
    if (!table) return;
    if (table.getAttribute('data-dbsext-table') === 'custom' ||
        table.getAttribute('data-dbsext-vp-table') ||
        table.getAttribute('data-dbsext-beacons-table')) {
      clearSelectionMarker(table);
      return;
    }

    var headerTable = table.querySelector('table.el-table__header');
    var bodyTable = table.querySelector('table.el-table__body');
    if (!headerTable || !bodyTable) {
      clearSelectionMarker(table);
      cleanupStickyRight(table);
      return;
    }

    var screen = getScreen();
    var isMultiHeader = isMultiRowOrSpanHeader(headerTable);
    if (isMultiHeader) {
      clearSelectionMarker(table);
      cleanupStickyRight(table);
      return;
    }

    var isValidTarget = validateTargetTable(table, screen, headerTable, bodyTable);
    // 未知表・不正形状・0行・多段ヘッダのテーブルに対しては DOM / UI / refresh を一切触らない（真の no-op: REMARK-TABLE-01）
    // ただし過去に拡張が class を付与していた場合は、自前 sticky class のみ安全にクリーンアップする (REMARK-W2R2-02)
    if (!isValidTarget) {
      clearSelectionMarker(table);
      cleanupStickyRight(table);
      return;
    }

    var actionIndices = findActionColumnIndices(headerTable);
    var hasActionCols = actionIndices.length > 0;

    ensureToggleUI(
      table,
      show,
      fit,
      hasActionCols,
      true
    );

    var existingUI = findExistingToggleUI(table);
    if (existingUI) {
      var aIn = existingUI.querySelector('[' + TOGGLE_INPUT_ATTR + ']');
      if (aIn) aIn.checked = !show;
      var afIn = existingUI.querySelector('[' + AUTOFIT_TOGGLE_ATTR + ']');
      if (afIn) afIn.checked = !!fit;
    }

    var headerRows = headerTable.querySelectorAll('thead tr, tr');
    var firstTh = (headerRows.length > 0 && headerRows[0].children.length > 0) ? headerRows[0].children[0] : null;
    var hasSelectionCol = hasCheckboxLike(firstTh);
    setSelectionMarker(table, hasSelectionCol);

    applyTableWidths(table, actionIndices, show, fit);
    applyStickyRight(table, screen, headerTable, bodyTable);

    // 実際に幅や操作列の変更・復元を行ったテーブルに対してのみ refresh を呼ぶ (REMARK-TABLE-01)
    if (D.tableWrap && typeof D.tableWrap.refresh === 'function') {
      D.tableWrap.refresh(table);
    }
  }

  /**
   * /users 画面で「利用明細」列を右端 sticky に設定する自前クラスを付与 (W2)
   */
  function applyStickyRight(table, screen, headerTable, bodyTable) {
    if (!table) return;
    if (!headerTable || !bodyTable) {
      cleanupStickyRight(table);
      return;
    }
    var normScreen = normalizePath(screen).toLowerCase();
    if (normScreen !== '/users') {
      cleanupStickyRight(table);
      return;
    }

    var headerRows = headerTable.querySelectorAll('thead tr, tr');
    if (headerRows.length !== 1) {
      cleanupStickyRight(table);
      return;
    }
    var headerThs = headerRows[0].children;
    var colCount = headerThs.length;
    if (colCount === 0) {
      cleanupStickyRight(table);
      return;
    }

    var matchIndices = [];
    for (var i = 0; i < colCount; i++) {
      if (headerName(headerThs[i]) === '利用明細') {
        matchIndices.push(i);
      }
    }

    // 見出し「利用明細」が一意でない場合は cleanup して no-op (fail-closed)
    if (matchIndices.length !== 1) {
      cleanupStickyRight(table);
      return;
    }
    var stickyIdx = matchIndices[0];

    var allBodyRows = bodyTable.querySelectorAll('tbody tr');
    if (allBodyRows.length === 0) {
      cleanupStickyRight(table);
      return;
    }

    // headerTh および全 body 行の同 index cell が存在することを検証
    if (!headerThs[stickyIdx]) {
      cleanupStickyRight(table);
      return;
    }
    for (var r = 0; r < allBodyRows.length; r++) {
      if (!allBodyRows[r].children || !allBodyRows[r].children[stickyIdx]) {
        cleanupStickyRight(table);
        return;
      }
    }

    var targetElements = [];
    targetElements.push(headerThs[stickyIdx]);
    for (var br = 0; br < allBodyRows.length; br++) {
      targetElements.push(allBodyRows[br].children[stickyIdx]);
    }

    // 以前拡張が付与した要素 (owned) のうち、今回対象外となった要素があれば class 除去
    var previousOwned = table._dbsextStickyOwnedElements || [];
    var nextOwned = [];
    for (var o = 0; o < previousOwned.length; o++) {
      var oldEl = previousOwned[o];
      if (targetElements.indexOf(oldEl) === -1) {
        if (oldEl && oldEl.classList && typeof oldEl.classList.remove === 'function') {
          oldEl.classList.remove('dbsext-sticky-right');
        }
      } else {
        nextOwned.push(oldEl);
      }
    }

    // 今回の対象要素に class 付与（元から class を持っていた要素は owned に含めず、持っていなかった要素のみ add して owned に記録）
    for (var t = 0; t < targetElements.length; t++) {
      var targetEl = targetElements[t];
      if (targetEl && targetEl.classList) {
        if (!targetEl.classList.contains('dbsext-sticky-right')) {
          if (typeof targetEl.classList.add === 'function') {
            targetEl.classList.add('dbsext-sticky-right');
          }
          nextOwned.push(targetEl);
        }
      }
    }

    table._dbsextStickyOwnedElements = nextOwned;
    table._dbsextStickyElements = targetElements;
    table._dbsextStickyApplied = true;
  }

  function reapplyCurrentScreen(overrideShow, overrideAutoFit) {
    if (typeof document === 'undefined') return;
    var currentScreen = getScreen();
    var show = (typeof overrideShow === 'boolean') ? overrideShow : loadToggleState(currentScreen);
    var fit = (typeof overrideAutoFit === 'boolean') ? overrideAutoFit : loadAutoFitState(currentScreen);

    var tables = document.querySelectorAll('.el-table');
    if (!tables || tables.length === 0) return;

    for (var t = 0; t < tables.length; t++) {
      processSingleTable(tables[t], show, fit);
    }
  }

  var isApplying = false;

  D.tableColumns = {
    ACTION_COLUMNS: ACTION_COLUMNS,
    STATIC_COLUMN_RECOMMENDATIONS: STATIC_COLUMN_RECOMMENDATIONS,
    STORAGE_FEATURE: STORAGE_FEATURE,
    STORAGE_FEATURE_AUTOFIT: STORAGE_FEATURE_AUTOFIT,

    apply: function () {
      if (typeof document === 'undefined') return;
      if (isApplying) return;
      isApplying = true;

      try {
        var screen = getScreen();
        var tables = document.querySelectorAll('.el-table');
        if (!tables || tables.length === 0) return;

        var showActionCols = loadToggleState(screen);
        var autoFitEnabled = loadAutoFitState(screen);

        for (var t = 0; t < tables.length; t++) {
          processSingleTable(tables[t], showActionCols, autoFitEnabled);
        }
      } finally {
        isApplying = false;
      }
    },

    /**
     * 「オリジナルに戻す」表示専用。保存済みの表示設定は変えず、
     * 一時的に全列表示・静的列幅OFFの純正状態へ戻す。
     */
    peekShowAll: function () {
      if (typeof document === 'undefined') return;
      var tables = document.querySelectorAll ? document.querySelectorAll('.el-table') : [];
      for (var i = 0; i < tables.length; i++) {
        var table = tables[i];
        if (table.getAttribute('data-dbsext-table') === 'custom' ||
            table.getAttribute('data-dbsext-vp-table') ||
            table.getAttribute('data-dbsext-beacons-table')) {
          continue;
        }
        var headerTable = table.querySelector('table.el-table__header');
        var actionIndices = findActionColumnIndices(headerTable);
        applyTableWidths(table, actionIndices, true, false);
      }
    },

    /** 「オリジナルに戻す」を解除し、保存済みの最新表示設定へ戻す */
    peekRestore: function () {
      reapplyCurrentScreen();
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
