/**
 * DBSEXT UI微調整モジュール
 *
 * - 戻るボタン: 隠さず、「1個前の画面へ戻る」挙動に差し替える
 * - 折りたたみセクション: 操作系は既定で閉じる（表示条件・検索条件等は開いたまま）
 * - ページサイズ: 車両情報 `/vehicles` で最大（1000）を自動選択する
 *
 * 契約（docs/06-module-contract.md §6）の遵守:
 *   setInterval を使わない / ポータルの既存DOMを削除・移動しない /
 *   更新系リクエストを発行しない
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  // ---------------------------------------------------------------------------
  // 画面の判定
  // ---------------------------------------------------------------------------

  /** 車両情報か */
  function isVehiclesPage() {
    return /^\/vehicles(\/|$)/.test(location.pathname);
  }

  /** ユーザ情報か（ここだけは検索前に表示条件を使うため開いておく） */
  function isUsersPage() {
    return /^\/users(\/|$)/.test(location.pathname);
  }

  function log(message, isError) {
    if (D.core && typeof D.core.log === 'function') D.core.log(message, isError);
  }

  // ---------------------------------------------------------------------------
  // 1. 戻るボタン — 非表示にする（W1-3）
  //
  // 決裁: 「1つ前の画面へ戻る」差し替えは、別タブで開く機能で間接的に
  // 対応済みのため削除でよい。戻るボタンは全画面から消す。
  //
  // テキストが「戻る」のボタンに属性を付け、CSSで非表示にする
  // ---------------------------------------------------------------------------

  /** テキストが「戻る」のボタンに印を付ける */
  function markBackButtons() {
    if (typeof document === 'undefined') return;
    var buttons = document.querySelectorAll('button, a, [role="button"]');
    for (var i = 0; i < buttons.length; i++) {
      var btn = buttons[i];
      if (btn.textContent && btn.textContent.trim() === '戻る') {
        btn.setAttribute('data-dbsext-hidden-back', '1');
      }
    }
  }

  // ---------------------------------------------------------------------------
  // 1b. 一覧のリンクを別タブで開く
  //
  // 現場の要望:
  //   絞り込んだ表から個別の画面へ飛ぶと、戻ったときに絞り込みが消えている。
  //   一覧はそのまま残し、個別画面は別タブで開きたい。
  //
  // **対象は `<a href>` だけに限る。** 表の中には「メンテナンス」「AT管理」「解錠」
  // 「再配置」といった**操作ボタン**が並んでおり、これらを別タブ化するのは危険であるうえ
  // 意味がない。リンク（画面遷移）とボタン（操作）を混同しない。
  //
  // Vue Router の RouterLink は、要素に `target="_blank"` が付いていると
  // 自前のルーティングを行わずブラウザに任せる。したがって属性を足すだけで、
  // クリックを横取りする必要がない（二重に開く事故も起きない）。
  // ---------------------------------------------------------------------------

  function openRowLinksInNewTab() {
    if (typeof document === 'undefined') return;
    var links = document.querySelectorAll('table.el-table__body tbody td a[href]');
    for (var i = 0; i < links.length; i++) {
      var link = links[i];
      if (link.hasAttribute('data-dbsext-newtab') || isUserLinkAnchor(link)) continue;
      var href = link.getAttribute('href');
      // 同一オリジンの通常リンクだけ。javascript: や外部リンクは触らない
      if (!href || href.charAt(0) !== '/') continue;
      link.setAttribute('data-dbsext-newtab', '1');
      link.setAttribute('target', '_blank');
      link.setAttribute('rel', 'noopener');
      link.title = (link.title ? link.title + ' / ' : '') + '別タブで開きます（一覧は残ります）';
    }
  }

  // ---------------------------------------------------------------------------
  // 1c. ユーザ識別番号のリンク化
  //
  // 車両情報 `/vehicles` の一覧で、「ユーザ識別番号」セルの値をクリックすると
  // 対応するユーザ詳細画面を別タブで開く。
  // ---------------------------------------------------------------------------

  function isValidUserId(id) {
    if (!id || typeof id !== 'string') return false;
    return /^USER:[A-Za-z0-9:_-]{1,256}$/.test(id);
  }

  function extractUserId(text) {
    if (!text || typeof text !== 'string') return null;
    var trimmed = text.trim();
    return isValidUserId(trimmed) ? trimmed : null;
  }

  function isValidAreaId(id) {
    if (!id || typeof id !== 'string') return false;
    return /^AREA:[A-Za-z0-9:_-]{1,256}$/.test(id);
  }

  function getSelectedAreaId() {
    if (typeof location === 'undefined') return null;
    var search = location.search;
    if (!search && location.href) {
      var qIdx = location.href.indexOf('?');
      if (qIdx !== -1) {
        search = location.href.substring(qIdx);
        var hIdx = search.indexOf('#');
        if (hIdx !== -1) search = search.substring(0, hIdx);
      }
    }
    if (!search) return null;
    var match = /[?&]selected-area-id=([^&#]*)/.exec(search);
    if (!match) return null;
    var decoded = '';
    try {
      decoded = decodeURIComponent(match[1]);
    } catch (e) {
      return null;
    }
    return isValidAreaId(decoded) ? decoded : null;
  }

  function getHeaderTitle(th) {
    if (!th) return '';
    if (th.hasAttribute && th.hasAttribute('data-dbsext-orig-title')) {
      return th.getAttribute('data-dbsext-orig-title');
    }
    var fullText = (th.textContent || '').trim();
    if (th.querySelectorAll) {
      var customEls = th.querySelectorAll('[data-dbsext-collapse-hint], [data-dbsext-sort], [data-dbsext-filter]');
      if (customEls.length > 0) {
        var customText = '';
        for (var i = 0; i < customEls.length; i++) {
          customText += customEls[i].textContent || '';
        }
        if (customText) {
          fullText = fullText.replace(customText.trim(), '').trim();
        }
      }
    }
    return fullText;
  }

  function openUserLink(href) {
    if (!href) return;
    var targetWindow = typeof window !== 'undefined' ? window : global;
    if (targetWindow && typeof targetWindow.open === 'function') {
      var win = targetWindow.open(href, '_blank', 'noopener,noreferrer');
      if (win) {
        try { win.opener = null; } catch (e) {}
      }
    }
  }

  function handleUserLinkClick(event) {
    var href = event.currentTarget ? event.currentTarget._dbsextHref : null;
    if (!href) return;
    if (typeof event.preventDefault === 'function') event.preventDefault();
    if (typeof event.stopPropagation === 'function') event.stopPropagation();
    openUserLink(href);
  }

  function handleUserLinkKeydown(event) {
    if (event.key === 'Enter' || event.keyCode === 13) {
      var href = event.currentTarget ? event.currentTarget._dbsextHref : null;
      if (!href) return;
      if (typeof event.preventDefault === 'function') event.preventDefault();
      if (typeof event.stopPropagation === 'function') event.stopPropagation();
      openUserLink(href);
    }
  }

  var trackedCells = [];
  var trackedAnchors = [];

  function isUserLinkCell(el) {
    return !!el && trackedCells.indexOf(el) !== -1;
  }

  function isUserLinkAnchor(el) {
    return !!el && trackedAnchors.indexOf(el) !== -1;
  }

  function cleanupCell(cell) {
    if (!cell || !isUserLinkCell(cell)) return;

    delete cell._dbsextHref;
    if (cell._dbsextUserLinkBound) {
      cell._dbsextUserLinkBound = false;
      if (typeof cell.removeEventListener === 'function') {
        cell.removeEventListener('click', handleUserLinkClick);
        cell.removeEventListener('keydown', handleUserLinkKeydown);
      }
    }

    if (cell._dbsextOrigRole) {
      if (cell._dbsextOrigRole.has) {
        cell.setAttribute('role', cell._dbsextOrigRole.val);
      } else {
        cell.removeAttribute('role');
      }
      delete cell._dbsextOrigRole;
    } else {
      cell.removeAttribute('role');
    }

    if (cell._dbsextOrigTabindex) {
      if (cell._dbsextOrigTabindex.has) {
        cell.setAttribute('tabindex', cell._dbsextOrigTabindex.val);
      } else {
        cell.removeAttribute('tabindex');
      }
      delete cell._dbsextOrigTabindex;
    } else {
      cell.removeAttribute('tabindex');
    }

    if (cell._dbsextOrigTitle) {
      if (cell._dbsextOrigTitle.has) {
        cell.setAttribute('title', cell._dbsextOrigTitle.val);
        cell.title = cell._dbsextOrigTitle.val;
      } else {
        cell.removeAttribute('title');
        cell.title = '';
      }
      delete cell._dbsextOrigTitle;
    } else {
      cell.removeAttribute('title');
      cell.title = '';
    }

    if (cell.style) {
      if (cell._dbsextOrigCursor) {
        if (cell._dbsextOrigCursor.set) {
          if (typeof cell.style.setProperty === 'function') {
            cell.style.setProperty('cursor', cell._dbsextOrigCursor.val, cell._dbsextOrigCursor.prio || '');
          } else {
            cell.style.cursor = cell._dbsextOrigCursor.val;
          }
        } else {
          if (typeof cell.style.removeProperty === 'function') {
            cell.style.removeProperty('cursor');
          }
          cell.style.cursor = '';
        }
        delete cell._dbsextOrigCursor;
      } else {
        if (typeof cell.style.removeProperty === 'function') {
          cell.style.removeProperty('cursor');
        }
        cell.style.cursor = '';
      }

      if (cell._dbsextOrigTextDec) {
        if (cell._dbsextOrigTextDec.set) {
          if (typeof cell.style.setProperty === 'function') {
            cell.style.setProperty('text-decoration', cell._dbsextOrigTextDec.val, cell._dbsextOrigTextDec.prio || '');
          } else {
            cell.style.textDecoration = cell._dbsextOrigTextDec.val;
          }
        } else {
          if (typeof cell.style.removeProperty === 'function') {
            cell.style.removeProperty('text-decoration');
          }
          cell.style.textDecoration = '';
        }
        delete cell._dbsextOrigTextDec;
      } else {
        if (typeof cell.style.removeProperty === 'function') {
          cell.style.removeProperty('text-decoration');
        }
        cell.style.textDecoration = '';
      }
    }

    var idx = trackedCells.indexOf(cell);
    if (idx !== -1) {
      trackedCells.splice(idx, 1);
    }
  }

  function cleanupAnchor(anchor) {
    if (!anchor || !isUserLinkAnchor(anchor)) return;

    if (anchor._dbsextOrigHref) {
      if (anchor._dbsextOrigHref.has) {
        anchor.setAttribute('href', anchor._dbsextOrigHref.val);
      } else {
        anchor.removeAttribute('href');
      }
      delete anchor._dbsextOrigHref;
    }

    if (anchor._dbsextOrigTarget) {
      if (anchor._dbsextOrigTarget.has) {
        anchor.setAttribute('target', anchor._dbsextOrigTarget.val);
      } else {
        anchor.removeAttribute('target');
      }
      delete anchor._dbsextOrigTarget;
    }

    if (anchor._dbsextOrigRel) {
      if (anchor._dbsextOrigRel.has) {
        anchor.setAttribute('rel', anchor._dbsextOrigRel.val);
      } else {
        anchor.removeAttribute('rel');
      }
      delete anchor._dbsextOrigRel;
    }

    if (anchor._dbsextOrigTitle) {
      if (anchor._dbsextOrigTitle.has) {
        anchor.setAttribute('title', anchor._dbsextOrigTitle.val);
        anchor.title = anchor._dbsextOrigTitle.val;
      } else {
        anchor.removeAttribute('title');
        anchor.title = '';
      }
      delete anchor._dbsextOrigTitle;
    }

    delete anchor._dbsextCleaned;

    var idx = trackedAnchors.indexOf(anchor);
    if (idx !== -1) {
      trackedAnchors.splice(idx, 1);
    }
  }

  function linkifyUserIds() {
    if (typeof document === 'undefined') return;

    var areaId = getSelectedAreaId();
    var isEligible = isVehiclesPage() && !!areaId;

    var activeCells = [];
    var activeAnchors = [];

    if (isEligible) {
      var tables = document.querySelectorAll('.el-table');
      for (var t = 0; t < tables.length; t++) {
        var container = tables[t];
        var headerTable = container.querySelector('table.el-table__header');
        var bodyTable = container.querySelector('table.el-table__body');

        if (!headerTable && container.classList && container.classList.contains('el-table__header')) {
          headerTable = container;
        }
        if (!bodyTable && container.classList && container.classList.contains('el-table__body')) {
          bodyTable = container;
        }

        if (!headerTable || !bodyTable) continue;

        var ths = headerTable.querySelectorAll('th');
        var targetColIndex = -1;
        for (var i = 0; i < ths.length; i++) {
          if (getHeaderTitle(ths[i]) === 'ユーザ識別番号') {
            targetColIndex = i;
            break;
          }
        }

        if (targetColIndex === -1) continue;

        var rows = bodyTable.querySelectorAll('tbody tr');
        if (!rows || rows.length === 0) {
          rows = bodyTable.querySelectorAll('tr');
        }
        for (var r = 0; r < rows.length; r++) {
          var row = rows[r];
          var tds = row.children;
          if (!tds || tds.length === 0) {
            tds = row.querySelectorAll('td');
          }
          if (targetColIndex >= tds.length) continue;
          var cell = tds[targetColIndex];

          var existingLink = cell.querySelector('a');
          if (existingLink) {
            var linkUserId = extractUserId(existingLink.textContent);
            if (linkUserId) {
              if (isUserLinkCell(cell)) {
                cleanupCell(cell);
              }
              delete existingLink._dbsextCleaned;
              if (!isUserLinkAnchor(existingLink)) {
                existingLink._dbsextOrigHref = { has: existingLink.hasAttribute('href'), val: existingLink.getAttribute('href') };
                existingLink._dbsextOrigTarget = { has: existingLink.hasAttribute('target'), val: existingLink.getAttribute('target') };
                existingLink._dbsextOrigRel = { has: existingLink.hasAttribute('rel'), val: existingLink.getAttribute('rel') };
                existingLink._dbsextOrigTitle = { has: existingLink.hasAttribute('title'), val: existingLink.title || existingLink.getAttribute('title') };
                if (trackedAnchors.indexOf(existingLink) === -1) {
                  trackedAnchors.push(existingLink);
                }
              }
              var expectedHref = '/users/general/' + encodeURIComponent(linkUserId) + '?selected-area-id=' + encodeURIComponent(areaId);
              existingLink.setAttribute('href', expectedHref);
              existingLink.setAttribute('target', '_blank');
              existingLink.setAttribute('rel', 'noopener noreferrer');
              existingLink.title = 'ユーザー詳細を別タブで開きます';
              if (activeAnchors.indexOf(existingLink) === -1) {
                activeAnchors.push(existingLink);
              }
            }
          } else {
            var cellUserId = extractUserId(cell.textContent);
            if (cellUserId) {
              if (!isUserLinkCell(cell)) {
                cell._dbsextOrigRole = { has: cell.hasAttribute('role'), val: cell.getAttribute('role') };
                cell._dbsextOrigTabindex = { has: cell.hasAttribute('tabindex'), val: cell.getAttribute('tabindex') };
                cell._dbsextOrigTitle = { has: cell.hasAttribute('title'), val: cell.title || cell.getAttribute('title') };
                var hasStyle = !!cell.style;
                var getPropVal = function (prop) {
                  if (!hasStyle) return '';
                  if (typeof cell.style.getPropertyValue === 'function') {
                    return cell.style.getPropertyValue(prop);
                  }
                  var camel = prop === 'text-decoration' ? 'textDecoration' : prop;
                  return cell.style[camel] || '';
                };
                var getPropPrio = function (prop) {
                  if (!hasStyle) return '';
                  if (typeof cell.style.getPropertyPriority === 'function') {
                    return cell.style.getPropertyPriority(prop) || '';
                  }
                  return '';
                };

                var curVal = getPropVal('cursor');
                var curPrio = getPropPrio('cursor');
                cell._dbsextOrigCursor = {
                  set: curVal !== '' || curPrio !== '',
                  val: curVal,
                  prio: curPrio
                };

                var decVal = getPropVal('text-decoration');
                var decPrio = getPropPrio('text-decoration');
                cell._dbsextOrigTextDec = {
                  set: decVal !== '' || decPrio !== '',
                  val: decVal,
                  prio: decPrio
                };
                if (trackedCells.indexOf(cell) === -1) {
                  trackedCells.push(cell);
                }
              }
              var href = '/users/general/' + encodeURIComponent(cellUserId) + '?selected-area-id=' + encodeURIComponent(areaId);
              cell._dbsextHref = href;
              cell.setAttribute('role', 'link');
              cell.setAttribute('tabindex', '0');
              cell.title = 'ユーザー詳細を別タブで開きます';
              cell.style.cursor = 'pointer';
              cell.style.textDecoration = 'underline';

              if (!cell._dbsextUserLinkBound) {
                cell._dbsextUserLinkBound = true;
                if (typeof cell.addEventListener === 'function') {
                  cell.addEventListener('click', handleUserLinkClick);
                  cell.addEventListener('keydown', handleUserLinkKeydown);
                }
              }
              if (activeCells.indexOf(cell) === -1) {
                activeCells.push(cell);
              }
            }
          }
        }
      }
    }

    for (var m = trackedCells.length - 1; m >= 0; m--) {
      var trackedCell = trackedCells[m];
      if (activeCells.indexOf(trackedCell) === -1) {
        cleanupCell(trackedCell);
      }
    }
    for (var n = trackedAnchors.length - 1; n >= 0; n--) {
      var trackedAnchor = trackedAnchors[n];
      if (activeAnchors.indexOf(trackedAnchor) === -1) {
        cleanupAnchor(trackedAnchor);
      }
    }
  }

  // ---------------------------------------------------------------------------
  // 2. 折りたたみセクション — ユーザ情報の表示条件だけ開いておく
  //
  // 現場確認により、ユーザ情報以外は「表示条件」も既定で閉じる。
  // ユーザ情報は検索しないと表が出ないため、入力に必要な表示条件だけ開いておく。
  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // W1-2: 表示条件パネルの1段組化と検索実行後の自動畳み
  // ---------------------------------------------------------------------------

  /** 対象パネルに属性を付ける（W1-2） */
  function markConditionPanels() {
    if (typeof document === 'undefined') return;
    var items = document.querySelectorAll('.el-collapse-item');
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      var header = item.querySelector('.el-collapse-item__header');
      if (!header) continue;
      var headerText = (header.textContent || '').trim();
      var isCondition = headerText.indexOf('表示条件') !== -1 ||
        headerText.indexOf('検索条件') !== -1 ||
        headerText.indexOf('絞り込み条件') !== -1;
      if (isCondition) {
        var content = item.querySelector('.el-collapse-item__content');
        if (content) {
          content.setAttribute('data-dbsext-cond-panel', '1');
        }
      }
    }
  }

  var searchButtonHooked = false;

  /** 検索ボタンをクリックして、自動畳み印を消す（W1-2） */
  function hookSearchButtons() {
    if (typeof document === 'undefined' || searchButtonHooked) return;
    searchButtonHooked = true;
    document.addEventListener('click', function (event) {
      var btn = event.target;
      if (!btn || (btn.tagName !== 'BUTTON' && btn.getAttribute('role') !== 'button')) return;
      // 検索ボタンか判定：テキストが「検索」で、クラスに el-button--primary を含む
      if ((btn.textContent || '').trim() !== '検索') return;
      if (!btn.classList || !btn.classList.contains('el-button--primary')) return;
      // 検索ボタンなので、次の行出現で1回だけ畳むよう印を消す
      var panels = document.querySelectorAll('[data-dbsext-cond-panel]');
      for (var i = 0; i < panels.length; i++) {
        panels[i].removeAttribute('data-dbsext-autocollapsed');
      }
    }, true);
  }

  /** 表示条件パネルの結果チェック：行が出たら1回だけ畳む（W1-2） */
  function shouldAutoCollapseCondition(condPanel) {
    if (!condPanel) return false;
    // 既に1回畳んでいる印があれば、これ以上畳まない
    if (condPanel.hasAttribute('data-dbsext-autocollapsed')) return false;
    // 結果表を探す：同じ親（内容エリア）の直後の表
    var parent = condPanel.parentElement;
    if (!parent) return false;
    // 「表示条件」の下には通常「結果表」が来る
    var bodyTable = parent.querySelector('table.el-table__body');
    if (!bodyTable) return false;
    var rows = bodyTable.querySelectorAll('tbody tr');
    if (!rows || rows.length === 0) return false;
    // 行が出た！1回だけ畳む
    condPanel.setAttribute('data-dbsext-autocollapsed', '1');
    return true;
  }

  function shouldKeepSectionOpen(headerText) {
    if (!headerText) return false;
    var isCondition = headerText.indexOf('表示条件') !== -1 ||
      headerText.indexOf('検索条件') !== -1 ||
      headerText.indexOf('絞り込み条件') !== -1;
    // 車種情報は初期状態でエリア選択→検索が必要。先に閉じると
    // vehicle-kinds.js のプルダウン操作と競合するため、結果が出るまで開いておく。
    if (typeof location !== 'undefined' && /^\/areas\/vehicle-kinds\/?$/.test(location.pathname || '') &&
        isCondition && !document.querySelector('table.el-table__body tbody tr')) {
      return true;
    }
    if (!isUsersPage()) return false;
    return isCondition;
  }

  function collapseSections() {
    if (typeof document === 'undefined') return;

    var items = document.querySelectorAll('.el-collapse-item');
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      var header = item.querySelector('.el-collapse-item__header');
      if (!header) continue;
      var initialized = header.hasAttribute('data-dbsext-collapsed');
      if (!initialized) header.setAttribute('data-dbsext-collapsed', '1');

      var headerText = (header.textContent || '').trim();
      var keepOpen = shouldKeepSectionOpen(headerText);

      // 開閉できることが見て分かるようにヒントを足す
      if (!initialized && !header.querySelector('[data-dbsext-collapse-hint]')) {
        var hint = document.createElement('span');
        hint.setAttribute('data-dbsext-collapse-hint', '1');
        hint.textContent = '▼';
        hint.style.cssText = 'font-size:11px;opacity:0.5;margin-left:2px';
        header.appendChild(hint);
      }

      // W1-2: 条件パネルで、行が出たら1回だけ畳む
      var content = item.querySelector('.el-collapse-item__content');
      if (content && content.hasAttribute('data-dbsext-cond-panel')) {
        if (shouldAutoCollapseCondition(content)) {
          // 行が出た！1回だけ畳む
          keepOpen = false;
        } else {
          // まだ行が出ていない。開いたままにする
          keepOpen = true;
        }
      }

      // 開いていればネイティブのクリックで閉じる。
      // クラスを直接操作すると Element Plus の内部状態とずれるため不可。
      if (!keepOpen && item.classList.contains('is-active')) {
        header.click();
      }
    }
  }

  // ---------------------------------------------------------------------------
  // 3. ページサイズ最大化（車両情報）
  //
  // Element Plus のサイズ選択は el-select で、ドロップダウンは teleport で
  // body 直下へ描画される。前回の実装が動かなかった原因として次を想定し、
  // すべて潰してある。
  //   - クリック対象が `.el-select` のルートだった（開くのは内側の wrapper/input）
  //   - 待ち時間が短く、teleport 描画前に諦めていた
  //   - document 全体から `.el-select-dropdown__item` を拾い、別のドロップダウンを
  //     掴む可能性があった → **クリック後に現れた・表示されているものだけ**を見る
  //   - 一度失敗すると印を付けて二度と再挑戦しなかった → 成功するまで印を付けない
  // ---------------------------------------------------------------------------

  var TARGET_PAGE_SIZE = 1000;
  var sizeDoneFor = {};   // pathname ごとに一度だけ実行する
  var sizeRunning = false;

  /**
   * ドロップダウンの中身が「表示件数」のものか。
   * **項目が全部ただの数字**であることを条件にする。
   */
  function isSizeDropdown(node) {
    if (!node) return false;
    var items = node.querySelectorAll('.el-select-dropdown__item');
    if (items.length < 2) return false;
    for (var i = 0; i < items.length; i++) {
      if (!/^\d+$/.test((items[i].textContent || '').trim())) return false;
    }
    return true;
  }

  function dropdownById(id) {
    if (!id) return null;
    var el = document.getElementById(id);
    if (!el) return null;
    // popper が dropdown を包んでいる場合と、dropdown 自身が返る場合の両方に対応
    return (typeof el.closest === 'function' && el.closest('.el-select-dropdown')) || el;
  }

  /**
   * 表示件数のドロップダウンを引き当てる。
   *
   * **ここが2回失敗した箇所。** 実測（2026-08-07 `investigation/out/diag-sizes.json`）で分かったこと:
   *
   *   `.el-pagination__sizes` の select は
   *     aria-controls    = el-id-1024-72 → 中身は「更新しない / 15分」← **無関係**
   *     aria-describedby = el-id-1024-76 → 中身は「50 / 100 / 200 / 500」← **正解**
   *
   * Element Plus のこの版では `aria-controls` が隣のセレクタの id を指しており、
   * これを信じると自動更新間隔のドロップダウンを掴んでしまう
   * （実機ログ: `[dbsext] 表示件数を 15分 に変更`）。
   *
   * そこで **id を信用せず、中身で確かめる**。候補を順に試し、
   * 「項目が全部数字」のものだけを採用する。
   */
  function findSizeDropdown(select) {
    var wrapper = select.querySelector('.el-select__wrapper');
    var combobox = select.querySelector('[aria-controls]');
    var candidates = [
      dropdownById(wrapper && wrapper.getAttribute('aria-describedby')),
      dropdownById(combobox && combobox.getAttribute('aria-controls'))
    ];
    for (var i = 0; i < candidates.length; i++) {
      if (isSizeDropdown(candidates[i])) return candidates[i];
    }
    // それでも決まらなければ、画面全体から「数字だけ」のものを探す
    return numericOnlyDropdown();
  }

  /** 開いているか。Element Plus は aria-expanded を更新する */
  function isExpanded(select) {
    var combobox = select.querySelector('[aria-expanded]');
    return !!combobox && combobox.getAttribute('aria-expanded') === 'true';
  }

  /**
   * `aria-controls` が取れない版への退避。
   * **選択肢が全部ただの数字**のドロップダウンだけを候補にする。
   * 実測では他のドロップダウンは「更新しない/15分」「全て表示/閾値以下」「昇順/降順」等で、
   * 数字だけのものはページサイズ（50/100/200/500）に限られていた。
   */
  function numericOnlyDropdown() {
    var list = document.querySelectorAll('.el-select-dropdown');
    for (var i = 0; i < list.length; i++) {
      if (isSizeDropdown(list[i])) return list[i];
    }
    return null;
  }

  /**
   * 1000 があればそれ、無ければ最大値を返す。
   *
   * **選択肢は「数字だけ」のものに限る。** 実機で `\d+` の部分一致にしていたため、
   * 自動更新間隔の「15分」から 15 を拾って選んでしまった
   * （2026-08-07 実測ログ: `[dbsext] 表示件数を 15分 に変更`）。
   */
  function pickLargestOption(dropdown) {
    var items = dropdown.querySelectorAll('.el-select-dropdown__item');
    var best = null;
    var bestValue = -1;
    var exact = null;
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      if (item.classList.contains('is-disabled')) continue;
      var text = (item.textContent || '').trim();
      if (!/^\d+$/.test(text)) continue;        // 「15分」「更新しない」は候補にしない
      var value = parseInt(text, 10);
      if (value === TARGET_PAGE_SIZE) exact = item;
      if (value > bestValue) { bestValue = value; best = item; }
    }
    return exact || best;
  }

  function currentPageSize(select) {
    // 実測の構造:
    //   .el-select__selected-item.el-select__input-wrapper.is-hidden > input(value="")
    //   .el-select__selected-item.el-select__placeholder > span "100"   ← 表示中の値はこちら
    // 先に placeholder を見ないと、隠しinputの空値を拾って NaN になる。
    var text = '';
    var display = select.querySelector('.el-select__placeholder');
    if (display) text = display.textContent || '';
    if (!text) {
      var input = select.querySelector('input');
      if (input) text = input.value || input.getAttribute('value') || '';
    }
    var matched = String(text).match(/\d+/);
    return matched ? parseInt(matched[0], 10) : NaN;
  }

  /** el-select を開くための実クリック対象。Element Plus の版差を吸収する */
  function selectTrigger(select) {
    return select.querySelector('.el-select__wrapper') ||
      select.querySelector('.el-input__inner') ||
      select.querySelector('.el-input__wrapper') ||
      select;
  }

  function maximizePageSize() {
    if (typeof document === 'undefined') return;
    if (!isVehiclesPage()) return;
    // 拡張版では vehicle-pagesize.js が「1000件表示（実ページ遷移方式）」を
    // 別途担う。ここでのドロップダウン操作（最大500）は**ブックマークレット版
    // 専用の代替手段**として残す。両方を同時に走らせると、ドロップダウンを
    // 500へ変えている最中に vehicle-pagesize.js が遷移を起こす、といった
    // 競合の余地が生まれるため、拡張版ではここを止める。
    if (D.platform && (D.platform.kind === 'extension' || D.platform.isUserScript)) return;
    if (sizeRunning || sizeDoneFor[location.pathname]) return;

    // **`.el-pagination__sizes` の中の select だけを対象にする。**
    // 以前は見つからないとき `pagination.querySelector('.el-select')` へ退避していたが、
    // ページャの中には自動更新間隔など別の select も居るため誤爆した。
    // 見つからないときは何もせず、次の再適用にゆだねる（印を付けないので再挑戦される）。
    var sizesHost = document.querySelector('.el-pagination__sizes');
    if (!sizesHost) return;
    var select = sizesHost.querySelector('.el-select');
    if (!select) return;

    var current = currentPageSize(select);
    if (current >= TARGET_PAGE_SIZE) {
      sizeDoneFor[location.pathname] = true;
      return;
    }

    sizeRunning = true;
    selectTrigger(select).click();

    // teleport + アニメーションを待つ。setInterval は契約で禁止のため再帰 setTimeout。
    var attempts = 0;
    (function waitForDropdown() {
      attempts++;

      // 開いたことを aria-expanded で確認してから中身を読む
      var opened = null;
      if (isExpanded(select)) {
        opened = findSizeDropdown(select);
      }

      if (opened) {
        var option = pickLargestOption(opened);
        if (option) {
          var label = (option.textContent || '').trim();
          option.click();
          sizeDoneFor[location.pathname] = true;
          // 本当に反映されたかを確かめる。掴む相手を間違えると
          // 「選んだのに変わらない」という静かな失敗になるため。
          setTimeout(function () {
            var now = currentPageSize(select);
            if (String(now) === label) {
              log('表示件数を ' + label + ' に変更');
            } else {
              log('表示件数を ' + label + ' に変えたが表示は ' + now + ' のまま', true);
              sizeDoneFor[location.pathname] = false;
            }
          }, 400);
        } else {
          log('表示件数の選択肢（数字のみ）が見つからない', true);
        }
        sizeRunning = false;
        return;
      }

      if (attempts >= 30) {   // 100ms × 30 = 約3秒
        log('表示件数のドロップダウンを特定できない（aria-controls も数字専用も不発）', true);
        sizeRunning = false;
        return;
      }
      setTimeout(waitForDropdown, 100);
    })();
  }

  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // ---------------------------------------------------------------------------
  // W1-4: ポート選択ドロップダウン並び替え
  // ---------------------------------------------------------------------------
  // W1-4: ポート選択ドロップダウン並び替え (REMARK-M1-TELEPORT)
  // ---------------------------------------------------------------------------

  function findSelectByLabel(labelText) {
    if (typeof document === 'undefined') return null;

    // 1. ラベル要素から探索（W0実測構造: label.contents と .el-form-item が兄弟関係）
    var labels = document.querySelectorAll('label, .el-form-item__label');
    for (var l = 0; l < labels.length; l++) {
      var lbl = labels[l];
      var text = (lbl.textContent || '').trim();
      if (text === labelText || (text.indexOf(labelText) !== -1 && text.indexOf('車両状態') === -1 && text.indexOf('ブロック') === -1)) {
        // 親枠（.flex / 行コンテナなど）から .el-select を探す
        var parent = lbl.parentElement;
        if (parent) {
          var sel = parent.querySelector('.el-select');
          if (sel) return sel;
          // 親の親（2段組枠など）からも探す
          var grand = parent.parentElement;
          if (grand) {
            var grandSel = grand.querySelector('.el-select');
            if (grandSel) return grandSel;
          }
        }
        // 次の兄弟要素から探す
        var sibling = lbl.nextElementSibling;
        while (sibling) {
          if (sibling.classList && sibling.classList.contains('el-select')) return sibling;
          var sibSel = sibling.querySelector ? sibling.querySelector('.el-select') : null;
          if (sibSel) return sibSel;
          sibling = sibling.nextElementSibling;
        }
      }
    }

    // 2. フォールバック: .el-select から探索（従来の .el-form-item 内に label がある場合）
    var selects = document.querySelectorAll('.el-select');
    for (var i = 0; i < selects.length; i++) {
      var select = selects[i];
      var formItem = (typeof select.closest === 'function') ? select.closest('.el-form-item') : null;
      if (!formItem && select.parentElement) {
        var p = select.parentElement;
        while (p) {
          if (p.classList && p.classList.contains('el-form-item')) {
            formItem = p;
            break;
          }
          p = p.parentElement;
        }
      }
      if (formItem) {
        var formLabel = formItem.querySelector('.el-form-item__label');
        if (formLabel && (formLabel.textContent || '').indexOf(labelText) !== -1) {
          return select;
        }
      }
    }
    return null;
  }

  function isDropdownVisible(el) {
    if (!el) return false;
    var curr = el;
    while (curr) {
      if (curr.nodeType && curr.nodeType !== 1) break;
      if (curr.getAttribute && curr.getAttribute('aria-hidden') === 'true') return false;
      if (curr.hasAttribute && curr.hasAttribute('hidden')) return false;
      if (curr.classList) {
        if (curr.classList.contains('is-hidden') ||
            curr.classList.contains('hidden') ||
            curr.classList.contains('el-zoom-in-top-leave-active') ||
            curr.classList.contains('el-zoom-in-top-leave-to') ||
            curr.classList.contains('v-leave-active') ||
            curr.classList.contains('v-leave-to')) {
          return false;
        }
      }
      if (curr.style) {
        if (curr.style.display === 'none') return false;
        if (curr.style.visibility === 'hidden' || curr.style.visibility === 'collapse') return false;
      }
      if (typeof window !== 'undefined' && typeof window.getComputedStyle === 'function') {
        try {
          var cs = window.getComputedStyle(curr);
          if (cs) {
            if (cs.display === 'none' || cs.visibility === 'hidden' || cs.visibility === 'collapse') {
              return false;
            }
          }
        } catch (e) {}
      }
      if (typeof curr.checkVisibility === 'function') {
        try {
          if (!curr.checkVisibility({ checkOpacity: false, checkVisibilityCSS: true })) {
            return false;
          }
        } catch (e) {}
      }
      if (curr.tagName === 'BODY' || curr.tagName === 'HTML') {
        break;
      }
      curr = curr.parentElement || curr.parentNode;
    }
    return true;
  }

  function isPortDropdown(node) {
    if (!node) return false;
    var dropdown = (node.classList && node.classList.contains('el-select-dropdown')) ? node : (node.querySelector ? node.querySelector('.el-select-dropdown') : null);
    if (!dropdown) return false;

    // 非表示・stale なドロップダウンを堅牢に除外 (REMARK-M1-TELEPORT: computed/visibility/class/ancestors)
    if (!isDropdownVisible(dropdown)) return false;

    if (isSizeDropdown(dropdown)) return false;

    var items = dropdown.querySelectorAll('.el-select-dropdown__item');
    if (items.length === 0) return false;

    // docs/17 実測値（ブロック・車両状態22件）に基づく既知の非ポート選択肢を除外 (REMARK-M1-TELEPORT: fail-closed)
    var forbiddenWords = [
      '金沢市', '野々市', 'ブロック',
      'AT未装着', '利用可能', '利用中', '一時駐輪', '予約中', '配置中', '回収中',
      '要回収', 'ポート外乗り捨て', 'メンテナンス', 'AT異常', '故障中', '充電中',
      '返却不可', '更新しない', '車両状態', '状態'
    ];
    for (var i = 0; i < items.length; i++) {
      var txt = (items[i].textContent || '').trim();
      for (var f = 0; f < forbiddenWords.length; f++) {
        if (txt === forbiddenWords[f] || txt.indexOf(forbiddenWords[f]) !== -1) {
          return false;
        }
      }
    }
    return true;
  }

  function findPortDropdown(select) {
    if (!select) return null;
    var wrapper = select.querySelector('.el-select__wrapper');
    var combobox = select.querySelector('[aria-controls]');
    var input = select.querySelector('input');
    var selectId = (select.getAttribute && select.getAttribute('id')) || select.id;
    var inputId = input && ((input.getAttribute && input.getAttribute('id')) || input.id);

    var candidates = [
      dropdownById(wrapper && wrapper.getAttribute('aria-describedby')),
      dropdownById(combobox && combobox.getAttribute('aria-controls')),
      dropdownById(select.getAttribute && select.getAttribute('aria-controls')),
      dropdownById(select.getAttribute && select.getAttribute('aria-owns')),
      dropdownById(input && input.getAttribute && input.getAttribute('aria-controls')),
      dropdownById(input && input.getAttribute && input.getAttribute('aria-describedby')),
      dropdownById(input && input.getAttribute && input.getAttribute('aria-owns'))
    ];
    for (var i = 0; i < candidates.length; i++) {
      var cand = candidates[i];
      if (cand && isPortDropdown(cand)) {
        return (cand.classList && cand.classList.contains('el-select-dropdown')) ? cand : (cand.querySelector ? cand.querySelector('.el-select-dropdown') : cand);
      }
    }

    // aria-labelledby による明示的な紐付けを探索
    if (selectId || inputId) {
      var dropdowns = document.querySelectorAll('.el-select-dropdown');
      for (var d = 0; d < dropdowns.length; d++) {
        var dd = dropdowns[d];
        var parent = dd.parentElement || dd;
        var labelledBy = (dd.getAttribute && dd.getAttribute('aria-labelledby')) || (parent.getAttribute && parent.getAttribute('aria-labelledby'));
        if (labelledBy && (labelledBy === selectId || labelledBy === inputId)) {
          if (isPortDropdown(dd)) {
            return dd;
          }
        }
      }
    }

    // 安定した紐付け（aria/id）が存在しない無関係なグローバルドロップダウンは決して拾わない (REMARK-M1-TELEPORT: fail-closed)
    return null;
  }

  function sortPortDropdownItems(select, optionalDropdown) {
    var portSortKey = (D.tableKit && D.tableKit.portSortKey) || (D.tableTools && D.tableTools.portSortKey);
    if (!portSortKey) return false;

    var dropdown = optionalDropdown || findPortDropdown(select);
    if (!dropdown) return false;

    var list = dropdown.querySelector('.el-select-dropdown__list');
    if (!list) return false;

    var items = list.querySelectorAll('.el-select-dropdown__item');
    if (items.length === 0) return false;

    // 各項目のテキストと sort key を集める
    var itemData = [];
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      var text = (item.textContent || '').trim();
      var key = portSortKey(text);
      itemData.push({ element: item, text: text, key: key });
    }

    // sort key で並べ替える（タプル比較）
    itemData.sort(function (a, b) {
      if (a.key[0] !== b.key[0]) return a.key[0] - b.key[0];
      if (a.key[1] !== b.key[1]) return a.key[1].localeCompare(b.key[1]);
      if (a.key[2] !== b.key[2]) return a.key[2] - b.key[2];
      return a.key[3].localeCompare(b.key[3], undefined, { numeric: true, sensitivity: 'base' });
    });

    // style.order で視覚順を変える（DOM 移動なし）
    for (var j = 0; j < itemData.length; j++) {
      itemData[j].element.style.order = j;
    }

    // リストコンテナに display:flex を設定（order を有効にするため）
    if (list.style) {
      list.style.display = 'flex';
      list.style.flexDirection = 'column';
    }

    list._dbsextPortSorted = true;
    return true;
  }

  function schedulePortSort(select) {
    var attempts = 0;
    var maxAttempts = 20; // 25ms × 20 = 500ms（有限・冪等な再試行）
    function retry() {
      attempts++;
      var done = sortPortDropdownItems(select);
      if (!done && attempts < maxAttempts) {
        setTimeout(retry, 25);
      }
    }
    retry();
  }

  function hookPortSelect() {
    if (typeof document === 'undefined') return;
    if (typeof location !== 'undefined' && !/^\/vehicle-states\/?$/.test(location.pathname || '')) return;

    var select = findSelectByLabel('ポート');
    if (!select) return; // DOM未生成時はフック済みにしない（次回再試行）

    var trigger = selectTrigger(select);
    if (!trigger) return;

    // 要素プロパティで冪等化（core ATTR_KIND を汚さない）
    if (trigger._dbsextPortHooked) return;
    trigger._dbsextPortHooked = true;

    trigger.addEventListener('click', function () {
      schedulePortSort(select);
    }, true);

    // 既に開いている場合はソート実行
    if (isExpanded(select)) {
      sortPortDropdownItems(select);
    }
  }

  D.uiTweaks = {
    apply: function () {
      if (typeof document === 'undefined' || !document.body) return;
      markBackButtons();
      linkifyUserIds();
      openRowLinksInNewTab();
      markConditionPanels();
      collapseSections();
      maximizePageSize();
      hookSearchButtons();
      hookPortSelect();  // W1-4
    },

    // 検証用（テストから状態を覗くため）
    _state: function () {
      return { sizeDoneFor: sizeDoneFor };
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
