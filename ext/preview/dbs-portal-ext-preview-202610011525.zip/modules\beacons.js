/**
 * DBSEXT ビーコン一覧モジュール
 * エリア内ポート割当済みビーコンの一覧取得、サイドバーの「ビーコン情報」リンク追加、
 * `/beacons` 画面での拡張所有パネル描画とデータ表示を担当する。
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var CACHE_TTL_MS = 5 * 60 * 1000; // 5分
  var cacheMap = Object.create(null); // areaId -> { rows, portCount, failedPortCount, timestamp }
  var latestGenerationByArea = Object.create(null);
  var isFetching = false;
  var currentGeneration = 0;
  var activeRequest = null;
  var pendingSidebarNavigation = false;
  var nativePopupState = null;
  var nativeSearchGeneration = 0;

  /**
   * ポータルID（areaId, portId等）の検証
   */
  function isValidPortalId(value) {
    return typeof value === 'string' && value.length >= 1 && value.length <= 256 && /^[A-Za-z0-9:_-]+$/.test(value);
  }

  /**
   * ビーコン種別の日本語変換
   */
  function formatBeaconType(type) {
    if (type === 'BLE_BEACON') return 'BLEビーコン';
    if (type === 'BLE_BEACON_VARIABLE_OUTPUT') return 'BLEビーコン出力可変版';
    if (type === 'WEAK_BEACON') return '微弱ビーコン';
    if (type === 'IOT_BEACON') return 'OMNIビーコン';
    return type || '';
  }

  /**
   * 重複除去: portBeaconId を優先キーとし、無ければ portId + portBeaconUniqueCode
   * Set や Object.create(null) を使用し、衝突を防ぐ長さprefix付きで管理
   */
  function dedupeBeacons(rows) {
    if (!Array.isArray(rows)) return [];
    var seen = Object.create(null);
    var result = [];
    for (var i = 0; i < rows.length; i++) {
      var item = rows[i];
      if (!item) continue;
      var key = null;
      if (item.portBeaconId) {
        var bId = String(item.portBeaconId);
        key = 'id:' + bId.length + ':' + bId;
      } else if (item.portId && item.portBeaconUniqueCode) {
        var pId = String(item.portId);
        var uCode = String(item.portBeaconUniqueCode);
        key = 'fb:' + pId.length + ':' + pId + ':' + uCode.length + ':' + uCode;
      }
      if (!key) {
        result.push(item);
        continue;
      }
      if (!seen[key]) {
        seen[key] = true;
        result.push(item);
      }
    }
    return result;
  }

  /**
   * 並べ替え: ポート識別番号を数値自然順、その後ビーコン識別番号順
   */
  function sortBeacons(rows) {
    return rows.slice().sort(function (a, b) {
      var portA = String(a.portUniqueCode || '');
      var portB = String(b.portUniqueCode || '');
      var cmpPort = portA.localeCompare(portB, undefined, { numeric: true, sensitivity: 'base' });
      if (cmpPort !== 0) return cmpPort;

      var beaconA = String(a.portBeaconUniqueCode || a.portBeaconId || '');
      var beaconB = String(b.portBeaconUniqueCode || b.portBeaconId || '');
      return beaconA.localeCompare(beaconB, undefined, { numeric: true, sensitivity: 'base' });
    });
  }

  /**
   * URLからselected-area-idを取得する（例外安全な検証済みIDのみを返却）
   */
  function getSelectedAreaId() {
    if (typeof location === 'undefined' || !location.search) return null;
    var match = location.search.match(/[?&]selected-area-id=([^&]+)/);
    if (!match) return null;
    try {
      var decoded = decodeURIComponent(match[1]);
      if (isValidPortalId(decoded)) {
        return decoded;
      }
    } catch (e) {
      // 不正な percent encoding など例外時は null
    }
    return null;
  }

  /**
   * パネルがDOMに接続されており、指定areaIdの画面と一致するか検証
   */
  function isPanelConnected(panel, areaId) {
    if (typeof document === 'undefined' || !panel) return false;
    if (typeof panel.isConnected === 'boolean' && !panel.isConnected) return false;
    var root = panel;
    while (root.parentNode) root = root.parentNode;
    if (root !== document) return false;
    return getSelectedAreaId() === areaId;
  }

  /** hrefを読み、ポータル標準のサイドバーリンクを探す。 */
  function findPortalAnchor(pathname) {
    var anchors = document.querySelectorAll('a');
    for (var i = 0; i < anchors.length; i++) {
      if (anchors[i].hasAttribute && anchors[i].hasAttribute('data-dbsext-beacons-link-a')) continue;
      var href = anchors[i].getAttribute('href') || '';
      if (href === pathname || href.indexOf(pathname + '?') === 0) return anchors[i];
    }
    return null;
  }

  /** ポータル標準リンクへ委譲し、Vue Router固有の履歴stateを維持する。 */
  function activateOriginalBeaconAnchor(anchor) {
    if (!anchor || typeof anchor.click !== 'function') return false;
    pendingSidebarNavigation = false;
    global.setTimeout(function () {
      anchor.click();
      global.setTimeout(function () {
        if (D.beacons && typeof D.beacons.apply === 'function') D.beacons.apply();
      }, 0);
    }, 0);
    return true;
  }

  /** ポート情報への標準遷移後、標準ビーコンリンクを1回だけ押す。 */
  function continuePendingSidebarNavigation() {
    if (!pendingSidebarNavigation) return;
    var originalAnchor = findPortalAnchor('/beacons');
    if (originalAnchor) activateOriginalBeaconAnchor(originalAnchor);
  }

  /**
   * 後付けリンクからもポータル標準ルーターだけを使い、ブックマークレットを維持する。
   * 修飾キー付きクリックはブラウザ標準（別タブ等）へ委ねる。
   */
  function bindSidebarNavigation(anchor) {
    if (!anchor || anchor.__dbsextBeaconSpaBound) return;
    anchor.__dbsextBeaconSpaBound = true;

    anchor.addEventListener('click', function (event) {
      if (event && (event.button > 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey)) {
        return;
      }
      if (event && typeof event.preventDefault === 'function') event.preventDefault();

      if (/^\/beacons(\/|$)/.test(location.pathname)) return;

      var originalAnchor = findPortalAnchor('/beacons');
      if (originalAnchor) {
        activateOriginalBeaconAnchor(originalAnchor);
        return;
      }

      var portAnchor = findPortalAnchor('/ports');
      if (!portAnchor || typeof portAnchor.click !== 'function') return;
      pendingSidebarNavigation = true;
      portAnchor.click();
    });
  }

  /**
   * サイドバーへ「ビーコン情報」リンクを追加・更新
   */
  function injectSidebarMenu() {
    if (typeof document === 'undefined') return;

    var selectedAreaId = getSelectedAreaId();
    var targetHref = '/beacons' + (selectedAreaId ? '?selected-area-id=' + encodeURIComponent(selectedAreaId) : '');
    var isBeaconsPage = /^\/beacons(\/|$)/.test(location.pathname);

    var existing = document.querySelector('[data-dbsext-beacons-link="1"]');

    if (existing) {
      var existingAnchor = existing.querySelector('a') || existing;
      existingAnchor.setAttribute('href', targetHref);
      bindSidebarNavigation(existingAnchor);

      if (isBeaconsPage) {
        existing.classList.add('bg-primary', 'text-white');
        existing.classList.remove('text-primary');
        existingAnchor.classList.add('router-link-active', 'router-link-exact-active');
      } else {
        existing.classList.remove('bg-primary', 'text-white');
        existing.classList.add('text-primary');
        existingAnchor.classList.remove('router-link-active', 'router-link-exact-active');
      }
      continuePendingSidebarNavigation();
      return;
    }

    var portAnchor = document.querySelector('a[href="/ports"], a[href^="/ports?"]');
    if (!portAnchor) return;

    var portItem = (typeof portAnchor.closest === 'function' && portAnchor.closest('.menu > *')) ||
                   portAnchor.parentElement || portAnchor;
    if (!portItem || !portItem.parentNode) return;

    var newItem = portItem.cloneNode(false);
    newItem.setAttribute('data-dbsext-beacons-link', '1');
    if (newItem.removeAttribute) newItem.removeAttribute('id');

    var newAnchor = document.createElement('a');
    newAnchor.setAttribute('data-dbsext-beacons-link-a', '1');
    newAnchor.setAttribute('href', targetHref);
    newAnchor.textContent = 'ビーコン情報';
    bindSidebarNavigation(newAnchor);

    if (portAnchor.className) {
      newAnchor.className = portAnchor.className.replace(/router-link-[^\s]+/g, '').trim();
    }

    if (isBeaconsPage) {
      newItem.classList.add('bg-primary', 'text-white');
      newItem.classList.remove('text-primary');
      newAnchor.classList.add('router-link-active', 'router-link-exact-active');
    } else {
      newItem.classList.remove('bg-primary', 'text-white');
      newItem.classList.add('text-primary');
      newAnchor.classList.remove('router-link-active', 'router-link-exact-active');
    }

    newItem.appendChild(newAnchor);
    portItem.parentNode.insertBefore(newItem, portItem.nextSibling);
    continuePendingSidebarNavigation();
  }

  /**
   * 標準表の直前（新規登録・検索ブロックの後）を優先し、見つからない場合は本文先頭へ戻す。
   */
  function findInsertionPoint() {
    if (typeof document === 'undefined') return null;

    var heading = null;
    var candidates = document.querySelectorAll('p, h1, h2, h3');
    for (var i = 0; i < candidates.length; i++) {
      var txt = (candidates[i].textContent || '').replace(/[\s\u3000]+/g, ' ').trim();
      if (txt === 'ビーコン情報 一覧') {
        heading = candidates[i];
        break;
      }
    }
    if (!heading) return null;

    var portalTable = document.querySelector('.el-table:not([data-dbsext-beacons-table])');
    if (!portalTable) return null;

    // 実画面では標準表が .mb-4 で包まれ、その直前に新規登録・検索ブロックがある。
    // 拡張パネルを .mb-4 の直前へ置けば、新規登録バーを上に残せる。
    var tableSection = portalTable;
    while (tableSection && tableSection !== document.body && tableSection !== document.documentElement) {
      if (tableSection.classList && tableSection.classList.contains('mb-4') && tableSection.parentNode) {
        return { container: tableSection.parentNode, targetSibling: tableSection };
      }
      tableSection = tableSection.parentNode;
    }

    var ancestorsH = [];
    var cur = heading;
    while (cur && cur !== document.body && cur !== document.documentElement) {
      ancestorsH.push(cur);
      cur = cur.parentNode;
    }

    var ancestorsT = [];
    cur = portalTable;
    while (cur && cur !== document.body && cur !== document.documentElement) {
      ancestorsT.push(cur);
      cur = cur.parentNode;
    }

    var mainContainer = null;
    var headingWrapper = null;

    for (var h = 0; h < ancestorsH.length; h++) {
      var nodeH = ancestorsH[h];
      for (var t = 0; t < ancestorsT.length; t++) {
        if (nodeH === ancestorsT[t]) {
          mainContainer = nodeH;
          headingWrapper = (h > 0) ? ancestorsH[h - 1] : heading;
          break;
        }
      }
      if (mainContainer) break;
    }

    if (!mainContainer || mainContainer === document.body || (mainContainer.id && mainContainer.id === '__nuxt')) {
      return null;
    }

    return {
      container: mainContainer,
      targetSibling: headingWrapper ? headingWrapper.nextSibling : null
    };
  }

  /**
   * `/beacons` 画面に拡張所有パネルを描画・更新
   */
  function renderPanel() {
    if (typeof document === 'undefined') return;
    if (nativePopupState && /^\/beacons(\/|$)/.test(location.pathname) &&
        (!isNodeConnected(nativePopupState.section) || !isNodeConnected(nativePopupState.table))) {
      closeNativeTablePopup();
    }
    if (!/^\/beacons(\/|$)/.test(location.pathname)) {
      closeNativeTablePopup();
      var stalePanels = document.querySelectorAll('[data-dbsext-beacons-panel="1"]');
      if (stalePanels.length > 0) {
        currentGeneration++;
        isFetching = false;
        activeRequest = null;
      }
      for (var sp = 0; sp < stalePanels.length; sp++) {
        if (stalePanels[sp].parentNode) {
          stalePanels[sp].parentNode.removeChild(stalePanels[sp]); // dbsext:own-ui
        }
      }
      return;
    }

    var existingPanel = document.querySelector('[data-dbsext-beacons-panel="1"]');
    var selectedAreaId = getSelectedAreaId();

    // Vue が同じURLのまま本文を差し替えると、取得開始時のパネルだけが
    // DOM から外れ、新しいパネルを作り直す場合がある。切断済みパネルの
    // リクエストを現行パネルへ誤って引き継がない。
    if (!existingPanel && activeRequest &&
        !isPanelConnected(activeRequest.panel, activeRequest.areaId)) {
      currentGeneration++;
      isFetching = false;
      activeRequest = null;
    }

    if (existingPanel) {
      var prevArea = existingPanel.getAttribute('data-dbsext-beacons-area');
      var currentAreaAttr = selectedAreaId || '';
      if (prevArea !== currentAreaAttr) {
        existingPanel.__dbsextBeaconAutoArea = null;
        if (selectedAreaId) {
          existingPanel.setAttribute('data-dbsext-beacons-area', selectedAreaId);
        } else {
          existingPanel.removeAttribute('data-dbsext-beacons-area');
        }
        currentGeneration++;
        isFetching = false;
        activeRequest = null;

        var statusDiv = existingPanel.querySelector('[data-dbsext-beacons-status="1"]');
        var tableWrap = existingPanel.querySelector('.dbsext-beacons-table-wrap');
        if (statusDiv) {
          while (statusDiv.firstChild) statusDiv.removeChild(statusDiv.firstChild); // dbsext:own-ui
          statusDiv.textContent = '';
          statusDiv.className = '';
        }
        if (tableWrap) {
          while (tableWrap.firstChild) tableWrap.removeChild(tableWrap.firstChild); // dbsext:own-ui
        }
      }
      updatePanelState(existingPanel, selectedAreaId);
      ensureAutoFetch(existingPanel, selectedAreaId);
      return;
    }

    var insertion = findInsertionPoint();
    if (!insertion || !insertion.container) return;

    var panel = document.createElement('div');
    panel.setAttribute('data-dbsext-beacons-panel', '1');
    if (selectedAreaId) {
      panel.setAttribute('data-dbsext-beacons-area', selectedAreaId);
    }

    var h2 = document.createElement('h2');
    h2.textContent = 'エリア内ビーコン一覧（拡張）';
    panel.appendChild(h2);

    var actionsDiv = document.createElement('div');
    actionsDiv.className = 'dbsext-beacons-actions';

    var btn = document.createElement('button');
    btn.setAttribute('data-dbsext-beacons-btn', '1');
    btn.className = 'dbsext-btn';
    btn.textContent = '再取得';

    btn.addEventListener('click', function () {
      handleFetchClick(panel);
    });

    actionsDiv.appendChild(btn);
    panel.appendChild(actionsDiv);

    var statusDiv = document.createElement('div');
    statusDiv.setAttribute('data-dbsext-beacons-status', '1');
    panel.appendChild(statusDiv);

    var tableWrap = document.createElement('div');
    tableWrap.className = 'dbsext-beacons-table-wrap';
    // 横スクロールバーの見た目は table-wrap.js が共通で与える
    tableWrap.setAttribute('data-dbsext-table-scroll', '1');
    panel.appendChild(tableWrap);

    if (insertion.targetSibling) {
      insertion.container.insertBefore(panel, insertion.targetSibling);
    } else {
      insertion.container.appendChild(panel);
    }

    updatePanelState(panel, selectedAreaId);
    ensureAutoFetch(panel, selectedAreaId);
  }

  /**
   * パネルのボタン状態と状態メッセージを更新
   */
  function updatePanelState(panel, selectedAreaId) {
    var btn = panel.querySelector('[data-dbsext-beacons-btn="1"]');
    var statusDiv = panel.querySelector('[data-dbsext-beacons-status="1"]');
    if (!btn || !statusDiv) return;

    var panelIsFetching = !!(isFetching && activeRequest &&
      activeRequest.panel === panel && activeRequest.areaId === selectedAreaId);
    if (panelIsFetching) {
      btn.disabled = true;
      btn.textContent = '取得中...';
      return;
    }

    btn.textContent = '再取得';
    if (!selectedAreaId) {
      btn.disabled = true;
      statusDiv.textContent = 'エリアを選択してください';
      statusDiv.className = 'dbsext-beacons-warn';
    } else {
      btn.disabled = false;
      if (statusDiv.textContent === 'エリアを選択してください') {
        statusDiv.textContent = '';
        statusDiv.className = '';
      }
    }
  }

  /**
   * 一覧取得ボタンのクリックハンドラ
   */
  function handleFetchClick(panel) {
    var selectedAreaId = getSelectedAreaId();
    if (!selectedAreaId || isFetching) return;

    currentGeneration++;
    var gen = currentGeneration;
    latestGenerationByArea[selectedAreaId] = gen;
    activeRequest = { generation: gen, areaId: selectedAreaId, panel: panel };

    var statusDiv = panel.querySelector('[data-dbsext-beacons-status="1"]');
    var tableWrap = panel.querySelector('.dbsext-beacons-table-wrap');

    isFetching = true;
    updatePanelState(panel, selectedAreaId);

    var now = Date.now();
    var cached = cacheMap[selectedAreaId];
    if (cached && (now - cached.timestamp < CACHE_TTL_MS)) {
      isFetching = false;
      activeRequest = null;
      if (gen === currentGeneration && isPanelConnected(panel, selectedAreaId)) {
        renderTableData(panel, cached.rows, cached.portCount, cached.failedPortCount);
        updatePanelState(panel, selectedAreaId);
      }
      return;
    }

    if (!D.platform || typeof D.platform.fetchBeaconsByArea !== 'function') {
      isFetching = false;
      activeRequest = null;
      if (gen === currentGeneration && isPanelConnected(panel, selectedAreaId)) {
        statusDiv.textContent = 'D.platform.fetchBeaconsByArea が利用できません';
        statusDiv.className = 'dbsext-beacons-error';
        updatePanelState(panel, selectedAreaId);
      }
      return;
    }

    D.platform.fetchBeaconsByArea(selectedAreaId)
      .then(function (result) {
        var res = result || { rows: [], portCount: 0, failedPortCount: 0 };
        // A1 → B → A2 の順に開始し、A2 より後で古い A1 が完了しても、
        // A2 の新しいキャッシュを上書きさせない。
        if (latestGenerationByArea[selectedAreaId] === gen) {
          cacheMap[selectedAreaId] = {
            rows: res.rows || [],
            portCount: res.portCount || 0,
            failedPortCount: res.failedPortCount || 0,
            timestamp: Date.now()
          };
        }
        if (activeRequest && activeRequest.generation === gen) {
          isFetching = false;
          activeRequest = null;
        }
        if (gen === currentGeneration && isPanelConnected(panel, selectedAreaId)) {
          renderTableData(panel, res.rows || [], res.portCount || 0, res.failedPortCount || 0);
          updatePanelState(panel, selectedAreaId);
        }
      })
      .catch(function (err) {
        if (activeRequest && activeRequest.generation === gen) {
          isFetching = false;
          activeRequest = null;
        }
        if (gen === currentGeneration && isPanelConnected(panel, selectedAreaId)) {
          var msg = (err && err.message) ? err.message : String(err);
          statusDiv.textContent = 'ビーコン一覧の取得に失敗しました: ' + msg;
          statusDiv.className = 'dbsext-beacons-error';
          if (tableWrap) {
            while (tableWrap.firstChild) tableWrap.removeChild(tableWrap.firstChild); // dbsext:own-ui
          }
          updatePanelState(panel, selectedAreaId);
        }
      });
  }

  /**
   * 取得結果データからテーブル・警告の表示を行う（XSS対策: textContent で挿入）
   */
  function renderTableData(panel, rawRows, portCount, failedPortCount) {
    var statusDiv = panel.querySelector('[data-dbsext-beacons-status="1"]');
    var tableWrap = panel.querySelector('.dbsext-beacons-table-wrap');
    if (!statusDiv || !tableWrap) return;

    // 前回の表示をクリア // dbsext:own-ui
    while (statusDiv.firstChild) {
      statusDiv.removeChild(statusDiv.firstChild); // dbsext:own-ui
    }
    while (tableWrap.firstChild) {
      tableWrap.removeChild(tableWrap.firstChild); // dbsext:own-ui
    }

    if (failedPortCount > 0) {
      statusDiv.textContent = '一部のポート（' + failedPortCount + '件）の取得に失敗しました。';
      statusDiv.className = 'dbsext-beacons-warn';
    } else {
      statusDiv.textContent = '';
      statusDiv.className = '';
    }

    var deduped = dedupeBeacons(rawRows);
    var sorted = sortBeacons(deduped);

    if (sorted.length === 0) {
      if (failedPortCount === 0) {
        statusDiv.textContent = '対象エリア内にポート割当済みビーコンはありません。';
        statusDiv.className = '';
      }
      return;
    }

    var columns = [
      {
        label: 'ビーコン識別番号',
        value: function (item) { return item.portBeaconUniqueCode || item.portBeaconId || ''; },
        render: function (td, item) {
          var code = String(item.portBeaconUniqueCode || item.portBeaconId || '');
          // 10桁の識別番号だけ、ポータル標準検索を開くボタンにする
          if (!/^[A-Za-z0-9]{10}$/.test(code)) {
            td.textContent = code;
            return;
          }
          var codeButton = document.createElement('button');
          codeButton.setAttribute('type', 'button');
          codeButton.className = 'dbsext-cell-link';
          codeButton.textContent = code;
          codeButton.addEventListener('click', function () {
            openNativeBeaconPopup(panel, code);
          });
          td.appendChild(codeButton);
        }
      },
      { label: 'ビーコン種別', value: function (item) { return formatBeaconType(item.beaconType); } },
      { label: 'ポート識別番号', value: function (item) { return item.portUniqueCode || ''; } },
      { label: 'ポート名', value: function (item) { return item.portNameJa || ''; } },
      { label: 'ビーコン電圧', value: function (item) {
        var val = item.portBeaconElectricVoltage;
        return (val !== null && val !== undefined && val !== '') ? String(val) : 'ー';
      } },
      { label: 'ビーコンバッテリー残量[%]', value: function (item) {
        var val = item.batteryRemainingAmount;
        return (val !== null && val !== undefined && val !== '') ? String(val) : 'ー';
      } },
      { label: '最終受信日時', value: function (item) { return item.lastReceivedTs || ''; } }
    ];

    // 描画・並べ替え・絞り込みは custom-table が担う。
    // 以前はここに約110行の自前実装があり、問題申告一覧とほぼ同じものだった
    // （112行中87行が同一。片方だけ直した改修が伝播せず見た目が食い違っていた）。
    //
    // 電圧・バッテリー残量の列は、共通コアの宣言表により
    // **「以上・以下」の数値絞り込み**になる。
    D.customTable.render({
      container: tableWrap,
      rows: sorted,
      columns: columns,
      tableAttrs: { 'data-dbsext-beacons-table': '1' },
      emptyText: '絞り込み条件に一致するビーコンはありません。'
    });
  }

  function ensureAutoFetch(panel, selectedAreaId) {
    if (!panel || !selectedAreaId) return;
    if (panel.__dbsextBeaconAutoArea === selectedAreaId) return;
    panel.__dbsextBeaconAutoArea = selectedAreaId;
    handleFetchClick(panel);
  }

  function isNodeConnected(node) {
    var cur = node;
    while (cur) {
      if (cur === document.body || cur === document.documentElement) return true;
      cur = cur.parentNode;
    }
    return false;
  }

  function findNativeTableSection(table) {
    var cur = table;
    while (cur && cur !== document.body && cur !== document.documentElement) {
      if (cur.classList && cur.classList.contains('mb-4')) return cur;
      cur = cur.parentNode;
    }
    return null;
  }

  function findNativeResult(code) {
    var tables = document.querySelectorAll('.el-table:not([data-dbsext-beacons-table])');
    for (var i = 0; i < tables.length; i++) {
      var cells = tables[i].querySelectorAll('td');
      for (var c = 0; c < cells.length; c++) {
        if (String(cells[c].textContent || '').trim() === code) {
          var section = findNativeTableSection(tables[i]);
          var row = cells[c];
          while (row && row !== tables[i] && String(row.tagName || '').toUpperCase() !== 'TR') {
            row = row.parentNode;
          }
          if (section) return {
            table: tables[i],
            section: section,
            row: row && String(row.tagName || '').toUpperCase() === 'TR' ? row : null,
            cell: cells[c]
          };
        }
      }
    }
    return null;
  }

  function findNativeSearchControls() {
    var buttons = document.querySelectorAll('button');
    for (var i = 0; i < buttons.length; i++) {
      if (String(buttons[i].textContent || '').replace(/[\s\u3000]+/g, '').trim() !== '検索') continue;
      var container = buttons[i].parentNode;
      while (container && container !== document.body && container !== document.documentElement) {
        var input = container.querySelector && container.querySelector('input');
        if (input) return { input: input, button: buttons[i] };
        container = container.parentNode;
      }
    }
    return null;
  }

  function setNativeInputValue(input, value) {
    var proto = global.HTMLInputElement && global.HTMLInputElement.prototype;
    var descriptor = proto && Object.getOwnPropertyDescriptor(proto, 'value');
    if (descriptor && descriptor.set) descriptor.set.call(input, value);
    else input.value = value;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function findNativeCancelButton() {
    if (!nativePopupState || !nativePopupState.section) return null;
    var buttons = nativePopupState.section.querySelectorAll('button');
    for (var i = 0; i < buttons.length; i++) {
      var label = String(buttons[i].textContent || '').replace(/[\s\u3000]+/g, '');
      if (label !== '取消' && label !== 'キャンセル') continue;
      if (buttons[i].disabled || buttons[i].hidden) continue;
      if (typeof buttons[i].getClientRects === 'function' && buttons[i].getClientRects().length === 0) continue;
      if (typeof global.getComputedStyle === 'function') {
        var style = global.getComputedStyle(buttons[i]);
        if (style && (style.display === 'none' || style.visibility === 'hidden')) continue;
      }
      return buttons[i];
    }
    return null;
  }

  function cancelNativeEditIfActive() {
    var cancelButton = findNativeCancelButton();
    if (!cancelButton || typeof cancelButton.click !== 'function') return false;
    cancelButton.click();
    return true;
  }

  function closeNativeTablePopup(cancelPending) {
    if (cancelPending !== false) nativeSearchGeneration++;
    if (!nativePopupState) return;
    cancelNativeEditIfActive();
    if (nativePopupState.section && nativePopupState.section.classList) {
      nativePopupState.section.classList.remove('dbsext-beacons-native-modal-open');
    }
    if (nativePopupState.root && nativePopupState.root.parentNode) {
      nativePopupState.root.parentNode.removeChild(nativePopupState.root); // dbsext:own-ui
    }
    nativePopupState = null;
  }

  function showNativeTablePopup(code, result) {
    closeNativeTablePopup(false);
    var root = document.createElement('div');
    root.setAttribute('data-dbsext-beacons-native-modal', '1');

    var backdrop = document.createElement('button');
    backdrop.setAttribute('type', 'button');
    backdrop.className = 'dbsext-beacons-native-backdrop';
    backdrop.setAttribute('aria-label', '標準ビーコン情報を閉じる');
    backdrop.addEventListener('click', function () { closeNativeTablePopup(); });
    root.appendChild(backdrop);

    var header = document.createElement('div');
    header.className = 'dbsext-beacons-native-header';
    var title = document.createElement('strong');
    title.textContent = '標準ビーコン情報: ' + code;
    header.appendChild(title);
    var note = document.createElement('span');
    note.textContent = '編集・削除はポータル標準の操作です。';
    header.appendChild(note);
    var closeButton = document.createElement('button');
    closeButton.setAttribute('type', 'button');
    closeButton.className = 'dbsext-beacons-native-close';
    closeButton.textContent = '閉じる';
    closeButton.addEventListener('click', function () { closeNativeTablePopup(); });
    header.appendChild(closeButton);
    root.appendChild(header);

    document.body.appendChild(root);
    result.section.classList.add('dbsext-beacons-native-modal-open');
    nativePopupState = { root: root, section: result.section, table: result.table, code: code };
  }

  function waitForNativeResult(code, generation, triggerSearch) {
    var beforeResult = findNativeResult(code);
    if (typeof MutationObserver === 'undefined') {
      triggerSearch();
      var immediate = findNativeResult(code);
      return immediate ? Promise.resolve(immediate) :
        Promise.reject(new Error('標準検索結果を確認できませんでした。'));
    }

    var standardTable = document.querySelector('.el-table:not([data-dbsext-beacons-table])');
    var standardSection = standardTable && findNativeTableSection(standardTable);
    var observedRoot = (standardSection && standardSection.parentNode) || document.body;

    return new Promise(function (resolve, reject) {
      var settled = false;
      var timer = null;
      var observer = new MutationObserver(function () {
        if (settled) return;
        if (generation !== nativeSearchGeneration) {
          settled = true;
          observer.disconnect();
          clearTimeout(timer);
          reject(new Error('標準検索が取り消されました。'));
          return;
        }
        var result = findNativeResult(code);
        if (!result) return;
        if (beforeResult && result.table === beforeResult.table &&
            result.row === beforeResult.row && result.cell === beforeResult.cell) return;
        settled = true;
        observer.disconnect();
        clearTimeout(timer);
        resolve(result);
      });
      // core.js と同じ理由の防御（実機で確認された例外）。
      // ここは Promise の executor 内なので、素通しにすると呼び出し元に
      // 例外ではなく **rejectとして** 伝わる方が自然（呼び出し元は catch している）。
      try {
        observer.observe(observedRoot, { childList: true, subtree: true, characterData: true });
      } catch (e) {
        reject(new Error('標準検索結果の監視を開始できませんでした: ' + (e && e.message ? e.message : e)));
        return;
      }
      timer = setTimeout(function () {
        if (settled) return;
        settled = true;
        observer.disconnect();
        reject(new Error('標準検索結果の表示を8秒以内に確認できませんでした。'));
      }, 8000);

      triggerSearch();
      if (!beforeResult) {
        var immediate = findNativeResult(code);
        if (immediate && !settled) {
          settled = true;
          observer.disconnect();
          clearTimeout(timer);
          resolve(immediate);
        }
      }
    });
  }

  function openNativeBeaconPopup(panel, rawCode) {
    var code = String(rawCode || '').trim();
    var statusDiv = panel.querySelector('[data-dbsext-beacons-status]');
    if (!/^[A-Za-z0-9]{10}$/.test(code)) {
      if (statusDiv) {
        statusDiv.textContent = '標準検索に渡せる10桁のビーコン識別番号ではありません。';
        statusDiv.className = 'dbsext-beacons-error';
      }
      return;
    }

    var controls = findNativeSearchControls();
    if (!controls) {
      if (statusDiv) {
        statusDiv.textContent = 'ポータル標準のビーコン検索欄を確認できませんでした。';
        statusDiv.className = 'dbsext-beacons-error';
      }
      return;
    }

    closeNativeTablePopup();
    var generation = ++nativeSearchGeneration;
    setNativeInputValue(controls.input, code);
    waitForNativeResult(code, generation, function () { controls.button.click(); }).then(function (result) {
      if (generation !== nativeSearchGeneration || !/^\/beacons(\/|$)/.test(location.pathname)) return;
      showNativeTablePopup(code, result);
    }).catch(function (err) {
      if (generation !== nativeSearchGeneration || !statusDiv) return;
      statusDiv.textContent = err && err.message ? err.message : '標準検索結果を表示できませんでした。';
      statusDiv.className = 'dbsext-beacons-error';
    });
  }

  D.beacons = {
    apply: function () {
      if (typeof document === 'undefined' || !document.body) return;
      injectSidebarMenu();
      renderPanel();
    },

    // テスト用の内部状態アクセス
    _clearCache: function () {
      cacheMap = Object.create(null);
      latestGenerationByArea = Object.create(null);
      isFetching = false;
      currentGeneration = 0;
      activeRequest = null;
      pendingSidebarNavigation = false;
      closeNativeTablePopup();
    },
    _getCache: function () {
      return cacheMap;
    },
    _isValidPortalId: isValidPortalId,
    _formatBeaconType: formatBeaconType,
    _dedupeBeacons: dedupeBeacons,
    _sortBeacons: sortBeacons
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
