(function () {
  'use strict';

  if (typeof importScripts === 'function') {
    try {
      importScripts('signature.js', 'remote-config.js', 'remote-updater.js', 'diagnostics.js', 'diagnostics-config.js');
    } catch (e) {
      // safe fallback if scripts cannot be imported
    }
  }

  // 開いてよいURLの許可リスト。
  // content script からのメッセージしか届かない想定だが、URLをそのまま
  // chrome.tabs.create / storage へ渡すのは避ける（多層防御）。
  // sidepanel.js の ALLOWED_PREFIX と同じ値を保つこと。
  var ALLOWED_PREFIX = 'https://dontsu87.github.io/';
  var diagnostics = (typeof DBSEXT_DIAGNOSTICS !== 'undefined') ? DBSEXT_DIAGNOSTICS.create({
    storage: chrome.storage.local,
    transport: fetch,
    config: (typeof DBSEXT_DIAGNOSTICS_CONFIG !== 'undefined') ? DBSEXT_DIAGNOSTICS_CONFIG : {}
  }) : null;

  function isAllowedUrl(url) {
    return typeof url === 'string' && url.indexOf(ALLOWED_PREFIX) === 0;
  }

  function initSidePanelBehavior() {
    if (chrome.sidePanel && typeof chrome.sidePanel.setPanelBehavior === 'function') {
      try {
        chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(function () {});
      } catch (e) {
        // Safe fallback if API is not supported in environment
      }
    }
  }

  async function initUserScripts() {
    if (chrome.userScripts && typeof chrome.userScripts.configureWorld === 'function') {
      try {
        await chrome.userScripts.configureWorld({ messaging: true });
      } catch (e) {
        console.warn('[service-worker] configureWorld 失敗: ' + (e && e.message ? e.message : e));
      }
    }
    if (typeof DBSEXT_REMOTE_UPDATER !== 'undefined' && typeof DBSEXT_REMOTE_UPDATER.updateAndRegister === 'function') {
      try {
        await DBSEXT_REMOTE_UPDATER.updateAndRegister();
      } catch (e) {
        console.warn('[service-worker] updateAndRegister 失敗: ' + (e && e.message ? e.message : e));
      }
    }
  }

  chrome.runtime.onInstalled.addListener(function () {
    initSidePanelBehavior();
    initUserScripts();
  });

  if (chrome.runtime.onStartup) {
    chrome.runtime.onStartup.addListener(function () {
      initUserScripts();
    });
  }

  // ポータルを開いたときに更新を確認（B-1: 5分以内の重複抑止、setInterval不使用）
  var lastCheckTime = 0;
  var CHECK_INTERVAL_MS = 5 * 60 * 1000;

  if (chrome.tabs && chrome.tabs.onUpdated) {
    chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
      var url = (changeInfo && changeInfo.url) || (tab && tab.url);
      if (url && url.indexOf('https://mg.docomo-cycle.jp/') === 0) {
        var now = Date.now();
        if (now - lastCheckTime >= CHECK_INTERVAL_MS) {
          lastCheckTime = now;
          initUserScripts().catch(function () {});
        }
      }
    });
  }

  initSidePanelBehavior();
  initUserScripts();

  function handleMessage(message, sender, sendResponse) {
    if (!message || typeof message.type !== 'string') {
      return false;
    }

    // 送信元検証 (A-4: R-04)
    var currentExtensionId = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) || null;
    if (!sender || (currentExtensionId && sender.id !== currentExtensionId)) {
      sendResponse({ ok: false, error: '拒否: 不正な送信元です (sender.id mismatch)' });
      return true;
    }

    if (sender.tab && sender.tab.url) {
      if (sender.tab.url.indexOf('https://mg.docomo-cycle.jp/') !== 0) {
        sendResponse({ ok: false, error: '拒否: 許可されていない送信元URLです' });
        return true;
      }
    }

    // 配信版が注入されたことの合図。**ここに出れば、注入は確実に起きている。**
    // ページのコンソールはフィルタや window.onerror で見えないことがあるため、
    // service worker 側にも必ず残す（利用者に見てもらう場所を1箇所にする）。
    if (message.type === 'dbsext:userScriptPing') {
      console.log('[dbsext-updater] 配信版が注入されました: 版=' + message.version +
        ' 適用元=' + message.source + ' url=' + message.url);
      sendResponse({ ok: true });
      return true;
    }

    if (message.type === 'dbsext:diagnosticConsentGet' && diagnostics) {
      diagnostics.consent().then(sendResponse, function () { sendResponse({ state: 'unknown' }); });
      return true;
    }

    if (message.type === 'dbsext:diagnosticConsentSet' && diagnostics) {
      diagnostics.setConsent(message.state).then(function () { sendResponse({ ok: true }); }, function () { sendResponse({ ok: false }); });
      return true;
    }

    if (message.type === 'dbsext:diagnosticRecord' && diagnostics) {
      var manifest = chrome.runtime.getManifest();
      var channel = (typeof DBSEXT_REMOTE_CONFIG !== 'undefined' && DBSEXT_REMOTE_CONFIG.CHANNEL_NAME) || 'production';
      diagnostics.record(message.event, { extensionVersion: manifest.version, channel: channel, installHash: '' })
        .then(function (queued) { sendResponse({ ok: true, queued: queued }); }, function () { sendResponse({ ok: false }); });
      return true;
    }

    if (message.type === 'dbsext:areas') {
      fetch('https://mg.docomo-cycle.jp/api/areas', { credentials: 'include' })
        .then(function (res) {
          if (!res.ok) {
            throw new Error('HTTP ' + res.status);
          }
          return res.json();
        })
        .then(function (body) {
          var areas = [];
          if (Array.isArray(body)) {
            areas = body;
          } else if (body && Array.isArray(body.dataList)) {
            areas = body.dataList;
          } else if (body && Array.isArray(body.items)) {
            areas = body.items;
          } else if (body && Array.isArray(body.data)) {
            areas = body.data;
          }
          sendResponse({ ok: true, areas: areas });
        })
        .catch(function (err) {
          sendResponse({ ok: false, error: err.message || String(err) });
        });
      return true;
    }

    if (message.type === 'dbsext:beaconPortsByArea') {
      var areaId = message.areaId;
      if (typeof areaId !== 'string' || !areaId || !/^[A-Za-z0-9:_-]{1,256}$/.test(areaId)) {
        sendResponse({ ok: false, error: '無効なエリアIDです' });
        return true;
      }
      var encodedAreaId = encodeURIComponent(areaId);
      fetch('https://mg.docomo-cycle.jp/api/ports/bulk?areaIds=' + encodedAreaId, { credentials: 'include' })
        .then(function (res) {
          if (!res.ok) {
            throw new Error('HTTP ' + res.status);
          }
          return res.json();
        })
        .then(function (body) {
          var ports = [];
          if (Array.isArray(body)) {
            ports = body;
          } else if (body && Array.isArray(body.dataList)) {
            ports = body.dataList;
          } else if (body && Array.isArray(body.items)) {
            ports = body.items;
          } else if (body && Array.isArray(body.data)) {
            ports = body.data;
          }
          sendResponse({ ok: true, ports: ports });
        })
        .catch(function (err) {
          sendResponse({ ok: false, error: err.message || String(err) });
        });
      return true;
    }

    if (message.type === 'dbsext:beaconsByPort') {
      var portId = message.portId;
      if (typeof portId !== 'string' || !portId || !/^[A-Za-z0-9:_-]{1,256}$/.test(portId)) {
        sendResponse({ ok: false, error: '無効なポートIDです' });
        return true;
      }
      var encodedPortId = encodeURIComponent(portId);
      fetch('https://mg.docomo-cycle.jp/api/ports/' + encodedPortId + '/beacons', { credentials: 'include' })
        .then(function (res) {
          if (!res.ok) {
            throw new Error('HTTP ' + res.status);
          }
          return res.json();
        })
        .then(function (body) {
          var items = [];
          if (Array.isArray(body)) {
            items = body;
          } else if (body && Array.isArray(body.dataList)) {
            items = body.dataList;
          } else if (body && Array.isArray(body.items)) {
            items = body.items;
          } else if (body && Array.isArray(body.data)) {
            items = body.data;
          }
          sendResponse({ ok: true, beacons: items });
        })
        .catch(function (err) {
          sendResponse({ ok: false, error: err.message || String(err) });
        });
      return true;
    }

    if (message.type === 'dbsext:openTab') {
      if (!isAllowedUrl(message.url)) {
        sendResponse({ ok: false, error: '許可されていないURLです' });
        return true;
      }
      chrome.tabs.create({ url: message.url }, function () {
        sendResponse({ ok: true });
      });
      return true;
    }

    if (message.type === 'dbsext:openSplit') {
      if (!isAllowedUrl(message.url)) {
        sendResponse({ ok: false, error: '許可されていないURLです' });
        return true;
      }
      var windowId = (sender && sender.tab) ? sender.tab.windowId : undefined;
      chrome.storage.session.set({ dbsextMapUrl: message.url })
        .then(function () {
          if (windowId !== undefined && chrome.sidePanel && typeof chrome.sidePanel.open === 'function') {
            return chrome.sidePanel.open({ windowId: windowId });
          } else {
            throw new Error('No windowId');
          }
        })
        .then(function () {
          sendResponse({ ok: true });
        })
        .catch(function () {
          sendResponse({
            ok: false,
            error: 'サイドパネルを開けませんでした。拡張機能のアイコンをクリックしてください'
          });
        });
      return true;
    }

    return false;
  }

  chrome.runtime.onMessage.addListener(handleMessage);

  if (chrome.runtime.onUserScriptMessage) {
    chrome.runtime.onUserScriptMessage.addListener(handleMessage);
  }
})();

