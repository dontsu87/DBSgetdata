/**
 * DBSEXT 通信ステータスモジュール
 * 通信監視、読み込み中マスク表示、エラー・セッション切れ通知を担当
 *
 * ---------------------------------------------------------------------------
 * **拡張版（β）・リモート配信版での動作方式:**
 *
 * 拡張の content script / user script は隔離ワールド（ISOLATED / USER_SCRIPT）で動くため、
 * このモジュールが直接ポータル本体（MAIN ワールド）の fetch / XHR を捕捉することはできない。
 * 代わりに、MAIN ワールドに注入された傍受スクリプト（net-status-main.js）が
 * fetch / XHR をラップして DOM カスタムイベント（`dbsext:main-fetch-start` /
 * `dbsext:main-fetch-end`）を発火し、このモジュールはそれを購読する。
 *
 * ブックマークレット版（α）はページの MAIN ワールドで動くため、
 * 従来どおり fetch / XHR を直接ラップして機能する。
 *
 * 出典: 独立監査 T-20260808-AUDIT 指摘5 / T-20260809-REMOTE-AUDIT R-07。HANDOFF.md にも記録済み。
 * ---------------------------------------------------------------------------
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var LOADING_DELAY_MS = 250;
  var MIN_VISIBLE_MS = 300;
  var HARD_MAX_BUSY_MS = 15000;
  var OVERLAY_ATTR = 'data-dbsext-loading-mask';
  var TOP_INDICATOR_ATTR = 'data-dbsext-top-indicator';
  var BANNER_ATTR = 'data-dbsext-error-banner';
  var HOST_ATTR = 'data-dbsext-net-status';
  var NAV_OVERLAY_ATTR = 'data-dbsext-navigation-loading';
  var BEFORE_NAV_READY_EVENT = 'dbsext:before-navigation-ready';
  var NAV_STORAGE_KEY = 'dbsext:navigation-loading-v2';
  var NAV_PENDING_KEY = 'dbsext:navigation-pending-v2';
  var NAV_MIN_VISIBLE_MS = 2000;

  var activeRequests = 0;
  var readinessMap = {};
  var silentDepth = 0;
  var delayTimer = null;
  var elapsedTimer = null;
  var minVisibleTimer = null;
  var watchdogTimer = null;
  var requestStartTime = 0;
  var uiVisibleStartTime = 0;
  var busyEpisodeStartTime = 0;
  var isMaskVisible = false;
  var mainWorldListening = false;
  var navigationObserver = null;
  var navigationTimer = null;
  var navigationPending = false;
  var navigationVisibleStartTime = 0;
  var navigationMinVisibleTimer = null;
  var navigationPollTimer = null;
  var navigationFinalizeTimer = null;

  function onNavigationStart() {
    navigationPending = true;
    try { sessionStorage.setItem(NAV_PENDING_KEY, '1'); } catch (e) {}
  }

  function onNavigationComplete() {
    navigationPending = false;
    try { sessionStorage.removeItem(NAV_PENDING_KEY); } catch (e) {}
  }

  function navigationTargetReady() {
    if (typeof document === 'undefined' || typeof location === 'undefined') return false;
    if (!navigationPending) return false;
    var params;
    try { params = new URLSearchParams(location.search); } catch (e) { return false; }
    var expected = null;
    if (/^\/vehicles\/?$/.test(location.pathname)) expected = '1000';
    else if (/^\/notifications\/messages\/?$/.test(location.pathname)) expected = '500';
    else return document.readyState === 'complete';
    if (params.get('page-size') !== expected) return false;
    return !!document.querySelector('table.el-table__body tbody tr');
  }

  function finalizeNavigationOverlayRemoval() {
    navigationFinalizeTimer = null;
    if (navigationObserver) { navigationObserver.disconnect(); navigationObserver = null; }
    if (navigationPollTimer) { clearTimeout(navigationPollTimer); navigationPollTimer = null; }
    if (navigationTimer) { clearTimeout(navigationTimer); navigationTimer = null; }
    onNavigationComplete();
    if (typeof document !== 'undefined') {
      var nodes = document.querySelectorAll('[' + NAV_OVERLAY_ATTR + ']');
      for (var i = 0; i < nodes.length; i++) {
        if (nodes[i].parentNode) nodes[i].parentNode.removeChild(nodes[i]); // dbsext:own-ui
      }
      // document_startで先にマスクしたMAIN worldにも準備完了を知らせる。
      try { document.dispatchEvent(new CustomEvent('dbsext:navigation-ready')); } catch (e) {}
    }
    try { sessionStorage.removeItem(NAV_STORAGE_KEY); } catch (e) {}
  }

  function removeNavigationOverlay() {
    if (navigationVisibleStartTime && Date.now() - navigationVisibleStartTime < NAV_MIN_VISIBLE_MS) {
      if (!navigationMinVisibleTimer) {
        navigationMinVisibleTimer = setTimeout(function () {
          navigationMinVisibleTimer = null;
          // readinessを検出した時点ではnavigationPendingはまだtrueのまま。
          // ここでpending解除を待つと循環条件になり、後続DOM変化がない画面では
          // 20秒ウォッチドッグまでオーバーレイが残るため、準備状態を再判定する。
          checkNavigationReady();
        }, NAV_MIN_VISIBLE_MS - (Date.now() - navigationVisibleStartTime));
      }
      return;
    }
    if (navigationFinalizeTimer) return;
    // 遷移先DOMが完成し、マスクを外す直前の最終調整点。
    // URLだけ先に変わる画面でも、この時点なら表と折りたたみDOMが揃っている。
    if (typeof document !== 'undefined') {
      try { document.dispatchEvent(new CustomEvent(BEFORE_NAV_READY_EVENT)); } catch (e) {}
    }
    // Element Plus/Vueはheader.click()後のclass反映をmicrotaskで行う。
    // 次のtimer taskまでマスクを残し、折りたたみ反映前の一瞬を見せない。
    navigationFinalizeTimer = setTimeout(finalizeNavigationOverlayRemoval, 0);
  }

  function checkNavigationReady() {
    if (navigationTargetReady()) removeNavigationOverlay();
  }

  function pollNavigationReady() {
    navigationPollTimer = null;
    if (!navigationPending) return;
    checkNavigationReady();
    if (navigationPending) navigationPollTimer = setTimeout(pollNavigationReady, 100);
  }

  function showNavigationOverlay(persist) {
    if (typeof document === 'undefined') return;
    // core再適用のたびに最小表示時間をリセットしない。遷移1回につき開始は1回。
    if (!navigationPending) onNavigationStart();
    if (!navigationVisibleStartTime) navigationVisibleStartTime = Date.now();
    if (persist) {
      try { sessionStorage.setItem(NAV_STORAGE_KEY, String(Date.now())); } catch (e) {}
    }
    var root = document.documentElement || document.body;
    if (!root) return;
    if (!document.querySelector('[' + NAV_OVERLAY_ATTR + ']')) {
      var overlay = document.createElement('div');
      overlay.setAttribute(NAV_OVERLAY_ATTR, '1');
      overlay.setAttribute(HOST_ATTR, '1');
      overlay.textContent = '読み込み中…';
      overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;background:rgba(235,238,242,.96);color:#334155;font:600 18px sans-serif;pointer-events:auto;';
      root.appendChild(overlay);
    }
    if (D.platform && D.platform.isUserScript) {
      // USER_SCRIPT worldのDOM参照はobserve()でNode型不一致になる実機がある。
      // MAIN worldの早期マスクと併用し、ここでは有限タイマー内のpollで準備判定する。
      if (!navigationPollTimer) navigationPollTimer = setTimeout(pollNavigationReady, 100);
    } else if (typeof MutationObserver !== 'undefined') {
      if (navigationObserver) { navigationObserver.disconnect(); }
      try {
        navigationObserver = new MutationObserver(checkNavigationReady);
        if (document && typeof document === 'object') {
          navigationObserver.observe(document, { childList: true, subtree: true });
        }
      } catch (e) {
        navigationObserver = null;
        if (D.core && typeof D.core.log === 'function') {
          D.core.log('navigationObserver の監視開始に失敗: ' + (e && e.message ? e.message : e), true);
        }
      }
    }
    if (!navigationTimer) navigationTimer = setTimeout(removeNavigationOverlay, 20000);
  }

  function restoreNavigationOverlay() {
    // すでに同じ遷移の監視中なら、core再適用で時計・overlayを作り直さない。
    if (navigationPending && navigationPollTimer) return;
    try {
      if (sessionStorage.getItem(NAV_PENDING_KEY) === '1') {
        navigationPending = true;
      }
    } catch (e) {}
    var started = 0;
    try { started = Number(sessionStorage.getItem(NAV_STORAGE_KEY) || 0); } catch (e) {}
    if (started && Date.now() - started < 30000) {
      showNavigationOverlay(false);
      // 新ページで navigationPending=true なら、checkNavigationReady() を開始する
      if (navigationPending) {
        setTimeout(checkNavigationReady, 400);
      }
    }
    else if (started) removeNavigationOverlay();
  }

  function getReadinessDepth() {
    var count = 0;
    for (var k in readinessMap) {
      if (Object.prototype.hasOwnProperty.call(readinessMap, k)) count++;
    }
    return count;
  }

  function isBusy() {
    return activeRequests > 0 || getReadinessDepth() > 0;
  }

  function clearWatchdog() {
    if (watchdogTimer) {
      clearTimeout(watchdogTimer);
      watchdogTimer = null;
    }
  }

  function forceResetBusy(reason) {
    activeRequests = 0;
    readinessMap = {};
    busyEpisodeStartTime = 0;
    uiVisibleStartTime = 0;
    clearWatchdog();
    if (delayTimer) { clearTimeout(delayTimer); delayTimer = null; }
    if (minVisibleTimer) { clearTimeout(minVisibleTimer); minVisibleTimer = null; }
    if (D && D.core && typeof D.core.log === 'function') {
      D.core.log('netStatus ハード上限リセット: ' + reason, true);
    }
    hideLoadingUI();
  }

  function updateLoadingText(elapsedSec) {
    var text = '読み込み中…';
    if (elapsedSec >= 1) {
      text = '読み込み中… ' + elapsedSec + '秒';
    }

    if (typeof document === 'undefined') return;

    var texts = document.querySelectorAll('[' + HOST_ATTR + '] .dbsext-loading-text');
    for (var i = 0; i < texts.length; i++) {
      texts[i].textContent = text;
    }
  }

  function scheduleElapsedTimer() {
    if (elapsedTimer) {
      clearTimeout(elapsedTimer);
      elapsedTimer = null;
    }
    elapsedTimer = setTimeout(function () {
      elapsedTimer = null;
      if (isBusy() && isMaskVisible) {
        var elapsedSec = Math.floor((Date.now() - requestStartTime) / 1000);
        updateLoadingText(elapsedSec);
        scheduleElapsedTimer();
      }
    }, 500);
  }

  function createTableOverlay() {
    var overlay = document.createElement('div');
    overlay.setAttribute(OVERLAY_ATTR, '1');
    overlay.setAttribute(HOST_ATTR, '1');
    overlay.style.cssText = [
      'position: absolute',
      'top: 0',
      'left: 0',
      'width: 100%',
      'height: 100%',
      'min-height: 80px',
      'background-color: rgba(255, 255, 255, 0.75)',
      'z-index: 2000',
      'display: flex',
      'flex-direction: column',
      'align-items: center',
      'justify-content: center',
      'pointer-events: auto'
    ].join(';');

    var content = document.createElement('div');
    content.style.cssText = [
      'background: rgba(0, 0, 0, 0.75)',
      'color: #ffffff',
      'padding: 8px 16px',
      'border-radius: 4px',
      'font-size: 13px',
      'font-weight: bold',
      'display: flex',
      'align-items: center',
      'gap: 8px',
      'box-shadow: 0 2px 8px rgba(0,0,0,0.2)'
    ].join(';');

    var textSpan = document.createElement('span');
    textSpan.className = 'dbsext-loading-text';
    textSpan.textContent = '読み込み中…';

    content.appendChild(textSpan);
    overlay.appendChild(content);
    return overlay;
  }

  function createTopIndicator() {
    var indicator = document.createElement('div');
    indicator.setAttribute(TOP_INDICATOR_ATTR, '1');
    indicator.setAttribute(HOST_ATTR, '1');
    indicator.style.cssText = [
      'position: fixed',
      'top: 12px',
      'right: 12px',
      'z-index: 2147483000',
      'background: rgba(0, 0, 0, 0.75)',
      'color: #ffffff',
      'padding: 6px 12px',
      'border-radius: 4px',
      'font-size: 12px',
      'font-weight: bold',
      'box-shadow: 0 2px 8px rgba(0,0,0,0.2)',
      'pointer-events: none'
    ].join(';');

    var textSpan = document.createElement('span');
    textSpan.className = 'dbsext-loading-text';
    textSpan.textContent = '読み込み中…';

    indicator.appendChild(textSpan);
    return indicator;
  }

  function renderMask() {
    if (typeof document === 'undefined' || !document.body) return;

    var tables = document.querySelectorAll('.el-table');
    if (tables && tables.length > 0) {
      for (var i = 0; i < tables.length; i++) {
        var table = tables[i];
        if (!table.querySelector('[' + OVERLAY_ATTR + ']')) {
          var position = (typeof window !== 'undefined' && window.getComputedStyle) ? window.getComputedStyle(table).position : table.style.position;
          if (position !== 'relative' && position !== 'absolute' && position !== 'fixed') {
            table.style.position = 'relative';
          }
          table.appendChild(createTableOverlay());
        }
      }
    } else {
      if (!document.querySelector('[' + TOP_INDICATOR_ATTR + ']')) {
        document.body.appendChild(createTopIndicator());
      }
    }
  }

  function showLoadingUI() {
    isMaskVisible = true;
    renderMask();
    var elapsedSec = Math.floor((Date.now() - requestStartTime) / 1000);
    updateLoadingText(elapsedSec);
  }

  function hideLoadingUI() {
    isMaskVisible = false;
    if (delayTimer) {
      clearTimeout(delayTimer);
      delayTimer = null;
    }
    if (elapsedTimer) {
      clearTimeout(elapsedTimer);
      elapsedTimer = null;
    }
    if (minVisibleTimer) {
      clearTimeout(minVisibleTimer);
      minVisibleTimer = null;
    }

    if (typeof document === 'undefined' || !document.body) return;

    var overlays = document.querySelectorAll('[' + OVERLAY_ATTR + ']');
    for (var i = 0; i < overlays.length; i++) {
      if (overlays[i].parentNode) {
        overlays[i].parentNode.removeChild(overlays[i]); // dbsext:own-ui
      }
    }

    var indicators = document.querySelectorAll('[' + TOP_INDICATOR_ATTR + ']');
    for (var j = 0; j < indicators.length; j++) {
      if (indicators[j].parentNode) {
        indicators[j].parentNode.removeChild(indicators[j]); // dbsext:own-ui
      }
    }
  }

  function reconcileBusy() {
    if (isBusy()) {
      if (busyEpisodeStartTime === 0) {
        busyEpisodeStartTime = Date.now();
        clearWatchdog();
        watchdogTimer = setTimeout(function () {
          forceResetBusy('busy状態が15秒を超えたため強制作消しました');
        }, HARD_MAX_BUSY_MS);
      }

      if (minVisibleTimer) {
        clearTimeout(minVisibleTimer);
        minVisibleTimer = null;
      }

      if (!isMaskVisible && !delayTimer) {
        requestStartTime = Date.now();
        delayTimer = setTimeout(function () {
          delayTimer = null;
          if (isBusy()) {
            uiVisibleStartTime = Date.now();
            showLoadingUI();
            scheduleElapsedTimer();
          }
        }, LOADING_DELAY_MS);
      }
    } else {
      if (delayTimer) {
        clearTimeout(delayTimer);
        delayTimer = null;
      }

      if (isMaskVisible) {
        var elapsed = Date.now() - uiVisibleStartTime;
        if (elapsed < MIN_VISIBLE_MS) {
          if (!minVisibleTimer) {
            minVisibleTimer = setTimeout(function () {
              minVisibleTimer = null;
              if (!isBusy()) {
                busyEpisodeStartTime = 0;
                clearWatchdog();
                hideLoadingUI();
              }
            }, MIN_VISIBLE_MS - elapsed);
          }
        } else {
          busyEpisodeStartTime = 0;
          clearWatchdog();
          hideLoadingUI();
        }
      } else {
        busyEpisodeStartTime = 0;
        clearWatchdog();
      }
    }
  }

  function onRequestStart() {
    activeRequests++;
    reconcileBusy();
  }

  function onRequestEnd() {
    activeRequests = Math.max(0, activeRequests - 1);
    reconcileBusy();
  }

  function beginReadiness(key) {
    if (typeof key !== 'string' || !key) return;
    readinessMap[key] = true;
    reconcileBusy();
  }

  function endReadiness(key) {
    if (typeof key !== 'string' || !key) return;
    delete readinessMap[key];
    reconcileBusy();
  }

  function showBanner(message, isAuthError) {
    if (typeof document === 'undefined' || !document.body) return;

    // 既存バナーがあれば更新（同時に1枚まで）
    var existing = document.querySelector('[' + BANNER_ATTR + ']');
    if (existing) {
      var msgSpan = existing.querySelector('.dbsext-banner-text');
      if (msgSpan) msgSpan.textContent = message;
      existing.style.backgroundColor = isAuthError ? '#c0392b' : '#d9534f';
      return;
    }

    var banner = document.createElement('div');
    banner.setAttribute(BANNER_ATTR, '1');
    banner.setAttribute(HOST_ATTR, '1');
    banner.style.cssText = [
      'position: fixed',
      'top: 12px',
      'left: 50%',
      'transform: translateX(-50%)',
      'z-index: 2147483001',
      'background-color: ' + (isAuthError ? '#c0392b' : '#d9534f'),
      'color: #ffffff',
      'padding: 8px 16px',
      'border-radius: 6px',
      'font-size: 13px',
      'font-weight: bold',
      'box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25)',
      'display: flex',
      'align-items: center',
      'gap: 12px'
    ].join(';');

    var textSpan = document.createElement('span');
    textSpan.className = 'dbsext-banner-text';
    textSpan.textContent = message;
    banner.appendChild(textSpan);

    var closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.textContent = '✕';
    closeBtn.style.cssText = [
      'background: none',
      'border: none',
      'color: #ffffff',
      'font-size: 14px',
      'font-weight: bold',
      'cursor: pointer',
      'padding: 0 4px',
      'line-height: 1'
    ].join(';');
    closeBtn.addEventListener('click', function () {
      if (banner.parentNode) {
        banner.parentNode.removeChild(banner); // dbsext:own-ui
      }
    });
    banner.appendChild(closeBtn);

    document.body.appendChild(banner);
  }

  function handleResponseStatus(status) {
    if (status === 401 || status === 403) {
      showBanner('ログインが切れました。再度ログインしてください', true);
    } else if (status >= 400) {
      showBanner('通信に失敗しました（HTTP ' + status + '）。再読込してください', false);
    }
  }

  function handleGenericError() {
    showBanner('通信に失敗しました。再読込してください', false);
  }

  /**
   * 中断されただけの通信か。
   *
   * ポータルは「同じエンドポイントへ新しい要求が来たら古い方を中断する」作りになっており、
   * 画面を操作しているだけで AbortError が日常的に発生する。**これは異常ではない。**
   * 利用者が中断した場合（画面遷移など）も同じ。**どちらも警告を出してはいけない。**
   */
  function isAbortError(err) {
    if (!err) return false;
    if (err.name === 'AbortError') return true;
    // 環境によっては DOMException の code だけが手がかりになる
    return err.code === 20;
  }

  function isPortalUrl(input) {
    var url = '';
    try {
      if (typeof input === 'string') url = input;
      else if (input && typeof input.url === 'string') url = input.url;
      else if (input && typeof input.href === 'string') url = input.href;
    } catch (e) {}
    // XHR send() without a captured open() URL is retained as portal traffic for
    // compatibility with old/mocked implementations. Explicit external URLs are excluded.
    if (!url) return true;
    return url.indexOf('https://mg.docomo-cycle.jp/') === 0 ||
      (url.indexOf('/') === 0 && url.indexOf('//') !== 0);
  }

  function wrapFetch() {
    if (typeof window === 'undefined' || !window.fetch) return;
    if (window.fetch.__dbsext_wrapped) return;

    var origFetch = window.fetch;
    var newFetch = function (input, init) {
      var isSilent = silentDepth > 0 || !isPortalUrl(input);
      if (!isSilent) {
        onRequestStart();
      }

      var promise;
      try {
        promise = origFetch.apply(this, arguments);
      } catch (err) {
        if (!isSilent) {
          onRequestEnd();
          handleGenericError();
        }
        throw err;
      }

      return promise.then(
        function (res) {
          if (!isSilent) {
            onRequestEnd();
            if (res && !res.ok) {
              handleResponseStatus(res.status);
            }
          }
          return res;
        },
        function (err) {
          if (!isSilent) {
            onRequestEnd();
            // **中断は失敗ではない。**
            // ポータルは同じエンドポイントへの重複リクエストを意図的に中断する
            // （実測: AbortError「Request aborted as another request to the same
            //   endpoint was initiated.」が /api/auth/me や /api/areas で常時発生）。
            // これを失敗として扱うと、通信が正常でも
            // **「通信に失敗しました」が出っぱなしになる**（現場から報告された不具合）。
            // XHR 側では abort を除外していたのに、fetch 側で同じ誤りを残していた。
            if (!isAbortError(err)) handleGenericError();
          }
          return Promise.reject(err);
        }
      );
    };

    newFetch.__dbsext_wrapped = true;
    window.fetch = newFetch;
  }

  function wrapXHR() {
    if (typeof XMLHttpRequest === 'undefined' || !XMLHttpRequest.prototype || !XMLHttpRequest.prototype.send) return;
    if (XMLHttpRequest.prototype.send.__dbsext_wrapped) return;

    var origSend = XMLHttpRequest.prototype.send;
    var newSend = function () {
      var xhr = this;
      var isSilent = silentDepth > 0 || !isPortalUrl(xhr.__dbsext_request_url);

      if (!isSilent) {
        onRequestStart();
        // 通信そのものが失敗した場合（回線断・タイムアウト）。
        // **`status === 0` で判定してはいけない。** abort も 0 になるため、
        // ポータルが遷移時にリクエストを中断しただけで
        // 「通信に失敗しました」と出てしまう。`error` / `timeout` だけを拾う。
        var failed = false;
        var onFail = function () { failed = true; };
        xhr.addEventListener('error', onFail);
        xhr.addEventListener('timeout', onFail);

        var onEnd = function () {
          xhr.removeEventListener('loadend', onEnd);
          xhr.removeEventListener('error', onFail);
          xhr.removeEventListener('timeout', onFail);
          onRequestEnd();
          var status = xhr.status;
          if (status === 401 || status === 403) {
            showBanner('ログインが切れました。再度ログインしてください', true);
          } else if (status >= 400) {
            showBanner('通信に失敗しました（HTTP ' + status + '）。再読込してください', false);
          } else if (failed) {
            handleGenericError();
          }
        };
        xhr.addEventListener('loadend', onEnd);

        // **send() が同期的に例外を投げる場合がある**（InvalidStateError など）。
        // そのとき loadend は一度も来ないため、ここで戻さないと
        // カウンタが増えたまま戻らず、**マスクが永久に出っぱなしになる**。
        try {
          return origSend.apply(this, arguments);
        } catch (err) {
          xhr.removeEventListener('loadend', onEnd);
          onRequestEnd();
          handleGenericError();
          throw err;   // ポータルの挙動を変えないよう、例外はそのまま通す
        }
      }

      return origSend.apply(this, arguments);
    };

    newSend.__dbsext_wrapped = true;
    XMLHttpRequest.prototype.send = newSend;

    if (XMLHttpRequest.prototype.open && !XMLHttpRequest.prototype.open.__dbsext_wrapped) {
      var origOpen = XMLHttpRequest.prototype.open;
      var newOpen = function (method, url) {
        try { this.__dbsext_request_url = String(url || ''); } catch (e) {}
        return origOpen.apply(this, arguments);
      };
      newOpen.__dbsext_wrapped = true;
      XMLHttpRequest.prototype.open = newOpen;
    }
  }

  function queryMainWorldSnapshot() {
    if (typeof document === 'undefined') return;
    try {
      var queryEvt = new CustomEvent('dbsext:main-fetch-query');
      document.dispatchEvent(queryEvt);
    } catch (e) {}
  }

  /**
   * MAIN ワールドの傍受スクリプト（net-status-main.js）が発火する
   * DOM カスタムイベントを購読する。
   * 拡張版（β）およびリモート配信版で使われる。
   */
  function listenToMainWorldEvents() {
    if (mainWorldListening) return;
    if (typeof document === 'undefined') return;
    mainWorldListening = true;

    document.addEventListener('dbsext:main-fetch-start', function (e) {
      var detail = (e && e.detail) || {};
      var count = detail.activeRequests;
      if (typeof count === 'number' && isFinite(count) && count >= 0 && Math.floor(count) === count) {
        activeRequests = count;
        reconcileBusy();
      } else {
        onRequestStart();
      }
    });

    document.addEventListener('dbsext:main-fetch-end', function (e) {
      var detail = (e && e.detail) || {};
      var count = detail.activeRequests;
      if (typeof count === 'number' && isFinite(count) && count >= 0 && Math.floor(count) === count) {
        activeRequests = count;
        reconcileBusy();
      } else {
        onRequestEnd();
      }
      var status = detail.status;
      if (status === 401 || status === 403) {
        showBanner('ログインが切れました。再度ログインしてください', true);
      } else if (status >= 400) {
        showBanner('通信に失敗しました（HTTP ' + status + '）。再読込してください', false);
      } else if (detail.error) {
        // 旧版MAIN傍受スクリプトは、画面遷移や重複GETの正常中断も
        // status=0/error=true としか通知しない。原因を識別できない汎用エラーは
        // 赤バナーにせず、判定可能なHTTPステータスだけを通知する。
      }
    });

    document.addEventListener('dbsext:main-fetch-snapshot', function (e) {
      var detail = (e && e.detail) || {};
      var count = detail.activeRequests;
      if (typeof count === 'number' && isFinite(count) && count >= 0 && Math.floor(count) === count) {
        activeRequests = count;
        reconcileBusy();
      }
    });

    queryMainWorldSnapshot();
  }

  D.netStatus = {
    LOADING_DELAY_MS: LOADING_DELAY_MS,

    beginReadiness: beginReadiness,
    endReadiness: endReadiness,

    apply: function () {
      // 拡張版（β）またはリモート配信版: MAIN ワールドからの DOM イベントを購読
      if (D.platform && (D.platform.kind === 'extension' || D.platform.isUserScript)) {
        listenToMainWorldEvents();
      } else {
        // ブックマークレット版（α）: fetch / XHR を直接ラップ
        wrapFetch();
        wrapXHR();
      }

      if (isMaskVisible && isBusy()) {
        renderMask();
      }
      restoreNavigationOverlay();
    },

    beginNavigation: function () {
      showNavigationOverlay(true);
    },

    silent: function (fn) {
      if (typeof fn !== 'function') return;
      silentDepth++;
      try {
        return fn();
      } finally {
        silentDepth--;
      }
    },

    _getActiveRequests: function () {
      return activeRequests;
    },
    _getReadinessDepth: getReadinessDepth,
    _isMaskVisible: function () {
      return isMaskVisible;
    },
    _forceResetBusy: forceResetBusy,
    _queryMainWorldSnapshot: queryMainWorldSnapshot
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
