/**
 * DBSEXT テーブル表示モジュール
 *
 * 目的: 一覧の見出し行を固定し、縦に長い表でも列名を見失わないようにする。
 *
 * ---------------------------------------------------------------------------
 * 実機実測でわかった Element Plus の構造（investigation/out/diag-tablewrap.json）
 * ---------------------------------------------------------------------------
 *
 *   div.el-table                     overflow:hidden      scrollW = clientW
 *     div.el-table__header-wrapper   overflow:hidden      scrollW = 3144
 *       table.el-table__header
 *     div.el-table__body-wrapper     overflow:hidden
 *       div.el-scrollbar
 *         div.el-scrollbar__wrap     overflow:auto        scrollW = 3144
 *           table.el-table__body
 *
 * 横スクロールを担っているのは .el-scrollbar__wrap であり、EP が JS で
 * ヘッダ側とスクロール位置を同期している。**ここに手を入れてはいけない。**
 *
 * 以前の実装は .el-table 自体を overflow:auto にし、内側のラッパーの overflow を
 * visible で潰していた。その結果、ヘッダは sticky で追随するのにボディは
 * body-wrapper の幅で止まり、**右へスクロールすると右側が白いまま**になった
 * （2026-08-07 に現場から報告された症状）。
 *
 * したがって現在の実装は、縦方向の高さを制限するだけに絞ってある。
 * EP 純正の .el-scrollbar__wrap が縦にスクロールし、その上にある
 * .el-table__header-wrapper は動かないので、sticky を使わずに見出しが固定される。
 * 横スクロールは EP のまま何も変えない。
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var SCROLL_CLASS = 'dbsext-scroll';
  var STYLE_ID = 'dbsext-table-wrap-style';
  var MAX_HEIGHT = '62vh';
  var TOP_BAR_ATTR = 'data-dbsext-top-scrollbar';
  var vehicleLayoutHooksInstalled = false;

  function injectStyles() {
    if (typeof document === 'undefined' || !document.head) return;
    if (document.getElementById(STYLE_ID)) return;

    var css = [
      /* 縦の高さだけを制限する。横スクロールと overflow には一切触れない。 */
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap {',
      '  max-height: ' + MAX_HEIGHT + ' !important;',
      '}',

      /* 車両情報: ポータル外枠の高さ上限と内側のスクロール領域を揃える。 */
      '.el-table.' + SCROLL_CLASS + '[data-dbsext-vehicle-layout] {',
      '  height: var(--dbsext-vehicle-table-height) !important;',
      '  max-height: var(--dbsext-vehicle-table-height) !important;',
      '}',
      '.el-table.' + SCROLL_CLASS + '[data-dbsext-vehicle-layout] .el-scrollbar__wrap {',
      '  height: var(--dbsext-vehicle-body-height) !important;',
      '  max-height: var(--dbsext-vehicle-body-height) !important;',
      '}',

      /* 高さ制限が効かない構造（scrollbar が無い版）への保険。こちらも縦だけ。 */
      '.el-table.' + SCROLL_CLASS + ' > .el-table__body-wrapper:not(:has(.el-scrollbar)) {',
      '  max-height: ' + MAX_HEIGHT + ' !important;',
      '  overflow-y: auto;',
      '}',

      /* 見出しを少し目立たせる（固定されていることが分かるように） */
      '.el-table.' + SCROLL_CLASS + ' .el-table__header-wrapper {',
      '  background: #fafafa;',
      '}',

      /* --- 横スクロールバーを常時見えるようにする -----------------------------
         **なぜ今まで実機で出なかったか（2026-08-09 に原因特定）**

         Element Plus は `.el-scrollbar__wrap` に **標準プロパティ
         `scrollbar-width: none`** を指定してネイティブのバーを消している。
         Chrome は**標準プロパティが指定されていると `::-webkit-scrollbar` の
         指定を丸ごと無視する**（本機は Chromium 148。`CSS.supports` で確認済み）。

         そのため `::-webkit-scrollbar { height: 10px }` だけを書いても効かない。
         モックには `scrollbar-width: none` が無かったので、
         **モックでは出るのに実機では出ない**という食い違いになっていた。

         対処: **標準プロパティで上書きする。** webkit 側は古い環境への保険として残す。

         なぜ常時表示が要るか: 画面幅は利用者ごとに違う。
         ポータルの body には `min-width: 1900px` が入っており、
         1900px 未満の画面では**ページ全体が横スクロールする**（実測）。
         狭い画面の利用者にとって、横スクロールは日常的な操作である。
         「自分の画面で収まったから不要」と判断してはいけない。
      ------------------------------------------------------------------------ */
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap {',
      '  scrollbar-width: auto !important;',      /* none を打ち消す。これが本命 */
      '  scrollbar-color: #8a9099 #e8e8e8 !important;',  /* つまみ / 溝 */
      '}',
      /* 以下は標準プロパティ非対応の環境向けの保険 */
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar {',
      '  display: block !important;',
      '  width: 12px;',
      '  height: 12px;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar-track {',
      '  background: #e8e8e8;',
      '  border-radius: 5px;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar-thumb {',
      '  background: #a0a0a0;',
      '  border-radius: 5px;',
      '  border: 2px solid #e8e8e8;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar-thumb:hover {',
      '  background: #707070;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__wrap::-webkit-scrollbar-corner {',
      '  background: #e8e8e8;',
      '}',

      /* --- 自前表のスクロール領域にも同じバーを出す --------------------------
         従来ここは `.el-table` 起点だけで書かれていたため、
         **ビーコン一覧・問題申告一覧（拡張）には横スクロールバーが付いていなかった**。
         自前表は `[data-dbsext-table-scroll]` を持つ（skin.js が overflow を与える）。
         同じ配色・同じ太さにして、どの表でも操作感を揃える。
      ---------------------------------------------------------------------- */
      '[data-dbsext-table-scroll] {',
      '  scrollbar-width: auto !important;',
      '  scrollbar-color: #8a9099 #e8e8e8 !important;',
      '}',
      '[data-dbsext-table-scroll]::-webkit-scrollbar {',
      '  display: block !important;',
      '  width: 12px;',
      '  height: 12px;',
      '}',
      '[data-dbsext-table-scroll]::-webkit-scrollbar-track {',
      '  background: #e8e8e8;',
      '  border-radius: 5px;',
      '}',
      '[data-dbsext-table-scroll]::-webkit-scrollbar-thumb {',
      '  background: #a0a0a0;',
      '  border-radius: 5px;',
      '  border: 2px solid #e8e8e8;',
      '}',
      '[data-dbsext-table-scroll]::-webkit-scrollbar-thumb:hover {',
      '  background: #707070;',
      '}',

      /* 見出しの上に置く操作用の帯。常に見える横スクロールバー */
      '.el-table.' + SCROLL_CLASS + ' .dbsext-top-scrollbar {',
      '  overflow-x: auto;',
      '  overflow-y: hidden;',
      '  scrollbar-width: auto;',
      '  scrollbar-color: #8a9099 #e8e8e8;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .dbsext-top-scrollbar > div {',
      '  height: 1px;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .dbsext-top-scrollbar::-webkit-scrollbar {',
      '  display: block !important;',
      '  height: 12px;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .dbsext-top-scrollbar::-webkit-scrollbar-track {',
      '  background: #e8e8e8;',
      '  border-radius: 6px;',
      '}',
      '.el-table.' + SCROLL_CLASS + ' .dbsext-top-scrollbar::-webkit-scrollbar-thumb {',
      '  background: #8a9099;',
      '  border-radius: 6px;',
      '}',

      /* EP 自前のスクロールバー（細い・hover時のみ）を隠す */
      '.el-table.' + SCROLL_CLASS + ' .el-scrollbar__bar {',
      '  display: none !important;',
      '}'
    ].join('\n');

    var style = document.createElement('style');
    style.id = STYLE_ID;
    style.setAttribute('data-dbsext-skin', '1');
    style.textContent = css;
    document.head.appendChild(style);
  }

  
  // ローディングオーバーレイによるクラス消失を防止

  /**
   * 見出しの**上**に横スクロールバーを置く。
   *
   * 現場からの指摘:
   *   「横スクロールバーが、表の一番下まで到達しないと見えない。常に見えるようにしてほしい。
   *     見出し列の上につけれればいいかも」
   *
   * そのとおりで、EP のスクロールバーは**スクロール領域の下端**にある。
   * 表は縦にも長く高さを 62vh に制限しているため、
   * **縦に一番下まで送らないと横バーが視界に入らない**。
   * 横に隠れた列があること自体に気づけない。
   *
   * 対処: 見出しの上に「操作用の細い帯」を置き、本体と**双方向に同期**させる。
   * 帯の中身は幅を合わせただけの空要素で、これを横に送ると本体も動く。
   *
   * **本体側の overflow には触らない**（触ると右側が描画されなくなる。table-wrap 冒頭の説明）。
   */
  function ensureTopScrollbar(table) {
    if (typeof document === 'undefined') return;
    // 車両情報の現行 Element Plus は内部DOMを再利用する。ここへ帯を挿入すると
    // 再描画時に見出し表が帯へ移され、行領域が0pxになることを実機で確認した。
    if (typeof location !== 'undefined' && /^\/vehicles\/?$/.test(location.pathname || '')) return;

    var wrap = table.querySelector('.el-scrollbar__wrap');
    var headerWrapper = table.querySelector('.el-table__header-wrapper');
    if (!wrap || !headerWrapper || !headerWrapper.parentNode) return;

    var bar = table.querySelector('[' + TOP_BAR_ATTR + ']');
    if (!bar) {
      bar = document.createElement('div');
      bar.setAttribute(TOP_BAR_ATTR, '1');
      bar.className = 'dbsext-top-scrollbar';
      var inner = document.createElement('div');
      inner.setAttribute('data-dbsext-top-scrollbar-inner', '1');
      bar.appendChild(inner);
      headerWrapper.parentNode.insertBefore(bar, headerWrapper);
    }

    var inner2 = bar.firstChild;
    if (!inner2) return;

    // 中身の幅を本体に合わせる（本体が広いときだけ帯が意味を持つ）
    var needed = wrap.scrollWidth;
    if (inner2.style.width !== needed + 'px') inner2.style.width = needed + 'px';
    bar.style.display = (needed > wrap.clientWidth) ? 'block' : 'none';

    // 表示列の切替やSPA再描画で wrap 自体が差し替わることがある。
    // 最初に見つけた wrap をクロージャへ固定すると、以後は古い領域しか動かせない。
    // bar 側から「現在の wrap」を参照し、差し替え後も同じ帯を使い続けられるようにする。
    bar.__dbsextWrap = wrap;
    bar.__dbsextHeaderWrapper = headerWrapper;

    if (!bar.__dbsextScrollHooked) {
      bar.__dbsextScrollHooked = true;
      bar.setAttribute('data-dbsext-synced', '1');
      bar.addEventListener('scroll', function () {
        var currentWrap = bar.__dbsextWrap;
        if (!currentWrap || bar.__dbsextSyncing) return;
        bar.__dbsextSyncing = true;
        currentWrap.scrollLeft = bar.scrollLeft;
        var currentHeader = bar.__dbsextHeaderWrapper;
        if (currentHeader) currentHeader.scrollLeft = bar.scrollLeft;
        bar.__dbsextSyncing = false;
      });
    }

    if (wrap.__dbsextTopBar !== bar) {
      wrap.__dbsextTopBar = bar;
      wrap.addEventListener('scroll', function () {
        if (bar.__dbsextSyncing) return;
        bar.__dbsextSyncing = true;
        bar.scrollLeft = wrap.scrollLeft;
        var currentHeader = bar.__dbsextHeaderWrapper;
        if (currentHeader) currentHeader.scrollLeft = wrap.scrollLeft;
        bar.__dbsextSyncing = false;
      });
    }

    headerWrapper.scrollLeft = wrap.scrollLeft;
  }

  /**
   * 列幅変更後に上部バーを再計測する。
   * CSSの追加・削除は同期的でも、Element Plus が同じターンの後で幅を書き戻すため、
   * 直後と次のタスクの2回測る。
   */
  function refreshTopScrollbar(table) {
    if (!table) return;
    ensureTopScrollbar(table);
    if (typeof setTimeout === 'function') {
      setTimeout(function () { ensureTopScrollbar(table); }, 0);
    }
  }

  function fitVehicleTable(table) {
    if (typeof location === 'undefined' || location.pathname !== '/vehicles'
        || typeof window === 'undefined' || !table.getBoundingClientRect) return;
    var wrap = table.querySelector('.el-scrollbar__wrap');
    var header = table.querySelector('.el-table__header-wrapper');
    if (!wrap || !header || !table.style || !table.setAttribute) return;

    // ポータルの元の上限はインライン指定なので、拡張CSSで上書きしても参照できる。
    var portalCap = parseFloat(table.style.maxHeight) || 0;
    var viewportTop = table.getBoundingClientRect().top;
    // スクロール後の getBoundingClientRect().top は画面上の位置になる。
    // そのまま使うと再適用時に表高が変わり、外側のスクロール位置が跳ねる。
    var top = viewportTop;
    for (var ancestor = table.parentElement; ancestor; ancestor = ancestor.parentElement) {
      top += ancestor.scrollTop || 0;
    }
    // 開いている操作欄の高さを引き、3欄を畳んだときの表の位置を基準にする。
    // 開閉のたびに表高まで縮めると、ページ下に大きな空白が生じる。
    var expandedAbove = 0;
    var sections = document.querySelectorAll('.el-collapse-item');
    for (var i = 0; i < sections.length; i++) {
      var section = sections[i];
      var sectionHeader = section.querySelector('.el-collapse-item__header');
      if (!sectionHeader || section.getBoundingClientRect().top >= viewportTop) continue;
      var label = sectionHeader.textContent || '';
      if (label.indexOf('表示条件') === -1 && label.indexOf('一括車両状態変更') === -1 &&
          label.indexOf('一括車両操作') === -1) continue;
      expandedAbove += Math.max(0, section.getBoundingClientRect().height -
        sectionHeader.getBoundingClientRect().height);
    }
    var collapsedTop = Math.max(0, top - expandedAbove);
    var pager = document.querySelector('.el-pagination');
    var pagerHeight = pager ? pager.getBoundingClientRect().height : 40;
    var available = Math.max(0, window.innerHeight - collapsedTop - pagerHeight - 36);
    var requestedHeight = Math.max(portalCap, available);
    var topBar = table.querySelector('[' + TOP_BAR_ATTR + ']');
    var barHeight = topBar && topBar.style.display !== 'none'
      ? topBar.getBoundingClientRect().height : 0;
    var fixedHeight = header.getBoundingClientRect().height + barHeight;
    var bodyHeight = Math.min(window.innerHeight * 0.62,
      Math.max(0, requestedHeight - fixedHeight));
    // 行領域の上限を超えた分だけ外枠も縮め、内部の空白を残さない。
    var tableHeight = Math.min(requestedHeight, fixedHeight + bodyHeight);

    if (table.style.getPropertyValue('--dbsext-vehicle-table-height') !== tableHeight + 'px')
      table.style.setProperty('--dbsext-vehicle-table-height', tableHeight + 'px');
    if (table.style.getPropertyValue('--dbsext-vehicle-body-height') !== bodyHeight + 'px')
      table.style.setProperty('--dbsext-vehicle-body-height', bodyHeight + 'px');
    if (!table.hasAttribute('data-dbsext-vehicle-layout'))
      table.setAttribute('data-dbsext-vehicle-layout', '1');
  }

  function fitVehicleTables() {
    var tables = document.querySelectorAll('.el-table');
    for (var i = 0; i < tables.length; i++) fitVehicleTable(tables[i]);
  }

  function installVehicleLayoutHooks() {
    if (vehicleLayoutHooksInstalled || typeof window === 'undefined'
        || !window.addEventListener || !document.addEventListener) return;
    vehicleLayoutHooksInstalled = true;
    window.addEventListener('resize', fitVehicleTables);
    document.addEventListener('click', function (event) {
      if (event.target && event.target.closest
          && event.target.closest('.el-collapse-item__header')) {
        setTimeout(fitVehicleTables, 500); // Element Plus の開閉アニメーション後に測る
      }
    });
  }

  function observeTableClass(table) {
    // USER_SCRIPT worldではMutationObserverのNode型不一致が起き得る。
    // MAIN worldから通知されるcore再適用でクラスを復元するため直接監視しない。
    if (D.platform && D.platform.isUserScript) return;
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
          if (!table.classList.contains(SCROLL_CLASS)) {
            table.classList.add(SCROLL_CLASS);
          }
        }
      });
    });

    // core.js と同じ理由の防御（別タブで開いたときに実機で確認された例外）。
    // ここが失敗しても致命的ではない。すでに SCROLL_CLASS は付与済みなので
    // 見た目はそのまま出る。**クラス監視だけを諦める。**
    try {
      observer.observe(table, { attributes: true, attributeFilter: ['class'] });
    } catch (e) {
      if (D.core && typeof D.core.log === 'function') {
        D.core.log('table-wrap: クラス監視の開始に失敗: ' + (e && e.message ? e.message : e), true);
      }
    }
  }

  D.tableWrap = {
    SCROLL_CLASS: SCROLL_CLASS,

    refresh: refreshTopScrollbar,

    apply: function () {
      if (typeof document === 'undefined') return;

      injectStyles();
      installVehicleLayoutHooks();

      var tables = document.querySelectorAll('.el-table');
      if (!tables || tables.length === 0) return;

      for (var t = 0; t < tables.length; t++) {
        var table = tables[t];

        // 幅は列の出し入れやリサイズで変わるので、**毎回**合わせ直す
        refreshTopScrollbar(table);

        var headerTable = table.querySelector('table.el-table__header');
        var bodyTable = table.querySelector('table.el-table__body');

        // **全家族に共通の目印。見た目のCSSはすべてこれを見る（skin.js）。**
        // ポータルの表は見出しとボディが別々の <table> なので、両方に付ける。
        //
        // **毎回付け直す。** SPAは外側の `.el-table` を残したまま内側の <table> だけを
        // 差し替えることがある。「初回だけ」にすると、差し替え後の表から目印が消え、
        // **その表だけ見た目が素に戻る**（この種の取りこぼしは過去に何度も出している）。
        //
        // **見出し表・ボディ表だけでなく、配下の <table> をすべて対象にする。**
        // 集約前のCSSは `.el-table th` という総当たりも持っていた。
        // 固定列版（`.el-table__fixed-*`）やフッタ表が現れたとき、
        // 2枚だけを見ていると**その表だけ配色が素に戻る**。
        var innerTables = table.querySelectorAll('table');
        for (var n = 0; n < innerTables.length; n++) {
          innerTables[n].setAttribute('data-dbsext-table', 'portal');
        }

        if (!table.classList.contains(SCROLL_CLASS) && headerTable && bodyTable) {
          table.classList.add(SCROLL_CLASS);
          observeTableClass(table);
          table.setAttribute('data-dbsext-wrap', '1');
        }
        // 見出しの見た目が確定してから高さを測る。
        fitVehicleTable(table);
      }
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
