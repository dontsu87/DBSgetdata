/**
 * DBSEXT QRコード生成モジュール
 * 外部通信なしで自前で QR コード (Model 2, Error Correction M, Byte Mode) を生成し、
 * canvas 経由で data:image/png;base64 データURLを返す。
 *
 * QRCode for JavaScript
 * Copyright (c) 2009 Kazuhiko Arase
 * Licensed under the MIT license: http://www.opensource.org/licenses/mit-license.php
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var QRMode = {
    MODE_8BIT_BYTE: 1 << 2
  };

  var QRErrorCorrectLevel = {
    M: 0
  };

  var QRMaskPattern = {
    PATTERN000: 0,
    PATTERN001: 1,
    PATTERN010: 2,
    PATTERN011: 3,
    PATTERN100: 4,
    PATTERN101: 5,
    PATTERN110: 6,
    PATTERN111: 7
  };

  // --- GF(2^8) 定数と計算 ---
  var EXP_TABLE = new Array(256);
  var LOG_TABLE = new Array(256);
  for (var i = 0; i < 8; i++) EXP_TABLE[i] = 1 << i;
  for (var i = 8; i < 256; i++) EXP_TABLE[i] = EXP_TABLE[i - 4] ^ EXP_TABLE[i - 5] ^ EXP_TABLE[i - 6] ^ EXP_TABLE[i - 8];
  for (var i = 0; i < 255; i++) LOG_TABLE[EXP_TABLE[i]] = i;

  var QRMath = {
    glog: function (n) {
      if (n < 1) throw new Error('glog(' + n + ')');
      return LOG_TABLE[n];
    },
    gexp: function (n) {
      while (n < 0) n += 255;
      while (n >= 255) n -= 255;
      return EXP_TABLE[n];
    }
  };

  // --- 多項式演算 ---
  function QRPolynomial(num, shift) {
    var offset = 0;
    while (offset < num.length && num[offset] === 0) offset++;
    this.num = new Array(num.length - offset + shift);
    for (var i = 0; i < num.length - offset; i++) {
      this.num[i] = num[i + offset];
    }
    for (var j = num.length - offset; j < this.num.length; j++) {
      this.num[j] = 0;
    }
  }

  QRPolynomial.prototype = {
    get: function (index) { return this.num[index]; },
    getLength: function () { return this.num.length; },
    multiply: function (e) {
      var num = new Array(this.getLength() + e.getLength() - 1);
      for (var k = 0; k < num.length; k++) num[k] = 0;
      for (var i = 0; i < this.getLength(); i++) {
        for (var j = 0; j < e.getLength(); j++) {
          if (this.get(i) === 0 || e.get(j) === 0) continue;
          num[i + j] ^= QRMath.gexp(QRMath.glog(this.get(i)) + QRMath.glog(e.get(j)));
        }
      }
      return new QRPolynomial(num, 0);
    },
    mod: function (e) {
      if (this.getLength() - e.getLength() < 0) return this;
      var ratio = QRMath.glog(this.get(0)) - QRMath.glog(e.get(0));
      var num = new Array(this.getLength());
      for (var i = 0; i < this.getLength(); i++) num[i] = this.get(i);
      for (var j = 0; j < e.getLength(); j++) {
        if (e.get(j) === 0) continue;
        num[j] ^= QRMath.gexp(QRMath.glog(e.get(j)) + ratio);
      }
      return new QRPolynomial(num, 0).mod(e);
    }
  };

  // --- RSブロック定義（Error Correction M 用 V1~V10） ---
  // 各要素: [RSブロック数, トータルデータコード数, データコード数]
  var RS_BLOCK_TABLE_M = [
    [],
    [1, 26, 16],             // V1
    [1, 44, 28],             // V2
    [1, 70, 44],             // V3
    [2, 50, 32],             // V4
    [2, 67, 43],             // V5
    [4, 43, 27],             // V6
    [4, 49, 31],             // V7
    [2, 60, 38, 2, 61, 39], // V8 (標準規格準拠: 60, 38 / 61, 39)
    [3, 58, 36, 2, 59, 37], // V9
    [4, 69, 43, 1, 70, 44]  // V10
  ];

  function getRSBlocks(typeNumber) {
    var rsArray = RS_BLOCK_TABLE_M[typeNumber];
    if (!rsArray) return [];
    var list = [];
    for (var i = 0; i < rsArray.length; i += 3) {
      var count = rsArray[i];
      var totalCount = rsArray[i + 1];
      var dataCount = rsArray[i + 2];
      for (var j = 0; j < count; j++) {
        list.push({ totalCount: totalCount, dataCount: dataCount });
      }
    }
    return list;
  }

  function getTypeNumberForBytes(dataBytes) {
    for (var v = 1; v <= 10; v++) {
      var rsBlocks = getRSBlocks(v);
      var capacity = 0;
      for (var b = 0; b < rsBlocks.length; b++) {
        capacity += rsBlocks[b].dataCount;
      }
      var headerBits = 4 + (v < 10 ? 8 : 16);
      if (dataBytes.length * 8 + headerBits <= capacity * 8) {
        return v;
      }
    }
    return 0;
  }

  // --- QRユーティリティ ---
  var QRUtil = {
    PATTERN_POSITION_TABLE: [
      [],
      [6, 18],
      [6, 22],
      [6, 26],
      [6, 30],
      [6, 34],
      [6, 22, 38],
      [6, 24, 42],
      [6, 26, 46],
      [6, 28, 50]
    ],
    G15: (1 << 10) | (1 << 8) | (1 << 5) | (1 << 4) | (1 << 2) | (1 << 1) | (1 << 0),
    G18: (1 << 12) | (1 << 11) | (1 << 10) | (1 << 9) | (1 << 8) | (1 << 5) | (1 << 2) | (1 << 0),
    G15_MASK: (1 << 14) | (1 << 12) | (1 << 10) | (1 << 4) | (1 << 1),

    getBCHTypeInfo: function (data) {
      var d = data << 10;
      while (QRUtil.getBCHDigit(d) - QRUtil.getBCHDigit(QRUtil.G15) >= 0) {
        d ^= (QRUtil.G15 << (QRUtil.getBCHDigit(d) - QRUtil.getBCHDigit(QRUtil.G15)));
      }
      return ((data << 10) | d) ^ QRUtil.G15_MASK;
    },

    getBCHTypeNumber: function (data) {
      var d = data << 12;
      while (QRUtil.getBCHDigit(d) - QRUtil.getBCHDigit(QRUtil.G18) >= 0) {
        d ^= (QRUtil.G18 << (QRUtil.getBCHDigit(d) - QRUtil.getBCHDigit(QRUtil.G18)));
      }
      return (data << 12) | d;
    },

    getBCHDigit: function (data) {
      var digit = 0;
      while (data !== 0) {
        digit++;
        data >>>= 1;
      }
      return digit;
    },

    getPatternPosition: function (typeNumber) {
      return QRUtil.PATTERN_POSITION_TABLE[typeNumber - 1] || [];
    },

    getMask: function (maskPattern, i, j) {
      switch (maskPattern) {
        case QRMaskPattern.PATTERN000: return (i + j) % 2 === 0;
        case QRMaskPattern.PATTERN001: return i % 2 === 0;
        case QRMaskPattern.PATTERN010: return j % 3 === 0;
        case QRMaskPattern.PATTERN011: return (i + j) % 3 === 0;
        case QRMaskPattern.PATTERN100: return (Math.floor(i / 2) + Math.floor(j / 3)) % 2 === 0;
        case QRMaskPattern.PATTERN101: return (i * j) % 2 + (i * j) % 3 === 0;
        case QRMaskPattern.PATTERN110: return ((i * j) % 2 + (i * j) % 3) % 2 === 0;
        case QRMaskPattern.PATTERN111: return ((i * j) % 3 + (i + j) % 2) % 2 === 0;
        default: throw new Error('bad maskPattern:' + maskPattern);
      }
    },

    getErrorCorrectionPolynomial: function (errorCorrectLength) {
      var a = new QRPolynomial([1], 0);
      for (var i = 0; i < errorCorrectLength; i++) {
        a = a.multiply(new QRPolynomial([1, QRMath.gexp(i)], 0));
      }
      return a;
    },

    getLostPoint: function (qrCode) {
      var moduleCount = qrCode.getModuleCount();
      var lostPoint = 0;

      // LEVEL1: 5個以上の同色連続
      for (var row = 0; row < moduleCount; row++) {
        for (var col = 0; col < moduleCount; col++) {
          var sameCount = 0;
          var dark = qrCode.isDark(row, col);
          for (var r = -1; r <= 1; r++) {
            if (row + r < 0 || moduleCount <= row + r) continue;
            for (var c = -1; c <= 1; c++) {
              if (col + c < 0 || moduleCount <= col + c) continue;
              if (r === 0 && c === 0) continue;
              if (dark === qrCode.isDark(row + r, col + c)) sameCount++;
            }
          }
          if (sameCount > 5) lostPoint += (3 + sameCount - 5);
        }
      }

      // LEVEL2: 2x2同色ブロック
      for (var row2 = 0; row2 < moduleCount - 1; row2++) {
        for (var col2 = 0; col2 < moduleCount - 1; col2++) {
          var count = 0;
          if (qrCode.isDark(row2, col2)) count++;
          if (qrCode.isDark(row2 + 1, col2)) count++;
          if (qrCode.isDark(row2, col2 + 1)) count++;
          if (qrCode.isDark(row2 + 1, col2 + 1)) count++;
          if (count === 0 || count === 4) lostPoint += 3;
        }
      }

      // LEVEL3: 1:1:3:1:1 ファインダ類似パターン
      for (var row3 = 0; row3 < moduleCount; row3++) {
        for (var col3 = 0; col3 < moduleCount - 6; col3++) {
          if (qrCode.isDark(row3, col3) &&
              !qrCode.isDark(row3, col3 + 1) &&
              qrCode.isDark(row3, col3 + 2) &&
              qrCode.isDark(row3, col3 + 3) &&
              qrCode.isDark(row3, col3 + 4) &&
              !qrCode.isDark(row3, col3 + 5) &&
              qrCode.isDark(row3, col3 + 6)) {
            lostPoint += 40;
          }
        }
      }

      for (var col4 = 0; col4 < moduleCount; col4++) {
        for (var row4 = 0; row4 < moduleCount - 6; row4++) {
          if (qrCode.isDark(row4, col4) &&
              !qrCode.isDark(row4 + 1, col4) &&
              qrCode.isDark(row4 + 2, col4) &&
              qrCode.isDark(row4 + 3, col4) &&
              qrCode.isDark(row4 + 4, col4) &&
              !qrCode.isDark(row4 + 5, col4) &&
              qrCode.isDark(row4 + 6, col4)) {
            lostPoint += 40;
          }
        }
      }

      // LEVEL4: 暗モジュール比率ペナルティ
      var darkCount = 0;
      for (var col5 = 0; col5 < moduleCount; col5++) {
        for (var row5 = 0; row5 < moduleCount; row5++) {
          if (qrCode.isDark(row5, col5)) darkCount++;
        }
      }
      var ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;
      lostPoint += ratio * 10;

      return lostPoint;
    }
  };

  // --- ビットバッファ ---
  function QRBitBuffer() {
    this.buffer = [];
    this.length = 0;
  }
  QRBitBuffer.prototype = {
    put: function (num, length) {
      for (var i = 0; i < length; i++) {
        this.putBit(((num >>> (length - i - 1)) & 1) === 1);
      }
    },
    putBit: function (bit) {
      var bufIndex = Math.floor(this.length / 8);
      if (this.buffer.length <= bufIndex) this.buffer.push(0);
      if (bit) this.buffer[bufIndex] |= (0x80 >>> (this.length % 8));
      this.length++;
    }
  };

  // UTF-8 バイト列変換
  function stringToUtf8Bytes(str) {
    var bytes = [];
    for (var i = 0; i < str.length; i++) {
      var code = str.charCodeAt(i);
      if (code < 0x80) {
        bytes.push(code);
      } else if (code < 0x800) {
        bytes.push(0xc0 | (code >> 6));
        bytes.push(0x80 | (code & 0x3f));
      } else if (code < 0xd800 || code >= 0xe000) {
        bytes.push(0xe0 | (code >> 12));
        bytes.push(0x80 | ((code >> 6) & 0x3f));
        bytes.push(0x80 | (code & 0x3f));
      } else {
        i++;
        var code2 = str.charCodeAt(i);
        var surrogate = 0x10000 + (((code & 0x33f) << 10) | (code2 & 0x3ff));
        bytes.push(0xf0 | (surrogate >> 18));
        bytes.push(0x80 | ((surrogate >> 12) & 0x3f));
        bytes.push(0x80 | ((surrogate >> 6) & 0x3f));
        bytes.push(0x80 | (surrogate & 0x3f));
      }
    }
    return bytes;
  }

  // --- QRモデル構築クラス ---
  function QRCodeModel(typeNumber, errorCorrectLevel) {
    this.typeNumber = typeNumber;
    this.errorCorrectLevel = errorCorrectLevel;
    this.modules = null;
    this.moduleCount = 0;
    this.dataCache = null;
  }

  QRCodeModel.prototype = {
    getModuleCount: function () {
      return this.moduleCount;
    },
    isDark: function (row, col) {
      if (this.modules && this.modules[row] && this.modules[row][col] !== null) {
        return this.modules[row][col];
      }
      return false;
    },
    make: function (dataBytes) {
      this.makeImpl(false, this.getBestMaskPattern(dataBytes), dataBytes);
    },
    makeImpl: function (test, maskPattern, dataBytes) {
      this.moduleCount = this.typeNumber * 4 + 17;
      this.modules = new Array(this.moduleCount);
      for (var r = 0; r < this.moduleCount; r++) {
        this.modules[r] = new Array(this.moduleCount);
        for (var c = 0; c < this.moduleCount; c++) {
          this.modules[r][c] = null;
        }
      }

      this.setupPositionProbePattern(0, 0);
      this.setupPositionProbePattern(this.moduleCount - 7, 0);
      this.setupPositionProbePattern(0, this.moduleCount - 7);
      this.setupPositionAdjustPattern();
      this.setupTimingPattern();
      this.setupTypeInfo(test, maskPattern);

      if (this.typeNumber >= 7) {
        this.setupTypeNumber(test);
      }

      if (this.dataCache === null) {
        this.dataCache = createData(this.typeNumber, this.errorCorrectLevel, dataBytes);
      }

      this.mapData(this.dataCache, maskPattern);
    },

    setupPositionProbePattern: function (row, col) {
      for (var r = -1; r <= 7; r++) {
        if (row + r <= -1 || this.moduleCount <= row + r) continue;
        for (var c = -1; c <= 7; c++) {
          if (col + c <= -1 || this.moduleCount <= col + c) continue;
          if ((0 <= r && r <= 6 && (c === 0 || c === 6)) ||
              (0 <= c && c <= 6 && (r === 0 || r === 6)) ||
              (2 <= r && r <= 4 && 2 <= c && c <= 4)) {
            this.modules[row + r][col + c] = true;
          } else {
            this.modules[row + r][col + c] = false;
          }
        }
      }
    },

    setupPositionAdjustPattern: function () {
      var pos = QRUtil.getPatternPosition(this.typeNumber);
      for (var i = 0; i < pos.length; i++) {
        for (var j = 0; j < pos.length; j++) {
          var row = pos[i];
          var col = pos[j];
          if (this.modules[row][col] !== null) continue;
          for (var r = -2; r <= 2; r++) {
            for (var c = -2; c <= 2; c++) {
              if (r === -2 || r === 2 || c === -2 || c === 2 || (r === 0 && c === 0)) {
                this.modules[row + r][col + c] = true;
              } else {
                this.modules[row + r][col + c] = false;
              }
            }
          }
        }
      }
    },

    setupTimingPattern: function () {
      for (var r = 8; r < this.moduleCount - 8; r++) {
        if (this.modules[r][6] !== null) continue;
        this.modules[r][6] = (r % 2 === 0);
      }
      for (var c = 8; c < this.moduleCount - 8; c++) {
        if (this.modules[6][c] !== null) continue;
        this.modules[6][c] = (c % 2 === 0);
      }
    },

    setupTypeInfo: function (test, maskPattern) {
      var data = (this.errorCorrectLevel << 3) | maskPattern;
      var bits = QRUtil.getBCHTypeInfo(data);

      // 垂直方向
      for (var i = 0; i < 15; i++) {
        var mod = (!test && ((bits >> i) & 1) === 1);
        if (i < 6) {
          this.modules[i][8] = mod;
        } else if (i < 8) {
          this.modules[i + 1][8] = mod;
        } else {
          this.modules[this.moduleCount - 15 + i][8] = mod;
        }
      }

      // 水平方向
      for (var j = 0; j < 15; j++) {
        var mod2 = (!test && ((bits >> j) & 1) === 1);
        if (j < 8) {
          this.modules[8][this.moduleCount - j - 1] = mod2;
        } else if (j < 9) {
          this.modules[8][15 - j - 1 + 1] = mod2;
        } else {
          this.modules[8][15 - j - 1] = mod2;
        }
      }

      // 固定ダークモジュール (4 * typeNumber + 9 = moduleCount - 8)
      this.modules[this.moduleCount - 8][8] = (!test);
    },

    setupTypeNumber: function (test) {
      var bits = QRUtil.getBCHTypeNumber(this.typeNumber);
      for (var i = 0; i < 18; i++) {
        var mod = (!test && ((bits >> i) & 1) === 1);
        this.modules[Math.floor(i / 3)][i % 3 + this.moduleCount - 8 - 3] = mod;
      }
      for (var j = 0; j < 18; j++) {
        var mod2 = (!test && ((bits >> j) & 1) === 1);
        this.modules[j % 3 + this.moduleCount - 8 - 3][Math.floor(j / 3)] = mod2;
      }
    },

    mapData: function (data, maskPattern) {
      var inc = -1;
      var row = this.moduleCount - 1;
      var bitIndex = 7;
      var byteIndex = 0;

      for (var col = this.moduleCount - 1; col > 0; col -= 2) {
        if (col === 6) col--;
        while (true) {
          for (var c = 0; c < 2; c++) {
            if (this.modules[row][col - c] === null) {
              var dark = false;
              if (byteIndex < data.length) {
                dark = (((data[byteIndex] >>> bitIndex) & 1) === 1);
              }
              var mask = QRUtil.getMask(maskPattern, row, col - c);
              if (mask) dark = !dark;

              this.modules[row][col - c] = dark;
              bitIndex--;
              if (bitIndex === -1) {
                byteIndex++;
                bitIndex = 7;
              }
            }
          }
          row += inc;
          if (row < 0 || this.moduleCount <= row) {
            row -= inc;
            inc = -inc;
            break;
          }
        }
      }
    },

    getBestMaskPattern: function (dataBytes) {
      var minLostPoint = 0;
      var pattern = 0;
      for (var i = 0; i < 8; i++) {
        this.makeImpl(true, i, dataBytes);
        var lostPoint = QRUtil.getLostPoint(this);
        if (i === 0 || minLostPoint > lostPoint) {
          minLostPoint = lostPoint;
          pattern = i;
        }
      }
      return pattern;
    }
  };

  function createData(typeNumber, errorCorrectLevel, dataBytes) {
    var rsBlocks = getRSBlocks(typeNumber);
    var buffer = new QRBitBuffer();

    // 8bit Byte Mode 指示子: 0100
    buffer.put(QRMode.MODE_8BIT_BYTE, 4);
    // 文字数指示子
    var countLength = (typeNumber < 10) ? 8 : 16;
    buffer.put(dataBytes.length, countLength);

    for (var i = 0; i < dataBytes.length; i++) {
      buffer.put(dataBytes[i], 8);
    }

    var totalDataCount = 0;
    for (var j = 0; j < rsBlocks.length; j++) {
      totalDataCount += rsBlocks[j].dataCount;
    }

    if (buffer.length + 4 <= totalDataCount * 8) {
      buffer.put(0, 4);
    }
    while (buffer.length % 8 !== 0) {
      buffer.putBit(false);
    }

    while (true) {
      if (buffer.length >= totalDataCount * 8) break;
      buffer.put(0xec, 8);
      if (buffer.length >= totalDataCount * 8) break;
      buffer.put(0x11, 8);
    }

    // RS パケットの分割および誤り訂正コード生成
    return createBytes(buffer, rsBlocks);
  }

  function createBytes(buffer, rsBlocks) {
    var offset = 0;
    var maxDcCount = 0;
    var maxEcCount = 0;
    var dcdata = new Array(rsBlocks.length);
    var ecdata = new Array(rsBlocks.length);

    for (var r = 0; r < rsBlocks.length; r++) {
      var dcCount = rsBlocks[r].dataCount;
      var ecCount = rsBlocks[r].totalCount - dcCount;

      maxDcCount = Math.max(maxDcCount, dcCount);
      maxEcCount = Math.max(maxEcCount, ecCount);

      dcdata[r] = new Array(dcCount);
      for (var i = 0; i < dcdata[r].length; i++) {
        dcdata[r][i] = 0xff & buffer.buffer[i + offset];
      }
      offset += dcCount;

      var rsPoly = QRUtil.getErrorCorrectionPolynomial(ecCount);
      var rawPoly = new QRPolynomial(dcdata[r], rsPoly.getLength() - 1);
      var modPoly = rawPoly.mod(rsPoly);

      ecdata[r] = new Array(rsPoly.getLength() - 1);
      for (var j = 0; j < ecdata[r].length; j++) {
        var modIndex = j + modPoly.getLength() - ecdata[r].length;
        ecdata[r][j] = (modIndex >= 0) ? modPoly.get(modIndex) : 0;
      }
    }

    var totalCodeCount = 0;
    for (var k = 0; k < rsBlocks.length; k++) {
      totalCodeCount += rsBlocks[k].totalCount;
    }

    var data = new Array(totalCodeCount);
    var index = 0;

    for (var l = 0; l < maxDcCount; l++) {
      for (var m = 0; m < rsBlocks.length; m++) {
        if (l < dcdata[m].length) {
          data[index++] = dcdata[m][l];
        }
      }
    }

    for (var n = 0; n < maxEcCount; n++) {
      for (var p = 0; p < rsBlocks.length; p++) {
        if (n < ecdata[p].length) {
          data[index++] = ecdata[p][n];
        }
      }
    }

    return data;
  }

  // --- D.qr API 実装 ---
  D.qr = {
    /**
     * 指定テキストから生成される QR コードの一辺のモジュール数を返す
     * @param {string} text エンコード対象文字列
     * @returns {number} モジュール数（21, 25, 29...）、失敗時・不正入力時は 0
     */
    moduleCount: function (text) {
      try {
        if (typeof text !== 'string' || text.length === 0) {
          return 0;
        }
        var dataBytes = stringToUtf8Bytes(text);
        var typeNumber = getTypeNumberForBytes(dataBytes);
        if (typeNumber === 0) {
          return 0;
        }
        return typeNumber * 4 + 17;
      } catch (e) {
        return 0;
      }
    },

    /**
     * 指定テキストから QR コードの data:image/png;base64 URL を生成する
     * 規格準拠の4モジュール以上のクワイエットゾーン（余白）を確保し、中央に描画する。
     * @param {string} text エンコード対象文字列
     * @param {number} [sizePx] 生成画像サイズ（px、既定: 160）
     * @returns {string|null} 成功時は data URL、失敗・非対応環境時は null
     */
    toDataUrl: function (text, sizePx) {
      try {
        if (typeof text !== 'string' || text.length === 0) {
          return null;
        }

        var targetSize = (typeof sizePx === 'number' && sizePx > 0) ? sizePx : 160;

        if (typeof document === 'undefined' || typeof document.createElement !== 'function') {
          return null;
        }

        var dataBytes = stringToUtf8Bytes(text);

        // バイト数に応じたタイプナンバー選択（V1~V10）
        var typeNumber = getTypeNumberForBytes(dataBytes);
        if (typeNumber === 0) {
          if (D.core && typeof D.core.log === 'function') {
            D.core.log('QR生成に失敗: データ長が最大容量(V10)を超えています');
          }
          return null;
        }

        var qrModel = new QRCodeModel(typeNumber, QRErrorCorrectLevel.M);
        qrModel.make(dataBytes);

        var canvas = document.createElement('canvas');
        if (!canvas || typeof canvas.getContext !== 'function') {
          return null;
        }

        canvas.width = targetSize;
        canvas.height = targetSize;
        var ctx = canvas.getContext('2d');
        if (!ctx) {
          return null;
        }

        var moduleCount = qrModel.getModuleCount();
        // 規格準拠: 4モジュール以上のクワイエットゾーン（白余白）を確保
        var margin = 4;
        var numModulesWithMargin = moduleCount + margin * 2;
        var cellSize = Math.floor(targetSize / numModulesWithMargin);
        if (cellSize < 1) cellSize = 1;

        // 全体を白で塗りつぶす（クワイエットゾーン含む）
        if (typeof ctx.fillStyle !== 'undefined') {
          ctx.fillStyle = '#FFFFFF';
        }
        if (typeof ctx.fillRect === 'function') {
          ctx.fillRect(0, 0, targetSize, targetSize);
        }

        if (typeof ctx.fillStyle !== 'undefined') {
          ctx.fillStyle = '#000000';
        }

        // 余白を均等に配分して中央にモジュールを配置
        var offset = Math.floor((targetSize - moduleCount * cellSize) / 2);

        for (var r = 0; r < moduleCount; r++) {
          for (var c = 0; c < moduleCount; c++) {
            if (qrModel.isDark(r, c)) {
              if (typeof ctx.fillRect === 'function') {
                ctx.fillRect(offset + c * cellSize, offset + r * cellSize, cellSize, cellSize);
              }
            }
          }
        }

        if (typeof canvas.toDataURL === 'function') {
          var result = canvas.toDataURL('image/png');
          return (typeof result === 'string' && result.length > 0) ? result : null;
        }

        return null;
      } catch (e) {
        if (D.core && typeof D.core.log === 'function') {
          D.core.log('QR生成に失敗: ' + (e && e.message ? e.message : String(e)));
        }
        return null;
      }
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
