/**
 * DBSEXT テーブルツール（並べ替え・絞り込み）モジュール
 *
 * **ポータル表むけのアダプタである。** 判定ロジック（並び順・絞り込み・見出しUI）は
 * `table-kit` が持ち、ここは「ポータルのDOMをどう動かすか」だけを担う。
 *
 *   並べ替え … 既存の <tr> を appendChild で並べ直す
 *   絞り込み … display:none で隠す
 *
 * **行を作り直してはいけない。** 行の中にはポータル（Vue）のイベントハンドラを持つ
 * 操作ボタン（解錠・再配置・メンテナンス）が入っており、作り直すと壊れる。
 * 契約§6「ポータルの既存DOMを削除・移動しない」。
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var tableStates = {};
  // 「オリジナルに戻す」表示中に、apply() が対象にした表を覚えておく
  var lastProcessed = [];

  function kit() {
    return D.tableKit;
  }

  function hasActiveFilter(state) {
    return kit().hasAnyCondition(state.conditions);
  }

  function rowCheckbox(row) {
    return row && row.querySelector ? row.querySelector('input[type=checkbox]') : null;
  }

  function setRowChecked(row, checked) {
    var input = rowCheckbox(row);
    if (!input || !!input.checked === checked) return;
    // checked を直接書くだけでは Element Plus の選択モデルへ伝わらない。
    // ネイティブ click でポータル自身の変更処理を通す（選択状態だけ。更新通信は発生しない）。
    input.click();
  }

  /** フィルタで非表示になった行を選択対象から外す */
  function deselectHiddenRows(table) {
    var rows = table.querySelectorAll('table.el-table__body tbody tr');
    for (var i = 0; i < rows.length; i++) {
      if (rows[i].style.display === 'none') setRowChecked(rows[i], false);
    }
  }

  /**
   * 見出しの全選択を、フィルタで表示中の行だけへ限定する。
   * フィルタ無しではポータル標準の全選択をそのまま使う。
   */
  function hookVisibleSelectAll(table, state) {
    var headerTable = table.querySelector('table.el-table__header');
    if (!headerTable) return;
    var master = headerTable.querySelector('input[type=checkbox]');
    if (!master || master.__dbsextVisibleSelectHooked) return;
    master.__dbsextVisibleSelectHooked = true;

    master.addEventListener('click', function (event) {
      if (!hasActiveFilter(state)) return;

      // 標準処理に任せると非表示行まで選択されるため、フィルタ中だけ横取りする。
      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === 'function') event.stopImmediatePropagation();

      var rows = table.querySelectorAll('table.el-table__body tbody tr');
      var visible = [];
      var allVisibleChecked = true;
      for (var i = 0; i < rows.length; i++) {
        if (rows[i].style.display === 'none') continue;
        visible.push(rows[i]);
        var input = rowCheckbox(rows[i]);
        if (!input || !input.checked) allVisibleChecked = false;
      }

      var selectVisible = visible.length > 0 && !allVisibleChecked;
      for (var j = 0; j < rows.length; j++) {
        var shouldCheck = rows[j].style.display !== 'none' && selectVisible;
        setRowChecked(rows[j], shouldCheck);
      }

      // Element Plus は全行基準だと「一部選択」と判定するが、ここでは見えている全行が基準。
      // 実 input の表示だけを最後に合わせる（次のポータル再描画時は再度計算される）。
      if (typeof setTimeout === 'function') {
        setTimeout(function () {
          master.checked = selectVisible;
          master.indeterminate = false;
        }, 0);
      }
    }, true);
  }

  function applyFilterAndSort(table, state, ths) {
    var bodyTable = table.querySelector('table.el-table__body');
    if (!bodyTable) return;

    var tbody = bodyTable.querySelector('tbody');
    if (!tbody) return;

    var trs = bodyTable.querySelectorAll('tbody tr');
    if (trs.length === 0) return;

    var trArray = Array.prototype.slice.call(trs);

    // 1. 絞り込み処理（判定は table-kit。文字列 / 数値の範囲を同じ入口で扱う）
    var filtering = hasActiveFilter(state);

    for (var i = 0; i < trArray.length; i++) {
      var tr = trArray[i];
      var show = true;
      if (filtering) {
        var cells = tr.children;
        for (var colIdxStr in state.conditions) {
          var cond = state.conditions[colIdxStr];
          if (!cond) continue;
          var colIdx = Number(colIdxStr);
          var cell = cells[colIdx];
          var cellText = cell ? cell.textContent.trim() : '';
          if (!kit().matchesFilter(cellText, cond)) {
            show = false;
            break;
          }
        }
      }
      tr.style.display = show ? '' : 'none';
    }

    // フィルタ変更前に選ばれていた行が隠れた場合も、一括処理の対象へ残さない。
    if (filtering) deselectHiddenRows(table);

    // 2. 並べ替え処理
    if (state.sortColIndex !== null && state.sortColIndex !== undefined) {
      var sortCol = state.sortColIndex;
      var sortOrder = state.sortOrder || 'asc';
      var th = ths[sortCol];
      var colTitle = th ? (th.getAttribute('data-dbsext-orig-title') || th.textContent.trim()) : '';

      // 列全体が数値なら数値として並べる。判定も比較も table-kit に任せる
      var columnValues = [];
      for (var j = 0; j < trArray.length; j++) {
        var tdNode = trArray[j].children[sortCol];
        columnValues.push(tdNode ? tdNode.textContent.trim() : '');
      }
      var sortOpts = {
        columnLabel: colTitle,
        numeric: !kit().isPortColumn(colTitle) && kit().isNumericColumn(columnValues)
      };

      trArray.sort(function (trA, trB) {
        var tdA = trA.children[sortCol];
        var tdB = trB.children[sortCol];
        var res = kit().compare(
          tdA ? tdA.textContent.trim() : '',
          tdB ? tdB.textContent.trim() : '',
          sortOpts
        );
        return sortOrder === 'desc' ? -res : res;
      });

      for (var k = 0; k < trArray.length; k++) {
        tbody.appendChild(trArray[k]);
      }
    }
  }

  function updateHeaderUI(ths, state) {
    for (var c = 0; c < ths.length; c++) {
      var controls = ths[c].__dbsextControls;
      if (!controls) continue;
      controls.updateSortIndicator(state.sortColIndex === c, state.sortOrder);
      controls.syncFromState(state.conditions[c]);
    }
  }

  D.tableTools = {
    // 互換のため残す。実装は table-kit にある（自前表からも同じ順序を使うため）
    portSortKey: function (name) { return kit().portSortKey(name); },

    // 検証用。DOMを伴うフィルタ／選択連動を実ブラウザ無しでも再現する。
    _applyFilterAndSort: applyFilterAndSort,
    _hookVisibleSelectAll: hookVisibleSelectAll,

    apply: function () {
      if (typeof document === 'undefined') return;

      var tables = document.querySelectorAll('.el-table');
      if (!tables || tables.length === 0) return;

      var pathname = (typeof location !== 'undefined') ? location.pathname : '';
      lastProcessed = [];

      for (var t = 0; t < tables.length; t++) {
        var table = tables[t];
        var headerTable = table.querySelector('table.el-table__header');
        var bodyTable = table.querySelector('table.el-table__body');
        if (!headerTable || !bodyTable) continue;

        var ths = headerTable.querySelectorAll('thead th, th');
        // **行数は見ない。** 行が0件でも列UIはヘッダに付ける。
        // 「先に絞り込み条件を入れてから検索したい」場面で使えないと不便であり、
        // 実機では検索するまで表が空なので、行を待つと一度もUIが付かない。
        if (ths.length === 0) continue;

        var stateKey = pathname + '#' + t;
        if (!tableStates[stateKey]) {
          tableStates[stateKey] = kit().createState();

          // 初回既定の並べ替え: ポート名またはポートの列があれば昇順1回
          for (var i = 0; i < ths.length; i++) {
            var title = ths[i].getAttribute('data-dbsext-orig-title') || ths[i].textContent.trim();
            if (kit().isPortColumn(title)) {
              tableStates[stateKey].sortColIndex = i;
              tableStates[stateKey].sortOrder = 'asc';
              break;
            }
          }
        }

        var state = tableStates[stateKey];
        hookVisibleSelectAll(table, state);
        var isFirstUIBuild = !table.hasAttribute('data-dbsext-tabled');

        if (isFirstUIBuild) {
          table.setAttribute('data-dbsext-tabled', '1');

          for (var c = 0; c < ths.length; c++) {
            (function (colIndex) {
              var th = ths[colIndex];
              var origTitle = th.textContent.trim();
              th.setAttribute('data-dbsext-orig-title', origTitle);

              // 見出しの操作UIは table-kit が作る。**自前表とまったく同じもの**を使う。
              // 見た目もCSS（skin.js）側で共通化してあるので、
              // ここでインラインstyleを書き足さないこと。
              //
              // 列によっては、文字列の部分一致より「以上・以下」の方が役に立つ
              // （電圧・バッテリー残量など）。どの列を数値扱いにするかは
              // table-kit の NUMERIC_COLUMN_HINTS に集約してある。
              var controls = kit().buildHeaderControls({
                columnLabel: origTitle,
                sortMode: 'indicator',
                onSort: function () {
                  if (state.sortColIndex === colIndex) {
                    state.sortOrder = (state.sortOrder === 'asc') ? 'desc' : 'asc';
                  } else {
                    state.sortColIndex = colIndex;
                    state.sortOrder = 'asc';
                  }
                  updateHeaderUI(ths, state);
                  applyFilterAndSort(table, state, ths);
                },
                onFilter: function (condition) {
                  state.conditions[colIndex] = condition;
                  applyFilterAndSort(table, state, ths);
                }
              });

              // 既定の条件を状態側にも置いておく（種類だけ先に決まる）
              if (!state.conditions[colIndex]) {
                state.conditions[colIndex] = controls.condition;
              } else {
                controls.syncFromState(state.conditions[colIndex]);
              }

              th.__dbsextControls = controls;
              th.appendChild(controls.sortEl);
              th.appendChild(controls.filterWrap);
            })(c);
          }
        }

        updateHeaderUI(ths, state);
        applyFilterAndSort(table, state, ths);
        lastProcessed.push({ table: table, state: state, ths: ths });
      }
    },

    /**
     * 「オリジナルに戻す」表示専用。並べ替え・絞り込みの**設定は変えず**、
     * 絞り込みで隠れている行だけを一時的にすべて見せる。
     */
    peekShowAll: function () {
      for (var i = 0; i < lastProcessed.length; i++) {
        var rows = lastProcessed[i].table.querySelectorAll('table.el-table__body tbody tr');
        for (var r = 0; r < rows.length; r++) rows[r].style.display = '';
      }
    },

    /** 「オリジナルに戻す」を解除し、保存済みの並べ替え・絞り込みへ戻す */
    peekRestore: function () {
      for (var i = 0; i < lastProcessed.length; i++) {
        applyFilterAndSort(lastProcessed[i].table, lastProcessed[i].state, lastProcessed[i].ths);
      }
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
