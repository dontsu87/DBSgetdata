/**
 * DBSEXT アップセル / 案内パネルモジュール
 * 画面右下に Shadow DOM によるパネルを表示する
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  D.upsell = {
    /**
     * パネルを描画（冪等）
     */
    apply: function () {
      if (typeof document === 'undefined' || !document.body) {
        return;
      }

      if (document.querySelector('[data-dbsext-upsell="1"]')) {
        return;
      }

      var host = document.createElement('div');
      host.setAttribute('data-dbsext-upsell', '1');

      var shadow = host.attachShadow({ mode: 'open' });

      var accent = (D.CONFIG && D.CONFIG.ACCENT) ? D.CONFIG.ACCENT : '#0b5cab';
      var accentDark = (D.CONFIG && D.CONFIG.ACCENT_DARK) ? D.CONFIG.ACCENT_DARK : '#083f75';
      var guideUrl = (D.CONFIG && D.CONFIG.GUIDE_URL) ? D.CONFIG.GUIDE_URL : 'https://dontsu87.github.io/DBSgetdata/ext/';
      var version = D.VERSION || '0.1.0';

      var platform = D.platform || {};
      var isEphemeral = (typeof platform.isEphemeral === 'function') ? platform.isEphemeral() : true;
      var kindText = (platform.kind === 'extension') ? '（拡張版）' : '（ブックマークレット版）';

      var style = document.createElement('style');
      style.textContent = [
        ':host {',
        '  position: fixed;',
        '  right: 140px;',
        '  bottom: 12px;',
        '  z-index: 2147483000;',
        '  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;',
        '}',
        '.panel {',
        '  position: relative;',
        '}',
        '.header {',
        '  padding: 8px 14px;',
        '  font-weight: bold;',
        '  cursor: pointer;',
        '  display: inline-flex;',
        '  align-items: center;',
        '  gap: 6px;',
        '  user-select: none;',
        '  background-color: ' + accentDark + ';',
        '  color: #ffffff;',
        '  border-radius: 20px;',
        '  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.25);',
        '  font-size: 12px;',
        '  line-height: 1.2;',
        '  white-space: nowrap;',
        '  transition: background-color 0.2s;',
        '}',
        '.header:hover {',
        '  background-color: ' + accent + ';',
        '}',
        '.header-title {',
        '  font-size: 12px;',
        '}',
        '.header-toggle {',
        '  font-size: 10px;',
        '  opacity: 0.8;',
        '}',
        '.body {',
        '  position: absolute;',
        '  bottom: calc(100% + 8px);',
        '  right: 0;',
        '  width: 260px;',
        '  background-color: ' + accent + ';',
        '  color: #ffffff;',
        '  border-radius: 8px;',
        '  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);',
        '  padding: 10px 12px;',
        '  display: flex;',
        '  flex-direction: column;',
        '  gap: 8px;',
        '  font-size: 12px;',
        '  line-height: 1.4;',
        '}',
        '.body.collapsed {',
        '  display: none;',
        '}',
        '.notice {',
        '  font-size: 11px;',
        '  opacity: 0.95;',
        '}',
        '.btn {',
        '  display: block;',
        '  background: #ffffff;',
        '  color: ' + accentDark + ';',
        '  border: none;',
        '  border-radius: 4px;',
        '  padding: 6px 10px;',
        '  font-size: 11px;',
        '  font-weight: bold;',
        '  cursor: pointer;',
        '  text-align: center;',
        '  text-decoration: none;',
        '}',
        '.btn:hover {',
        '  background: #f0f0f0;',
        '}',
        '.link {',
        '  color: #ffffff;',
        '  text-decoration: underline;',
        '  cursor: pointer;',
        '  font-size: 11px;',
        '  text-align: right;',
        '  display: inline-block;',
        '}',
        '.link:hover {',
        '  opacity: 0.8;',
        '}',
        '.store-section {',
        '  border-top: 1px solid rgba(255, 255, 255, 0.2);',
        '  padding-top: 8px;',
        '  display: flex;',
        '  flex-direction: column;',
        '  gap: 6px;',
        '}',
        '.store-title {',
        '  font-weight: bold;',
        '  font-size: 11px;',
        '}',
        '.store-list {',
        '  display: flex;',
        '  flex-direction: column;',
        '  gap: 4px;',
        '  max-height: 120px;',
        '  overflow-y: auto;',
        '}',
        '.store-item {',
        '  background: rgba(0, 0, 0, 0.15);',
        '  border-radius: 4px;',
        '  padding: 4px 6px;',
        '  font-size: 10px;',
        '}',
        '.store-item-label {',
        '  font-weight: bold;',
        '}',
        '.store-item-val {',
        '  word-break: break-all;',
        '  opacity: 0.9;',
        '}',
        '.store-item-date {',
        '  font-size: 9px;',
        '  opacity: 0.75;',
        '}',
        '.store-empty {',
        '  font-size: 10px;',
        '  opacity: 0.8;',
        '}',
        '.store-clear-btn {',
        '  background: #ffffff;',
        '  color: #c0392b;',
        '  border: none;',
        '  border-radius: 4px;',
        '  padding: 4px 8px;',
        '  font-size: 10px;',
        '  font-weight: bold;',
        '  cursor: pointer;',
        '  margin-top: 4px;',
        '}',
        '.store-clear-btn:hover {',
        '  background: #f0f0f0;',
        '}'
      ].join('\n');

      shadow.appendChild(style);

      var panel = document.createElement('div');
      panel.className = 'panel';

      // ヘッダ（折りたたみ操作）
      var header = document.createElement('div');
      header.className = 'header';

      var titleSpan = document.createElement('span');
      titleSpan.className = 'header-title';
      titleSpan.textContent = 'DBS 拡張ステータス';

      var toggleSpan = document.createElement('span');
      toggleSpan.className = 'header-toggle';
      // **既定は畳んだ状態。** 右下にピル型で配置し、クリックで上方向へ展開する。
      toggleSpan.textContent = '▲';

      header.appendChild(titleSpan);
      header.appendChild(toggleSpan);
      panel.appendChild(header);

      // パネル本文
      var body = document.createElement('div');
      body.className = 'body';

      // 行1: 拡張適用中 v<VERSION> (形式) または 配信版/保存版/同梱版 (B-2)
      var remoteStatus = (typeof platform.getRemoteStatus === 'function') ? platform.getRemoteStatus() : null;
      var remoteStatusLabel = '';
      if (platform.kind !== 'bookmarklet' && remoteStatus) {
        var sourceText = '不明';
        if (remoteStatus.source === 'remote') {
          sourceText = '配信版';
        } else if (remoteStatus.source === 'saved') {
          sourceText = '保存版';
        } else if (remoteStatus.source === 'fallback') {
          sourceText = '同梱版';
        }
        var verText = remoteStatus.version || version;
        remoteStatusLabel = sourceText + ' ' + verText;
      }

      var row1 = document.createElement('div');
      var channelLabel = (typeof DBSEXT_CHANNEL !== 'undefined' && DBSEXT_CHANNEL.label)
        ? ' [' + DBSEXT_CHANNEL.label + ']'
        : '';
      if (remoteStatusLabel) {
        row1.textContent = '拡張適用中' + channelLabel + ' ' + remoteStatusLabel;
      } else {
        row1.textContent = '拡張適用中' + channelLabel + ' ' + version + kindText;
      }
      body.appendChild(row1);

      if (isEphemeral) {
        // 行2: 再読込注意
        var row2 = document.createElement('div');
        row2.className = 'notice';
        row2.textContent = '画面を再読込したら、もう一度ブックマークを押してください';
        body.appendChild(row2);

        // 行3: Chrome拡張の導入案内ボタン
        var row3 = document.createElement('button');
        row3.className = 'btn';
        row3.type = 'button';
        row3.textContent = '機能充実版（Chrome拡張）の導入はこちら';
        row3.addEventListener('click', function (e) {
          e.stopPropagation();
          if (D.platform && typeof D.platform.openGuide === 'function') {
            D.platform.openGuide(guideUrl);
          }
        });
        body.appendChild(row3);

        // 行4: 更新を確認リンク
        var row4Wrapper = document.createElement('div');
        row4Wrapper.style.textAlign = 'right';
        var row4 = document.createElement('a');
        row4.className = 'link';
        row4.textContent = '更新を確認';
        row4.addEventListener('click', function (e) {
          e.preventDefault();
          e.stopPropagation();
          if (D.platform && typeof D.platform.openGuide === 'function') {
            D.platform.openGuide(guideUrl);
          }
        });
        row4Wrapper.appendChild(row4);
        body.appendChild(row4Wrapper);
      }

      // 保存した情報を見る／消す セクション
      var storeSection = document.createElement('div');
      storeSection.className = 'store-section';

      var storeTitle = document.createElement('div');
      storeTitle.className = 'store-title';
      storeTitle.textContent = '保存した情報（キャッシュ）';
      storeSection.appendChild(storeTitle);

      var storeList = document.createElement('div');
      storeList.className = 'store-list';

      function renderStoreList() {
        while (storeList.firstChild) {
          storeList.removeChild(storeList.firstChild); // dbsext:own-ui
        }

        var items = (D.stateStore && typeof D.stateStore.list === 'function') ? D.stateStore.list() : [];
        if (items.length === 0) {
          var empty = document.createElement('div');
          empty.className = 'store-empty';
          empty.textContent = '保存された情報はありません';
          storeList.appendChild(empty);
          return;
        }

        for (var i = 0; i < items.length; i++) {
          var item = items[i];
          var row = document.createElement('div');
          row.className = 'store-item';

          var label = item.feature;
          if (D.stateForms && D.stateForms.DECLARATIONS) {
            for (var d = 0; d < D.stateForms.DECLARATIONS.length; d++) {
              var dec = D.stateForms.DECLARATIONS[d];
              if (dec.feature === item.feature) {
                label = dec.label || item.feature;
                break;
              }
            }
          }

          var labelEl = document.createElement('div');
          labelEl.className = 'store-item-label';
          labelEl.textContent = label + ' [' + item.storage + ']';
          row.appendChild(labelEl);

          var valEl = document.createElement('div');
          valEl.className = 'store-item-val';
          var valText = Array.isArray(item.data) ? item.data.join(', ') : (typeof item.data === 'object' && item.data !== null ? JSON.stringify(item.data) : String(item.data));
          valEl.textContent = '値: ' + valText;
          row.appendChild(valEl);

          if (item.at) {
            var dateEl = document.createElement('div');
            dateEl.className = 'store-item-date';
            var dObj = new Date(item.at);
            dateEl.textContent = '日時: ' + dObj.toLocaleString();
            row.appendChild(dateEl);
          }

          storeList.appendChild(row);
        }

        var clearBtn = document.createElement('button');
        clearBtn.className = 'store-clear-btn';
        clearBtn.type = 'button';
        clearBtn.textContent = 'すべて消す';
        clearBtn.addEventListener('click', function (e) {
          e.stopPropagation();
          if (D.stateStore && typeof D.stateStore.clearAll === 'function') {
            D.stateStore.clearAll();
            renderStoreList();
          }
        });
        storeList.appendChild(clearBtn);
      }

      renderStoreList();
      storeSection.appendChild(storeList);
      body.appendChild(storeSection);

      panel.appendChild(body);

      // 開閉トグル処理（**既定は畳んだ状態**）
      var isFolded = true;
      body.classList.add('collapsed');
      header.addEventListener('click', function () {
        isFolded = !isFolded;
        if (isFolded) {
          body.classList.add('collapsed');
          toggleSpan.textContent = '▲';
        } else {
          body.classList.remove('collapsed');
          toggleSpan.textContent = '▼';
        }
      });

      shadow.appendChild(panel);
      document.body.appendChild(host);
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
