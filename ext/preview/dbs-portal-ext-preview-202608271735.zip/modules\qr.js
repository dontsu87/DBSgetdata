/**
 * DBSEXT QRコード生成モジュール
 * 外部通信なしで自前で QR コード (Model 2, Error Correction M, Byte Mode) を生成し、
 * canvas 経由で data:image/png;base64 データURLを返す。
 *
 * QRCode for JavaScript
 * Copyright (c) 2009 Kazuhiko Arase
 * Licensed under the MIT license: http://www.opensource.org/licenses/mit-license.php
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  // --- GF(2^8) 定数と計算 ---
  var EXP_TABLE = new Array(256);
  var LOG_TABLE = new Array(256);
  for (var i = 0; i < 8; i++) EXP_TABLE[i] = 1 << i;
  for (var i = 8; i < 256; i++) EXP_TABLE[i] = EXP_TABLE[i - 4] ^ EXP_TABLE[i - 5] ^ EXP_TABLE[i - 6] ^ EXP_TABLE[i - 8];
  for (var i = 0; i < 255; i++) LOG_TABLE[EXP_TABLE[i]] = i;

  var QRMath = {
    glog: function (n) {
      if (n < 1) throw new Error('glog(' + n + ')');
      return LOG_TABLE[n];
    },
    gexp: function (n) {
      while (n < 0) n += 255;
      while (n >= 255) n -= 255;
      return EXP_TABLE[n];
    }
  };

  // --- 多項式演算 ---
  function QRPolynomial(num, shift) {
    var offset = 0;
    while (offset < num.length && num[offset] === 0) offset++;
    this.num = new Array(num.length - offset + shift);
    for (var i = 0; i < num.length - offset; i++) {
      this.num[i] = num[i + offset];
    }
    for (var j = num.length - offset; j < this.num.length; j++) {
      this.num[j] = 0;
    }
  }

  QRPolynomial.prototype = {
    get: function (index) { return this.num[index]; },
    getLength: function () { return this.num.length; },
    multiply: function (e) {
      var num = new Array(this.getLength() + e.getLength() - 1);
      for (var k = 0; k < num.length; k++) num[k] = 0;
      for (var i = 0; i < this.getLength(); i++) {
        for (var j = 0; j < e.getLength(); j++) {
          if (this.get(i) === 0 || e.get(j) === 0) continue;
          num[i + j] ^= QRMath.gexp(QRMath.glog(this.get(i)) + QRMath.glog(e.get(j)));
        }
      }
      return new QRPolynomial(num, 0);
    },
    mod: function (e) {
      if (this.getLength() - e.getLength() < 0) return this;
      var ratio = QRMath.glog(this.get(0)) - QRMath.glog(e.get(0));
      var num = new Array(this.getLength());
      for (var i = 0; i < this.getLength(); i++) num[i] = this.get(i);
      for (var j = 0; j < e.getLength(); j++) {
        if (e.get(j) === 0) continue;
        num[j] ^= QRMath.gexp(QRMath.glog(e.get(j)) + ratio);
      }
      return new QRPolynomial(num, 0).mod(e);
    }
  };

  // --- RSブロック定義（Error Correction M 用 V1~V10） ---
  // 各要素: [RSブロック数, トータルデータコード数, データコード数]
  var RS_BLOCK_TABLE_M = [
    [],
    [1, 26, 16],   // V1
    [1, 44, 28],   // V2
    [1, 70, 44],   // V3
    [2, 50, 32],   // V4
    [2, 67, 43],   // V5
    [4, 43, 27],   // V6
    [4, 49, 31],   // V7
    [2, 61, 38, 2, 62, 39], // V8
    [3, 58, 36, 2, 59, 37], // V9
    [4, 69, 43, 1, 70, 44]  // V10
  ];

  function getRSBlocks(typeNumber) {
    var rsArray = RS_BLOCK_TABLE_M[typeNumber];
    var list = [];
    for (var i = 0; i < rsArray.length; i += 3) {
      var count = rsArray[i];
      var totalCount = rsArray[i + 1];
      var dataCount = rsArray[i + 2];
      for (var j = 0; j < count; j++) {
        list.push({ totalCount: totalCount, dataCount: dataCount });
      }
    }
    return list;
  }

  function getTypeNumberForBytes(dataBytes) {
    for (var v = 1; v <= 10; v++) {
      var rsBlocks = getRSBlocks(v);
      var capacity = 0;
      for (var b = 0; b < rsBlocks.length; b++) {
        capacity += rsBlocks[b].dataCount;
      }
      var headerBits = 4 + (v < 10 ? 8 : 16);
      if (dataBytes.length * 8 + headerBits <= capacity * 8) {
        return v;
      }
    }
    return 0;
  }

  // --- ビットバッファ ---
  function QRBitBuffer() {
    this.buffer = [];
    this.length = 0;
  }
  QRBitBuffer.prototype = {
    put: function (num, length) {
      for (var i = 0; i < length; i++) {
        this.putBit(((num >>> (length - i - 1)) & 1) === 1);
      }
    },
    putBit: function (bit) {
      var bufIndex = Math.floor(this.length / 8);
      if (this.buffer.length <= bufIndex) this.buffer.push(0);
      if (bit) this.buffer[bufIndex] |= (0x80 >>> (this.length % 8));
      this.length++;
    }
  };

  // UTF-8 バイト列変換
  function stringToUtf8Bytes(str) {
    var bytes = [];
    for (var i = 0; i < str.length; i++) {
      var code = str.charCodeAt(i);
      if (code < 0x80) {
        bytes.push(code);
      } else if (code < 0x800) {
        bytes.push(0xc0 | (code >> 6));
        bytes.push(0x80 | (code & 0x3f));
      } else if (code < 0xd800 || code >= 0xe000) {
        bytes.push(0xe0 | (code >> 12));
        bytes.push(0x80 | ((code >> 6) & 0x3f));
        bytes.push(0x80 | (code & 0x3f));
      } else {
        i++;
        var code2 = str.charCodeAt(i);
        var surrogate = 0x10000 + (((code & 0x33f) << 10) | (code2 & 0x3ff));
        bytes.push(0xf0 | (surrogate >> 18));
        bytes.push(0x80 | ((surrogate >> 12) & 0x3f));
        bytes.push(0x80 | ((surrogate >> 6) & 0x3f));
        bytes.push(0x80 | (surrogate & 0x3f));
      }
    }
    return bytes;
  }

  // --- QRモデル構築クラス ---
  function QRCodeModel(typeNumber) {
    this.typeNumber = typeNumber;
    this.moduleCount = typeNumber * 4 + 17;
    this.modules = null;
  }

  QRCodeModel.prototype = {
    isDark: function (row, col) {
      if (this.modules && this.modules[row] && this.modules[row][col] !== null) {
        return this.modules[row][col];
      }
      return false;
    },
    make: function (dataBytes) {
      this.makeImpl(dataBytes, 0); // マスクパターン 0 固定（実用上可読）
    },
    makeImpl: function (dataBytes, maskPattern) {
      this.modules = new Array(this.moduleCount);
      for (var r = 0; r < this.moduleCount; r++) {
        this.modules[r] = new Array(this.moduleCount);
        for (var c = 0; c < this.moduleCount; c++) {
          this.modules[r][c] = null;
        }
      }

      this.setupPositionProbePattern(0, 0);
      this.setupPositionProbePattern(this.moduleCount - 7, 0);
      this.setupPositionProbePattern(0, this.moduleCount - 7);
      this.setupTimingPattern();
      this.setupAlignmentPattern();

      var data = createData(this.typeNumber, dataBytes);
      this.mapData(data, maskPattern);
    },

    setupPositionProbePattern: function (row, col) {
      for (var r = -1; r <= 7; r++) {
        if (row + r <= -1 || this.moduleCount <= row + r) continue;
        for (var c = -1; c <= 7; c++) {
          if (col + c <= -1 || this.moduleCount <= col + c) continue;
          if ((0 <= r && r <= 6 && (c === 0 || c === 6)) ||
              (0 <= c && c <= 6 && (r === 0 || r === 6)) ||
              (2 <= r && r <= 4 && 2 <= c && c <= 4)) {
            this.modules[row + r][col + c] = true;
          } else {
            this.modules[row + r][col + c] = false;
          }
        }
      }
    },

    setupTimingPattern: function () {
      for (var r = 8; r < this.moduleCount - 8; r++) {
        if (this.modules[r][6] !== null) continue;
        this.modules[r][6] = (r % 2 === 0);
      }
      for (var c = 8; c < this.moduleCount - 8; c++) {
        if (this.modules[6][c] !== null) continue;
        this.modules[6][c] = (c % 2 === 0);
      }
    },

    setupAlignmentPattern: function () {
      var pos = getAlignmentPatternPos(this.typeNumber);
      for (var i = 0; i < pos.length; i++) {
        for (var j = 0; j < pos.length; j++) {
          var row = pos[i];
          var col = pos[j];
          if (this.modules[row][col] !== null) continue;
          for (var r = -2; r <= 2; r++) {
            for (var c = -2; c <= 2; c++) {
              if (r === -2 || r === 2 || c === -2 || c === 2 || (r === 0 && c === 0)) {
                this.modules[row + r][col + c] = true;
              } else {
                this.modules[row + r][col + c] = false;
              }
            }
          }
        }
      }
    },

    mapData: function (data, maskPattern) {
      var inc = -1;
      var row = this.moduleCount - 1;
      var bitIndex = 7;
      var byteIndex = 0;

      for (var col = this.moduleCount - 1; col > 0; col -= 2) {
        if (col === 6) col--;
        while (true) {
          for (var c = 0; c < 2; c++) {
            if (this.modules[row][col - c] === null) {
              var dark = false;
              if (byteIndex < data.length) {
                dark = (((data[byteIndex] >>> bitIndex) & 1) === 1);
              }
              // マスクパターン（Pattern 0: (row + col) % 2 === 0）
              var mask = ((row + (col - c)) % 2 === 0);
              if (mask) dark = !dark;

              this.modules[row][col - c] = dark;
              bitIndex--;
              if (bitIndex === -1) {
                byteIndex++;
                bitIndex = 7;
              }
            }
          }
          row += inc;
          if (row < 0 || this.moduleCount <= row) {
            row -= inc;
            inc = -inc;
            break;
          }
        }
      }
    }
  };

  function getAlignmentPatternPos(typeNumber) {
    if (typeNumber === 1) return [];
    if (typeNumber === 2) return [6, 18];
    if (typeNumber === 3) return [6, 22];
    if (typeNumber === 4) return [6, 26];
    if (typeNumber === 5) return [6, 30];
    if (typeNumber === 6) return [6, 34];
    if (typeNumber === 7) return [6, 22, 38];
    if (typeNumber === 8) return [6, 24, 42];
    if (typeNumber === 9) return [6, 26, 46];
    if (typeNumber === 10) return [6, 28, 50];
    return [];
  }

  function createData(typeNumber, dataBytes) {
    var rsBlocks = getRSBlocks(typeNumber);
    var buffer = new QRBitBuffer();

    // 8bit Byte Mode 指示子: 0100
    buffer.put(4, 4);
    // 文字数指示子
    var countLength = (typeNumber < 10) ? 8 : 16;
    buffer.put(dataBytes.length, countLength);

    for (var i = 0; i < dataBytes.length; i++) {
      buffer.put(dataBytes[i], 8);
    }

    var totalDataCount = 0;
    for (var j = 0; j < rsBlocks.length; j++) {
      totalDataCount += rsBlocks[j].dataCount;
    }

    if (buffer.length + 4 <= totalDataCount * 8) {
      buffer.put(0, 4);
    }
    while (buffer.length % 8 !== 0) {
      buffer.putBit(false);
    }

    while (true) {
      if (buffer.length >= totalDataCount * 8) break;
      buffer.put(0xec, 8);
      if (buffer.length >= totalDataCount * 8) break;
      buffer.put(0x11, 8);
    }

    // RS パケットの分割および誤り訂正コード生成
    return createBytes(buffer, rsBlocks);
  }

  function createBytes(buffer, rsBlocks) {
    var offset = 0;
    var maxDcCount = 0;
    var maxEcCount = 0;
    var dcdata = new Array(rsBlocks.length);
    var ecdata = new Array(rsBlocks.length);

    for (var r = 0; r < rsBlocks.length; r++) {
      var dcCount = rsBlocks[r].dataCount;
      var ecCount = rsBlocks[r].totalCount - dcCount;

      maxDcCount = Math.max(maxDcCount, dcCount);
      maxEcCount = Math.max(maxEcCount, ecCount);

      dcdata[r] = new Array(dcCount);
      for (var i = 0; i < dcdata[r].length; i++) {
        dcdata[r][i] = 0xff & buffer.buffer[i + offset];
      }
      offset += dcCount;

      var rsPoly = getErrorCorrectionPolynomial(ecCount);
      var rawPoly = new QRPolynomial(dcdata[r], rsPoly.getLength() - 1);
      var modPoly = rawPoly.mod(rsPoly);

      ecdata[r] = new Array(rsPoly.getLength() - 1);
      for (var j = 0; j < ecdata[r].length; j++) {
        var modIndex = j + modPoly.getLength() - ecdata[r].length;
        ecdata[r][j] = (modIndex >= 0) ? modPoly.get(modIndex) : 0;
      }
    }

    var totalCodeCount = 0;
    for (var k = 0; k < rsBlocks.length; k++) {
      totalCodeCount += rsBlocks[k].totalCount;
    }

    var data = new Array(totalCodeCount);
    var index = 0;

    for (var l = 0; l < maxDcCount; l++) {
      for (var m = 0; m < rsBlocks.length; m++) {
        if (l < dcdata[m].length) {
          data[index++] = dcdata[m][l];
        }
      }
    }

    for (var n = 0; n < maxEcCount; n++) {
      for (var p = 0; p < rsBlocks.length; p++) {
        if (n < ecdata[p].length) {
          data[index++] = ecdata[p][n];
        }
      }
    }

    return data;
  }

  function getErrorCorrectionPolynomial(errorCorrectLength) {
    var a = new QRPolynomial([1], 0);
    for (var i = 0; i < errorCorrectLength; i++) {
      a = a.multiply(new QRPolynomial([1, QRMath.gexp(i)], 0));
    }
    return a;
  }

  // --- D.qr API 実装 ---
  D.qr = {
    /**
     * 指定テキストから生成される QR コードの一辺のモジュール数を返す
     * @param {string} text エンコード対象文字列
     * @returns {number} モジュール数（21, 25, 29...）、失敗時・不正入力時は 0
     */
    moduleCount: function (text) {
      try {
        if (typeof text !== 'string' || text.length === 0) {
          return 0;
        }
        var dataBytes = stringToUtf8Bytes(text);
        var typeNumber = getTypeNumberForBytes(dataBytes);
        if (typeNumber === 0) {
          return 0;
        }
        return typeNumber * 4 + 17;
      } catch (e) {
        return 0;
      }
    },

    /**
     * 指定テキストから QR コードの data:image/png;base64 URL を生成する
     * @param {string} text エンコード対象文字列
     * @param {number} [sizePx] 生成画像サイズ（px、既定: 160）
     * @returns {string|null} 成功時は data URL、失敗・非対応環境時は null
     */
    toDataUrl: function (text, sizePx) {
      try {
        if (typeof text !== 'string' || text.length === 0) {
          return null;
        }

        var targetSize = (typeof sizePx === 'number' && sizePx > 0) ? sizePx : 160;

        if (typeof document === 'undefined' || typeof document.createElement !== 'function') {
          return null;
        }

        var dataBytes = stringToUtf8Bytes(text);

        // バイト数に応じたタイプナンバー選択（V1~V10）
        var typeNumber = getTypeNumberForBytes(dataBytes);
        if (typeNumber === 0) {
          if (D.core && typeof D.core.log === 'function') {
            D.core.log('QR生成に失敗: データ長が最大容量(V10)を超えています');
          }
          return null;
        }

        var qrModel = new QRCodeModel(typeNumber);
        qrModel.make(dataBytes);

        var canvas = document.createElement('canvas');
        if (!canvas || typeof canvas.getContext !== 'function') {
          return null;
        }

        canvas.width = targetSize;
        canvas.height = targetSize;
        var ctx = canvas.getContext('2d');
        if (!ctx) {
          return null;
        }

        var moduleCount = qrModel.moduleCount;
        var cellSize = targetSize / moduleCount;

        if (typeof ctx.fillStyle !== 'undefined') {
          ctx.fillStyle = '#FFFFFF';
        }
        if (typeof ctx.fillRect === 'function') {
          ctx.fillRect(0, 0, targetSize, targetSize);
        }

        if (typeof ctx.fillStyle !== 'undefined') {
          ctx.fillStyle = '#000000';
        }

        for (var r = 0; r < moduleCount; r++) {
          for (var c = 0; c < moduleCount; c++) {
            if (qrModel.isDark(r, c)) {
              if (typeof ctx.fillRect === 'function') {
                ctx.fillRect(c * cellSize, r * cellSize, cellSize, cellSize);
              }
            }
          }
        }

        if (typeof canvas.toDataURL === 'function') {
          var result = canvas.toDataURL('image/png');
          return (typeof result === 'string' && result.length > 0) ? result : null;
        }

        return null;
      } catch (e) {
        if (D.core && typeof D.core.log === 'function') {
          D.core.log('QR生成に失敗: ' + (e && e.message ? e.message : String(e)));
        }
        return null;
      }
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);

