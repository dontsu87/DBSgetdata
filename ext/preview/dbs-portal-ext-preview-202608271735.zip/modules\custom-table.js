/**
 * DBSEXT 自前表（データ駆動）のアダプタ
 *
 * 配列データと列定義から表を描く。並べ替え・絞り込みは**再描画**で行う。
 * 判定ロジック（並び順・絞り込み・見出しUI）は `table-kit` が持つ。
 *
 * ---------------------------------------------------------------------------
 * なぜ切り出したか
 * ---------------------------------------------------------------------------
 * ビーコン一覧と問題申告一覧（拡張）が**112行中87行まで同じコード**を持っていた
 * （2026-08-10 実測）。差分は「セルをリンクにするかどうか」と空表の文言だけ。
 * その結果、片方だけ直した改修が伝播せず、**同じ「自前表」なのに見た目が
 * 食い違っていた**（見出しが灰と青、文字が14pxと13px…）。
 *
 * ここに1つ置き、違いは**列定義のセルレンダラ**として渡す。
 *
 * **ポータル表には使えない。** あちらは行の中にVueのイベントハンドラを持つ
 * 操作ボタンがあり、再描画すると壊れる（契約§6）。ポータル表は table-tools。
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  function kit() {
    return D.tableKit;
  }

  function clear(node) {
    while (node.firstChild) node.removeChild(node.firstChild); // dbsext:own-ui
  }

  /**
   * 表を描いて container へ入れる。
   *
   * @param {object} spec
   *   container   … 描画先（中身は消して作り直す）
   *   rows        … データ配列
   *   columns     … [{ label, value(row), render(td, row), filterOptions }]
   *                 render を渡すとセルの中身を自前で作れる（リンク等）。
   *                 filterOptions（例: ['公開','非公開']）を渡すと、その列の
   *                 見出し絞り込みが文字入力ではなくプルダウン選択式になる
   *                 （table-kit.buildHeaderControls参照。完全一致で絞り込む）
   *   tableAttrs  … 表に付ける属性 { 'data-dbsext-beacons-table': '1', ... }
   *   emptyText   … 絞り込み結果が0件のときの文言
   *   initialSort … { columnIndex, direction } 省略時は並べ替えなし
   *   initialState … 既存表をデータ更新で描き直すときの状態（並べ替え・絞り込み）
   * @returns {object} { table, refresh }
   */
  function render(spec) {
    var container = spec.container;
    var rows = spec.rows || [];
    var columns = spec.columns || [];
    if (!container) return null;

    clear(container);

    var table = document.createElement('table');
    // **全家族共通の目印。見た目のCSSはすべてこれを見る（skin.js の tableCss）。**
    // これが無いと、ヘッダ固定もゼブラも横スクロールも一切効かない。
    table.setAttribute('data-dbsext-table', 'custom');
    if (spec.tableAttrs) {
      for (var attr in spec.tableAttrs) {
        table.setAttribute(attr, spec.tableAttrs[attr]);
      }
    }

    var thead = document.createElement('thead');
    var headerRow = document.createElement('tr');
    var tbody = document.createElement('tbody');

    var state = kit().createState();
    // データ更新で表を描き直す場合も、利用者が操作中の条件を失わせない。
    // sortColIndex は null/undefined のとき未選択として扱い、条件は後段の
    // 見出しコントロール生成時に各入力へ同期する。
    var initialState = spec.initialState || null;
    if (initialState && typeof initialState.sortColIndex === 'number') {
      state.sortColIndex = initialState.sortColIndex;
      state.sortOrder = initialState.sortOrder === 'desc' ? 'desc' : 'asc';
    }
    if (spec.initialSort && typeof spec.initialSort.columnIndex === 'number') {
      state.sortColIndex = spec.initialSort.columnIndex;
      state.sortOrder = spec.initialSort.direction === 'desc' ? 'desc' : 'asc';
    }

    var controlsByColumn = [];

    function valueOf(column, row) {
      var v = column.value ? column.value(row) : '';
      return v === null || v === undefined ? '' : String(v);
    }

    function updateSortIndicators() {
      for (var i = 0; i < controlsByColumn.length; i++) {
        controlsByColumn[i].updateSortIndicator(state.sortColIndex === i, state.sortOrder);
      }
    }

    function refresh() {
      clear(tbody);

      // --- 絞り込み ---
      var kept = [];
      for (var i = 0; i < rows.length; i++) {
        var ok = true;
        for (var c = 0; c < columns.length; c++) {
          if (!kit().matchesFilter(valueOf(columns[c], rows[i]), state.conditions[c])) {
            ok = false;
            break;
          }
        }
        if (ok) kept.push({ row: rows[i], originalIndex: i });
      }

      // --- 並べ替え ---
      if (state.sortColIndex !== null && state.sortColIndex !== undefined) {
        var col = columns[state.sortColIndex];
        if (col) {
          var values = [];
          for (var v = 0; v < kept.length; v++) values.push(valueOf(col, kept[v].row));
          var opts = {
            columnLabel: col.label,
            numeric: !kit().isPortColumn(col.label) && kit().isNumericColumn(values)
          };
          var direction = state.sortOrder === 'desc' ? -1 : 1;
          kept.sort(function (a, b) {
            var cmp = kit().compare(valueOf(col, a.row), valueOf(col, b.row), opts);
            // **同じ値のときは元の並びを保つ。** ここを入れないと、
            // 再描画のたびに同値の行が入れ替わって見える
            if (cmp === 0) return a.originalIndex - b.originalIndex;
            return cmp * direction;
          });
        }
      }

      if (kept.length === 0) {
        var emptyRow = document.createElement('tr');
        var emptyCell = document.createElement('td');
        emptyCell.setAttribute('colspan', String(columns.length));
        emptyCell.className = 'dbsext-table-empty';
        emptyCell.textContent = spec.emptyText || '条件に一致する行はありません。';
        emptyRow.appendChild(emptyCell);
        tbody.appendChild(emptyRow);
      } else {
        for (var r = 0; r < kept.length; r++) {
          var tr = document.createElement('tr');
          for (var k = 0; k < columns.length; k++) {
            var td = document.createElement('td');
            if (typeof columns[k].render === 'function') {
              // セルの中身を自前で作る（リンク・ボタン等）
              columns[k].render(td, kept[r].row);
            } else {
              // **必ず textContent。** APIの文字列からHTMLを作らない
              td.textContent = valueOf(columns[k], kept[r].row);
            }
            tr.appendChild(td);
          }
          tbody.appendChild(tr);
        }
      }

      // tbodyの再構築が終わった直後に呼ぶフック（省略可）。
      // 2026-08-12独立監査「絞り込み後、port-bulk-actions.jsの見出し一括選択
      // チェックボックスの状態(checked/indeterminate)が古いままになる」への対応。
      // tbody内の行を見て何かを同期したい呼び出し側（見出しチェックボックス等）が
      // 絞り込み・並替のたびに再同期できるようにする
      if (typeof spec.onRefresh === 'function') spec.onRefresh();
    }

    // --- 見出し ---
    for (var h = 0; h < columns.length; h++) {
      (function (columnIndex) {
        var th = document.createElement('th');
        var controls = kit().buildHeaderControls({
          columnLabel: columns[columnIndex].label,
          filterOptions: columns[columnIndex].filterOptions,
          sortMode: 'button',
          onSort: function () {
            if (state.sortColIndex === columnIndex) {
              state.sortOrder = state.sortOrder === 'asc' ? 'desc' : 'asc';
            } else {
              state.sortColIndex = columnIndex;
              state.sortOrder = 'asc';
            }
            updateSortIndicators();
            refresh();
          },
          onFilter: function (condition) {
            state.conditions[columnIndex] = condition;
            refresh();
          }
        });
        state.conditions[columnIndex] = controls.condition;
        if (initialState && initialState.conditions) {
          controls.syncFromState(initialState.conditions[columnIndex]);
        }
        controlsByColumn.push(controls);
        th.appendChild(controls.sortEl);
        th.appendChild(controls.filterWrap);
        headerRow.appendChild(th);
      })(h);
    }

    updateSortIndicators();
    thead.appendChild(headerRow);
    table.appendChild(thead);
    table.appendChild(tbody);
    container.appendChild(table);
    refresh();

    return { table: table, refresh: refresh, state: state };
  }

  D.customTable = {
    render: render
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
