(function (global) {
  'use strict';

  var CONSENT_VERSION = '2026-08-13-v1';
  var MAX_QUEUE = 50;
  var ALLOWED_FEATURES = ['observer', 'loading', 'vehicle-kinds', 'port-bulk', 'user-link', 'runtime'];
  var ALLOWED_STAGES = ['start', 'complete', 'recover', 'cancel', 'error'];
  var ALLOWED_CODES = ['OK', 'TIMEOUT', 'NETWORK', 'OBSERVER_RETRY', 'ROUTE_EXIT', 'USER_CANCEL', 'VALIDATION'];

  function allowed(value, values, field) {
    if (values.indexOf(value) < 0) throw new Error('diagnostic field rejected: ' + field);
    return value;
  }

  function serialize(input, context) {
    if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('diagnostic event must be an object');
    var known = ['feature', 'stage', 'code', 'ok', 'statusClass', 'durationBucket', 'countBucket', 'screen'];
    Object.keys(input).forEach(function (key) {
      if (known.indexOf(key) < 0) throw new Error('diagnostic field rejected: ' + key);
    });
    var event = {
      schema: 'dbsext.diagnostic/v1',
      extensionVersion: String(context.extensionVersion || ''),
      channel: allowed(context.channel, ['preview', 'production'], 'channel'),
      install: String(context.installHash || '').slice(0, 32),
      feature: allowed(input.feature, ALLOWED_FEATURES, 'feature'),
      stage: allowed(input.stage, ALLOWED_STAGES, 'stage'),
      code: allowed(input.code, ALLOWED_CODES, 'code'),
      ok: input.ok === true,
      statusClass: allowed(input.statusClass || 'none', ['none', '2xx', '4xx', '429', '5xx', 'offline'], 'statusClass'),
      durationBucket: allowed(input.durationBucket || 'none', ['none', '<250ms', '<1s', '<5s', '>=5s'], 'durationBucket'),
      countBucket: allowed(input.countBucket || 'none', ['none', '0', '1', '2-10', '11-50', '50+'], 'countBucket'),
      screen: allowed(input.screen || 'other', ['other', 'ports', 'vehicles', 'beacons', 'areas'], 'screen')
    };
    return event;
  }

  function create(options) {
    var storage = options.storage;
    var transport = options.transport;
    var config = options.config || {};
    var queue = [];
    var sending = false;

    async function installHash() {
      var stored = await storage.get('dbsextDiagnosticInstallSeed');
      var seed = stored && stored.dbsextDiagnosticInstallSeed;
      if (typeof seed !== 'string' || !/^[a-f0-9]{32}$/.test(seed)) {
        var bytes = new Uint8Array(16);
        crypto.getRandomValues(bytes);
        seed = Array.from(bytes, function (value) { return value.toString(16).padStart(2, '0'); }).join('');
        await storage.set({ dbsextDiagnosticInstallSeed: seed });
      }
      var digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('dbsext-diagnostic-v1:' + seed));
      return Array.from(new Uint8Array(digest), function (value) { return value.toString(16).padStart(2, '0'); }).join('').slice(0, 32);
    }

    async function consent() {
      var value = await storage.get('dbsextDiagnosticConsent');
      var item = value && value.dbsextDiagnosticConsent;
      if (!item || item.version !== CONSENT_VERSION || !['accepted', 'declined'].includes(item.state)) {
        return { state: 'unknown', version: CONSENT_VERSION };
      }
      return item;
    }

    async function setConsent(state) {
      if (state !== 'accepted' && state !== 'declined') throw new Error('invalid consent state');
      await storage.set({ dbsextDiagnosticConsent: { state: state, version: CONSENT_VERSION, decidedAt: new Date().toISOString() } });
      if (state !== 'accepted') queue.length = 0;
    }

    function enabled() {
      return config.enabled === true && config.killSwitch === false &&
        config.channel === 'preview' && config.endpoint === 'https://dontsu87.github.io/DBSgetdata/ext/preview/diagnostics';
    }

    async function flush() {
      if (sending || !enabled() || queue.length === 0) return false;
      var currentConsent = await consent();
      if (currentConsent.state !== 'accepted') { queue.length = 0; return false; }
      sending = true;
      var batch = queue.slice(0, 10);
      try {
        var response = await transport(config.endpoint, {
          method: 'POST',
          credentials: 'omit',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ schema: 'dbsext.diagnostic-batch/v1', events: batch })
        });
        if (response && response.ok) queue.splice(0, batch.length);
        return !!(response && response.ok);
      } catch (_) {
        return false;
      } finally {
        sending = false;
      }
    }

    async function record(input, context) {
      if (!enabled()) { queue.length = 0; return false; }
      var currentConsent = await consent();
      if (currentConsent.state !== 'accepted') return false;
      var safeContext = Object.assign({}, context, { installHash: await installHash() });
      var event = serialize(input, safeContext);
      queue.push(event);
      if (queue.length > MAX_QUEUE) queue.splice(0, queue.length - MAX_QUEUE);
      return true;
    }

    function applyConfig(next) {
      config = next || {};
      if (!enabled()) queue.length = 0;
    }

    return { consent: consent, setConsent: setConsent, record: record, flush: flush, applyConfig: applyConfig,
      queueSize: function () { return queue.length; } };
  }

  global.DBSEXT_DIAGNOSTICS = { CONSENT_VERSION: CONSENT_VERSION, serialize: serialize, create: create };
})(typeof globalThis !== 'undefined' ? globalThis : self);
