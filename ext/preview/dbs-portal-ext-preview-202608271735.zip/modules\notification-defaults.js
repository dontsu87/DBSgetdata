/** 配信機能を掲載状態4種・500件表示で初期表示する（拡張版限定）。 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;
  var DESIRED_PAGE_SIZE = 500;
  var DESIRED_STATUSES = ['掲載準備中', '未掲載', '掲載中', '掲載準備完了'];
  var triedThisLoad = false;

  function isTargetPage() {
    return typeof location !== 'undefined' && /^\/notifications\/messages\/?$/.test(location.pathname);
  }

  function isExtensionPlatform() {
    return !!(D.platform && (D.platform.kind === 'extension' || D.platform.isUserScript));
  }

  function currentValues(params, key) {
    return params.getAll(key).slice().sort();
  }

  function hasDefaults() {
    if (typeof location === 'undefined') return true;
    var params = new URLSearchParams(location.search);
    var expected = DESIRED_STATUSES.slice().sort();
    return params.get('page') === '1' && params.get('page-size') === String(DESIRED_PAGE_SIZE) &&
      JSON.stringify(currentValues(params, 'publish-statuses')) === JSON.stringify(expected);
  }

  function buildTargetUrl() {
    var params = new URLSearchParams(location.search);
    params.delete('publish-statuses');
    for (var i = 0; i < DESIRED_STATUSES.length; i++) params.append('publish-statuses', DESIRED_STATUSES[i]);
    params.set('page', '1');
    params.set('page-size', String(DESIRED_PAGE_SIZE));
    return location.pathname + '?' + params.toString();
  }

  function signalNavigationLoading() {
    if (D.netStatus && typeof D.netStatus.beginNavigation === 'function') {
      D.netStatus.beginNavigation();
      return;
    }
    try { document.dispatchEvent(new CustomEvent('dbsext:navigation-loading')); } catch (e) {}
  }

  D.notificationDefaults = {
    DESIRED_PAGE_SIZE: DESIRED_PAGE_SIZE,
    DESIRED_STATUSES: DESIRED_STATUSES.slice(),
    apply: function () {
      if (!isExtensionPlatform() || !isTargetPage() || triedThisLoad || hasDefaults()) return;
      triedThisLoad = true;
      var target = buildTargetUrl();
      if (D.core && typeof D.core.log === 'function') D.core.log('配信機能を既定条件で開き直します: ' + target);
      signalNavigationLoading();
      location.replace(target);
    },
    _reset: function () { triedThisLoad = false; },
    _hasDefaults: hasDefaults,
    _buildTargetUrl: buildTargetUrl
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
