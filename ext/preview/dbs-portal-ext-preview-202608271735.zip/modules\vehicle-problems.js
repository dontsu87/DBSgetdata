/**
 * DBSEXT 車両個別画面の問題申告一覧モジュール
 *
 * 車両個別画面（`/vehicles/:id`）で純正の問題申告テーブルを非表示にし、
 * 自前の多機能テーブル（並べ替え・絞り込み・部位×事象展開）を表示する。
 *
 * 契約（docs/06-module-contract.md §6）の遵守:
 *   - 読み取り専用（GET /api/vehicles/:id/problems のみ）
 *   - 更新系リクエストは一切発行しない
 *   - setInterval を使わない
 *   - ポータルの既存DOMを削除・移動しない（非表示にするのみ）
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var PANEL_ATTR = 'data-dbsext-vehicle-problems';
  var TABLE_ATTR = 'data-dbsext-vp-table';

  // キャッシュ: vehicleId -> { rows: Array, timestamp: number }
  var cacheMap = {};
  var CACHE_TTL = 30000; // 30秒

  // 重複fetch防止・世代管理
  var currentGeneration = 0;
  var isFetching = false;
  var currentVehicleId = null;

  /**
   * 車両個別画面かどうかの判定
   * パス例: /vehicles/VEHICLE:019053c7-ef57-7975-bebe-08f335b36aa4
   */
  function getVehicleIdFromUrl() {
    if (typeof location === 'undefined') return null;
    var match = /^\/vehicles\/([A-Za-z0-9:_-]+)\/?$/.exec(location.pathname);
    if (!match) return null;
    var id = match[1];
    if (id === 'list' || id === 'search') return null;
    return id;
  }

  /**
   * 純正の「問題申告」セクションのテーブルを探索
   */
  function findOriginalTable() {
    if (typeof document === 'undefined') return null;
    var headers = document.querySelectorAll('h3, .el-collapse-item__header, .section-title, span, div');
    for (var i = 0; i < headers.length; i++) {
      var h = headers[i];
      if ((h.textContent || '').trim() === '問題申告') {
        var container = h.closest('.el-collapse-item') || h.closest('.section') || h.parentElement;
        if (container) {
          var table = container.querySelector('.el-table');
          if (table) return { container: container, table: table, header: h };
        }
      }
    }
    // フォールバック: 画面内のすべての .el-table から探す
    var tables = document.querySelectorAll('.el-table');
    for (var j = 0; j < tables.length; j++) {
      var t = tables[j];
      var ths = t.querySelectorAll('thead th');
      for (var k = 0; k < ths.length; k++) {
        var text = (ths[k].textContent || '').trim();
        if (text === '問題申告日時' || text === '事象' || text === '部位') {
          return { container: t.parentElement, table: t, header: null };
        }
      }
    }
    return null;
  }

  /**
   * 自前テーブルの挿入先を決定
   */
  function findInsertionPoint() {
    var orig = findOriginalTable();
    if (orig && orig.table) {
      var wrapper = orig.table.parentElement;
      while (wrapper && wrapper !== document.body && !(wrapper.classList && wrapper.classList.contains('mb-4'))) {
        wrapper = wrapper.parentElement;
      }
      if (wrapper && wrapper !== document.body && wrapper.parentElement) {
        return { container: wrapper.parentElement, targetSibling: wrapper };
      }
      return { container: orig.table.parentElement, targetSibling: orig.table };
    }
    if (orig && orig.container) {
      return { container: orig.container, targetSibling: null };
    }
    var main = document.querySelector('.main-content, .el-main, #app');
    if (main) {
      return { container: main, targetSibling: null };
    }
    return null;
  }

  /**
   * 純正テーブルを隠す（DOM削除はしない、display:none のみ）
   */
  function hideOriginalTable() {
    var orig = findOriginalTable();
    if (!orig || !orig.table) return false;
    var wrapper = orig.table.parentElement;
    while (wrapper && wrapper !== document.body && !(wrapper.classList && wrapper.classList.contains('mb-4'))) {
      wrapper = wrapper.parentElement;
    }
    if (wrapper && wrapper !== document.body) {
      wrapper.setAttribute(PANEL_ATTR + '-hidden', '1');
      wrapper.style.display = 'none';
    }
    orig.table.setAttribute(PANEL_ATTR + '-hidden', '1');
    return true;
  }

  /**
   * 純正テーブルを再表示（画面離脱時など）
   */
  function showOriginalTable() {
    var hidden = document.querySelectorAll('[' + PANEL_ATTR + '-hidden="1"]');
    for (var i = 0; i < hidden.length; i++) {
      hidden[i].style.display = '';
      hidden[i].removeAttribute(PANEL_ATTR + '-hidden');
    }
  }

  /**
   * パネルが現在も有効か検証
   */
  function isPanelValid(panel, vehicleId) {
    if (!panel || !panel.parentNode) return false;
    if (panel.getAttribute(PANEL_ATTR + '-vid') !== vehicleId) return false;
    return true;
  }

  /**
   * APIから問題申告データを取得
   */
  function fetchProblems(vehicleId, panel, gen) {
    var statusDiv = panel.querySelector('[' + PANEL_ATTR + '-status]');

    // キャッシュチェック
    var cached = cacheMap[vehicleId];
    if (cached && (Date.now() - cached.timestamp < CACHE_TTL)) {
      renderTable(panel, cached.rows);
      return;
    }

    if (isFetching && currentVehicleId === vehicleId) {
      return;
    }

    isFetching = true;
    currentVehicleId = vehicleId;

    if (statusDiv) {
      statusDiv.textContent = '問題申告データを読み込み中...';
      statusDiv.className = 'dbsext-vp-status';
    }

    // APIから取得
    var url = '/api/vehicles/' + vehicleId + '/problems';
    fetch(url, { credentials: 'include' })
      .then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.json();
      })
      .then(function (items) {
        if (!Array.isArray(items)) items = [];
        // problemOccurrences を展開してフラットな行配列にする
        var rows = [];
        for (var i = 0; i < items.length; i++) {
          var item = items[i];
          var occs = item.problemOccurrences || [];
          for (var j = 0; j < occs.length; j++) {
            rows.push({
              problemReportTs: item.problemReportTs || '',
              userUniqueCode: item.userUniqueCode || '',
              importanceCategory: occs[j].importanceCategory || '',
              partNameJa: occs[j].partNameJa || '',
              partCode: occs[j].partCode || '',
              occurrenceNameJa: occs[j].occurrenceNameJa || '',
              occurrenceCode: occs[j].occurrenceCode || '',
              collectionStatus: item.collectionStatus || '',
              collectionCompleteExecutionTs: item.collectionCompleteExecutionTs || ''
            });
          }
        }

        cacheMap[vehicleId] = { rows: rows, timestamp: Date.now() };

        if (gen === currentGeneration && isPanelValid(panel, vehicleId)) {
          isFetching = false;
          currentVehicleId = null;
          renderTable(panel, rows);
        } else {
          isFetching = false;
          currentVehicleId = null;
        }
      })
      .catch(function (err) {
        if (gen === currentGeneration && isPanelValid(panel, vehicleId)) {
          isFetching = false;
          currentVehicleId = null;
          if (statusDiv) {
            statusDiv.textContent = '問題申告の取得に失敗しました: ' + (err && err.message ? err.message : String(err));
            statusDiv.className = 'dbsext-vp-error';
          }
        } else {
          isFetching = false;
          currentVehicleId = null;
        }
      });
  }

  /**
   * テーブルを描画
   */
  function renderTable(panel, rows) {
    var statusDiv = panel.querySelector('[' + PANEL_ATTR + '-status]');
    var tableWrap = panel.querySelector('[' + PANEL_ATTR + '-wrap]');
    if (!tableWrap) return;

    // 前回の表示をクリア
    while (tableWrap.firstChild) tableWrap.removeChild(tableWrap.firstChild); // dbsext:own-ui

    if (!rows || rows.length === 0) {
      if (statusDiv) {
        statusDiv.textContent = 'この車両の問題申告はありません。';
        statusDiv.className = 'dbsext-vp-status';
      }
      return;
    }

    if (statusDiv) {
      statusDiv.textContent = '全 ' + rows.length + ' 件（部位×事象を展開）';
      statusDiv.className = 'dbsext-vp-status';
    }

    var areaId = (D.userSummary && typeof D.userSummary.getSelectedAreaId === 'function')
      ? D.userSummary.getSelectedAreaId()
      : null;

    var codesToPreload = [];
    for (var p = 0; p < rows.length; p++) {
      var c = (rows[p].userUniqueCode || '').trim();
      if (c && c !== '-' && codesToPreload.indexOf(c) === -1) {
        codesToPreload.push(c);
      }
    }

    var columns = [
      { label: '問題申告日時',    value: function (r) { return r.problemReportTs; } },
      {
        label: 'ユーザ識別番号',
        value: function (r) { return r.userUniqueCode; },
        render: function (td, r) {
          var code = (r.userUniqueCode || '').trim();
          if (!code || code === '-') {
            td.textContent = '-';
            return;
          }
          td.textContent = code;

          var applyLink = function (summary) {
            if (!(td.parentNode || td.parentElement)) return;
            while (td.firstChild) td.removeChild(td.firstChild); // dbsext:own-ui
            if (summary && summary.userKind) {
              var buildUrlFn = (D.userSummary && typeof D.userSummary.buildUserDetailUrl === 'function')
                ? D.userSummary.buildUserDetailUrl
                : null;
              var href = buildUrlFn ? buildUrlFn(summary.userKind, code, areaId) : null;
              if (href) {
                var a = document.createElement('a');
                a.setAttribute('href', href);
                a.setAttribute('target', '_blank');
                a.setAttribute('rel', 'noopener noreferrer');
                a.textContent = code;
                a.className = 'dbsext-cell-link';
                a.title = 'ユーザー詳細を別タブで開きます';
                td.appendChild(a);
                return;
              }
            }
            td.textContent = code;
          };

          if (D.userSummary) {
            var cache = (typeof D.userSummary._getCacheMap === 'function') ? D.userSummary._getCacheMap()[code] : null;
            if (cache && cache.userKind && (!cache.expiry || Date.now() <= cache.expiry)) {
              applyLink(cache);
            } else {
              D.userSummary.requestSummaries([code], function (resCode, summary) {
                if (resCode === code) {
                  applyLink(summary);
                }
              });
            }
          }
        }
      },
      {
        label: '会員区分',
        value: function (r) { return r._summaryKindName || '-'; },
        render: function (td, r) {
          var code = (r.userUniqueCode || '').trim();
          if (!code || code === '-') {
            td.textContent = '-';
            return;
          }
          td.textContent = '-';

          var applyKind = function (summary) {
            if (!(td.parentNode || td.parentElement)) return;
            if (summary && summary.userKind) {
              var kindName = (D.userSummary && typeof D.userSummary.getUserKindDisplayName === 'function')
                ? D.userSummary.getUserKindDisplayName(summary.userKind)
                : summary.userKind;
              r._summaryKindName = kindName;
              td.textContent = kindName || '-';
            } else {
              td.textContent = '-';
            }
          };

          if (D.userSummary) {
            var cache = (typeof D.userSummary._getCacheMap === 'function') ? D.userSummary._getCacheMap()[code] : null;
            if (cache && cache.userKind && (!cache.expiry || Date.now() <= cache.expiry)) {
              applyKind(cache);
            } else {
              D.userSummary.requestSummaries([code], function (resCode, summary) {
                if (resCode === code) {
                  applyKind(summary);
                }
              });
            }
          }
        }
      },
      {
        label: 'ユーザーID',
        value: function (r) { return r._summaryUserId || '-'; },
        render: function (td, r) {
          var code = (r.userUniqueCode || '').trim();
          if (!code || code === '-') {
            td.textContent = '-';
            return;
          }
          td.textContent = '-';

          var applyId = function (summary) {
            if (!(td.parentNode || td.parentElement)) return;
            if (summary && summary.userId) {
              r._summaryUserId = summary.userId;
              td.textContent = summary.userId;
            } else {
              td.textContent = '-';
            }
          };

          if (D.userSummary) {
            var cache = (typeof D.userSummary._getCacheMap === 'function') ? D.userSummary._getCacheMap()[code] : null;
            if (cache && cache.userKind && (!cache.expiry || Date.now() <= cache.expiry)) {
              applyId(cache);
            } else {
              D.userSummary.requestSummaries([code], function (resCode, summary) {
                if (resCode === code) {
                  applyId(summary);
                }
              });
            }
          }
        }
      },
      { label: '重要度',          value: function (r) { return r.importanceCategory; } },
      { label: '部位',            value: function (r) { return r.partNameJa; } },
      { label: '事象',            value: function (r) { return r.occurrenceNameJa; } },
      { label: '回収状況',        value: function (r) { return r.collectionStatus; } },
      { label: '回収完了日時',    value: function (r) { return r.collectionCompleteExecutionTs; } }
    ];

    if (D.userSummary && codesToPreload.length > 0) {
      D.userSummary.requestSummaries(codesToPreload);
    }

    // 描画・並べ替え・絞り込みは custom-table が担う。
    // 以前はここに約110行の自前実装があり、ビーコン一覧とほぼ同じものだった。
    D.customTable.render({
      container: tableWrap,
      rows: rows,
      columns: columns,
      // 初期表示は「最新申告日時」が先頭になるよう降順にする。
      // ヘッダをクリックした場合は custom-table 側の通常のトグルへ戻る。
      initialSort: { columnIndex: 0, direction: 'desc' },
      tableAttrs: (function () { var a = {}; a[TABLE_ATTR] = '1'; return a; })(),
      emptyText: '絞り込み条件に一致する申告はありません。'
    });
  }

  /**
   * 自前パネルを構築
   */
  function buildPanel(vehicleId) {
    if (typeof document === 'undefined') return null;

    var existing = document.querySelector('[' + PANEL_ATTR + '="1"]');
    if (existing) {
      // 車両が変わったら破棄して作り直す
      if (existing.getAttribute(PANEL_ATTR + '-vid') !== vehicleId) {
        if (existing.parentNode) existing.parentNode.removeChild(existing); // dbsext:own-ui
        currentGeneration++;
        isFetching = false;
        currentVehicleId = null;
      } else {
        return existing;
      }
    }

    var insertion = findInsertionPoint();
    if (!insertion || !insertion.container) return null;

    var panel = document.createElement('div');
    panel.setAttribute(PANEL_ATTR, '1');
    panel.setAttribute(PANEL_ATTR + '-vid', vehicleId);

    var header = document.createElement('div');
    header.className = 'dbsext-vp-header';

    var h2 = document.createElement('h3');
    h2.textContent = '問題申告一覧（拡張）';
    header.appendChild(h2);

    var statusDiv = document.createElement('div');
    statusDiv.setAttribute(PANEL_ATTR + '-status', '1');
    header.appendChild(statusDiv);

    panel.appendChild(header);

    var tableWrap = document.createElement('div');
    tableWrap.setAttribute(PANEL_ATTR + '-wrap', '1');
    tableWrap.className = 'dbsext-vp-table-wrap';
    // 横スクロールバーの見た目は table-wrap.js が共通で与える
    tableWrap.setAttribute('data-dbsext-table-scroll', '1');
    panel.appendChild(tableWrap);

    if (insertion.targetSibling) {
      insertion.container.insertBefore(panel, insertion.targetSibling);
    } else {
      insertion.container.appendChild(panel);
    }

    return panel;
  }

  /**
   * 画面離脱時の後片付け
   */
  function teardown() {
    showOriginalTable();
    var panel = document.querySelector('[' + PANEL_ATTR + '="1"]');
    if (panel && panel.parentNode) {
      panel.parentNode.removeChild(panel); // dbsext:own-ui
    }
    currentGeneration++;
    isFetching = false;
    currentVehicleId = null;
  }

  D.vehicleProblems = {
    apply: function () {
      if (typeof document === 'undefined' || !document.body) return;

      var vehicleId = getVehicleIdFromUrl();
      if (!vehicleId) {
        teardown();
        return;
      }

      var orig = findOriginalTable();
      if (!orig) {
        // 純正テーブルがまだ描画されていない場合は待つ
        return;
      }

      hideOriginalTable();

      var panel = buildPanel(vehicleId);
      if (!panel) return;

      fetchProblems(vehicleId, panel, currentGeneration);
    },

    peekShowAll: function () {
      showOriginalTable();
    },

    peekRestore: function () {
      if (getVehicleIdFromUrl()) hideOriginalTable();
    },

    // テスト用の内部状態アクセス
    _getVehicleIdFromUrl: getVehicleIdFromUrl,
    _findProblemTable: findOriginalTable,
    _getCache: function () { return cacheMap; },
    _clearCache: function () { cacheMap = {}; },
    _resetForTest: function () {
      cacheMap = {};
      currentGeneration = 0;
      isFetching = false;
      currentVehicleId = null;
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
