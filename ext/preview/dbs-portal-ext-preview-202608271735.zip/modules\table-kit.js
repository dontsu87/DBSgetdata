/**
 * DBSEXT 表の共通コア（table-kit）
 *
 * ---------------------------------------------------------------------------
 * なぜ「共通の基底クラス」ではなく「共通コア＋アダプタ」なのか
 * ---------------------------------------------------------------------------
 * 表は2種類あり、**行の持ち主が違う**。
 *
 *   ポータル表 … ポータルが描画済みの <tr>。行の中に **Vueのイベントハンドラを持つ
 *                 操作ボタン**（解錠・再配置・メンテナンス）が入っている。
 *                 並べ替えは appendChild で並べ直す。絞り込みは display:none。
 *   自前表     … 配列データから拡張が描画する。並べ替え・絞り込みは再描画。
 *
 * ポータル表を「再描画」にすると操作ボタンのVueハンドラが壊れる。
 * これは契約§6「ポータルの既存DOMを削除・移動しない」に正面から反する
 * （`tests/test_table_columns.js` が `btn.customProp === 'unmodified'` で検証済み）。
 *
 * したがって**行をどう動かすかは共有できない**。共有するのはここに置いた4つだけ:
 *
 *   1. compare()            … 並び順の決め方（自然順・数値・ポート名の特別扱い）
 *   2. matchesFilter()      … 絞り込みの判定（文字列 / 数値の範囲）
 *   3. buildHeaderControls()… 見出しの操作UI（同じマークアップ・同じCSS）
 *   4. createState()        … 状態の持ち方
 *
 * これで「同じ改修がすべての表へ伝播する」ことと、
 * 「ポータルDOMを壊さない」ことを両立させる。
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  // ---------------------------------------------------------------------------
  // 絞り込みの種類
  //
  // **列によって、文字列の部分一致より「以上・以下」の方が役に立つ。**
  // 電圧やバッテリー残量は「3.5V以下だけ見たい」という使い方をする。
  // ここを1箇所の宣言表にしておけば、現場からの要望に応じて
  // **1行足すだけ**で切り替えられる。
  // ---------------------------------------------------------------------------

  var FILTER_TEXT = 'text';
  var FILTER_NUMBER = 'number';
  // 列挙値の列（公開設定など）向け。文字列部分一致だと、選択肢の一方が
  // もう一方の部分文字列になる場合に誤って両方ヒットする（例:「公開」は
  // 「非公開」の部分文字列）。そのためプルダウン選択式は必ず完全一致で絞り込む
  var FILTER_SELECT = 'select';

  /**
   * 列名 → 絞り込みの種類。**ここが唯一の宣言場所。**
   *
   * 判定は「完全一致」ではなく「見出しがこの語を含むか」で行う。
   * 実際の見出しは `ビーコンバッテリー残量[%]` のように単位や修飾が付くため、
   * 完全一致にすると**1列も一致せず、静かに文字列絞り込みのままになる**
   * （table-columns で同じ失敗を1度している）。
   *
   * 追加するときは、**部分一致で他の列を巻き込まないか**を確かめること。
   * 例: `残量` は良いが `量` だけにすると `交通量` のような列まで数値扱いになる。
   */
  var NUMERIC_COLUMN_HINTS = [
    '電圧',
    'バッテリー',
    '残量',
    '台数',
    'ラック数'
  ];

  /** 見出し名から絞り込みの種類を決める */
  function filterKindFor(columnLabel) {
    var label = String(columnLabel == null ? '' : columnLabel);
    for (var i = 0; i < NUMERIC_COLUMN_HINTS.length; i++) {
      if (label.indexOf(NUMERIC_COLUMN_HINTS[i]) >= 0) return FILTER_NUMBER;
    }
    return FILTER_TEXT;
  }

  /**
   * セルの文字列から数値を取り出す。
   *
   * 実データには単位や記号が混ざる（`3.9V` / `80%` / `1,200`）。
   * また値が無い行は `ー` や空文字で表される。
   * **取り出せなければ null を返す。0 と混同してはいけない。**
   */
  function toNumber(text) {
    if (text === null || text === undefined) return null;
    if (typeof text === 'number') return isFinite(text) ? text : null;
    var cleaned = String(text).replace(/,/g, '');
    var m = cleaned.match(/-?\d+(?:\.\d+)?/);
    if (!m) return null;
    var n = Number(m[0]);
    return isFinite(n) ? n : null;
  }

  // ---------------------------------------------------------------------------
  // 並び順
  // ---------------------------------------------------------------------------

  /**
   * ポート名の並び順キー。`A-12` のような英字＋番号を、
   * 英字→数値の順で自然に並べる。数値部分を持たないものは後ろへ。
   */
  function portSortKey(name) {
    if (name === null || name === undefined) return [1, '', 0, ''];
    var str = String(name);
    var m = str.trim().match(/^\s*([A-Za-z]*)-?(\d+)/);
    if (m) return [0, m[1].toUpperCase(), Number(m[2]), str];
    return [1, '', 0, str];
  }

  function comparePortKeys(a, b) {
    if (a[0] !== b[0]) return a[0] - b[0];
    if (a[1] !== b[1]) return a[1].localeCompare(b[1]);
    if (a[2] !== b[2]) return a[2] - b[2];
    return a[3].localeCompare(b[3], undefined, { numeric: true, sensitivity: 'base' });
  }

  function isPortColumn(label) {
    return label === 'ポート名' || label === 'ポート';
  }

  /**
   * 2つのセル値を比べる。
   *
   * @param {string} a
   * @param {string} b
   * @param {object} [opts] columnLabel … 列名（ポート名の特別扱いに使う）
   *                        numeric     … 数値として比べる（列全体が数値のとき）
   */
  function compare(a, b, opts) {
    var options = opts || {};
    var textA = a === null || a === undefined ? '' : String(a).trim();
    var textB = b === null || b === undefined ? '' : String(b).trim();

    if (isPortColumn(options.columnLabel)) {
      return comparePortKeys(portSortKey(textA), portSortKey(textB));
    }
    if (options.numeric) {
      // 空欄は一番小さいものとして扱う（並べたときに端へ寄る）
      var numA = textA === '' ? -Infinity : Number(textA);
      var numB = textB === '' ? -Infinity : Number(textB);
      if (!isFinite(numA)) numA = -Infinity;
      if (!isFinite(numB)) numB = -Infinity;
      return numA - numB;
    }
    return textA.localeCompare(textB, undefined, { numeric: true, sensitivity: 'base' });
  }

  /** 列の値がすべて数値として扱えるか（空欄は無視。1つも値が無ければ false） */
  function isNumericColumn(values) {
    var seen = 0;
    for (var i = 0; i < values.length; i++) {
      var text = values[i] === null || values[i] === undefined ? '' : String(values[i]).trim();
      if (text === '') continue;
      seen++;
      if (isNaN(Number(text))) return false;
    }
    return seen > 0;
  }

  // ---------------------------------------------------------------------------
  // 絞り込みの判定
  // ---------------------------------------------------------------------------

  /**
   * 1セルが絞り込み条件に合うか。
   *
   * @param {string} cellText セルの表示文字列
   * @param {object} cond     { kind, text } または { kind, min, max }
   * @returns {boolean}
   */
  function matchesFilter(cellText, cond) {
    if (!cond) return true;

    if (cond.kind === FILTER_NUMBER) {
      var hasMin = cond.min !== '' && cond.min !== null && cond.min !== undefined;
      var hasMax = cond.max !== '' && cond.max !== null && cond.max !== undefined;
      if (!hasMin && !hasMax) return true;

      var value = toNumber(cellText);
      // **値が無い行は、範囲を指定した時点で対象外。**
      // `ー`（電圧なし）は「3.5以上」を満たしようがない。
      // ここで通すと、絞り込んだのに空の行が並んで意味をなさなくなる。
      if (value === null) return false;

      if (hasMin) {
        var min = toNumber(cond.min);
        if (min !== null && value < min) return false;
      }
      if (hasMax) {
        var max = toNumber(cond.max);
        if (max !== null && value > max) return false;
      }
      return true;
    }

    if (cond.kind === FILTER_SELECT) {
      var selected = String(cond.text == null ? '' : cond.text);
      if (selected === '') return true; // 「すべて」
      var cellValue = cellText === null || cellText === undefined ? '' : String(cellText);
      return cellValue === selected; // **完全一致。** 部分一致にすると列挙値どうしが誤って重なりうる
    }

    var needle = String(cond.text == null ? '' : cond.text);
    if (needle === '') return true;
    var hay = cellText === null || cellText === undefined ? '' : String(cellText);
    return hay.toLocaleLowerCase().indexOf(needle.toLocaleLowerCase()) >= 0;
  }

  /** 条件が1つでも入っているか */
  function hasAnyCondition(conditions) {
    for (var key in conditions) {
      var cond = conditions[key];
      if (!cond) continue;
      if (cond.kind === FILTER_NUMBER) {
        if ((cond.min !== '' && cond.min != null) || (cond.max !== '' && cond.max != null)) return true;
      } else if (cond.text) {
        return true;
      }
    }
    return false;
  }

  // ---------------------------------------------------------------------------
  // 状態
  // ---------------------------------------------------------------------------

  function createState() {
    return {
      sortColIndex: null,
      sortOrder: null,      // 'asc' | 'desc'
      conditions: {}        // 列番号 -> { kind, text } / { kind, min, max }
    };
  }

  function conditionFor(state, colIndex, columnLabel) {
    if (!state.conditions[colIndex]) {
      state.conditions[colIndex] = { kind: filterKindFor(columnLabel), text: '', min: '', max: '' };
    }
    return state.conditions[colIndex];
  }

  // ---------------------------------------------------------------------------
  // 見出しの操作UI
  // ---------------------------------------------------------------------------

  function makeInput(attrName, placeholder, title) {
    var input = document.createElement('input');
    input.type = 'text';
    input.setAttribute(attrName, '1');
    input.placeholder = placeholder;
    if (title) input.title = title;
    // クリックやキー操作がポータルの並べ替え等へ伝わらないようにする
    input.addEventListener('click', function (e) { e.stopPropagation(); });
    input.addEventListener('keydown', function (e) { e.stopPropagation(); });
    return input;
  }

  /**
   * 見出しへ「並べ替え」と「絞り込み」を足す。**全家族で同じものを使う。**
   *
   * 見た目はCSS（skin.js）が持つ。ここではマークアップと配線だけ。
   *
   * @param {object} spec
   *   columnLabel   … 列名（絞り込みの種類の判定に使う）
   *   sortMode      … 'indicator'（見出し文字の隣に▲を足す）/ 'button'（見出し全体をボタンに）
   *   onSort        … 並べ替えが押された
   *   onFilter      … 絞り込みが変わった（引数は条件オブジェクト）
   *   filterOptions … 列挙値の配列（例: ['公開','非公開']）を渡すと、文字入力の代わりに
   *                   プルダウン選択式の絞り込みになる（先頭に「すべて」を自動で足す）。
   *                   **列名によらず、渡された時点で選択式が優先される。**
   *                   値の完全一致で絞り込む（部分一致にすると「公開」が「非公開」も
   *                   拾ってしまうため）
   * @returns {object} { sortEl, filterWrap, condition, syncFromState }
   */
  function buildHeaderControls(spec) {
    var columnLabel = spec.columnLabel || '';
    var hasSelectOptions = Array.isArray(spec.filterOptions) && spec.filterOptions.length > 0;
    var kind = hasSelectOptions ? FILTER_SELECT : filterKindFor(columnLabel);
    var condition = { kind: kind, text: '', min: '', max: '' };

    // --- 並べ替え ---
    var sortEl;
    var sortArrowEl; // 'button'モードのときだけ使う（矢印だけを薄く/濃くするため見出し文字と分ける）
    if (spec.sortMode === 'button') {
      sortEl = document.createElement('button');
      sortEl.type = 'button';
      sortEl.className = 'dbsext-th-sort';
      sortEl.title = 'クリックで並べ替え';

      var labelEl = document.createElement('span');
      labelEl.textContent = columnLabel;
      sortEl.appendChild(labelEl);

      // 並べ替えが働いていないときも矢印を薄く表示し、この列が並べ替え可能だと
      // 分かるようにする（'indicator'モードは元から同じ考え方で薄い▲を出していた。
      // 'button'モードだけ、働いたときにしか矢印が出ない仕様になっていたのを揃えた）
      sortArrowEl = document.createElement('span');
      sortArrowEl.className = 'dbsext-th-sort-arrow';
      sortArrowEl.textContent = ' ▲';
      sortArrowEl.style.opacity = '0.3';
      sortEl.appendChild(sortArrowEl);
    } else {
      sortEl = document.createElement('span');
      sortEl.setAttribute('data-dbsext-sort', '1');
      sortEl.textContent = ' ▲';
      sortEl.style.opacity = '0.3';
    }
    sortEl.addEventListener('click', function (e) {
      e.stopPropagation();
      if (typeof spec.onSort === 'function') spec.onSort();
    });

    // --- 絞り込み ---
    var filterWrap = document.createElement('div');
    filterWrap.className = 'dbsext-th-filters';

    var inputs = [];
    function notify() {
      if (typeof spec.onFilter === 'function') spec.onFilter(condition);
    }

    if (kind === FILTER_SELECT) {
      var select = document.createElement('select');
      select.setAttribute('data-dbsext-filter-select', '1');
      select.title = columnLabel + ' で絞り込み';
      select.addEventListener('click', function (e) { e.stopPropagation(); });
      select.addEventListener('keydown', function (e) { e.stopPropagation(); });

      var allOption = document.createElement('option');
      allOption.value = '';
      allOption.textContent = 'すべて';
      select.appendChild(allOption);

      // 重複は1つにまとめる。表示順は呼び出し側が渡した順のまま
      var seen = Object.create(null);
      for (var oi = 0; oi < spec.filterOptions.length; oi++) {
        var optValue = String(spec.filterOptions[oi]);
        if (seen[optValue]) continue;
        seen[optValue] = true;
        var opt = document.createElement('option');
        opt.value = optValue;
        opt.textContent = optValue;
        select.appendChild(opt);
      }

      select.addEventListener('change', function () { condition.text = select.value; notify(); });
      filterWrap.appendChild(select);
      inputs.push({ key: 'text', el: select });
    } else if (kind === FILTER_NUMBER) {
      // 「以上」「以下」の2欄。**空欄は「制限なし」**
      var minInput = makeInput('data-dbsext-filter-min', '以上', columnLabel + ' がこの値以上');
      var maxInput = makeInput('data-dbsext-filter-max', '以下', columnLabel + ' がこの値以下');
      minInput.addEventListener('input', function () { condition.min = minInput.value; notify(); });
      maxInput.addEventListener('input', function () { condition.max = maxInput.value; notify(); });
      filterWrap.appendChild(minInput);
      filterWrap.appendChild(maxInput);
      inputs.push({ key: 'min', el: minInput }, { key: 'max', el: maxInput });
    } else {
      var textInput = makeInput('data-dbsext-filter', '絞り込み', columnLabel + ' で絞り込み');
      textInput.addEventListener('input', function () { condition.text = textInput.value; notify(); });
      filterWrap.appendChild(textInput);
      inputs.push({ key: 'text', el: textInput });
    }

    return {
      sortEl: sortEl,
      sortArrowEl: sortArrowEl, // 'button'モードのみ。矢印だけを検証したいテスト用
      filterWrap: filterWrap,
      condition: condition,
      kind: kind,
      /** 状態側の値を入力欄へ反映する（再適用で作り直したときのため） */
      syncFromState: function (saved) {
        if (!saved) return;
        for (var i = 0; i < inputs.length; i++) {
          var key = inputs[i].key;
          var value = saved[key] === undefined || saved[key] === null ? '' : String(saved[key]);
          var el = inputs[i].el;
          if (el) {
            if (typeof document !== 'undefined' && document.activeElement === el) {
              if (el.value !== value) {
                var sStart = el.selectionStart;
                var sEnd = el.selectionEnd;
                el.value = value;
                try {
                  if (typeof sStart === 'number' && typeof sEnd === 'number') {
                    el.setSelectionRange(sStart, sEnd);
                  }
                } catch (e) {}
              }
            } else {
              if (el.value !== value) el.value = value;
            }
          }
          condition[key] = value;
        }
      },
      /** 並べ替えの表示を更新する。**働いていないときも矢印は薄く出す**（この列が
       * 並べ替え可能だと分かるように。indicatorモードは元からこの考え方だった） */
      updateSortIndicator: function (isActive, order) {
        if (spec.sortMode === 'button') {
          sortArrowEl.textContent = isActive ? (order === 'asc' ? ' ▲' : ' ▼') : ' ▲';
          sortArrowEl.style.opacity = isActive ? '1' : '0.3';
          return;
        }
        sortEl.textContent = isActive ? (order === 'asc' ? ' ▲' : ' ▼') : ' ▲';
        sortEl.style.opacity = isActive ? '1' : '0.3';
      }
    };
  }

  D.tableKit = {
    FILTER_TEXT: FILTER_TEXT,
    FILTER_NUMBER: FILTER_NUMBER,
    FILTER_SELECT: FILTER_SELECT,
    NUMERIC_COLUMN_HINTS: NUMERIC_COLUMN_HINTS,

    filterKindFor: filterKindFor,
    toNumber: toNumber,
    compare: compare,
    isNumericColumn: isNumericColumn,
    isPortColumn: isPortColumn,
    portSortKey: portSortKey,
    matchesFilter: matchesFilter,
    hasAnyCondition: hasAnyCondition,
    createState: createState,
    conditionFor: conditionFor,
    buildHeaderControls: buildHeaderControls
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
