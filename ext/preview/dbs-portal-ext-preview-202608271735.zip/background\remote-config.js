(function (global) {
  'use strict';

  var DBSEXT_REMOTE_CONFIG = {
    CHANNEL_NAME: 'preview',
    CHANNEL_LABEL: 'PREVIEW',
    // ECDSA P-256 (SPKI base64) 公開鍵。manifest.json の key とは別物。
    PUBLIC_KEY_SPKI_B64: 'MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEQmXj33c+OsMQ/CVxWQU6phCWTeviocT+We25Kgk4QKTGDgfwHlAtlESSVGUMV8uS7KF+9v1tCkgZQJ9Vq1d7pQ==',
    LATEST_URL: 'https://dontsu87.github.io/DBSgetdata/ext/preview/remote/latest.json',
    BASE_URL: 'https://dontsu87.github.io/DBSgetdata/ext/preview/remote/',
    USER_SCRIPT_ID: 'dbsext-remote-preview',
    USER_SCRIPT_MATCHES: ['https://mg.docomo-cycle.jp/*']
  };

  global.DBSEXT_REMOTE_CONFIG = DBSEXT_REMOTE_CONFIG;
})(typeof globalThis !== 'undefined' ? globalThis : self);
