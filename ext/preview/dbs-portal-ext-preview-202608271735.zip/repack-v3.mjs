import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '../..');
const distDir = path.resolve(projectRoot, 'dist/extension');
const KEY_PATH = path.resolve(projectRoot, 'dist/extension/dbs-portal-ext.pem');

// 既存のZIPを読み込む
const zipPath = process.argv[2];
if (!zipPath || !fs.existsSync(zipPath)) {
  console.error('ZIPファイルが指定されていないか存在しません:', zipPath);
  process.exit(1);
}

const zipData = fs.readFileSync(zipPath);
console.log('ZIP size:', (zipData.length / 1024).toFixed(1), 'KB');

// 鍵を読み込む
const pem = fs.readFileSync(KEY_PATH, 'utf-8');
const privKey = crypto.createPrivateKey(pem);
const pubKey = crypto.createPublicKey(privKey);
const publicKeyDer = pubKey.export({ type: 'spki', format: 'der' });

// V3形式でCRXを生成
const sign = crypto.createSign('RSA-SHA256');
sign.update(zipData);
const signature = sign.sign(privKey);

function encodeVarint(value) {
  const bytes = [];
  while (value > 0x7f) {
    bytes.push((value & 0x7f) | 0x80);
    value >>>= 7;
  }
  bytes.push(value & 0x7f);
  return Buffer.from(bytes);
}

function encodeField(fieldNumber, wireType, data) {
  const tag = encodeVarint((fieldNumber << 3) | wireType);
  if (wireType === 2) {
    const length = encodeVarint(data.length);
    return Buffer.concat([tag, length, data]);
  } else if (wireType === 0) {
    return Buffer.concat([tag, encodeVarint(data)]);
  }
  throw new Error('unsupported wire type');
}

const protoHeader = Buffer.concat([
  encodeField(1, 2, publicKeyDer),
  encodeField(2, 2, signature),
  encodeField(3, 0, 1)
]);

const header = Buffer.alloc(12 + protoHeader.length);
let offset = 0;

header.write('Cr24', offset, 4, 'ascii'); offset += 4;
header.writeUInt32LE(3, offset); offset += 4;
header.writeUInt32LE(protoHeader.length, offset); offset += 4;
protoHeader.copy(header, offset);

const crxData = Buffer.concat([header, zipData]);

const crxPath = path.join(distDir, 'dbs-portal-ext.crx');
fs.writeFileSync(crxPath, crxData);
console.log('CRX V3 生成完了:', crxPath);
console.log('サイズ:', (crxData.length / 1024).toFixed(1), 'KB');

// ヘッダーを検証
const magic = crxData.slice(0, 4).toString('ascii');
const version = crxData.readUInt32LE(4);
const protoLen = crxData.readUInt32LE(8);
console.log('マジック:', magic);
console.log('バージョン:', version);
console.log('protobuf長:', protoLen);