/**
 * 車種情報画面（/areas/vehicle-kinds）の初期表示
 *
 * この画面は開いた直後だと**何も表示されていない**。エリアを選んで「検索」を
 * 押して初めて中身が出る。エリアの選択肢が1つしかない利用者にとって、この
 * 操作は毎回同じ結果にしかならないため、拡張が代わりに済ませておく。
 *
 * ---------------------------------------------------------------------------
 * **選択肢がちょうど1つのときだけ**自動で選ぶ
 * ---------------------------------------------------------------------------
 * 2つ以上あるなら、どれを選ぶかは利用者の意思である。拡張が勝手に決めると
 * 「自分が選んだつもりのない範囲」を見せることになり、しかも画面上は
 * ふつうに検索済みに見えるため**間違いに気づけない**。
 * だから複数あるときは何もせず、開いた選択肢も**閉じて元の見た目に戻す**。
 *
 * 押すのは「検索」だけである。解錠・再配置・メンテナンス等の操作系には
 * 一切触れない（契約§6）。検索は読み取りであり、画面の状態も変えない。
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var TARGET_PATH = '/areas/vehicle-kinds';
  var DROPDOWN_MAX_ATTEMPTS = 30; // 30回 × 50ms = 1.5秒
  var AFTER_PICK_MS = 50;
  var HYDRATION_RETRY_MAX = 3;
  var HYDRATION_RETRY_DELAY_MS = 500;

  // 画面ごとに1回だけ試す。SPA遷移でこの画面へ入り直したときは再び試す
  var lastPath = null;
  var triedOnThisScreen = false;
  var running = false;
  var currentGeneration = 0;
  var pendingTimeouts = [];
  var autoSelectedName = null;
  var autoSelectionGuard = null;
  var hydrationRetryCount = 0;

  function clearAutoSelectionGuard() {
    var guard = autoSelectionGuard;
    autoSelectionGuard = null;
    if (!guard || !guard.select || typeof guard.select.removeEventListener !== 'function') return;
    for (var i = 0; i < guard.events.length; i++) {
      try { guard.select.removeEventListener(guard.events[i], guard.invalidate, true); } catch (e) {}
    }
  }

  function armAutoSelectionGuard(select, gen) {
    clearAutoSelectionGuard();
    var guard = { select: select, generation: gen, valid: true, events: ['click', 'input', 'change'] };
    guard.invalidate = function () { guard.valid = false; };
    if (select && typeof select.addEventListener === 'function') {
      for (var i = 0; i < guard.events.length; i++) {
        try { select.addEventListener(guard.events[i], guard.invalidate, true); } catch (e) {}
      }
    }
    autoSelectionGuard = guard;
  }

  function ownsAutoSelection(select, gen, name) {
    return !!(autoSelectionGuard && autoSelectionGuard.valid &&
      autoSelectionGuard.select === select && autoSelectionGuard.generation === gen &&
      autoSelectedName === name);
  }

  function log(message, isError) {
    if (D && D.core && typeof D.core.log === 'function') {
      D.core.log(message, isError);
    }
  }

  function currentPath() {
    if (typeof location === 'undefined' || !location.pathname) return '';
    return location.pathname.replace(/\/+$/, '') || '/';
  }

  function clearPendingTimeouts() {
    for (var i = 0; i < pendingTimeouts.length; i++) {
      try { clearTimeout(pendingTimeouts[i]); } catch (e) {}
    }
    pendingTimeouts = [];
  }

  function addTimeout(fn, delay) {
    var timerId;
    timerId = setTimeout(function () {
      var idx = pendingTimeouts.indexOf(timerId);
      if (idx >= 0) pendingTimeouts.splice(idx, 1);
      fn();
    }, delay);
    pendingTimeouts.push(timerId);
    return timerId;
  }

  function isNodeConnected(node) {
    if (!node) return false;
    if (typeof node.isConnected === 'boolean') return node.isConnected;
    if (typeof document !== 'undefined') {
      if (document.documentElement && typeof document.documentElement.contains === 'function') {
        return document.documentElement.contains(node);
      }
      if (document.body && typeof document.body.contains === 'function') {
        return document.body.contains(node);
      }
    }
    return true;
  }

  /**
   * 隠れている要素か。
   *
   * Element Plus は閉じた選択肢リストを DOM に残したまま隠す。
   * 隠れたリストを「開いている」と誤認すると、**見えていない選択肢を
   * クリックしてしまう**（＝利用者の意図しないエリアが適用される）。
   */
  function isHiddenElement(el) {
    for (var node = el; node; node = node.parentElement) {
      var style = node.style;
      if (style && (style.display === 'none' || style.visibility === 'hidden')) return true;
      if (typeof getComputedStyle === 'function') {
        var cs = getComputedStyle(node);
        if (cs && (cs.display === 'none' || cs.visibility === 'hidden')) return true;
      }
    }
    if (typeof el.getBoundingClientRect === 'function') {
      var rect = el.getBoundingClientRect();
      if (rect && rect.width === 0 && rect.height === 0) return true;
    }
    return false;
  }

  function visibleAll(selector) {
    if (typeof document === 'undefined') return [];
    var nodes = document.querySelectorAll(selector);
    var out = [];
    for (var i = 0; i < nodes.length; i++) {
      if (!isHiddenElement(nodes[i])) out.push(nodes[i]);
    }
    return out;
  }

  /** 開いている選択肢リスト（Element Plus は body 直下へ出す） */
  function getVisibleDropdowns() {
    return visibleAll('.el-select-dropdown');
  }

  function labelTextOf(select) {
    var item = (typeof select.closest === 'function') ? select.closest('.el-form-item') : null;
    if (!item) return '';
    var label = item.querySelector('.el-form-item__label');
    return label ? (label.textContent || '').trim() : '';
  }

  /**
   * エリアの選択欄を取る。
   *
   * 実測ではこの画面の選択欄は1つだけである。**複数見えたときは、
   * エリアだと確信できるものが無い限り触らない。**別の条件欄を勝手に
   * 変えるくらいなら、何もしない方がよい。
   */
  function getAreaSelect() {
    var selects = visibleAll('.el-select');
    if (selects.length === 0) return null;
    if (selects.length === 1) return selects[0];
    for (var i = 0; i < selects.length; i++) {
      if (labelTextOf(selects[i]).indexOf('エリア') >= 0) return selects[i];
    }
    return null;
  }

  function getTrigger(select) {
    return select.querySelector('.el-select__wrapper') ||
      select.querySelector('.el-input__wrapper') ||
      select.querySelector('input') ||
      select;
  }

  /** すでに何か選ばれているか（利用者が選んだものを上書きしない） */
  function hasSelectedValue(select) {
    var picked = select.querySelector('.el-select__selected-item, .el-select__tags-text');
    if (picked && (picked.textContent || '').trim()) return true;
    var input = select.querySelector('input');
    if (input && typeof input.value === 'string' && input.value.trim()) return true;
    return false;
  }

  function selectedValueText(select) {
    var picked = select.querySelector('.el-select__selected-item, .el-select__tags-text');
    if (picked && (picked.textContent || '').trim()) return (picked.textContent || '').trim();
    var input = select.querySelector('input');
    return input && typeof input.value === 'string' ? input.value.trim() : '';
  }

  /** 選べる選択肢だけを返す（無効・非表示は除く） */
  function getSelectableOptions(dropdown) {
    var items = dropdown.querySelectorAll('.el-select-dropdown__item');
    var out = [];
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      if (item.classList && item.classList.contains('is-disabled')) continue;
      if (isHiddenElement(item)) continue;
      out.push(item);
    }
    return out;
  }

  function getSearchButton() {
    if (typeof document === 'undefined') return null;
    var buttons = document.querySelectorAll('button');
    for (var i = 0; i < buttons.length; i++) {
      var btn = buttons[i];
      if ((btn.textContent || '').trim() !== '検索') continue;
      if (btn.disabled) continue;
      if (isHiddenElement(btn)) continue;
      return btn;
    }
    return null;
  }

  /** すでに検索済み（表が出ている）なら触らない */
  function alreadySearched() {
    if (typeof document === 'undefined') return false;
    var tables = document.querySelectorAll('.el-table');
    for (var i = 0; i < tables.length; i++) {
      if (tables[i].querySelectorAll('tbody tr').length > 0) return true;
    }
    return false;
  }

  function finishSuccess(gen) {
    if (gen === currentGeneration) {
      running = false;
      triedOnThisScreen = true;
      clearAutoSelectionGuard();
    }
  }

  function finishFailure(gen, preserveAutoSelection) {
    if (gen === currentGeneration) {
      running = false;
      triedOnThisScreen = false;
      clearPendingTimeouts();
      if (!preserveAutoSelection) {
        autoSelectedName = null;
        clearAutoSelectionGuard();
      }
    }
  }

  function safeClick(node, desc) {
    try {
      if (node && typeof node.click === 'function') {
        node.click();
        return true;
      }
    } catch (e) {
      log('車種情報: ' + desc + 'のクリックに失敗しました: ' + (e && e.message ? e.message : e), true);
      return false;
    }
    log('車種情報: ' + desc + 'のクリック要素が無効です', true);
    return false;
  }

  /** 選択肢リストが開いたあとの処理 */
  function onDropdownReady(gen, select, trigger, dropdown) {
    if (gen !== currentGeneration || currentPath() !== TARGET_PATH) {
      finishFailure(gen);
      return;
    }
    if (!isNodeConnected(select) || !isNodeConnected(trigger) || !isNodeConnected(dropdown)) {
      finishFailure(gen);
      return;
    }

    var options = getSelectableOptions(dropdown);

    if (options.length !== 1) {
      // **開けたままにしない。** 利用者から見て「勝手に何か開いた」状態を残さない
      if (!safeClick(trigger, '選択肢閉じトリガー')) {
        finishFailure(gen);
        return;
      }
      log('車種情報: エリアの選択肢が' + options.length + '件のため自動選択しません');
      finishSuccess(gen);
      return;
    }

    var name = (options[0].textContent || '').trim();
    if (!safeClick(options[0], '選択肢')) {
      finishFailure(gen);
      return;
    }
    autoSelectedName = name;
    armAutoSelectionGuard(select, gen);

    addTimeout(function () {
      if (gen !== currentGeneration || currentPath() !== TARGET_PATH) {
        finishFailure(gen);
        return;
      }
      if (!isNodeConnected(select) || !isNodeConnected(trigger) || !isNodeConnected(dropdown)) {
        finishFailure(gen);
        return;
      }
      if (!ownsAutoSelection(select, gen, name)) {
        finishFailure(gen);
        return;
      }
      var btn = getSearchButton();
      if (!btn || !isNodeConnected(btn)) {
        log('車種情報: 検索ボタンが見つからないため、選択のみで止めました', true);
        finishFailure(gen, true);
        return;
      }
      if (safeClick(btn, '検索ボタン')) {
        log('車種情報: エリア「' + name + '」を選んで検索しました');
        finishSuccess(gen);
      } else {
        finishFailure(gen, true);
      }
    }, AFTER_PICK_MS);
  }

  function openAndPick(gen, select) {
    var before = getVisibleDropdowns();
    var trigger = getTrigger(select);
    if (!trigger || !safeClick(trigger, '開くトリガー')) {
      finishFailure(gen);
      return;
    }

    var attempts = 0;
    function poll() {
      if (gen !== currentGeneration || currentPath() !== TARGET_PATH) {
        finishFailure(gen);
        return;
      }
      if (!isNodeConnected(select) || !isNodeConnected(trigger)) {
        finishFailure(gen);
        return;
      }

      attempts++;
      var now = getVisibleDropdowns();
      var found = null;
      for (var i = 0; i < now.length; i++) {
        if (before.indexOf(now[i]) < 0) { found = now[i]; break; }
      }
      // 既存のリストが再利用されることもある。1つしか見えていないならそれで確定
      if (!found && now.length === 1) found = now[0];

      if (found) {
        onDropdownReady(gen, select, trigger, found);
        return;
      }
      if (attempts < DROPDOWN_MAX_ATTEMPTS) {
        addTimeout(poll, 50);
        return;
      }
      if (hydrationRetryCount < HYDRATION_RETRY_MAX - 1) {
        // 初期水和前のクリックは例外なしで無視されることがある。同じ画面・同じ世代で
        // 有限回だけ待って再試行し、利用者操作や常駐pollにはしない。
        hydrationRetryCount++;
        running = false;
        triedOnThisScreen = false;
        addTimeout(function () {
          if (gen === currentGeneration && currentPath() === TARGET_PATH) D.vehicleKinds.apply();
        }, HYDRATION_RETRY_DELAY_MS);
      } else {
        // 一時的な水和遅延は想定内。有限回すべて失敗した場合だけ警告する。
        log('車種情報: 選択肢が開かなかったため何もしません', true);
        finishFailure(gen);
      }
    }

    addTimeout(poll, 50);
  }

  D.vehicleKinds = {
    apply: function () {
      var path = currentPath();
      if (lastPath !== path) {
        lastPath = path;
        triedOnThisScreen = false;
        currentGeneration++;
        clearPendingTimeouts();
        running = false;
        autoSelectedName = null;
        hydrationRetryCount = 0;
        clearAutoSelectionGuard();
      }
      if (path !== TARGET_PATH) return;
      if (triedOnThisScreen || running) return;
      if (typeof document === 'undefined' || !document.body) return;

      // すでに結果が出ているなら用は無い
      if (alreadySearched()) {
        triedOnThisScreen = true;
        return;
      }

      var select = getAreaSelect();
      // まだ描画されていないだけかもしれない。次の変化で改めて試す
      if (!select) return;

      if (hasSelectedValue(select)) {
        // この世代で拡張自身が選んだ値だけは、直前の検索失敗から再試行する。
        // 利用者が選んだ値や別の値は従来どおり一切自動検索しない。
        if (autoSelectedName && ownsAutoSelection(select, currentGeneration, autoSelectedName)) {
          var retryGen = currentGeneration;
          running = true;
          triedOnThisScreen = true;
          addTimeout(function () {
            if (retryGen !== currentGeneration || currentPath() !== TARGET_PATH || !isNodeConnected(select)) {
              finishFailure(retryGen);
              return;
            }
            if (!ownsAutoSelection(select, retryGen, autoSelectedName)) {
              finishFailure(retryGen);
              return;
            }
            var retryButton = getSearchButton();
            if (!retryButton || !isNodeConnected(retryButton) || !safeClick(retryButton, '検索ボタン')) {
              finishFailure(retryGen, true);
              return;
            }
            log('車種情報: エリア「' + autoSelectedName + '」の検索を再試行しました');
            finishSuccess(retryGen);
          }, AFTER_PICK_MS);
          return;
        }
        triedOnThisScreen = true;
        return;
      }

      // 利用者が自分で選択肢を開いている最中に割り込まない
      if (getVisibleDropdowns().length > 0) return;

      triedOnThisScreen = true;
      running = true;
      openAndPick(currentGeneration, select);
    },

    _reset: function () {
      lastPath = null;
      triedOnThisScreen = false;
      running = false;
      currentGeneration++;
      autoSelectedName = null;
      hydrationRetryCount = 0;
      clearAutoSelectionGuard();
      clearPendingTimeouts();
    },
    _state: function () {
      return { lastPath: lastPath, tried: triedOnThisScreen, running: running, generation: currentGeneration };
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
