(function (global) {
  'use strict';
  global.DBSEXT_DIAGNOSTICS_CONFIG = Object.freeze({
    enabled: false,
    killSwitch: true,
    channel: 'preview',
    endpoint: 'https://dontsu87.github.io/DBSgetdata/ext/preview/diagnostics'
  });
})(typeof globalThis !== 'undefined' ? globalThis : self);
