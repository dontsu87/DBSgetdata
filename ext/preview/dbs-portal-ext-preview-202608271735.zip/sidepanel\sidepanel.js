(function () {
  'use strict';

  var ALLOWED_PREFIX = 'https://dontsu87.github.io/';

  var iframeEl = document.getElementById('map');
  var statusContainerEl = document.getElementById('status-container');
  var statusMessageEl = document.getElementById('status-message');
  var spinnerEl = document.getElementById('spinner');
  var diagnosticStatusEl = document.getElementById('diagnostic-consent-status');

  function refreshDiagnosticConsent() {
    chrome.runtime.sendMessage({ type: 'dbsext:diagnosticConsentGet' }, function (result) {
      var state = result && result.state;
      if (diagnosticStatusEl) diagnosticStatusEl.textContent = state === 'accepted' ? '同意済み' : state === 'declined' ? '送信しない' : '未選択';
    });
  }

  function setDiagnosticConsent(state) {
    chrome.runtime.sendMessage({ type: 'dbsext:diagnosticConsentSet', state: state }, refreshDiagnosticConsent);
  }

  var acceptEl = document.getElementById('diagnostic-accept');
  var declineEl = document.getElementById('diagnostic-decline');
  if (acceptEl) acceptEl.addEventListener('click', function () { setDiagnosticConsent('accepted'); });
  if (declineEl) declineEl.addEventListener('click', function () { setDiagnosticConsent('declined'); });

  function updateMapUrl(url) {
    if (!url) {
      if (spinnerEl) spinnerEl.style.display = 'none';
      if (statusMessageEl) statusMessageEl.textContent = '左メニューの「バッテリーマップを開く」から起動してください。';
      if (statusContainerEl) statusContainerEl.style.display = 'flex';
      if (iframeEl) {
        iframeEl.style.display = 'none';
        iframeEl.src = '';
      }
      return;
    }

    if (typeof url !== 'string' || url.indexOf(ALLOWED_PREFIX) !== 0) {
      if (spinnerEl) spinnerEl.style.display = 'none';
      if (statusMessageEl) statusMessageEl.textContent = 'エラー: 許可されていないURLです。';
      if (statusContainerEl) statusContainerEl.style.display = 'flex';
      if (iframeEl) {
        iframeEl.style.display = 'none';
        iframeEl.src = '';
      }
      return;
    }

    if (statusContainerEl) statusContainerEl.style.display = 'none';
    if (iframeEl) {
      iframeEl.src = url;
      iframeEl.style.display = 'block';
    }
  }

  function loadInitialUrl() {
    chrome.storage.session.get('dbsextMapUrl', function (data) {
      var err = chrome.runtime.lastError;
      if (err) {
        if (spinnerEl) spinnerEl.style.display = 'none';
        if (statusMessageEl) statusMessageEl.textContent = '設定の読み込み中にエラーが発生しました。';
        return;
      }
      var url = data ? data.dbsextMapUrl : null;
      updateMapUrl(url);
    });
  }

  chrome.storage.session.onChanged.addListener(function (changes) {
    if (changes && changes.dbsextMapUrl) {
      updateMapUrl(changes.dbsextMapUrl.newValue);
    }
  });

  document.addEventListener('DOMContentLoaded', function () { loadInitialUrl(); refreshDiagnosticConsent(); });
})();
