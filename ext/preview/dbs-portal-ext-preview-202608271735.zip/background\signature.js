(function (global) {
  'use strict';

  /**
   * base64 文字列をバイト配列（Uint8Array）に変換する。
   * 不正な文字列や変換エラー時は null を返し例外を投げない。
   *
   * @param {string} b64
   * @returns {Uint8Array|null}
   */
  function base64ToBytes(b64) {
    if (typeof b64 !== 'string') return null;
    var clean = b64.replace(/\s+/g, '');
    if (!clean) return null;
    // base64 パターンの基本チェック
    if (!/^[A-Za-z0-9+/]+={0,2}$/.test(clean) || clean.length % 4 !== 0) {
      return null;
    }
    try {
      if (typeof Buffer !== 'undefined') {
        return new Uint8Array(Buffer.from(clean, 'base64'));
      }
      var bin = atob(clean);
      var bytes = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) {
        bytes[i] = bin.charCodeAt(i);
      }
      return bytes;
    } catch (e) {
      return null;
    }
  }

  var DBSEXT_SIGNATURE = {
    /**
     * ECDSA P-256 / SHA-256 署名を検証する（共有コード）。
     * Node のテスト環境および Chrome 拡張の service worker の両方で動作する。
     *
     * 署名対象ペイロード:
     *   "dbsext-remote-v1\n" + version + "\n" + minExtensionVersion + "\n" + bundleText
     *
     * 例外は一切投げず、検証に成功した場合のみ true、それ以外はすべて false を返す。
     *
     * @param {string} publicKeySpkiB64 - SPKI 形式の公開鍵 (base64)
     * @param {string} version - バージョン文字列 (YYYYMMDDHHmm)
     * @param {string} minExtensionVersion - 要求最小拡張バージョン
     * @param {string|Uint8Array} bundleText - 署名対象のバンドル本文 (UTF-8文字列またはバイト列)
     * @param {string} signatureB64 - ECDSA P-256 署名 (IEEE P1363 64バイト, base64)
     * @returns {Promise<boolean>}
     */
    verify: async function (publicKeySpkiB64, version, minExtensionVersion, bundleText, signatureB64) {
      try {
        if (typeof publicKeySpkiB64 !== 'string' || typeof signatureB64 !== 'string') {
          return false;
        }
        if (typeof version !== 'string' || typeof minExtensionVersion !== 'string') {
          return false;
        }
        if (bundleText === null || bundleText === undefined) {
          return false;
        }

        var keyBytes = base64ToBytes(publicKeySpkiB64);
        var sigBytes = base64ToBytes(signatureB64);
        if (!keyBytes || !sigBytes) {
          return false;
        }

        // ECDSA P-256 (IEEE P1363) 署名は 64 バイト (r: 32 bytes, s: 32 bytes)
        if (sigBytes.length !== 64) {
          return false;
        }

        var cryptoObj = (typeof crypto !== 'undefined' && crypto.subtle)
          ? crypto
          : ((typeof globalThis !== 'undefined' && globalThis.crypto && globalThis.crypto.subtle)
              ? globalThis.crypto
              : null);

        if (!cryptoObj || !cryptoObj.subtle) {
          return false;
        }

        var key = await cryptoObj.subtle.importKey(
          'spki',
          keyBytes,
          {
            name: 'ECDSA',
            namedCurve: 'P-256'
          },
          false,
          ['verify']
        );

        var text;
        if (typeof bundleText === 'string') {
          text = bundleText;
        } else if (bundleText instanceof Uint8Array || (typeof Buffer !== 'undefined' && Buffer.isBuffer(bundleText))) {
          text = new TextDecoder('utf-8').decode(bundleText);
        } else {
          text = String(bundleText);
        }

        var payload = 'dbsext-remote-v1\n' + version + '\n' + minExtensionVersion + '\n' + text;
        var dataBytes = new TextEncoder().encode(payload);

        var isValid = await cryptoObj.subtle.verify(
          {
            name: 'ECDSA',
            hash: { name: 'SHA-256' }
          },
          key,
          sigBytes,
          dataBytes
        );

        return Boolean(isValid);
      } catch (e) {
        return false;
      }
    }
  };

  global.DBSEXT_SIGNATURE = DBSEXT_SIGNATURE;
})(typeof globalThis !== 'undefined' ? globalThis : self);

