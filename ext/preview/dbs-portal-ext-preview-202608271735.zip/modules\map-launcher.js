/**
 * DBSEXT マップ導線モジュール
 * 左メニューにバッテリーマップ起動ボタンを追加し、画面中央にモーダルパネル（Shadow DOM）を開く
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var currentPanelHost = null;

  // ログイン中アカウントの対象エリア確認の進行状況。
  //   null        … 未確認（次の apply() で確認を開始する）
  //   'pending'   … 確認中（D.areas.load() の完了待ち）
  //   'supported' … 対応エリアあり、または確認不能につき安全側でボタンを出す
  //   'unsupported' … 対応エリアが1つも無いことを確認済み、ボタンを出さない
  var areaCheckState = null;

  function isOriginalViewActive() {
    if (!D.originalView) return false;
    if (typeof D.originalView.isActive === 'function' && D.originalView.isActive()) return true;
    if (typeof D.originalView._isActive === 'function' && D.originalView._isActive()) return true;
    return false;
  }

  function closePanel() {
    if (currentPanelHost && currentPanelHost.parentNode) {
      currentPanelHost.parentNode.removeChild(currentPanelHost); // dbsext:own-ui
    }
    currentPanelHost = null;
  }

  function createLauncherPanel() {
    closePanel();
    if (isOriginalViewActive()) return;

    var host = document.createElement('div');
    host.setAttribute('data-dbsext-launcher-panel', '1');
    currentPanelHost = host;

    var shadow = host.attachShadow ? host.attachShadow({ mode: 'open' }) : host;

    // オーバーレイ背景
    var overlay = document.createElement('div');
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100vw';
    overlay.style.height = '100vh';
    overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
    overlay.style.zIndex = '999999';
    overlay.style.display = 'flex';
    overlay.style.alignItems = 'center';
    overlay.style.justifyContent = 'center';
    overlay.style.boxSizing = 'border-box';
    overlay.style.padding = '16px';

    // モーダルカード
    var card = document.createElement('div');
    card.style.backgroundColor = '#ffffff';
    card.style.borderRadius = '8px';
    card.style.padding = '24px';
    card.style.maxWidth = '480px';
    card.style.width = '100%';
    card.style.boxShadow = '0 10px 25px rgba(0, 0, 0, 0.2)';
    card.style.fontFamily = 'sans-serif';
    card.style.color = '#333333';
    card.style.boxSizing = 'border-box';

    // カードクリックでオーバーレイ閉じるイベントを発火させない
    card.addEventListener('click', function (e) {
      e.stopPropagation();
    });

    // オーバーレイのクリックで閉じる
    overlay.addEventListener('click', function () {
      closePanel();
    });

    // ヘッダー
    var header = document.createElement('div');
    header.style.display = 'flex';
    header.style.justifyContent = 'space-between';
    header.style.alignItems = 'center';
    header.style.marginBottom = '16px';

    var title = document.createElement('h3');
    title.textContent = 'バッテリーマップ';
    title.style.margin = '0';
    title.style.fontSize = '18px';
    title.style.fontWeight = 'bold';
    title.style.color = (D.CONFIG && D.CONFIG.ACCENT) || '#0b5cab';

    var closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.textContent = '✕';
    closeBtn.style.background = 'none';
    closeBtn.style.border = 'none';
    closeBtn.style.fontSize = '18px';
    closeBtn.style.cursor = 'pointer';
    closeBtn.style.color = '#666666';
    closeBtn.addEventListener('click', closePanel);

    header.appendChild(title);
    header.appendChild(closeBtn);
    card.appendChild(header);

    // エリア表示セクション
    var areaSection = document.createElement('div');
    areaSection.style.marginBottom = '20px';
    areaSection.style.padding = '12px';
    areaSection.style.backgroundColor = '#f5f7fa';
    areaSection.style.borderRadius = '6px';
    areaSection.style.fontSize = '14px';

    var areaText = document.createElement('div');
    areaText.textContent = 'エリアを判定中…';
    areaSection.appendChild(areaText);

    var manualAreaContainer = document.createElement('div');
    manualAreaContainer.style.marginTop = '10px';
    manualAreaContainer.style.display = 'none';
    areaSection.appendChild(manualAreaContainer);

    card.appendChild(areaSection);

    // 表示タイプ3ボタンセクション（横並び）
    var btnContainer = document.createElement('div');
    btnContainer.style.display = 'flex';
    btnContainer.style.gap = '8px';
    btnContainer.style.marginBottom = '20px';

    var tabBtn = document.createElement('button');
    tabBtn.type = 'button';
    tabBtn.textContent = '別タブで開く';
    styleActionButton(tabBtn);

    var splitBtn = document.createElement('button');
    splitBtn.type = 'button';
    splitBtn.textContent = '横に並べて表示';
    styleActionButton(splitBtn);

    var qrBtn = document.createElement('button');
    qrBtn.type = 'button';
    qrBtn.textContent = 'スマホ・タブレットで開く';
    styleActionButton(qrBtn);

    btnContainer.appendChild(tabBtn);
    btnContainer.appendChild(splitBtn);
    btnContainer.appendChild(qrBtn);
    card.appendChild(btnContainer);

    // QR表示セクション
    var qrSection = document.createElement('div');
    qrSection.style.display = 'none';
    qrSection.style.textAlign = 'center';
    qrSection.style.padding = '12px';
    qrSection.style.borderTop = '1px solid #eeeeee';

    var qrImg = document.createElement('img');
    qrImg.style.width = '220px';
    qrImg.style.height = '220px';
    qrImg.style.display = 'block';
    qrImg.style.margin = '0 auto 8px auto';
    qrImg.alt = 'QR Code';

    var qrErrorText = document.createElement('div');
    qrErrorText.style.color = '#d9534f';
    qrErrorText.style.fontSize = '13px';
    qrErrorText.style.marginBottom = '8px';
    qrErrorText.style.display = 'none';

    var urlText = document.createElement('div');
    urlText.style.fontSize = '12px';
    urlText.style.color = '#666666';
    urlText.style.wordBreak = 'break-all';

    qrSection.appendChild(qrImg);
    qrSection.appendChild(qrErrorText);
    qrSection.appendChild(urlText);
    card.appendChild(qrSection);

    overlay.appendChild(card);
    shadow.appendChild(overlay);

    document.body.appendChild(host);

    // Escape キーでのパネル閉じ
    function onKeyDown(e) {
      if (e.key === 'Escape' || e.keyCode === 27) {
        closePanel();
        window.removeEventListener('keydown', onKeyDown);
      }
    }
    window.addEventListener('keydown', onKeyDown);

    // 現在のターゲットURL保持
    var currentMapUrl = (D.areas && typeof D.areas.buildMapUrl === 'function')
      ? D.areas.buildMapUrl([])
      : ((D.CONFIG && D.CONFIG.MAP_APP_URL) || 'https://dontsu87.github.io/DBSgetdata/');

    function updateUrlAndQr(url) {
      currentMapUrl = url;

      // url が null＝表示範囲が確定していない。
      // 権限を確認できていない状態で全エリアを開かせないため、3つのボタンを無効にする。
      var ready = typeof url === 'string' && url.length > 0;
      setActionsEnabled(ready);

      if (!ready) {
        urlText.textContent = 'エリアを選ぶとURLが決まります';
        qrImg.style.display = 'none';
        qrErrorText.textContent = 'エリアを選んでください';
        qrErrorText.style.display = 'block';
        return;
      }

      urlText.textContent = url;

      if (D.qr && typeof D.qr.toDataUrl === 'function') {
        var dataUrl = D.qr.toDataUrl(url, 220);
        if (dataUrl) {
          qrImg.src = dataUrl;
          qrImg.style.display = 'block';
          qrErrorText.style.display = 'none';
        } else {
          qrImg.style.display = 'none';
          qrErrorText.textContent = 'QRコードを生成できませんでした';
          qrErrorText.style.display = 'block';
        }
      } else {
        qrImg.style.display = 'none';
        qrErrorText.textContent = 'QRコードを生成できませんでした';
        qrErrorText.style.display = 'block';
      }
    }

    /** 表示範囲が確定していないあいだ、3つのボタンを押せなくする */
    function setActionsEnabled(enabled) {
      var buttons = [tabBtn, splitBtn, qrBtn];
      for (var i = 0; i < buttons.length; i++) {
        buttons[i].disabled = !enabled;
        buttons[i].style.opacity = enabled ? '1' : '0.45';
        buttons[i].style.cursor = enabled ? 'pointer' : 'not-allowed';
        buttons[i].title = enabled ? '' : 'エリアを選ぶと押せます';
      }
    }

    /** URLが未確定なら何もしない（権限未確認で全エリアを開かせない） */
    function hasUrl() {
      return typeof currentMapUrl === 'string' && currentMapUrl.length > 0;
    }

    // ボタンのイベントハンドラ
    tabBtn.addEventListener('click', function () {
      if (!hasUrl()) return;
      if (D.platform && typeof D.platform.openTab === 'function') {
        D.platform.openTab(currentMapUrl);
      }
      closePanel();
    });

    splitBtn.addEventListener('click', function () {
      if (!hasUrl()) return;
      if (D.platform && typeof D.platform.openSplit === 'function') {
        D.platform.openSplit(currentMapUrl);
      }
      closePanel();
    });

    qrBtn.addEventListener('click', function () {
      if (!hasUrl()) return;
      qrSection.style.display = 'block';
    });

    // 非同期でエリア情報をロード
    if (D.areas && typeof D.areas.load === 'function') {
      D.areas.load().then(function (res) {
        if (!currentPanelHost) return; // ロード完了前に閉じた場合

        if (res && res.ok) {
          var targetUrl = res.url || D.areas.buildMapUrl(res.areas);
          if (!targetUrl) {
            // 取得は成功したがエリア名が1つも取れなかった場合も手動選択にする
            showManualAreaSelection();
            return;
          }
          updateUrlAndQr(targetUrl);

          if (targetUrl.indexOf('?kanriall') !== -1) {
            areaText.textContent = '表示範囲: 全エリア';
          } else if (res.areas && res.areas.length > 0) {
            var names = [];
            for (var i = 0; i < res.areas.length; i++) {
              var a = res.areas[i];
              var name = typeof a === 'string' ? a : (a && a.areaName ? a.areaName : '');
              if (name && names.indexOf(name) === -1) {
                names.push(name);
              }
            }
            var codeToName2 = (D.CONFIG && D.CONFIG.AREA_CODE_TO_NAME) ? D.CONFIG.AREA_CODE_TO_NAME : {};
            var displayNames = [];
            for (var ni = 0; ni < names.length; ni++) {
              var cn = codeToName2[names[ni]];
              displayNames.push(cn ? names[ni] + ' ' + cn : names[ni]);
            }
            areaText.textContent = '表示範囲: ' + displayNames.join(', ');
          } else {
            showManualAreaSelection();
          }
        } else {
          showManualAreaSelection();
        }
      }).catch(function () {
        if (currentPanelHost) {
          showManualAreaSelection();
        }
      });
    } else {
      showManualAreaSelection();
    }

    function showManualAreaSelection() {
      areaText.textContent = 'エリアを自動判定できませんでした。手動で選んでください';
      manualAreaContainer.innerHTML = '';
      manualAreaContainer.style.display = 'block';

      var knownCodes = (D.CONFIG && D.CONFIG.KNOWN_AREA_CODES)
        ? D.CONFIG.KNOWN_AREA_CODES
        : ['FKI', 'KMT', 'KNZ', 'SNN', 'SPS', 'TRG'];
      var codeToName = (D.CONFIG && D.CONFIG.AREA_CODE_TO_NAME)
        ? D.CONFIG.AREA_CODE_TO_NAME
        : { FKI: '福井', KMT: '小松', KNZ: '金沢', SNN: '上田千曲広域', SPS: '出雲・松江・境港', TRG: '敦賀' };

      var selectedMap = {};

      var checkboxesDiv = document.createElement('div');
      checkboxesDiv.style.display = 'flex';
      checkboxesDiv.style.flexWrap = 'wrap';
      checkboxesDiv.style.gap = '8px';
      checkboxesDiv.style.marginTop = '8px';

      for (var j = 0; j < knownCodes.length; j++) {
        (function (areaCode) {
          var label = document.createElement('label');
          label.style.fontSize = '13px';
          label.style.cursor = 'pointer';
          label.style.display = 'inline-flex';
          label.style.alignItems = 'center';
          label.style.gap = '4px';

          var chk = document.createElement('input');
          chk.type = 'checkbox';
          chk.value = areaCode;
          chk.addEventListener('change', function () {
            if (chk.checked) {
              selectedMap[areaCode] = true;
            } else {
              delete selectedMap[areaCode];
            }
            var selectedList = [];
            for (var k = 0; k < knownCodes.length; k++) {
              if (selectedMap[knownCodes[k]]) {
                selectedList.push(knownCodes[k]);
              }
            }
            var newUrl = D.areas.buildMapUrl(selectedList);
            updateUrlAndQr(newUrl);
          });

          label.appendChild(chk);
          var displayName = (codeToName[areaCode] || areaCode);
          label.appendChild(document.createTextNode(areaCode + ' ' + displayName));
          checkboxesDiv.appendChild(label);
        })(knownCodes[j]);
      }

      manualAreaContainer.appendChild(checkboxesDiv);
      // 何も選ばれていない状態では URL を確定させない（buildMapUrl([]) は null を返す）。
      // 全エリアへ落とすと、権限未確認のまま全件を開いてしまう。
      updateUrlAndQr(D.areas.buildMapUrl([]));
    }
  }

  function styleActionButton(btn) {
    btn.style.flex = '1';
    btn.style.padding = '8px 12px';
    btn.style.backgroundColor = '#ffffff';
    btn.style.color = (D.CONFIG && D.CONFIG.ACCENT) || '#0b5cab';
    btn.style.border = '1px solid ' + ((D.CONFIG && D.CONFIG.ACCENT) || '#0b5cab');
    btn.style.borderRadius = '4px';
    btn.style.fontSize = '12px';
    btn.style.fontWeight = 'bold';
    btn.style.cursor = 'pointer';
    btn.style.transition = 'all 0.2s ease';

    btn.addEventListener('mouseenter', function () {
      btn.style.backgroundColor = (D.CONFIG && D.CONFIG.ACCENT) || '#0b5cab';
      btn.style.color = '#ffffff';
    });
    btn.addEventListener('mouseleave', function () {
      btn.style.backgroundColor = '#ffffff';
      btn.style.color = (D.CONFIG && D.CONFIG.ACCENT) || '#0b5cab';
    });
  }

  // ---------------------------------------------------------------------------
  // 起動ボタンは **document.body 直下の固定要素** にする
  //
  // 以前は左メニュー（`a[href="/vehicles"]` から辿ったコンテナ）へ appendChild していたが、
  // **表示されないことがある**と現場から報告があった。原因は次のとおり:
  //
  //   - `core.js` の onContentChange に登録されているのは tableWrap / uiTweaks / tableTools
  //     の3つだけで、**mapLauncher は boot() 時の1回しか走らない**
  //   - Vue が左メニューを再描画すると挿入したボタンは消え、**二度と戻らない**
  //
  // 右下の upsell パネルが消えないのは body 直下にあり Vue の管理外だからである。
  // 同じ作りにすれば、ポータルがどう再描画しても影響を受けない。
  // 位置は人間の指定どおり **左下**（右下の upsell と重ならない）。
  // ---------------------------------------------------------------------------

  var LAUNCHER_ATTR = 'data-dbsext-launcher';

  function buildLauncher() {
    var host = document.createElement('div');
    host.setAttribute(LAUNCHER_ATTR, '1');
    host.style.cssText = [
      'position:fixed',
      'left:12px',
      'bottom:12px',
      'z-index:2147483000',
      'width:auto'
    ].join(';');

    var shadow = host.attachShadow ? host.attachShadow({ mode: 'open' }) : null;
    var root = shadow || host;

    var accent = (D.CONFIG && D.CONFIG.ACCENT) || '#0b5cab';
    var accentDark = (D.CONFIG && D.CONFIG.ACCENT_DARK) || '#083f75';

    if (shadow) {
      var style = document.createElement('style');
      style.textContent = [
        ':host { all: initial; }',
        'button {',
        '  font: bold 14px/1.4 system-ui, -apple-system, "Segoe UI", sans-serif;',
        '  padding: 12px 18px;',
        '  background: ' + accent + ';',
        '  color: #fff;',
        '  border: none;',
        '  border-radius: 8px;',
        '  cursor: pointer;',
        '  box-shadow: 0 4px 14px rgba(0,0,0,.3);',
        '  white-space: nowrap;',
        '}',
        'button:hover { background: ' + accentDark + '; }'
      ].join('\n');
      root.appendChild(style);
    }

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = '🔋 バッテリーマップを開く';
    if (!shadow) {
      // Shadow DOM が使えない環境への退避（ポータルCSSの影響を受けうる）
      btn.style.cssText = 'font:bold 14px system-ui;padding:12px 18px;background:' + accent +
        ';color:#fff;border:none;border-radius:8px;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.3)';
    }
    btn.addEventListener('click', function () {
      createLauncherPanel();
    });
    root.appendChild(btn);

    return host;
  }

  function isBatteryLauncherPresent() {
    if (typeof document === 'undefined') return false;
    if (typeof document.querySelector === 'function') {
      if (document.querySelector('[' + LAUNCHER_ATTR + '="1"]')) return true;
    }
    if (typeof document.querySelectorAll === 'function') {
      var all = document.querySelectorAll('[' + LAUNCHER_ATTR + ']');
      for (var i = 0; i < all.length; i++) {
        if (all[i].getAttribute(LAUNCHER_ATTR) === '1') return true;
      }
    }
    return false;
  }

  function cleanupBatteryLauncherUI() {
    closePanel();
    if (typeof document === 'undefined' || typeof document.querySelectorAll !== 'function') return;
    var all = document.querySelectorAll('[' + LAUNCHER_ATTR + ']');
    for (var i = 0; i < all.length; i++) {
      if (all[i].getAttribute(LAUNCHER_ATTR) === '1' && all[i].parentNode) {
        all[i].parentNode.removeChild(all[i]); // dbsext:own-ui
      }
    }
  }

  function insertLauncherIfAbsent() {
    if (typeof document === 'undefined' || !document.body) return;
    if (isOriginalViewActive()) return;
    if (isBatteryLauncherPresent()) return; // 既出（冪等）
    document.body.appendChild(buildLauncher());
  }

  // ===========================================================================
  // 車両情報履歴: 既存地図の拡大表示（W4）
  // ===========================================================================

  var VEHICLE_HISTORIES_PATH_RE = /^\/vehicles\/VHCL:[A-Za-z0-9:_-]{1,256}\/histories\/?$/;
  var HISTORY_EXPECTED_HEADERS = [
    'イベント発生日時',
    '位置情報',
    'イベント',
    'ユーザ識別番号',
    'ポート名',
    '駐輪台数制限',
    '駐輪台数',
    '返却ポート予約数',
    '駐輪台数上限'
  ];
  var COORD_PATTERN_RE = /^N?\s*-?\d+(?:\.\d+)?\s*,\s*-?\d+(?:\.\d+)?$/;

  var HISTORY_MAP_BTN_ATTR = 'data-dbsext-launcher';
  var HISTORY_MAP_BTN_VALUE = 'history-map';
  var HISTORY_MAP_CLOSE_PANEL_ATTR = 'data-dbsext-launcher-panel';
  var HISTORY_MAP_CLOSE_PANEL_VALUE = 'history-map-close';
  var HISTORY_MAP_EXPANDED_CLASS = 'dbsext-history-map-expanded';

  var activeHistoryMapElement = null;
  var activeHistoryMapCloseHost = null;
  var historyKeydownHandler = null;

  function isVehicleHistoriesPath() {
    if (typeof location === 'undefined' || !location.pathname) return false;
    return VEHICLE_HISTORIES_PATH_RE.test(location.pathname);
  }

  function getTableHeaders(table) {
    if (!table) return [];
    var headerRow = table.querySelector('table.el-table__header tr, thead tr, tr');
    if (!headerRow) return [];
    var ths = headerRow.querySelectorAll('th');
    if (!ths || ths.length === 0) return [];
    var headers = [];
    for (var i = 0; i < ths.length; i++) {
      var th = ths[i];
      var text = th.getAttribute('data-dbsext-orig-title') || th.textContent || '';
      headers.push(text.trim());
    }
    return headers;
  }

  function findMatchingHistoryTable() {
    if (typeof document === 'undefined' || typeof document.querySelectorAll !== 'function') return null;
    var tables = document.querySelectorAll('.el-table, table');
    for (var i = 0; i < tables.length; i++) {
      var table = tables[i];
      var headers = getTableHeaders(table);
      if (headers.length === HISTORY_EXPECTED_HEADERS.length) {
        var match = true;
        for (var j = 0; j < HISTORY_EXPECTED_HEADERS.length; j++) {
          if (headers[j] !== HISTORY_EXPECTED_HEADERS[j]) {
            match = false;
            break;
          }
        }
        if (match) return table;
      }
    }
    return null;
  }

  function hasValidCoordinateLink(table) {
    if (!table || typeof table.querySelectorAll !== 'function') return false;
    // 位置情報列は2列目（index 1）
    var rows = table.querySelectorAll('table.el-table__body tbody tr, tbody tr');
    if (!rows || rows.length === 0) return false;

    var validCoordFound = false;
    for (var i = 0; i < rows.length; i++) {
      var cells = rows[i].querySelectorAll('td');
      if (cells.length > 1) {
        var posCell = cells[1];
        var link = posCell.querySelector('a[href]');
        if (link) {
          var text = (link.textContent || '').trim();
          if (COORD_PATTERN_RE.test(text)) {
            validCoordFound = true;
            break;
          }
        }
      }
    }
    return validCoordFound;
  }

  function isElementVisible(el) {
    if (!el || el.nodeType !== 1) return false;
    if (typeof document !== 'undefined' && document.body) {
      if (typeof document.body.contains === 'function' && !document.body.contains(el)) {
        return false;
      }
    }
    if (el.style && (el.style.display === 'none' || el.style.visibility === 'hidden' || el.style.opacity === '0')) return false;

    if (typeof window !== 'undefined' && typeof window.getComputedStyle === 'function') {
      try {
        var style = window.getComputedStyle(el);
        if (!style || style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
          return false;
        }
      } catch (e) {
        return false;
      }
    }

    // geometry checks: getBoundingClientRect must return finite, positive size, intersecting viewport
    if (typeof el.getBoundingClientRect === 'function') {
      try {
        var rect = el.getBoundingClientRect();
        if (!rect) return false;
        if (!isFinite(rect.width) || !isFinite(rect.height) || !isFinite(rect.top) || !isFinite(rect.bottom) || !isFinite(rect.left) || !isFinite(rect.right)) {
          return false;
        }
        if (rect.width <= 0 || rect.height <= 0) {
          return false;
        }
        var vpWidth = (typeof window !== 'undefined' && window.innerWidth) || (typeof document !== 'undefined' && document.documentElement && document.documentElement.clientWidth) || 0;
        var vpHeight = (typeof window !== 'undefined' && window.innerHeight) || (typeof document !== 'undefined' && document.documentElement && document.documentElement.clientHeight) || 0;
        if (vpWidth > 0 && vpHeight > 0) {
          if (rect.bottom <= 0 || rect.top >= vpHeight || rect.right <= 0 || rect.left >= vpWidth) {
            return false;
          }
        }
      } catch (e) {
        return false;
      }
    }
    if (typeof el.offsetWidth === 'number' && typeof el.offsetHeight === 'number') {
      if (!isFinite(el.offsetWidth) || !isFinite(el.offsetHeight) || el.offsetWidth <= 0 || el.offsetHeight <= 0) {
        return false;
      }
    }

    // 祖先の可視性チェック
    var parent = el.parentElement || el.parentNode;
    while (parent && parent.nodeType === 1) {
      if (parent.style && (parent.style.display === 'none' || parent.style.visibility === 'hidden' || parent.style.opacity === '0')) {
        return false;
      }
      if (typeof window !== 'undefined' && typeof window.getComputedStyle === 'function') {
        try {
          var pStyle = window.getComputedStyle(parent);
          if (pStyle && (pStyle.display === 'none' || pStyle.visibility === 'hidden' || pStyle.opacity === '0')) {
            return false;
          }
        } catch (e) {
          return false;
        }
      }
      parent = parent.parentElement || parent.parentNode;
    }

    return true;
  }

  function isExplicitMapElement(el) {
    if (!el || el.nodeType !== 1) return false;
    var className = el.className || '';
    if (typeof className !== 'string') {
      className = el.getAttribute ? (el.getAttribute('class') || '') : '';
    }
    if (/\b(?:leaflet-container|map-container|history-map|gis-map|portal-map)\b/i.test(className)) {
      return true;
    }
    if (el.hasAttribute) {
      if (el.hasAttribute('data-map')) return true;
      var role = el.getAttribute('data-role') || el.getAttribute('role');
      if (role && role.toLowerCase() === 'map') return true;
    }
    return false;
  }

  function findUniqueVisibleMapCandidate() {
    if (typeof document === 'undefined' || typeof document.querySelectorAll !== 'function') return null;

    var rawCandidates = [];

    // 1. 明確な地図コンテナ（.leaflet-container 等）
    var containers = document.querySelectorAll('.leaflet-container, .map-container, .history-map, .gis-map, .portal-map, [data-map], [data-role="map"]');
    for (var l = 0; l < containers.length; l++) {
      var c = containers[l];
      if (isExplicitMapElement(c) && rawCandidates.indexOf(c) === -1) {
        rawCandidates.push(c);
      }
    }

    // 2. canvas を含むコンテナ:
    //    明確な地図祖先コンテナ（または自身）が存在する場合のみ候補とする（generic canvas parent は禁止）
    var canvases = document.querySelectorAll('canvas');
    for (var ci = 0; ci < canvases.length; ci++) {
      var canvas = canvases[ci];
      var mapAncestor = null;
      if (canvas.closest) {
        mapAncestor = canvas.closest('.leaflet-container, .map-container, .history-map, .gis-map, .portal-map, [data-map], [data-role="map"]');
      } else {
        var cur = canvas.parentElement;
        while (cur && cur.nodeType === 1) {
          if (isExplicitMapElement(cur)) {
            mapAncestor = cur;
            break;
          }
          cur = cur.parentElement || cur.parentNode;
        }
      }

      if (mapAncestor && isExplicitMapElement(mapAncestor)) {
        if (rawCandidates.indexOf(mapAncestor) === -1) {
          rawCandidates.push(mapAncestor);
        }
      } else if (isExplicitMapElement(canvas)) {
        if (rawCandidates.indexOf(canvas) === -1) {
          rawCandidates.push(canvas);
        }
      }
    }

    // 3. iframe 地図:
    //    明確な地図祖先コンテナが存在するか、iframe 自身が地図コンテナである場合のみ候補とする（generic iframe parent は禁止）
    var iframes = document.querySelectorAll('iframe');
    for (var f = 0; f < iframes.length; f++) {
      var iframe = iframes[f];
      var ifrMapAncestor = null;
      if (iframe.closest) {
        ifrMapAncestor = iframe.closest('.leaflet-container, .map-container, .history-map, .gis-map, .portal-map, [data-map], [data-role="map"]');
      } else {
        var pCur = iframe.parentElement;
        while (pCur && pCur.nodeType === 1) {
          if (isExplicitMapElement(pCur)) {
            ifrMapAncestor = pCur;
            break;
          }
          pCur = pCur.parentElement || pCur.parentNode;
        }
      }

      if (ifrMapAncestor && isExplicitMapElement(ifrMapAncestor)) {
        if (rawCandidates.indexOf(ifrMapAncestor) === -1) {
          rawCandidates.push(ifrMapAncestor);
        }
      } else if (isExplicitMapElement(iframe)) {
        if (rawCandidates.indexOf(iframe) === -1) {
          rawCandidates.push(iframe);
        }
      }
    }

    // 重複除去と可視・正寸法・自前UI除外チェック
    var visibleCandidates = [];
    for (var i = 0; i < rawCandidates.length; i++) {
      var item = rawCandidates[i];
      if (item.closest && (item.closest('[' + HISTORY_MAP_CLOSE_PANEL_ATTR + ']') || item.closest('[' + HISTORY_MAP_BTN_ATTR + ']') || item.closest('[' + LAUNCHER_ATTR + ']'))) {
        continue;
      }
      if (isElementVisible(item)) {
        if (visibleCandidates.indexOf(item) === -1) {
          visibleCandidates.push(item);
        }
      }
    }

    if (visibleCandidates.length === 1) {
      return visibleCandidates[0];
    }
    return null;
  }

  function collapseHistoryMap() {
    if (activeHistoryMapElement) {
      if (activeHistoryMapElement.__dbsextExpandedByLauncher) {
        if (activeHistoryMapElement.classList && typeof activeHistoryMapElement.classList.remove === 'function') {
          activeHistoryMapElement.classList.remove(HISTORY_MAP_EXPANDED_CLASS);
        }
        delete activeHistoryMapElement.__dbsextExpandedByLauncher;
      }
      activeHistoryMapElement = null;
    }

    if (activeHistoryMapCloseHost && activeHistoryMapCloseHost.parentNode) {
      activeHistoryMapCloseHost.parentNode.removeChild(activeHistoryMapCloseHost); // dbsext:own-ui
    }
    activeHistoryMapCloseHost = null;

    if (historyKeydownHandler && typeof window !== 'undefined') {
      window.removeEventListener('keydown', historyKeydownHandler);
      historyKeydownHandler = null;
    }

    if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
      try {
        window.dispatchEvent(new Event('resize'));
      } catch (e) {}
    }
  }

  function cleanupHistoryMapUI() {
    collapseHistoryMap();
    if (typeof document === 'undefined' || typeof document.querySelectorAll !== 'function') return;
    var existingBtns = document.querySelectorAll('[' + HISTORY_MAP_BTN_ATTR + '="' + HISTORY_MAP_BTN_VALUE + '"]');
    for (var i = 0; i < existingBtns.length; i++) {
      if (existingBtns[i].parentNode) {
        existingBtns[i].parentNode.removeChild(existingBtns[i]); // dbsext:own-ui
      }
    }
  }

  function expandHistoryMap(mapElement) {
    if (isOriginalViewActive()) {
      collapseHistoryMap();
      return;
    }

    // Action-time fail-closed 再検証:
    // 1. exact path チェック
    if (!isVehicleHistoriesPath()) {
      cleanupHistoryMapUI();
      return;
    }

    // 2. 履歴テーブル & 座標リンクチェック
    var table = findMatchingHistoryTable();
    if (!table || !hasValidCoordinateLink(table)) {
      cleanupHistoryMapUI();
      return;
    }

    // 3. 現在の有効な地図候補の再検証（非表示化・寸法変更・DOM切断・複数化を検出）
    var validCandidate = findUniqueVisibleMapCandidate();
    if (!validCandidate) {
      cleanupHistoryMapUI();
      return;
    }

    // 4. mapElement が渡された場合、現在の有効候補と一致しているかチェック
    if (mapElement && mapElement !== validCandidate) {
      cleanupHistoryMapUI();
      return;
    }

    var targetElement = validCandidate;
    collapseHistoryMap();

    activeHistoryMapElement = targetElement;
    var hadClass = false;
    if (targetElement.classList && typeof targetElement.classList.contains === 'function') {
      hadClass = targetElement.classList.contains(HISTORY_MAP_EXPANDED_CLASS);
    }
    if (!hadClass) {
      targetElement.__dbsextExpandedByLauncher = true;
      if (targetElement.classList && typeof targetElement.classList.add === 'function') {
        targetElement.classList.add(HISTORY_MAP_EXPANDED_CLASS);
      }
    } else {
      delete targetElement.__dbsextExpandedByLauncher;
    }

    // 閉じる自前ボタン作成
    var closeHost = document.createElement('div');
    closeHost.setAttribute(HISTORY_MAP_CLOSE_PANEL_ATTR, HISTORY_MAP_CLOSE_PANEL_VALUE);

    var closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'dbsext-history-map-close-btn';
    closeBtn.textContent = '✕ 閉じる (Esc)';
    closeBtn.setAttribute('aria-label', '地図を閉じる');
    closeBtn.addEventListener('click', function () {
      collapseHistoryMap();
    });

    closeHost.appendChild(closeBtn);
    activeHistoryMapCloseHost = closeHost;
    document.body.appendChild(closeHost);

    // Escape キー監視
    historyKeydownHandler = function (e) {
      if (e.key === 'Escape' || e.keyCode === 27) {
        collapseHistoryMap();
      }
    };
    if (typeof window !== 'undefined') {
      window.addEventListener('keydown', historyKeydownHandler);
    }

    // リサイズイベント発火（LeafletやCanvasの再描画用）
    if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
      try {
        window.dispatchEvent(new Event('resize'));
      } catch (e) {}
    }
  }

  function applyVehicleHistoryMap() {
    if (typeof document === 'undefined' || !document.body) return;

    if (isOriginalViewActive()) {
      cleanupHistoryMapUI();
      return;
    }

    // 1. exact path チェック
    if (!isVehicleHistoriesPath()) {
      cleanupHistoryMapUI();
      return;
    }

    // 2. 9列header完全一致チェック
    var table = findMatchingHistoryTable();
    if (!table) {
      cleanupHistoryMapUI();
      return;
    }

    // 3. 位置情報セルの座標linkチェック
    if (!hasValidCoordinateLink(table)) {
      cleanupHistoryMapUI();
      return;
    }

    // 4. visible map候補が一意であることのチェック
    var mapCandidate = findUniqueVisibleMapCandidate();
    if (!mapCandidate) {
      cleanupHistoryMapUI();
      return;
    }

    // 5. 自前ボタンの挿入（冪等）
    var existingBtn = document.querySelector('[' + HISTORY_MAP_BTN_ATTR + '="' + HISTORY_MAP_BTN_VALUE + '"]');
    if (existingBtn) {
      return;
    }

    var btnHost = document.createElement('div');
    btnHost.setAttribute(HISTORY_MAP_BTN_ATTR, HISTORY_MAP_BTN_VALUE);
    btnHost.className = 'dbsext-history-map-btn-host';

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'dbsext-history-map-btn';
    btn.textContent = '🗺️ 地図を拡大表示';
    btn.addEventListener('click', function () {
      var currentCandidate = findUniqueVisibleMapCandidate();
      if (!currentCandidate || (mapCandidate && mapCandidate !== currentCandidate)) {
        cleanupHistoryMapUI();
        return;
      }
      expandHistoryMap(currentCandidate);
    });

    btnHost.appendChild(btn);

    if (mapCandidate.parentNode) {
      mapCandidate.parentNode.insertBefore(btnHost, mapCandidate);
    } else if (table.parentNode) {
      table.parentNode.insertBefore(btnHost, table);
    } else {
      document.body.appendChild(btnHost);
    }
  }

  function applyBatteryLauncher() {
    if (typeof document === 'undefined' || !document.body) return;

    if (isOriginalViewActive()) {
      cleanupBatteryLauncherUI();
      return;
    }

    if (isBatteryLauncherPresent()) return; // 既出（冪等）

    if (areaCheckState === 'supported') {
      insertLauncherIfAbsent();
      return;
    }
    if (areaCheckState === 'unsupported' || areaCheckState === 'pending') {
      return; // 対象外確定、または前回のapply()で確認開始済み・結果待ち
    }

    // areaCheckState === null: 初回。確認を開始する
    if (!D.areas || typeof D.areas.load !== 'function' || typeof D.areas.hasKnownArea !== 'function') {
      // areasモジュールが無い異常系は、従来どおり表示する
      areaCheckState = 'supported';
      if (!isOriginalViewActive()) {
        insertLauncherIfAbsent();
      }
      return;
    }

    areaCheckState = 'pending';
    D.areas.load().then(function (res) {
      if (res && res.ok && D.areas.hasKnownArea(res.areas)) {
        areaCheckState = 'supported';
        if (!isOriginalViewActive()) {
          insertLauncherIfAbsent();
        }
      } else if (res && res.ok) {
        // 取得は成功したが、対応エリアが1つも無い
        areaCheckState = 'unsupported';
      } else {
        // 取得失敗（セッション切れ等）。安全側として表示する
        areaCheckState = 'supported';
        if (!isOriginalViewActive()) {
          insertLauncherIfAbsent();
        }
      }
    }).catch(function () {
      areaCheckState = 'supported';
      if (!isOriginalViewActive()) {
        insertLauncherIfAbsent();
      }
    });
  }

  // production original-view のトグル連携（バブリングフェーズで同期連携）
  if (typeof document !== 'undefined' && typeof document.addEventListener === 'function') {
    document.addEventListener('click', function (e) {
      var target = e.target;
      if (!target) return;
      var isOrigBtn = false;
      if (target.hasAttribute && (target.hasAttribute('data-dbsext-original-view') || target.hasAttribute('data-dbsext-original-view-btn'))) {
        isOrigBtn = true;
      } else if (target.closest && (target.closest('[data-dbsext-original-view]') || target.closest('[data-dbsext-original-view-btn]'))) {
        isOrigBtn = true;
      }
      if (isOrigBtn) {
        if (isOriginalViewActive()) {
          collapseHistoryMap();
          cleanupHistoryMapUI();
          cleanupBatteryLauncherUI();
        }
      }
    }, false);
  }

  D.mapLauncher = {
    _collapseHistoryMap: collapseHistoryMap,
    _expandHistoryMap: expandHistoryMap,
    _applyVehicleHistoryMap: applyVehicleHistoryMap,
    _cleanupHistoryMapUI: cleanupHistoryMapUI,
    _cleanupBatteryLauncherUI: cleanupBatteryLauncherUI,
    _applyBatteryLauncher: applyBatteryLauncher,

    peekShowAll: function () {
      collapseHistoryMap();
      cleanupHistoryMapUI();
      cleanupBatteryLauncherUI();
    },
    peekRestore: function () {
      applyVehicleHistoryMap();
      applyBatteryLauncher();
    },

    /**
     * 起動ボタンを表示する（冪等・reapply対応）。
     *
     * 1. 車両履歴画面（/vehicles/VHCL:.../histories）では既存地図の拡大表示ボタンを出す
     * 2. 左下固定のバッテリーマップ起動ボタンを出す
     */
    apply: function () {
      if (typeof document === 'undefined' || !document.body) return;

      applyVehicleHistoryMap();
      applyBatteryLauncher();
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
