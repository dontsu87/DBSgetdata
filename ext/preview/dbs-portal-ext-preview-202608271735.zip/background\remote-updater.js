/**
 * DBSEXT リモートアップデータ (β-remote)
 *
 * 責務:
 *   1. latest.json を取得する
 *   2. 保存済みと同じ版なら再取得しない
 *   3. bundle-<version>.js を取得する
 *   4. DBSEXT_SIGNATURE.verify() で署名を検証する
 *   5. minExtensionVersion が拡張の版より新しければ捨てる
 *   6. chrome.storage.local に保存する
 *   7. 3段フォールバック（検証済みの新版 → 前回保存した版 → 拡張同梱版）
 *   8. chrome.userScripts.register() / update() で登録
 */
(function (global) {
  'use strict';

  /**
   * セマンティックバージョニング文字列の比較
   * a > b なら 1, a < b なら -1, a === b なら 0
   */
  function compareSemver(a, b) {
    if (typeof a !== 'string' || typeof b !== 'string') return 0;
    var pa = a.split('.').map(function (n) { return parseInt(n, 10) || 0; });
    var pb = b.split('.').map(function (n) { return parseInt(n, 10) || 0; });
    var len = Math.max(pa.length, pb.length);
    for (var i = 0; i < len; i++) {
      var na = pa[i] || 0;
      var nb = pb[i] || 0;
      if (na > nb) return 1;
      if (na < nb) return -1;
    }
    return 0;
  }

  function storageGet(keys) {
    return new Promise(function (resolve) {
      try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.get(keys, function (items) {
            var err = chrome.runtime && chrome.runtime.lastError;
            if (err) {
              resolve({});
            } else {
              resolve(items || {});
            }
          });
        } else {
          resolve({});
        }
      } catch (e) {
        resolve({});
      }
    });
  }

  function storageSet(obj) {
    return new Promise(function (resolve) {
      try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set(obj, function () {
            resolve();
          });
        } else {
          resolve();
        }
      } catch (e) {
        resolve();
      }
    });
  }

  /**
   * 同梱フォールバックバンドルを取得する
   */
  async function loadFallbackBundle() {
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.getURL === 'function') {
        var url = chrome.runtime.getURL('remote-fallback/bundle.js');
        var res = await fetch(url);
        if (res && res.ok) {
          return await res.text();
        }
      }
    } catch (e) {}
    return '';
  }

  /**
   * userScripts へバンドルを登録・更新する
   */
  async function registerUserScript(bundleText, config, statusInfo) {
    if (!bundleText) return false;
    if (typeof chrome === 'undefined' || !chrome.userScripts || typeof chrome.userScripts.register !== 'function') {
      return false;
    }

    var scriptId = (config && config.USER_SCRIPT_ID) || 'dbsext-remote';
    var matches = (config && config.USER_SCRIPT_MATCHES) || ['https://mg.docomo-cycle.jp/*'];

    var statusObj = statusInfo || { source: 'unknown', version: '' };

    // **DOM に「配信版が引き受ける」印を最初に置く。**
    //
    // content script（同梱版）と user script（配信版）はワールドが違うので、
    // 変数では互いを見られない。**DOM だけがワールドをまたいで共有される。**
    //
    // `runAt: 'document_start'` にして最初にこの印を置けば、
    // document_idle で走る同梱版は**必ずこの印を見られる**。
    // 「起動が間に合うか」という競争を、順序が確定した合図に置き換える。
    //
    // 印を置いただけで配信版が途中で失敗する場合に備え、
    // 同梱版は「印はあるが一定時間たっても起動していない」なら引き受ける（boot.js 参照）。
    // 配信版が**注入された瞬間**の合図を2つ出す。
    //
    //   (1) DOM の印        … 同梱版が起動順序を判断するために使う
    //   (2) service worker へのログ転送
    //
    // (2) が要る理由: USER_SCRIPT world の console 出力はページのコンソールに出るが、
    // フィルタ・表示レベル・ページ側の window.onerror で**見えないことがある**。
    // 実機調査では、ページのコンソールに何も出ず判断できなかった。
    // service worker のコンソールへ転送しておけば、
    // **「注入されたか」だけは確実に確認できる**（利用者に見てもらう場所も1箇所で済む）。
    var claimJs =
      'try{document.documentElement.setAttribute("data-dbsext-remote-claim","1");}catch(e){}; ' +
      'var DBSEXT_CHANNEL = ' + JSON.stringify({
        name: (config && config.CHANNEL_NAME) || 'production',
        label: (config && config.CHANNEL_LABEL) || ''
      }) + '; ' +
      'var DBSEXT_REMOTE_STATUS = ' + JSON.stringify(statusObj) + '; ' +
      'try{console.log("[dbsext] 配信版を注入しました", DBSEXT_REMOTE_STATUS.version, location.href);}catch(e){}; ' +
      'try{chrome.runtime.sendMessage({type:"dbsext:userScriptPing",' +
      'version:DBSEXT_REMOTE_STATUS.version,source:DBSEXT_REMOTE_STATUS.source,url:location.href});}catch(e){};';

    var scriptConfig = {
      id: scriptId,
      matches: matches,
      world: 'USER_SCRIPT',
      // **document_start にする。** document_idle だと静的 content script と
      // 同じ段階になり、どちらが先かが環境依存になる（実機で同梱版が勝っていた）。
      runAt: 'document_start',
      js: [
        { code: claimJs },
        { file: 'content/platform-userscript.js' },
        { code: bundleText },
        { file: 'content/boot.js' }
      ]
    };

    try {
      if (typeof chrome.userScripts.getScripts === 'function') {
        var existing = await chrome.userScripts.getScripts({ ids: [scriptId] });
        if (existing && existing.length > 0) {
          if (typeof chrome.userScripts.update === 'function') {
            await chrome.userScripts.update([scriptConfig]);
            return true;
          }
          if (typeof chrome.userScripts.unregister === 'function') {
            await chrome.userScripts.unregister({ ids: [scriptId] });
          }
        }
      }
    } catch (e) {
      // update/getScripts 失敗時は unregister/register にフォールバック
    }

    try {
      await chrome.userScripts.register([scriptConfig]);
      return true;
    } catch (e) {
      try {
        if (typeof chrome.userScripts.unregister === 'function') {
          await chrome.userScripts.unregister({ ids: [scriptId] });
          await chrome.userScripts.register([scriptConfig]);
          return true;
        }
      } catch (e2) {
        return false;
      }
      return false;
    }
  }

  async function isSavedBundleValid(savedVersion, savedMinExtVer, savedBundle, savedSignature, signatureVerifier, config) {
    if (!savedVersion || !savedBundle || !savedSignature || !signatureVerifier || !config) return false;
    try {
      return await signatureVerifier.verify(
        config.PUBLIC_KEY_SPKI_B64,
        savedVersion,
        savedMinExtVer || '0.0.0',
        savedBundle,
        savedSignature
      );
    } catch (e) {
      return false;
    }
  }

  var inFlightUpdatePromise = null;

  /**
   * MAIN ワールドで fetch / XHR をラップする傍受スクリプトを
   * user script として登録する。
   *
   * ポータル本体の通信は MAIN ワールドで行われるため、
   * ISOLATED / USER_SCRIPT ワールドの net-status.js だけでは
   * 通信を捕捉できない。このスクリプトが MAIN ワールドで
   * DOM カスタムイベントを発火し、net-status.js がそれを購読する。
   */
  async function registerMainWorldInterceptor(fetchImpl) {
    if (typeof chrome === 'undefined' || !chrome.userScripts ||
        typeof chrome.userScripts.register !== 'function') {
      return false;
    }

    var doFetch = fetchImpl || (typeof fetch !== 'undefined' ? fetch : null);
    if (!doFetch) return false;

    var scriptId = 'dbsext-remote-main';
    var matches = ['https://mg.docomo-cycle.jp/*'];

    // 同梱ファイルから傍受スクリプトの内容を取得する
    var code = '';
    try {
      var fileUrl = chrome.runtime.getURL('content/net-status-main.js');
      var res = await doFetch(fileUrl);
      if (res && res.ok) {
        code = await res.text();
      }
    } catch (e) {
      // ファイルが読めなければ登録しない（安全側に倒す）
      console.warn('[dbsext-updater] MAIN ワールド傍受スクリプトの読み込みに失敗: ' +
        (e && e.message ? e.message : e));
      return false;
    }

    if (!code) return false;

    var scriptConfig = {
      id: scriptId,
      matches: matches,
      world: 'MAIN',
      runAt: 'document_start',
      js: [{ code: code }]
    };

    try {
      if (typeof chrome.userScripts.getScripts === 'function') {
        var existing = await chrome.userScripts.getScripts({ ids: [scriptId] });
        if (existing && existing.length > 0) {
          if (typeof chrome.userScripts.update === 'function') {
            await chrome.userScripts.update([scriptConfig]);
            return true;
          }
          if (typeof chrome.userScripts.unregister === 'function') {
            await chrome.userScripts.unregister({ ids: [scriptId] });
          }
        }
      }
    } catch (e) {
      // update/getScripts 失敗時は unregister/register にフォールバック
    }

    try {
      await chrome.userScripts.register([scriptConfig]);
      return true;
    } catch (e) {
      try {
        if (typeof chrome.userScripts.unregister === 'function') {
          await chrome.userScripts.unregister({ ids: [scriptId] });
          await chrome.userScripts.register([scriptConfig]);
          return true;
        }
      } catch (e2) {
        return false;
      }
      return false;
    }
  }

  async function executeUpdateAndRegister(options) {
    options = options || {};

    var extVersion = options.extensionVersion ||
      ((typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.getManifest === 'function' && chrome.runtime.getManifest().version)
        ? chrome.runtime.getManifest().version
        : '0.1.0');

    var config = options.config ||
      (typeof global.DBSEXT_REMOTE_CONFIG !== 'undefined'
        ? global.DBSEXT_REMOTE_CONFIG
        : (typeof DBSEXT_REMOTE_CONFIG !== 'undefined' ? DBSEXT_REMOTE_CONFIG : null));

    var signatureVerifier = options.signatureVerifier ||
      (typeof global.DBSEXT_SIGNATURE !== 'undefined'
        ? global.DBSEXT_SIGNATURE
        : (typeof DBSEXT_SIGNATURE !== 'undefined' ? DBSEXT_SIGNATURE : null));

    var fetchImpl = options.fetchFn ||
      (typeof fetch !== 'undefined' ? fetch : null);

    var storageData = {};
    try {
      storageData = await storageGet(['remoteVersion', 'remoteBundle', 'remoteSignature', 'remoteMinExtensionVersion']);
    } catch (e) {
      storageData = {};
    }

    var savedVersion = storageData.remoteVersion || '';
    var savedBundle = storageData.remoteBundle || '';
    var savedSignature = storageData.remoteSignature || '';
    var savedMinExtVer = storageData.remoteMinExtensionVersion || '0.0.0';

    var selectedBundle = null;
    var selectedVersion = '';
    var source = 'fallback'; // 'remote' | 'saved' | 'fallback'

    if (config && config.LATEST_URL && fetchImpl) {
      try {
        var latestRes = await fetchImpl(config.LATEST_URL, { cache: 'no-cache' });
        if (latestRes && latestRes.ok) {
          var latestJson = await latestRes.json();
          if (latestJson && typeof latestJson.version === 'string') {
            var minExtVer = latestJson.minExtensionVersion || '0.0.0';

            // A-1: 版の後戻りを拒否（ロールバック防止）
            if (savedVersion && latestJson.version < savedVersion) {
              console.warn('[dbsext-updater] ロールバックを検知したため拒否しました (保存版: ' + savedVersion + ', 受信版: ' + latestJson.version + ')');
              if (savedBundle && (await isSavedBundleValid(savedVersion, savedMinExtVer, savedBundle, savedSignature, signatureVerifier, config))) {
                selectedBundle = savedBundle;
                selectedVersion = savedVersion;
                source = 'saved';
              }
            } else if (compareSemver(minExtVer, extVersion) > 0) {
              // 5. minExtensionVersion が拡張の版より新しければ捨てる
              console.warn('[dbsext-updater] 拡張のバージョンが古いため新版を破棄しました (要求: ' + minExtVer + ', 現在: ' + extVersion + ')');
            } else if (savedVersion && savedVersion === latestJson.version && savedBundle) {
              // 2. 保存済みと同じ版なら再取得しない (A-2: 保存版の署名も検証)
              if (await isSavedBundleValid(savedVersion, savedMinExtVer, savedBundle, savedSignature, signatureVerifier, config)) {
                selectedBundle = savedBundle;
                selectedVersion = savedVersion;
                source = 'saved';
              }
            } else if (latestJson.bundle && latestJson.signature) {
              // 3. bundle-<version>.js を取得
              var bundleUrl = latestJson.bundle.indexOf('http') === 0
                ? latestJson.bundle
                : (config.BASE_URL + latestJson.bundle);
              var bundleRes = await fetchImpl(bundleUrl);
              if (bundleRes && bundleRes.ok) {
                var bundleText = await bundleRes.text();
                // 4. 署名を検証 (A-1: payload による検証)
                var isValid = false;
                if (signatureVerifier && typeof signatureVerifier.verify === 'function') {
                  isValid = await signatureVerifier.verify(
                    config.PUBLIC_KEY_SPKI_B64,
                    latestJson.version,
                    minExtVer,
                    bundleText,
                    latestJson.signature
                  );
                }
                if (isValid) {
                  // 6. 検証成功 -> storage に保存 (A-2: minExtensionVersion も保存)
                  selectedBundle = bundleText;
                  selectedVersion = latestJson.version;
                  source = 'remote';
                  try {
                    await storageSet({
                      remoteVersion: latestJson.version,
                      remoteBundle: bundleText,
                      remoteSignature: latestJson.signature,
                      remoteMinExtensionVersion: minExtVer
                    });
                  } catch (e) {
                    // storageSet 例外時もフォールバックせず新版を使用
                  }
                }
              }
            }
          }
        }
      } catch (err) {
        // 通信異常やJSONエラーなどは例外を外に漏らさずフォールバックへ
      }
    }

    // フォールバック制御
    // 1段目 (新版取得) が選ばれなかった場合
    if (!selectedBundle) {
      // 2段目: 前回保存した版 (A-2: 署名を再検証)
      if (savedBundle && (await isSavedBundleValid(savedVersion, savedMinExtVer, savedBundle, savedSignature, signatureVerifier, config))) {
        selectedBundle = savedBundle;
        selectedVersion = savedVersion;
        source = 'saved';
      } else {
        // 3段目: 同梱版
        var fallbackBundle = options.fallbackBundle;
        if (fallbackBundle === undefined) {
          fallbackBundle = await loadFallbackBundle();
        }
        selectedBundle = fallbackBundle || '';
        selectedVersion = 'fallback';
        source = 'fallback';
      }
    }

    // どの経路で動いているかを保存しておく。
    // 表示自体は登録時に注入する DBSEXT_REMOTE_STATUS を使うが、
    // **現場で切り分けるとき、service worker のコンソールから
    // chrome.storage.local を覗いて確認できるようにしておく**。
    // 実機の不具合調査では、ここが空だったことが手がかりの1つになった。
    try {
      await storageSet({ remoteSource: source, remoteSelectedVersion: selectedVersion });
    } catch (e) {
      // 保存できなくても動作は続ける
    }

    var registered = false;
    if (selectedBundle) {
      try {
        registered = await registerUserScript(selectedBundle, config, {
          source: source,
          version: selectedVersion
        });
      } catch (e) {
        registered = false;
      }
    }

    // MAIN ワールド傍受スクリプトの登録（USER_SCRIPT の成否に依存しない）
    var mainRegistered = false;
    try {
      mainRegistered = await registerMainWorldInterceptor(fetchImpl);
    } catch (e) {
      console.warn('[dbsext-updater] MAIN ワールド傍受スクリプトの登録に失敗: ' +
        (e && e.message ? e.message : e));
    }

    return {
      source: source,
      bundle: selectedBundle,
      version: selectedVersion,
      registered: registered,
      mainInterceptorRegistered: mainRegistered
    };
  }

  var DBSEXT_REMOTE_UPDATER = {
    compareSemver: compareSemver,

    /**
     * 最新の配信物を取得・検証し、フォールバック制御を行い userScripts に登録する。
     * 多重呼び出し時は実行中の Promise を共有する (A-5: in-flight 共有)。
     *
     * @param {object} [options]
     * @param {string} [options.extensionVersion]
     * @param {object} [options.config]
     * @param {object} [options.signatureVerifier]
     * @param {string} [options.fallbackBundle]
     * @param {function} [options.fetchFn]
     * @returns {Promise<{source: string, bundle: string, version: string, registered: boolean}>}
     */
    updateAndRegister: function (options) {
      if (inFlightUpdatePromise) {
        return inFlightUpdatePromise;
      }
      inFlightUpdatePromise = (async function () {
        try {
          return await executeUpdateAndRegister(options);
        } finally {
          inFlightUpdatePromise = null;
        }
      })();
      return inFlightUpdatePromise;
    }
  };

  global.DBSEXT_REMOTE_UPDATER = DBSEXT_REMOTE_UPDATER;
})(typeof globalThis !== 'undefined' ? globalThis : self);
