/**
 * DBSEXT 画面入力宣言表・復元モジュール
 * 各画面の宣言に基づき、エリア選択などの入力状態の自動適用と安全弁UIを提供する
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var appliedInTab = false;
  var DIALOG_MAX_ATTEMPTS = 30; // 30回 × 50ms = 1.5秒
  var NOTICE_ATTR = 'data-dbsext-state-forms';

  /**
   * ヘッダのエリア選択トリガー要素を取得
   */
  // エリア表示の文言。実測では `エリア未選択` / `6エリア選択中` の2形。
  // **単に「エリア」を含むかで探してはいけない。**
  // サイドバーのメニュー項目 `エリア情報` も `.cursor-pointer` を持っており
  // （実測DOM。`tests/fixtures/mock-portal.html` 参照）、そちらを掴むと
  // **クリックで `/areas` へ画面遷移してしまう**。
  var AREA_LABEL_RE = /エリア(未選択|選択中)/;

  function getHeaderAreaElement() {
    if (typeof document === 'undefined') return null;

    // 1. 実測で確定している具体的なセレクタを最優先で試す
    var exact = document.querySelector('p.col-span-3.cursor-pointer.text-right');
    if (exact && AREA_LABEL_RE.test(exact.textContent || '')) return exact;

    // 2. 退避: 文言が一致するものだけを候補にする。
    //    さらに**リンクを含む/リンクである要素は除く**（メニュー項目は必ず a を持つ）。
    //    候補が複数あるときは、**最も文字数の少ないもの**を採る。
    //    ヘッダ全体を包む大きな div も文言を含んでしまうため、
    //    「最も内側＝最も短い」ものが目的の要素になる。
    var candidates = document.querySelectorAll('.cursor-pointer');
    var best = null;
    var bestLen = Infinity;
    for (var i = 0; i < candidates.length; i++) {
      var el = candidates[i];
      var text = (el.textContent || '').trim();
      if (!AREA_LABEL_RE.test(text)) continue;
      if (el.tagName === 'A') continue;
      if (typeof el.querySelector === 'function' && el.querySelector('a[href]')) continue;
      if (text.length < bestLen) {
        bestLen = text.length;
        best = el;
      }
    }
    return best;
  }

  /**
   * 現在開いているエリア選択ダイアログを取得
   */
  function getVisibleAreaDialog() {
    if (typeof document === 'undefined') return null;
    var dialogs = document.querySelectorAll('[role="dialog"], .el-dialog');
    for (var i = 0; i < dialogs.length; i++) {
      var d = dialogs[i];
      if ((d.textContent || '').indexOf('エリア選択') < 0) continue;
      if (isHiddenElement(d)) continue;
      return d;
    }
    return null;
  }

  /**
   * 隠れている要素か。
   *
   * **ここを緩くしてはいけない。** Element Plus は閉じたダイアログを
   * DOM に残したまま親を `display:none` にする。隠れたダイアログを
   * 「開いている」と誤認すると、**見えていないダイアログのチェックボックスを操作して
   * 「選択」まで押してしまう**（＝利用者の意図しない表示範囲が適用される）。
   */
  function isHiddenElement(el) {
    // 祖先を辿る。`nodeType` の有無に依存しない（親が無くなったら終わり）
    for (var node = el; node; node = node.parentElement) {
      var style = node.style;
      if (style && (style.display === 'none' || style.visibility === 'hidden')) return true;
      if (typeof getComputedStyle === 'function') {
        var cs = getComputedStyle(node);
        if (cs && (cs.display === 'none' || cs.visibility === 'hidden')) return true;
      }
    }
    // レイアウトを持たない＝画面に出ていない（position:fixed は offsetParent が null になるため除く）
    if (typeof el.getBoundingClientRect === 'function') {
      var rect = el.getBoundingClientRect();
      if (rect && rect.width === 0 && rect.height === 0) return true;
    }
    return false;
  }

  /**
   * ダイアログ内でチェックされているエリア名の一覧を取得
   */
  function getCheckedAreaNamesFromDialog(dialog) {
    var names = [];
    if (!dialog) return names;
    var checkboxes = dialog.querySelectorAll('.el-checkbox');
    for (var i = 0; i < checkboxes.length; i++) {
      var cb = checkboxes[i];
      var label = (cb.querySelector('.el-checkbox__label') || cb).textContent.trim();
      if (label === 'すべて選択' || !label) continue;

      var isChecked = cb.classList.contains('is-checked');
      var input = cb.querySelector('input[type="checkbox"]');
      if (input && input.checked) {
        isChecked = true;
      }
      if (isChecked) {
        names.push(label);
      }
    }
    return names;
  }

  /**
   * 通知UIを削除する
   */
  function removeNoticeUI() {
    if (typeof document === 'undefined') return;
    var notices = document.querySelectorAll('[' + NOTICE_ATTR + ']');
    for (var i = 0; i < notices.length; i++) {
      if (notices[i].parentNode) {
        notices[i].parentNode.removeChild(notices[i]); // dbsext:own-ui
      }
    }
  }

  /**
   * 自動適用完了時の通知バーを表示（安全弁 2 & 3）
   */
  function showAutoAppliedNotice(areaNames) {
    if (typeof document === 'undefined' || !document.body) return;
    removeNoticeUI();

    var namesStr = Array.isArray(areaNames) ? areaNames.join(', ') : String(areaNames);

    var container = document.createElement('div');
    container.setAttribute(NOTICE_ATTR, '1');
    // **画面の右上に出す。**
    // 以前は左下（bottom:12px; left:300px）に出していたが、
    // 表や操作の邪魔になると指摘された。右上は情報の通知に使われる定位置で、
    // 表本体にもサイドバーにも重ならない。
    container.style.cssText = [
      'position: fixed',
      'top: 8px',
      'right: 8px',
      'max-width: 40vw',
      'z-index: 2147482990',
      'background-color: #0b5cab',
      'color: #ffffff',
      'padding: 8px 14px',
      'border-radius: 6px',
      'box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25)',
      'font-size: 12px',
      'display: flex',
      'align-items: center',
      'gap: 12px',
      'font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    ].join(';');

    var textSpan = document.createElement('span');
    textSpan.className = 'dbsext-state-notice-text';
    textSpan.textContent = 'エリアを自動で選択しました: ' + namesStr;
    container.appendChild(textSpan);

    // 「エリアを選び直す」ボタン
    var reselectBtn = document.createElement('button');
    reselectBtn.type = 'button';
    reselectBtn.className = 'dbsext-state-reselect-btn';
    reselectBtn.textContent = 'エリアを選び直す';
    reselectBtn.style.cssText = [
      'background: #ffffff',
      'color: #083f75',
      'border: none',
      'border-radius: 4px',
      'padding: 4px 8px',
      'font-size: 11px',
      'font-weight: bold',
      'cursor: pointer'
    ].join(';');
    reselectBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      var headerArea = getHeaderAreaElement();
      if (headerArea) {
        headerArea.click();
      }
      removeNoticeUI();
    });
    container.appendChild(reselectBtn);

    // 閉じるボタン
    var closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.textContent = '✕';
    closeBtn.style.cssText = [
      'background: none',
      'border: none',
      'color: #ffffff',
      'font-size: 12px',
      'cursor: pointer',
      'padding: 0 4px'
    ].join(';');
    closeBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      removeNoticeUI();
    });
    container.appendChild(closeBtn);

    document.body.appendChild(container);
  }

  /**
   * エリア選択ダイアログを自動操作して保存エリアを適用する
   */
  function restoreAreaSelection(targetAreaNames, callback) {
    if (!targetAreaNames || !Array.isArray(targetAreaNames) || targetAreaNames.length === 0) {
      if (typeof callback === 'function') callback(false);
      return;
    }

    var headerArea = getHeaderAreaElement();
    if (!headerArea) {
      if (typeof callback === 'function') callback(false);
      return;
    }

    // 1. ヘッダのエリア要素をクリックしてダイアログを開く
    headerArea.click();

    // 2. 再帰 setTimeout でダイアログの出現を待つ（上限回数を設定）
    var attempts = 0;
    function pollDialog() {
      attempts++;
      var dialog = getVisibleAreaDialog();
      if (dialog) {
        applyCheckboxesAndSelect(dialog, targetAreaNames, callback);
      } else if (attempts < DIALOG_MAX_ATTEMPTS) {
        setTimeout(pollDialog, 50);
      } else {
        if (typeof callback === 'function') callback(false);
      }
    }

    setTimeout(pollDialog, 50);
  }

  /**
   * ダイアログ内のチェックボックスをクリック操作し、「選択」ボタンを押す
   */
  function applyCheckboxesAndSelect(dialog, targetAreaNames, callback) {
    var checkboxes = dialog.querySelectorAll('.el-checkbox');
    var targetSet = {};
    for (var k = 0; k < targetAreaNames.length; k++) {
      targetSet[targetAreaNames[k]] = true;
    }

    // **保存したエリアが今のダイアログに何件あるかを数える。**
    // 権限エリアの変更やエリア名の改称で、保存値が現在の選択肢に無いことがある。
    // 1件も一致しないまま「選択」を押すと、**空の選択が適用されたうえで
    // 「自動で選択しました」と表示される**（＝静かな不一致）。
    var matched = [];

    for (var i = 0; i < checkboxes.length; i++) {
      var cb = checkboxes[i];
      var label = (cb.querySelector('.el-checkbox__label') || cb).textContent.trim();
      if (label === 'すべて選択' || !label) continue;

      var isChecked = cb.classList.contains('is-checked');
      var input = cb.querySelector('input[type="checkbox"]');
      if (input && input.checked) {
        isChecked = true;
      }

      var shouldBeChecked = !!targetSet[label];
      if (shouldBeChecked) matched.push(label);
      if (shouldBeChecked !== isChecked) {
        // ネイティブ click() で Element Plus の状態を更新
        cb.click();
      }
    }

    // 1件も一致しないなら**何も適用せずに諦める**。
    // 中途半端に適用して成功を名乗るより、黙って元のまま（＝エリア未選択）の方が安全。
    if (matched.length === 0) {
      if (D.core && typeof D.core.log === 'function') {
        D.core.log('エリアの自動適用を中止: 保存したエリアが現在の選択肢に無い', true);
      }
      if (typeof callback === 'function') callback(false);
      return;
    }

    // 4. 「選択」ボタンをクリック（invisible クラスが無いもの）
    var buttons = dialog.querySelectorAll('button');
    var selectBtn = null;
    for (var j = 0; j < buttons.length; j++) {
      var btn = buttons[j];
      var text = (btn.textContent || '').trim();
      if (text === '選択' && !btn.classList.contains('invisible') && btn.style.display !== 'none') {
        selectBtn = btn;
        break;
      }
    }

    if (selectBtn) {
      selectBtn.click();
      // **実際に適用できた分だけを表示する。** 保存値をそのまま並べると、
      // 一部しか一致していないときに利用者が見ている範囲を誤認する。
      showAutoAppliedNotice(matched);
      if (typeof callback === 'function') callback(true);
    } else {
      if (typeof callback === 'function') callback(false);
    }
  }

  // ユーザー自身の手動操作でエリアが選択されたときのキャプチャ監視
  function attachManualCaptureListener() {
    if (typeof document === 'undefined') return;
    if (document.__dbsext_state_forms_listener) return;
    document.__dbsext_state_forms_listener = true;

    document.addEventListener('click', function (e) {
      var target = e.target;
      if (!target) return;
      var btn = (typeof target.closest === 'function') ? target.closest('button') : null;
      if (!btn && target.tagName === 'BUTTON') {
        btn = target;
      }
      if (!btn) return;

      var text = (btn.textContent || '').trim();
      if (text === '選択') {
        var dialog = (typeof btn.closest === 'function') ? btn.closest('[role="dialog"], .el-dialog') : null;
        if (!dialog) {
          dialog = getVisibleAreaDialog();
        }
        if (dialog && (dialog.textContent || '').indexOf('エリア選択') >= 0) {
          var names = getCheckedAreaNamesFromDialog(dialog);
          if (!D.stateStore) return;

          if (names && names.length > 0) {
            if (typeof D.stateStore.save === 'function') {
              D.stateStore.save('/', 'areaSelection', names, { scope: 'local' });
            }
          } else if (typeof D.stateStore.clear === 'function') {
            // **チェックを全部外して「選択」を押した＝「エリアなし」という明示の意思表示。**
            // ここで保存値を消さないと、次回の起動で拡張が古いエリアを
            // 自動適用し、**利用者が自分で解除したはずの範囲が黙って戻る**。
            // 利用者の明示的な操作を、拡張が後から打ち消してはいけない。
            D.stateStore.clear('/', 'areaSelection');
            if (D.core && typeof D.core.log === 'function') {
              D.core.log('エリアが全解除されたため、保存していたエリアを消去した');
            }
          }
          // 自動適用中でなくても、利用者が自分で選び直したら通知は用済み
          removeNoticeUI();
        }
      }
    }, true);
  }

  D.stateForms = {
    DECLARATIONS: [
      {
        screen: '/',
        feature: 'areaSelection',
        scope: 'local',
        label: 'エリア選択',
        capture: function () {
          var dialog = getVisibleAreaDialog();
          if (dialog) {
            return getCheckedAreaNamesFromDialog(dialog);
          }
          if (D.stateStore && typeof D.stateStore.load === 'function') {
            return D.stateStore.load('/', 'areaSelection');
          }
          return null;
        },
        restore: function (value, callback) {
          restoreAreaSelection(value, callback);
        }
      }
    ],

    /**
     * 自動適用（安全弁チェック付き）
     */
    apply: function () {
      attachManualCaptureListener();

      // 安全弁 0: **トップ画面でしか自動適用しない**
      //
      // エリアを適用するとポータルが再描画され、**トップ画面へ戻される**。
      // 一覧から「別タブで開く」で個別画面を開いた場合、そのタブはエリア未選択なので
      // 自動適用が走り、**利用者が開こうとした画面が消えてトップに飛ばされる**
      // （現場から報告された実害。ポート情報→ポート識別番号で再現）。
      //
      // 通常ポータルを開いたときの入口はトップ画面なので、そこだけで適用すれば足りる。
      // SPA内で一覧へ移動する頃には、すでに適用済みになっている。
      //
      // **利用者が明示的に開いた画面を、拡張が勝手に別の画面へ移してはいけない。**
      if (typeof location !== 'undefined' && location.pathname &&
          location.pathname !== '/' && location.pathname !== '') {
        return;
      }

      // 安全弁 1: 同じタブで二度自動適用しない
      if (appliedInTab) {
        return;
      }

      // 安全弁 2: 保存されたエリアがあるか（初回は自動適用しない）
      if (!D.stateStore || typeof D.stateStore.load !== 'function') {
        return;
      }
      var savedAreas = D.stateStore.load('/', 'areaSelection');
      if (!savedAreas || !Array.isArray(savedAreas) || savedAreas.length === 0) {
        return;
      }

      // 安全弁 3: 現在のヘッダが「エリア未選択」である（すでに選ばれているなら触らない）
      var headerArea = getHeaderAreaElement();
      if (!headerArea) {
        return;
      }
      var headerText = (headerArea.textContent || '').trim();
      if (headerText.indexOf('エリア未選択') === -1) {
        return;
      }

      // 条件をすべて満たしたため自動適用を実施
      appliedInTab = true;
      restoreAreaSelection(savedAreas);
    },

    _hasAppliedInTab: function () {
      return appliedInTab;
    },
    _resetAppliedInTab: function () {
      appliedInTab = false;
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
