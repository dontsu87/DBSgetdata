/**
 * 起動役。**content script 版（同梱）と user script 版（配信）で共有している。**
 *
 * ---------------------------------------------------------------------------
 * どちらが起動するかの決め方（実機で3回失敗して確定した形）
 * ---------------------------------------------------------------------------
 *
 * 【1回目】両方を無条件に起動させた
 *   content_scripts が必ず先に走って印を立て、配信版は「適用済み」と判断して終了。
 *   → **配信されたコードが一度も実行されなかった**（画面は動くので気づけない）。
 *
 * 【2回目】service worker に「配信版が登録済みか」を問い合わせた
 *   登録が残っていても実際には注入されないことがあり、同梱版が遠慮したまま
 *   配信版も動かず、**画面が素のポータルのままになった**。
 *   「登録されている」ことと「実際に動いた」ことは別物だった。
 *
 * 【3回目】「一定時間待って、誰も起動していなければ同梱版が起動」にした
 *   両方とも `document_idle` だったため、**どちらが先かは環境依存**のまま。
 *   実機では待ち時間（0.6秒）内に配信版が来ず、同梱版が勝ち続けた。
 *   **競争が残っていた。**
 *
 * 【現在の形】**順序が確定した合図を使う**
 *   配信版は `document_start` で走り、真っ先に
 *   `document.documentElement` に `data-dbsext-remote-claim` を置く。
 *   **DOM だけがワールドをまたいで共有される**ので、
 *   `document_idle` で走る同梱版は必ずこの印を見られる。
 *
 *     印が無い  … 配信版は動いていない → 同梱版が**すぐ**起動する
 *     印がある  … 配信版が引き受ける → 同梱版は待ち、
 *                 それでも起動しなければ**保険として引き受ける**
 *
 * 印だけ置いて配信版が途中で失敗する場合があるため、保険は必ず残す。
 * **画面から拡張が丸ごと消えることが最悪**であり、そこへは倒さない。
 */
(function (global) {
  'use strict';

  var D = global.DBSEXT;
  if (!D || !D.core) return;

  var CLAIM_ATTR = 'data-dbsext-remote-claim';
  // 印はあるのに配信版が起動しないときの保険。ここを過ぎたら同梱版が引き受ける
  var CLAIM_GRACE_MS = 2000;

  function boot() {
    try {
      D.core.boot();
    } catch (e) {
      if (typeof D.core.log === 'function') {
        D.core.log('boot 失敗: ' + (e && e.message ? e.message : e), true);
      }
    }
  }

  function isApplied() {
    try {
      return D.core.isApplied();
    } catch (e) {
      return false;
    }
  }

  /** document.body が使えるようになってから実行する */
  function whenBodyReady(fn) {
    if (typeof document === 'undefined') { fn(); return; }
    if (document.body) { fn(); return; }
    if (typeof document.addEventListener === 'function') {
      document.addEventListener('DOMContentLoaded', function () { fn(); }, { once: true });
      return;
    }
    fn();
  }

  // -------------------------------------------------------------------------
  // 配信版（user script）: document_start で走るため、DOM の準備を待ってから起動する
  // -------------------------------------------------------------------------
  if (D.platform && D.platform.isUserScript) {
    whenBodyReady(boot);
    return;
  }

  // -------------------------------------------------------------------------
  // 同梱版（content script）: document_idle。ここでは印の有無が確定している
  // -------------------------------------------------------------------------
  var claimed = false;
  try {
    claimed = !!(document.documentElement &&
      document.documentElement.getAttribute(CLAIM_ATTR));
  } catch (e) {
    claimed = false;
  }

  if (!claimed) {
    // 配信版は動いていない。待つ理由がないので即起動する
    boot();
    return;
  }

  // 配信版が引き受けている。ただし途中で失敗する可能性があるので見届ける
  if (typeof setTimeout !== 'function') {
    boot();
    return;
  }

  setTimeout(function () {
    if (isApplied()) {
      if (typeof D.core.log === 'function') {
        D.core.log('配信版が起動済みのため、同梱版は起動しません');
      }
      return;
    }
    if (typeof D.core.log === 'function') {
      D.core.log('配信版の印はあるが起動しなかったため、同梱版が引き受けます', true);
    }
    boot();
  }, CLAIM_GRACE_MS);
})(typeof globalThis !== 'undefined' ? globalThis : window);
