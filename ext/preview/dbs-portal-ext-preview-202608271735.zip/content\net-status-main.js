/**
 * DBSEXT 通信ステータス MAIN-world 傍受スクリプト
 *
 * ポータルが動く MAIN ワールドで fetch / XHR をラップし、
 * 通信の開始・終了を DOM カスタムイベントとして発火する。
 * ISOLATED / USER_SCRIPT ワールドの net-status.js はこれを購読して
 * 「読み込み中…」マスクの表示・非表示を行う。
 *
 * このファイルは極力薄く保ち、UI生成・タイミング制御・エラー表示は
 * すべて net-status.js 側に任せる。
 *
 * 置き場所:
 *   - manifest.json content_scripts (world: "MAIN") → 同梱版フォールバック
 *   - remote-updater.js が登録する MAIN-world user script → リモート配信版
 */
(function () {
  'use strict';

  if (typeof window === 'undefined') return;
  if (typeof document === 'undefined') return;

  var EVENT_PREFIX = 'dbsext:main-fetch';
  var NAV_EVENT = 'dbsext:navigation-loading';
  // USER_SCRIPT側(net-status.js)と同じキーを使う。旧キーのままだと、
  // reload直後のMAIN-worldが遷移開始を認識できず、純正の赤い画面が一瞬露出する。
  var NAV_STORAGE_KEY = 'dbsext:navigation-loading-v2';
  var NAV_READY_EVENT = 'dbsext:navigation-ready';
  var DOM_CHANGE_EVENT = 'dbsext:main-dom-change';
  var navigationLoaded = document.readyState === 'complete';
  var navigationOverlay = null;
  var navigationSettleTimer = null;

  function isAbortError(error) {
    if (!error) return false;
    if (error.name === 'AbortError') return true;
    var message = String(error.message || error);
    return /\babort(?:ed)?\b/i.test(message);
  }

  function clearNavigationOverlay() {
    if (navigationSettleTimer) { clearTimeout(navigationSettleTimer); navigationSettleTimer = null; }
    if (navigationOverlay && navigationOverlay.parentNode) navigationOverlay.parentNode.removeChild(navigationOverlay);
    navigationOverlay = null;
    try { sessionStorage.removeItem(NAV_STORAGE_KEY); } catch (e) {}
  }

  function maybeClearNavigationOverlay() {
    // 車両・配信画面はload後にもSPA側が一覧を組み立てるため、
    // USER_SCRIPT側の準備完了通知まではマスクを維持する。
    if (isManagedNavigationPath()) return;
    if (!navigationOverlay || !navigationLoaded || getActiveRequests() > 0) return;
    if (navigationSettleTimer) clearTimeout(navigationSettleTimer);
    navigationSettleTimer = setTimeout(function () {
      navigationSettleTimer = null;
      if (navigationLoaded && getActiveRequests() === 0) clearNavigationOverlay();
    }, 500);
  }

  function isManagedNavigationPath() {
    var path = '';
    try { path = String(window.location && window.location.pathname || ''); } catch (e) {}
    return /^\/vehicles(?:\/|$)/.test(path) || /^\/notifications\/messages(?:\/|$)/.test(path);
  }

  function showNavigationOverlay() {
    if (navigationOverlay && navigationOverlay.parentNode) return;
    // manifest同梱版とリモートMAIN版が同じdocument_startで走っても1枚に保つ。
    var existing = document.querySelector && document.querySelector('[data-dbsext-navigation-loading]');
    if (existing) {
      navigationOverlay = existing;
      return;
    }
    var root = document.documentElement || document.body;
    if (!root || typeof document.createElement !== 'function') return;
    var overlay = document.createElement('div');
    overlay.setAttribute('data-dbsext-navigation-loading', '1');
    overlay.textContent = '読み込み中…';
    overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;background:rgba(235,238,242,.94);color:#334155;font:600 18px sans-serif;';
    root.appendChild(overlay);
    navigationOverlay = overlay;
    setTimeout(clearNavigationOverlay, 20000);
    maybeClearNavigationOverlay();
  }

  document.addEventListener(NAV_EVENT, function () {
    try { sessionStorage.setItem(NAV_STORAGE_KEY, String(Date.now())); } catch (e) {}
    showNavigationOverlay();
  });
  document.addEventListener(NAV_READY_EVENT, clearNavigationOverlay);
  try {
    var navigationStartedAt = Number(sessionStorage.getItem(NAV_STORAGE_KEY) || 0);
    // 対象画面は直リンク・手動reloadでもdocument_startから覆う。
    if (isManagedNavigationPath() || (navigationStartedAt && Date.now() - navigationStartedAt < 30000)) showNavigationOverlay();
    else if (navigationStartedAt) sessionStorage.removeItem(NAV_STORAGE_KEY);
  } catch (e) {}
  if (typeof window.addEventListener === 'function') {
    window.addEventListener('load', function () { navigationLoaded = true; maybeClearNavigationOverlay(); }, { once: true });
  }

  if (typeof window.__dbsext_main_active_requests !== 'number') {
    window.__dbsext_main_active_requests = 0;
  }

  function getActiveRequests() {
    return Math.max(0, window.__dbsext_main_active_requests || 0);
  }

  function incrementActive() {
    window.__dbsext_main_active_requests = getActiveRequests() + 1;
    if (navigationSettleTimer) { clearTimeout(navigationSettleTimer); navigationSettleTimer = null; }
  }

  function decrementActive() {
    window.__dbsext_main_active_requests = Math.max(0, getActiveRequests() - 1);
    maybeClearNavigationOverlay();
  }

  function dispatch(name, detail) {
    try {
      var event = new CustomEvent(EVENT_PREFIX + '-' + name, {
        detail: detail || {},
        bubbles: false
      });
      document.dispatchEvent(event);
    } catch (e) {
      // document が使えない環境では何もしない
    }
  }

  function dispatchSnapshot() {
    dispatch('snapshot', { activeRequests: getActiveRequests() });
  }

  function hasDbsextAttribute(node) {
    if (!node || node.nodeType !== 1 || !node.attributes) return false;
    for (var i = 0; i < node.attributes.length; i += 1) {
      if (String(node.attributes[i].name || '').indexOf('data-dbsext-') === 0) return true;
    }
    return false;
  }

  function isWithinDbsextOwnRoot(node) {
    if (!node) return false;
    var element = node.nodeType === 1 ? node : node.parentElement;
    if (!element) return false;
    try {
      return !!(element.closest && element.closest('[data-dbsext-upsell],[data-dbsext-launcher],[data-dbsext-panel],[data-dbsext-toast],[data-dbsext-banner],[data-dbsext-loading],[data-dbsext-navigation-loading],[data-dbsext-top-scrollbar],[data-dbsext-fab],[data-dbsext-modal],[data-dbsext-inline-ui]'));
    } catch (e) {
      return false;
    }
  }

  function isDbsextAddedNode(node) {
    if (!node) return false;
    var element = node.nodeType === 1 ? node : node.parentElement;
    return !!(element && (hasDbsextAttribute(element) || isWithinDbsextOwnRoot(element)));
  }

  function containsPortalDomChange(mutations) {
    for (var i = 0; i < mutations.length; i += 1) {
      var mutation = mutations[i];
      // targetに付ける data-dbsext-tabled 等は純正DOMへの目印であって、
      // 自前UIではない。OWN rootの内側だけを自己変更として除外する。
      if (isWithinDbsextOwnRoot(mutation.target)) continue;
      if (mutation.type === 'characterData') return true;
      if (mutation.removedNodes && mutation.removedNodes.length) return true;
      var added = mutation.addedNodes || [];
      for (var j = 0; j < added.length; j += 1) {
        if (!isDbsextAddedNode(added[j])) return true;
      }
    }
    return false;
  }

  // USER_SCRIPT world では MutationObserver.observe(document) が Node 型不一致を
  // 投げる実機事例がある。DOMを正しく扱える MAIN world で監視し、イベントだけを
  // USER_SCRIPTへ渡す。二重注入時も1本だけにする。
  if (!window.__dbsext_main_dom_observer_installed && typeof MutationObserver !== 'undefined') {
    window.__dbsext_main_dom_observer_installed = true;
    var domChangeTimer = null;
    try {
      var domObserver = new MutationObserver(function (mutations) {
        // 拡張自身のUI追加では通知せず、再適用の自己ループを防ぐ。
        if (!containsPortalDomChange(mutations || [])) return;
        if (domChangeTimer) clearTimeout(domChangeTimer);
        domChangeTimer = setTimeout(function () {
          domChangeTimer = null;
          try { document.dispatchEvent(new CustomEvent(DOM_CHANGE_EVENT)); } catch (e) {}
        }, 100);
      });
      var domTarget = document.documentElement || document;
      domObserver.observe(domTarget, { childList: true, subtree: true, characterData: true });
      window.__dbsext_main_dom_observer = domObserver;
    } catch (e) {
      window.__dbsext_main_dom_observer_installed = false;
    }
  }

  if (!window.__dbsext_main_query_listener_installed) {
    window.__dbsext_main_query_listener_installed = true;
    document.addEventListener('dbsext:main-fetch-query', function () {
      dispatchSnapshot();
    });
  }

  // ---- fetch のラップ ----

  if (window.fetch && !window.fetch.__dbsext_main_wrapped) {
    var _origFetch = window.fetch;

    window.fetch = function (input, init) {
      var url = '';
      try {
        if (typeof input === 'string') {
          url = input;
        } else if (input && typeof input.url === 'string') {
          url = input.url;
        } else if (input && typeof input.href === 'string') {
          url = input.href;
        }
      } catch (e) {}

      var isPortal = url.indexOf('https://mg.docomo-cycle.jp/') === 0 ||
                     (url.indexOf('/') === 0 && url.indexOf('//') !== 0);

      if (isPortal) {
        incrementActive();
        dispatch('start', { activeRequests: getActiveRequests() });
      }

      var promise;
      try {
        promise = _origFetch.apply(this, arguments);
      } catch (err) {
        if (isPortal) {
          decrementActive();
          dispatch('end', { status: 0, error: true, activeRequests: getActiveRequests() });
        }
        throw err;
      }

      return promise.then(
        function (res) {
          if (isPortal) {
            decrementActive();
            dispatch('end', { status: res ? res.status : 0, activeRequests: getActiveRequests() });
          }
          return res;
        },
        function (err) {
          if (isPortal) {
            decrementActive();
            dispatch('end', { status: 0, error: !isAbortError(err), aborted: isAbortError(err), activeRequests: getActiveRequests() });
          }
          return Promise.reject(err);
        }
      );
    };

    window.fetch.__dbsext_main_wrapped = true;
  }

  // ---- XMLHttpRequest のラップ ----

  if (typeof XMLHttpRequest !== 'undefined' &&
      XMLHttpRequest.prototype &&
      XMLHttpRequest.prototype.send &&
      !XMLHttpRequest.prototype.send.__dbsext_main_wrapped) {

    var _origSend = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.send = function () {
      var xhr = this;
      var isPortal = false;

      try {
        var rawUrl = '';
        try {
          rawUrl = (typeof xhr._dbsext_url === 'string') ? xhr._dbsext_url : '';
        } catch (e) {}
        isPortal = rawUrl.indexOf('https://mg.docomo-cycle.jp/') === 0 ||
                   (rawUrl.indexOf('/') === 0 && rawUrl.indexOf('//') !== 0);
      } catch (e) {}

      if (isPortal) {
        incrementActive();
        dispatch('start', { activeRequests: getActiveRequests() });
      }

      var onEnd = function () {
        xhr.removeEventListener('loadend', onEnd);
        if (isPortal) {
          decrementActive();
          dispatch('end', { status: xhr.status, activeRequests: getActiveRequests() });
        }
      };
      xhr.addEventListener('loadend', onEnd);

      try {
        return _origSend.apply(this, arguments);
      } catch (err) {
        xhr.removeEventListener('loadend', onEnd);
        if (isPortal) {
          decrementActive();
          dispatch('end', { status: 0, error: true, activeRequests: getActiveRequests() });
        }
        throw err;
      }
    };

    XMLHttpRequest.prototype.send.__dbsext_main_wrapped = true;

    // XHR の open() もラップして URL を保存する。
    if (XMLHttpRequest.prototype.open &&
        !XMLHttpRequest.prototype.open.__dbsext_main_wrapped) {
      var _origOpen = XMLHttpRequest.prototype.open;
      XMLHttpRequest.prototype.open = function (method, url) {
        try { this._dbsext_url = String(url || ''); } catch (e) {}
        return _origOpen.apply(this, arguments);
      };
      XMLHttpRequest.prototype.open.__dbsext_main_wrapped = true;
    }
  }

  dispatchSnapshot();
})();
