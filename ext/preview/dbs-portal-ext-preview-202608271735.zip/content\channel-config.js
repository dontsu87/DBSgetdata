(function(global){'use strict';global.DBSEXT_CHANNEL=Object.freeze({"name":"preview","label":"PREVIEW"});})(typeof globalThis!=='undefined'?globalThis:self);
