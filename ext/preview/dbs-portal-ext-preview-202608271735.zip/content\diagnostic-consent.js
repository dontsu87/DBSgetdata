(function () {
  'use strict';
  if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) return;

  function decide(state, root) {
    chrome.runtime.sendMessage({ type: 'dbsext:diagnosticConsentSet', state: state }, function () {
      if (root && root.parentNode) root.parentNode.removeChild(root); // dbsext:own-ui
    });
  }

  function show() {
    if (document.querySelector('[data-dbsext-diagnostic-consent]')) return;
    var root = document.createElement('section');
    root.setAttribute('data-dbsext-diagnostic-consent', '1');
    root.setAttribute('role', 'dialog');
    root.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;max-width:420px;padding:16px;background:#fff;border:2px solid #0b5cab;color:#111;box-shadow:0 4px 20px rgba(0,0,0,.3)';
    var text = document.createElement('p');
    text.textContent = '品質改善のため、個人・顧客・業務データを含まない固定項目の匿名診断を送信してもよいですか。後から変更できます。';
    var accept = document.createElement('button'); accept.textContent = '同意する';
    var decline = document.createElement('button'); decline.textContent = '同意しない'; decline.style.marginLeft = '12px';
    accept.addEventListener('click', function () { decide('accepted', root); });
    decline.addEventListener('click', function () { decide('declined', root); });
    root.addEventListener('keydown', function (event) { if (event.key === 'Escape') decide('declined', root); });
    root.appendChild(text); root.appendChild(accept); root.appendChild(decline);
    (document.body || document.documentElement).appendChild(root);
  }

  chrome.runtime.sendMessage({ type: 'dbsext:diagnosticConsentGet' }, function (result) {
    if (!result || result.state === 'unknown') show();
  });
})();
