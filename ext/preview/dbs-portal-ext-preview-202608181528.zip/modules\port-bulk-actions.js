/**
 * DBSEXT ポート情報 一括操作モジュール
 *
 * `/ports` 限定。選択した複数ポートに対し、運用状態の変更をまとめて実行する。
 *
 * ---------------------------------------------------------------------------
 * これは契約§6の原則に対する明示的な例外である
 * ---------------------------------------------------------------------------
 * 他の全モジュールは読み取り専用（GET）に徹しているが、このモジュールだけは
 * `PUT /api/ports/{portId}` を発行する。2026-08-12 人間決裁により、実機での
 * 検証（`docs/02-portal-facts.md` §5「フェーズ0.5 実施結果」）を踏まえた
 * 限定的な例外として認められている。詳細は `AGENTS.md` 禁止事項1の例外条項、
 * `docs/06-module-contract.md` §6の例外条項を参照。
 *
 * **この例外は本ファイルの書き込み先（`/api/ports/{portId}` へのPUT）に限定される。**
 * 他のいかなるエンドポイントへの更新系リクエストも許可されない。
 *
 * ---------------------------------------------------------------------------
 * 最重要の安全ルール: レコード全体を送り返す方式である
 * ---------------------------------------------------------------------------
 * 実機確認の結果、`PUT /api/ports/{portId}` は**レコード全体**を要求する
 * （部分更新ではない）。ポート名・住所・緯度経度・シェアリング設定・
 * ビーコン紐付け配列まで、画面に出ている・出ていないに関わらず全項目を
 * 含めて送り返す必要がある。
 *
 * そのため、**対象ポートごとに実行の直前で必ず`GET /api/ports/{portId}`から
 * 最新のレコードを取得し直し、変更したい項目以外は一切書き換えずに
 * そのまま`PUT`で送り返す。** 選択時に読み込んだ一覧のキャッシュや、
 * 他のポートを処理している間に古くなったデータを使い回してはいけない。
 * さもないと、意図しない項目（シェアリング設定・予約数・ビーコン紐付け等）
 * を静かに壊す恐れがある。取得した応答が本当に完全なレコードかも検証する
 * （`isValidPortDetailRecord()`。2026-08-12 独立監査で「形を検証していない」と
 * 指摘され対応した）。
 *
 * ---------------------------------------------------------------------------
 * 変更対象フィールドの確度について
 * ---------------------------------------------------------------------------
 * - `serviceState`（運用状態）: `investigation/probe_service_state_options.py`
 *   （2026-08-12・非破壊。ドロップダウンを開いて選択肢を読むだけで何も選ばず閉じた）で
 *   全選択肢を確認済み: 「運用中」「運用中（貸出制限中）」「一時駐輪用」「一時休止中」「停止中」。
 *   「停止中」「一時休止中」は2026-08-12にPUTでの往復を実測済み（`docs/02-portal-facts.md`§5）。
 *   残り3値（「運用中」「運用中（貸出制限中）」「一時駐輪用」）も2026-08-13、依頼者立ち会いの
 *   もと本機能自体で実際に変更し、ポータル画面上で正しく反映されることを実機確認済み
 * - `publishFlag`（公開・非公開）: `investigation/probe_port_field_mapping.py`
 *   （2026-08-12・非破壊。敦賀エリア8ポートで詳細画面のラジオボタン選択状態と
 *   `GET /api/ports/{id}`の`publishFlag`を突き合わせ）で、**8件すべて`公開`⇔`true`が一致**
 *   することを確認済み。`false`⇔`非公開`の対応は当時サンプルが無く推論（消去法）だったが、
 *   2026-08-13、依頼者立ち会いのもと本機能自体で実際に`非公開`へ変更し、ポータル画面上で
 *   正しく反映されることを実機確認済み（推論どおりの対応で確定）
 *
 * ---------------------------------------------------------------------------
 * 実行中の画面・エリア変更に対する安全装置（2026-08-12 独立監査で指摘・対応）
 * ---------------------------------------------------------------------------
 * 逐次実行は複数秒〜数十秒かかりうる。その間に利用者が `/ports` から離れたり
 * 別エリアを選び直したりした場合、**古い対象への書き込みを続けてはいけない。**
 * `activeRunToken` で「今有効な実行」を1つに絞り、各行の処理直前・直後に
 * 画面パス・選択中エリア・トークンの一致を再確認する（`isRunStillValid()`）。
 * 不一致になった時点で、実行中の1件だけ完了させ、以降は「中断」と同じ扱いで
 * スキップする。
 */
(function (global) {
  'use strict';
  var D = global.DBSEXT;

  var PANEL_ATTR = 'data-dbsext-port-bulk-panel';
  var PACE_MS = 700; // 行間の意図的な待機。タイトループにしない
  var CACHE_TTL_MS = 60 * 1000; // 1分。一覧の再取得負荷を抑えるだけの短いキャッシュ

  // 運用状態の選択肢。実機のドロップダウンを非破壊で読んで確認済み（上記コメント参照）
  var SERVICE_STATE_OPTIONS = ['運用中', '運用中（貸出制限中）', '一時駐輪用', '一時休止中', '停止中'];
  // 公開設定の選択肢。true=公開 / false=非公開（上記コメント参照。非公開側は推論）
  var PUBLISH_FLAG_OPTIONS = [
    { label: '公開', value: true },
    { label: '非公開', value: false }
  ];
  // 2026-08-12: 実機の非破壊調査（上記コメント参照）で公開⇔trueの対応を確認できたため有効化
  var PUBLISH_FLAG_VERIFIED = true;
  var NO_CHANGE = '__no_change__';

  var cacheByArea = Object.create(null); // areaId -> { rows, timestamp }
  // portId -> { value: boolean|null, timestamp }。表示専用（書き込み判定には使わない。
  // 書き込み直前は必ず startExecution() が別途 fetchPortDetail() で取り直す）
  var publishFlagCache = Object.create(null);
  // ensurePublishFlags()の同時GET数を絞るスロット状態（`platform-page.js`の
  // runWithBeaconPortSlot()と同じ考え方。2026-08-12独立監査「一覧の行数ぶん
  // 無制限に同時発行している」への対応）
  var publishFlagSlotsActive = 0;
  var publishFlagSlotQueue = [];
  var PUBLISH_FLAG_CONCURRENCY = 3;
  var selectedIds = Object.create(null); // portId -> true
  var currentGeneration = 0; // 画面/エリアの世代（エリア切替・離脱のたびに進める。早期無効化用）
  var listFetchSeq = 0; // 一覧取得の通し番号（フェッチ開始のたびに進める。追い越し検知用）
  var activeRunToken = 0; // 逐次実行の世代（実行開始のたびに進める）
  var runState = null; // { aborted, results, total, token }

  // ---------------------------------------------------------------------------
  // ヘルパ
  // ---------------------------------------------------------------------------

  function isValidPortalId(value) {
    return typeof value === 'string' && value.length >= 1 && value.length <= 256 && /^[A-Za-z0-9:_-]+$/.test(value);
  }

  /** `beacons.js` と同じ手法。URLの `selected-area-id` を読む */
  function getSelectedAreaId() {
    if (typeof location === 'undefined' || !location.search) return null;
    var match = location.search.match(/[?&]selected-area-id=([^&]+)/);
    if (!match) return null;
    try {
      var decoded = decodeURIComponent(match[1]);
      if (isValidPortalId(decoded)) return decoded;
    } catch (e) {
      // 不正な percent encoding
    }
    return null;
  }

  function isPortsListPath() {
    return typeof location !== 'undefined' && location.pathname === '/ports';
  }

  function clearNode(node) {
    while (node.firstChild) node.removeChild(node.firstChild); // dbsext:own-ui
  }

  // 実機確認済みのレコード全項目（敦賀「19.ニューサンピア敦賀」でのPUTボディ実測。
  // `docs/02-portal-facts.md` §5参照）。**この一覧が唯一の宣言場所。**
  // 2026-08-12 3回目独立監査「3項目しか見ておらず不完全な応答でもPUTしてしまう」
  // への対応。欠けていれば「不完全」として弾き、その行は失敗扱いにする（PUTしない）。
  // 実機の別ポートで未知のフィールドが増減する可能性はあるが、
  // **未知の欠落を検出できない方が実害（他項目の消失）が大きいため、判定は厳しめに倒す。**
  //
  // 2026-08-12 本番配信後の実機テストで「ポート詳細の応答形式が不正です」により
  // 全件失敗（`investigation/probe_port_detail_shape.py`で `GET /api/ports/{id}` を
  // 2ポート実測して確認）。**`beaconIds` は `GET` 応答に一度も含まれないキーだった。**
  // 手動PUT実測（§5）で観測した「PUTボディにbeaconIdsが含まれる」事実は、ポータル
  // 純正のVueアプリが別経路（このGETとは別のAPI）から補って送信しているためと見られ、
  // `GET`をそのまま返す本機能では最初から取得できない値だった。よって必須項目から外す。
  // `buildUpdatedRecord()` は `record` に存在するキーだけをコピーするため、
  // `beaconIds` を必須から外しても「無いものを勝手に空配列として送る」動作にはならず、
  // 実際のGET応答をそのまま返す（＝このキー自体を含まないPUTボディになる）。
  //
  // 2026-08-13 上記の503対策として一時的に入れていた「欠落時は空配列[]を補う」実装
  // （後述buildUpdatedRecord参照）が、**ビーコンが紐づくポートで紐付けを消す実害が
  // あることを敦賀エリアで確定した**（`investigation/probe_beacon_linked_port_shape.py`。
  // `GET /api/ports/{id}/beacons`でビーコン紐付き済みと確認できた敦賀5ポートすべてで、
  // `GET /api/ports/{id}`の応答に`beaconIds`キーが無かった。つまりこのキーの有無は
  // 「ビーコンの有無」を一切表さず常に省略される。結果採取:
  // `investigation/out/beacon-linked-port-detail-shape.json`）。ビーコンが紐づく
  // ポート（今回確認した敦賀20ポート全数）へ一括操作を行うたび紐付けが消えていた。
  //
  // 2026-08-13 続き: 依頼者提供の実機PUTログ（フェーズ0.5、DevTools記録）と
  // `GET /api/ports/{id}/beacons`応答を突き合わせたところ、実際に送信された
  // `beaconIds`配列の値が、この`/beacons`応答の`portBeaconId`フィールドと
  // **完全一致**することが確認できた（`investigation/probe_beacon_id_field_match.py`）。
  // これにより`fetchPortBeaconIds()`（読み取り専用）で正しい`beaconIds`値そのものを
  // 復元してPUTできるようになった。復元に失敗した場合（応答形式が不正・
  // `portBeaconId`が欠けている等）だけ**推測でPUTせず、その行を失敗扱いにする**
  // （安全側優先。`buildUpdatedRecord()`が例外を投げ、既存の1件失敗時の継続処理に乗る）。
  var REQUIRED_RECORD_KEYS = [
    'portUniqueCode', 'portNameJa', 'portNameEn', 'portBusinessType',
    'affiliationAreaId', 'affiliationBlockId', 'serviceState', 'publishFlag',
    'location', 'globalLocationLatitude', 'globalLocationLongitude',
    'portAddressPostCode', 'portAddressPrefecture', 'portAddressMunicipalities',
    'portAddressBuilding', 'businessHoursStartTime', 'businessHoursEndTime',
    'businessHoursNote', 'portImageId', 'directionsComment', 'note',
    'sharingSetting', 'portRange', 'rackCount', 'parkingQuantityLimitationFlag',
    'portAppropriateVehicleQuantity', 'parkingQuantity', 'returnReservationQuantity',
    'lastReceivedTs', 'returnableVehicleQuantity',
    'portSharedBys', 'portSharingTos', 'landownerSettlements'
  ];
  var REQUIRED_ARRAY_KEYS = ['portSharedBys', 'portSharingTos', 'landownerSettlements'];

  /**
   * `GET /api/ports/{id}` の応答が本当に完全なレコードかを確認する。
   * 2026-08-12 独立監査（1回目・3回目）「形を検証せずPUTしている」「3項目しか
   * 見ておらず不完全な応答でも通る」への対応。ポートIDそのものはレコード本文に
   * 含まれない仕様（実機確認済み）のため、一致確認はできないが、既知の
   * 必須フィールド**全項目**の存在・型を確かめる。
   */
  function isValidPortDetailRecord(record) {
    if (!record || typeof record !== 'object' || Array.isArray(record)) return false;
    for (var i = 0; i < REQUIRED_RECORD_KEYS.length; i++) {
      if (!Object.prototype.hasOwnProperty.call(record, REQUIRED_RECORD_KEYS[i])) return false;
    }
    if (typeof record.serviceState !== 'string') return false;
    if (typeof record.publishFlag !== 'boolean') return false;
    for (var j = 0; j < REQUIRED_ARRAY_KEYS.length; j++) {
      if (!Array.isArray(record[REQUIRED_ARRAY_KEYS[j]])) return false;
    }
    return true;
  }

  // ---------------------------------------------------------------------------
  // API呼び出し
  // ---------------------------------------------------------------------------

  /** 一覧取得（読み取り専用）。areaId/portIdはポータル自身が発行するID形式（コロン込み）で、
   * 実機確認済みのURLはコロンをエンコードしない形だったため、ここでも合わせる */
  function fetchPortsList(areaId) {
    var url = '/api/ports/bulk?areaIds=' + areaId;
    return fetch(url, { credentials: 'include' }).then(function (res) {
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return res.json();
    }).then(function (items) {
      return Array.isArray(items) ? items : [];
    });
  }

  /**
   * 対象ポートの最新レコードを取得（読み取り専用）。実行の直前に毎回呼ぶこと。
   * 応答の形も検証する（不正なら例外を投げ、呼び出し側で「失敗」として扱う）。
   */
  function fetchPortDetail(portId) {
    var url = '/api/ports/' + portId;
    return fetch(url, { credentials: 'include' }).then(function (res) {
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return res.json();
    }).then(function (record) {
      if (!isValidPortDetailRecord(record)) {
        throw new Error('ポート詳細の応答形式が不正です');
      }
      return record;
    });
  }

  /**
   * 対象ポートに紐づくビーコンIDの配列を、実際の紐付けから正しく復元する（読み取り専用）。
   * `beacons.js`/`platform-page.js`のfetchBeaconsByAreaと同じ、ビーコン一覧機能が
   * 既に使っているAPI（`GET /api/ports/{id}/beacons`）。
   *
   * `GET /api/ports/{id}`（`fetchPortDetail`）の応答は`beaconIds`キーを常に省略し、
   * それはビーコンの有無を表さない（2026-08-13 敦賀20ポート全数調査で確認。
   * 上記`REQUIRED_RECORD_KEYS`のコメント参照）。
   *
   * 2026-08-13 依頼者提供の実機PUTログ（フェーズ0.5・敦賀「19.ニューサンピア敦賀」
   * `PORT:01KY4PF9WD29EZHYZPCBFC7ZRW-t`、DevTools記録）で、実際に送信された
   * `beaconIds: ["BECN:01KYWEZ37GJT9ZGK9B8XZQYY8F-t"]` が、この`/beacons`APIの
   * 応答項目の`portBeaconId`フィールドと**完全一致**することを実機で確認した
   * （`investigation/probe_beacon_id_field_match.py`。同じポート・同じ値で照合）。
   * よってこの関数は「紐づきの有無」だけでなく**正しい値そのもの**を復元して返す。
   *
   * 応答が期待した形でない場合（配列でない、`portBeaconId`が空文字/非文字列等）は
   * 例外を投げる。復元できない値を推測で埋めるより、その行を失敗させるほうが安全なため
   * （安全側優先。呼び出し側`processIndex`はこの例外をそのまま伝播させ「失敗」として扱う）。
   */
  function fetchPortBeaconIds(portId) {
    var url = '/api/ports/' + portId + '/beacons';
    return fetch(url, { credentials: 'include' }).then(function (res) {
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return res.json();
    }).then(function (body) {
      var items = Array.isArray(body) ? body
        : (body && Array.isArray(body.dataList)) ? body.dataList
        : (body && Array.isArray(body.items)) ? body.items
        : (body && Array.isArray(body.data)) ? body.data
        : null;
      if (!Array.isArray(items)) {
        throw new Error('ビーコン一覧の応答形式が不正です');
      }
      var ids = [];
      for (var i = 0; i < items.length; i++) {
        var id = items[i] && items[i].portBeaconId;
        if (typeof id !== 'string' || !id) {
          throw new Error('ビーコン識別番号の形式が不正です');
        }
        ids.push(id);
      }
      return ids;
    });
  }

  /**
   * レコード全体を送り返す。**唯一の書き込みエンドポイント。**
   * `record` は直前の `fetchPortDetail` の結果をそのまま使い、
   * 変更したいフィールドだけを書き換えたものであること。
   */
  function putPortDetail(portId, record) {
    var url = '/api/ports/' + portId;
    return fetch(url, {
      method: 'PUT',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(record)
    }).then(function (res) {
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return res;
    });
  }

  // ---------------------------------------------------------------------------
  // パネル構築
  // ---------------------------------------------------------------------------

  function ensurePanel() {
    var existing = document.querySelector('[' + PANEL_ATTR + ']');
    if (existing) return existing;

    var insertion = findInsertionPoint();
    if (!insertion) return null;

    var panel = document.createElement('div');
    panel.setAttribute(PANEL_ATTR, '1');
    panel.className = 'dbsext-port-bulk-panel';

    var heading = document.createElement('h2');
    heading.textContent = 'ポート一括操作（拡張）';
    panel.appendChild(heading);

    var status = document.createElement('div');
    status.className = 'dbsext-port-bulk-status';
    panel.appendChild(status);

    var toolbar = document.createElement('div');
    toolbar.className = 'dbsext-port-bulk-toolbar';
    panel.appendChild(toolbar);

    var tableWrap = document.createElement('div');
    tableWrap.className = 'dbsext-port-bulk-table-wrap';
    tableWrap.setAttribute('data-dbsext-table-scroll', '1');
    panel.appendChild(tableWrap);

    var confirmBox = document.createElement('div');
    confirmBox.className = 'dbsext-port-bulk-confirm';
    confirmBox.style.display = 'none';
    panel.appendChild(confirmBox);

    var resultsBox = document.createElement('div');
    resultsBox.className = 'dbsext-port-bulk-results';
    resultsBox.style.display = 'none';
    panel.appendChild(resultsBox);

    if (insertion.targetSibling) {
      insertion.container.insertBefore(panel, insertion.targetSibling);
    } else {
      insertion.container.appendChild(panel);
    }

    return panel;
  }

  /** ポータル標準の表の直前に置く（`beacons.js` の `findInsertionPoint` と同じ考え方） */
  function findInsertionPoint() {
    var portalTable = document.querySelector('.el-table:not([data-dbsext-port-bulk-table])');
    if (!portalTable) {
      // 表がまだ描画されていない場合は本文の適当な位置に足す
      var main = document.querySelector('main') || document.body;
      return main ? { container: main, targetSibling: main.firstChild } : null;
    }
    var section = portalTable;
    while (section && section !== document.body && section !== document.documentElement) {
      if (section.classList && section.classList.contains('mb-4') && section.parentNode) {
        return { container: section.parentNode, targetSibling: section };
      }
      section = section.parentNode;
    }
    return portalTable.parentNode ? { container: portalTable.parentNode, targetSibling: portalTable } : null;
  }

  /**
   * ポータル純正の`.el-table`を表示/非表示にする（依頼1対応）。
   * 削除・移動はしない（契約§6）。`display`を切り替えるだけ。
   * SPA再描画で純正表のDOMノードが作り直される場合に備え、毎回その場で探し直す。
   */
  function setNativeTableHidden(hidden) {
    var t = document.querySelector('.el-table:not([data-dbsext-port-bulk-table])');
    if (t) t.style.display = hidden ? 'none' : '';
    return t;
  }

  function setStatus(panel, text, kind) {
    var status = panel.querySelector('.dbsext-port-bulk-status');
    if (!status) return;
    status.textContent = text || '';
    status.className = 'dbsext-port-bulk-status' + (kind ? ' dbsext-port-bulk-status--' + kind : '');
  }

  // ---------------------------------------------------------------------------
  // 表の描画（自前表。custom-table アダプタを使う）
  // ---------------------------------------------------------------------------

  /**
   * 表をデータ更新で描き直す場合に、利用者が操作中の状態を引き継ぐ。
   * custom-table は再描画時に state を作り直すため、条件オブジェクトを複製して
   * 次の表へ渡す（元の state を共有すると新旧表のイベントが混線する）。
   */
  function snapshotTableState(result) {
    var state = result && result.state;
    if (!state) return null;
    var snapshot = {
      sortColIndex: state.sortColIndex,
      sortOrder: state.sortOrder,
      conditions: {}
    };
    var conditions = state.conditions || {};
    for (var key in conditions) {
      if (!Object.prototype.hasOwnProperty.call(conditions, key) || !conditions[key]) continue;
      var condition = conditions[key];
      snapshot.conditions[key] = {
        kind: condition.kind,
        text: condition.text,
        min: condition.min,
        max: condition.max
      };
    }
    return snapshot;
  }

  function renderTable(panel, rows) {
    var tableWrap = panel.querySelector('.dbsext-port-bulk-table-wrap');
    if (!tableWrap) return;

    var previousState = snapshotTableState(panel.__dbsextPortBulkTableResult);

    // **一覧が入れ替わるたびに選択状態を今の行に合わせる。**
    // 2026-08-12 独立監査「古い選択IDを実行対象にできる」への対応。
    // 一覧から消えた・識別番号が不正な行の選択は残さない
    var validIds = Object.create(null);
    for (var r = 0; r < rows.length; r++) {
      if (rows[r] && isValidPortalId(rows[r].portId)) validIds[rows[r].portId] = true;
    }
    for (var key in selectedIds) {
      if (!validIds[key]) delete selectedIds[key];
    }

    var areaId = getSelectedAreaId();

    var columns = [
      {
        label: '選択',
        value: function (row) { return selectedIds[row.portId] ? '1' : '0'; },
        render: function (td, row) {
          // 識別番号が不正な行は選択させない（そのまま書き込みURLへ連結されるため）
          if (!isValidPortalId(row.portId)) {
            td.textContent = '（識別番号不正）';
            return;
          }
          var checkbox = document.createElement('input');
          checkbox.type = 'checkbox';
          checkbox.className = 'dbsext-port-bulk-checkbox';
          // 見出しの「一括選択」チェックボックスが、表示中の行を辿るための目印。
          // data-dbsext-* ではない自前の属性なので ATTR_KIND への登録は不要
          checkbox.setAttribute('data-port-id', row.portId);
          checkbox.checked = !!selectedIds[row.portId];
          checkbox.addEventListener('change', function () {
            if (checkbox.checked) selectedIds[row.portId] = true;
            else delete selectedIds[row.portId];
            updateToolbar(panel);
            syncSelectAllHeaderCheckbox(panel);
          });
          td.appendChild(checkbox);
        }
      },
      {
        label: 'ポート識別番号',
        value: function (row) { return row.portUniqueCode != null ? String(row.portUniqueCode) : ''; },
        render: function (td, row) {
          var text = row.portUniqueCode != null ? String(row.portUniqueCode) : '';
          // オリジナルの一覧行と同様、個別編集画面をタブ開きにする（依頼2対応）。
          // 識別番号が不正な行はリンク化しない（URLへそのまま連結されるため）
          if (!isValidPortalId(row.portId)) {
            td.textContent = text;
            return;
          }
          var a = document.createElement('a');
          a.className = 'dbsext-cell-link';
          a.setAttribute('href', '/ports/' + row.portId + (areaId ? '?selected-area-id=' + areaId : ''));
          a.setAttribute('target', '_blank');
          a.setAttribute('rel', 'noopener');
          a.textContent = text;
          td.appendChild(a);
        }
      },
      { label: 'ポート名', value: function (row) { return row.portNameJa || ''; } },
      { label: '運用状態', value: function (row) { return row.serviceState || ''; } },
      {
        // 一覧API（GET /api/ports/bulk）にはpublishFlagが含まれない（実機確認済み。
        // investigation/probe_port_list_shape.py）ため、この列は行ごとに個別GETした
        // 結果（publishFlagCache）を表示する。ensurePublishFlags()が非同期で埋める
        label: '公開設定',
        // 「公開」「非公開」以外の値は無い列挙値のため、絞り込みは文字入力ではなく
        // プルダウン選択式にする（table-kit.js のFILTER_SELECT。完全一致で絞り込む）。
        // PUBLISH_FLAG_OPTIONSのlabelをそのまま使い、表記のずれを防ぐ
        filterOptions: PUBLISH_FLAG_OPTIONS.map(function (o) { return o.label; }),
        value: function (row) {
          var entry = publishFlagCache[row.portId];
          if (!entry || entry.value === null || entry.value === undefined) return '';
          return entry.value ? '公開' : '非公開';
        },
        render: function (td, row) {
          td.setAttribute('data-publish-cell-port-id', row.portId);
          var entry = publishFlagCache[row.portId];
          if (!entry) { td.textContent = '取得中…'; return; }
          if (entry.value === null || entry.value === undefined) { td.textContent = '不明'; return; }
          td.textContent = entry.value ? '公開' : '非公開';
        }
      }
    ];

    var result = D.customTable.render({
      container: tableWrap,
      rows: rows,
      columns: columns,
      tableAttrs: { 'data-dbsext-port-bulk-table': '1' },
      emptyText: '絞り込み条件に一致するポートはありません。',
      initialState: previousState,
      // 2026-08-12独立監査「絞り込み・並替のたびにtbodyが再構築されるが、見出しの
      // 一括選択チェックボックスのchecked/indeterminateが古いままになる」への対応。
      // custom-table.jsのrefresh()（絞り込み・並替時）のたびにこのコールバックが
      // 呼ばれるので、その場で見出しの見た目を今のtbodyに合わせ直す
      onRefresh: function () { syncSelectAllHeaderCheckbox(panel); }
    });

    panel.__dbsextPortBulkTableResult = result;

    addSelectAllHeaderCheckbox(panel, result && result.table);
  }

  /** 同じデータに対する再適用では表とツールバーを作り直さない。 */
  function renderIfNeeded(panel, areaId, rows) {
    var table = panel.querySelector('[data-dbsext-port-bulk-table]');
    var toolbar = panel.querySelector('.dbsext-port-bulk-toolbar');
    var hasToolbar = toolbar && toolbar.querySelector('.dbsext-port-bulk-exec-btn');
    var sameRender = panel.__dbsextPortBulkRenderedAreaId === areaId &&
      panel.__dbsextPortBulkRenderedRows === rows;
    if (sameRender && table && hasToolbar) return false;

    renderTable(panel, rows);
    renderToolbar(panel, rows);
    panel.__dbsextPortBulkRenderedAreaId = areaId;
    panel.__dbsextPortBulkRenderedRows = rows;
    return true;
  }

  /**
   * 選択列の見出しに「表示中の行を一括選択/解除」するチェックボックスを追加する（依頼5対応）。
   * オリジナルの車両情報表（ポータル純正）の見出しチェックボックスと同じ考え方。
   *
   * 自前表(`custom-table.js`)は絞り込みで非該当行を**tbodyから完全に取り除く**方式のため、
   * 「その時点でtbodyに存在する行」＝「絞り込み後に見えている行」となる。よって
   * ハンドラは、tbody内に今ある `.dbsext-port-bulk-checkbox` の `data-port-id` を
   * 一括で選択/解除するだけでよい（`table-tools.js`の`hookVisibleSelectAll()`と
   * 同じ考え方だが、ポータル純正のVue状態を経由しない自前チェックボックスのため
   * `.checked`を直接書き換えてよい）。
   */
  function addSelectAllHeaderCheckbox(panel, table) {
    if (!table) return;
    var headerRow = table.querySelector('thead tr');
    if (!headerRow || !headerRow.children[0]) return;
    var th = headerRow.children[0];

    var checkbox = th.querySelector('.dbsext-port-bulk-select-all');
    if (!checkbox) {
      checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.className = 'dbsext-port-bulk-select-all';
      checkbox.title = '表示中の行をすべて選択／解除';
      checkbox.addEventListener('click', function (e) { e.stopPropagation(); });
      checkbox.addEventListener('change', function () {
        var tbody = table.querySelector('tbody');
        var rowCheckboxes = tbody ? tbody.querySelectorAll('.dbsext-port-bulk-checkbox') : [];
        var shouldSelect = checkbox.checked;
        for (var i = 0; i < rowCheckboxes.length; i++) {
          var cb = rowCheckboxes[i];
          var pid = cb.getAttribute('data-port-id');
          if (!pid) continue;
          cb.checked = shouldSelect;
          if (shouldSelect) selectedIds[pid] = true;
          else delete selectedIds[pid];
        }
        updateToolbar(panel);
      });
      th.insertBefore(checkbox, th.firstChild);
    }
    syncSelectAllHeaderCheckbox(panel);
  }

  /** 見出しチェックボックスの見た目を、今の選択状態（全選択/一部選択/未選択）に合わせる */
  function syncSelectAllHeaderCheckbox(panel) {
    var tableWrap = panel.querySelector('.dbsext-port-bulk-table-wrap');
    var headerCheckbox = tableWrap && tableWrap.querySelector('.dbsext-port-bulk-select-all');
    if (!headerCheckbox) return;
    var rowCheckboxes = tableWrap.querySelectorAll('.dbsext-port-bulk-checkbox');
    var total = rowCheckboxes.length;
    var checkedCount = 0;
    for (var i = 0; i < total; i++) {
      if (rowCheckboxes[i].checked) checkedCount++;
    }
    headerCheckbox.checked = total > 0 && checkedCount === total;
    headerCheckbox.indeterminate = checkedCount > 0 && checkedCount < total;
  }

  // ---------------------------------------------------------------------------
  // ツールバー（選択件数・操作選択・実行ボタン）
  // ---------------------------------------------------------------------------

  function buildOptionEl(value, label) {
    var opt = document.createElement('option');
    opt.value = value;
    opt.textContent = label;
    return opt;
  }

  function renderToolbar(panel, rows) {
    var toolbar = panel.querySelector('.dbsext-port-bulk-toolbar');
    if (!toolbar) return;
    clearNode(toolbar);

    var countLabel = document.createElement('span');
    countLabel.className = 'dbsext-port-bulk-count';
    toolbar.appendChild(countLabel);

    var serviceSelect = document.createElement('select');
    serviceSelect.className = 'dbsext-port-bulk-service-select';
    serviceSelect.appendChild(buildOptionEl(NO_CHANGE, '運用状態を変更しない'));
    for (var i = 0; i < SERVICE_STATE_OPTIONS.length; i++) {
      serviceSelect.appendChild(buildOptionEl(SERVICE_STATE_OPTIONS[i], '運用状態を「' + SERVICE_STATE_OPTIONS[i] + '」にする'));
    }
    toolbar.appendChild(serviceSelect);

    // 公開設定は`公開⇔true`(2026-08-12・8件実測)・`非公開⇔false`(2026-08-13・
    // 依頼者立ち会いで本機能自体を使い実測)の両方向とも確認済みのため常に有効。
    // PUBLISH_FLAG_VERIFIED を参照する箇所はここ1箇所だけ
    var publishSelect = null;
    if (PUBLISH_FLAG_VERIFIED) {
      publishSelect = document.createElement('select');
      publishSelect.className = 'dbsext-port-bulk-publish-select';
      publishSelect.appendChild(buildOptionEl(NO_CHANGE, '公開設定を変更しない'));
      for (var j = 0; j < PUBLISH_FLAG_OPTIONS.length; j++) {
        publishSelect.appendChild(buildOptionEl(String(PUBLISH_FLAG_OPTIONS[j].value), '「' + PUBLISH_FLAG_OPTIONS[j].label + '」にする'));
      }
      toolbar.appendChild(publishSelect);
      publishSelect.addEventListener('change', function () { updateToolbar(panel); });
    } else {
      var note = document.createElement('span');
      note.className = 'dbsext-port-bulk-unverified-note';
      note.textContent = '公開設定の一括変更は実機検証が済むまで提供していません';
      toolbar.appendChild(note);
    }

    var execBtn = document.createElement('button');
    execBtn.type = 'button';
    execBtn.className = 'dbsext-btn dbsext-port-bulk-exec-btn';
    execBtn.textContent = '実行';
    execBtn.addEventListener('click', function () {
      onExecuteClick(panel, rows, serviceSelect.value, publishSelect ? publishSelect.value : NO_CHANGE);
    });
    toolbar.appendChild(execBtn);

    serviceSelect.addEventListener('change', function () { updateToolbar(panel); });

    updateToolbar(panel);
  }

  function updateToolbar(panel) {
    var toolbar = panel.querySelector('.dbsext-port-bulk-toolbar');
    if (!toolbar) return;
    var countLabel = toolbar.querySelector('.dbsext-port-bulk-count');
    var execBtn = toolbar.querySelector('.dbsext-port-bulk-exec-btn');
    var serviceSelect = toolbar.querySelector('.dbsext-port-bulk-service-select');
    var publishSelect = toolbar.querySelector('.dbsext-port-bulk-publish-select');

    var count = Object.keys(selectedIds).length;
    if (countLabel) countLabel.textContent = count + '件選択中';

    if (execBtn) {
      var hasAction = !!(serviceSelect && serviceSelect.value !== NO_CHANGE) ||
        !!(publishSelect && publishSelect.value !== NO_CHANGE);
      execBtn.disabled = count === 0 || !hasAction;
    }
  }

  // ---------------------------------------------------------------------------
  // 確認画面
  // ---------------------------------------------------------------------------

  function describeChanges(serviceValue, publishValue) {
    var lines = [];
    if (serviceValue !== NO_CHANGE) lines.push('運用状態 → 「' + serviceValue + '」');
    if (publishValue !== NO_CHANGE) {
      var label = publishValue === 'true' ? '公開' : '非公開';
      lines.push('公開設定 → 「' + label + '」');
    }
    return lines;
  }

  function onExecuteClick(panel, rows, serviceValue, publishValue) {
    var targetIds = Object.keys(selectedIds);
    if (targetIds.length === 0) return;

    // **確認画面を開いた時点のエリアを固定する。**
    // 2026-08-12 3回目独立監査「URLだけエリアを変えてapply()が呼ばれる前に
    // 古い確認ボタンを押すと、新エリアのrunAreaIdの下で旧エリアのtargetIdsが
    // 実行されてしまう」への対応。確定クリック時に、ここで固定した値と
    // 現在の状態が一致するかを再確認してから実行を始める（時間差を作らない）
    var confirmAreaId = getSelectedAreaId();

    var byId = Object.create(null);
    for (var i = 0; i < rows.length; i++) {
      if (rows[i] && rows[i].portId) byId[rows[i].portId] = rows[i];
    }

    var toolbar = panel.querySelector('.dbsext-port-bulk-toolbar');
    var tableWrap = panel.querySelector('.dbsext-port-bulk-table-wrap');
    var confirmBox = panel.querySelector('.dbsext-port-bulk-confirm');
    if (!confirmBox) return;

    clearNode(confirmBox);

    var title = document.createElement('h3');
    title.textContent = '次の内容で実行します。よろしいですか？';
    confirmBox.appendChild(title);

    var changeList = document.createElement('ul');
    var changes = describeChanges(serviceValue, publishValue);
    for (var c = 0; c < changes.length; c++) {
      var li = document.createElement('li');
      li.textContent = changes[c];
      changeList.appendChild(li);
    }
    confirmBox.appendChild(changeList);

    var targetLabel = document.createElement('p');
    targetLabel.textContent = '対象（' + targetIds.length + '件）:';
    confirmBox.appendChild(targetLabel);

    var targetList = document.createElement('ul');
    targetList.className = 'dbsext-port-bulk-confirm-targets';
    for (var t = 0; t < targetIds.length; t++) {
      var row = byId[targetIds[t]];
      var tli = document.createElement('li');
      tli.textContent = row ? row.portNameJa || targetIds[t] : targetIds[t];
      targetList.appendChild(tli);
    }
    confirmBox.appendChild(targetList);

    var btnRow = document.createElement('div');
    btnRow.className = 'dbsext-port-bulk-confirm-buttons';

    var cancelBtn = document.createElement('button');
    cancelBtn.type = 'button';
    cancelBtn.className = 'dbsext-btn dbsext-btn--plain';
    cancelBtn.textContent = 'キャンセル';
    cancelBtn.addEventListener('click', function () {
      confirmBox.style.display = 'none';
      if (toolbar) toolbar.style.display = '';
      if (tableWrap) tableWrap.style.display = '';
    });
    btnRow.appendChild(cancelBtn);

    var confirmBtn = document.createElement('button');
    confirmBtn.type = 'button';
    confirmBtn.className = 'dbsext-btn';
    confirmBtn.textContent = '確定して実行';
    confirmBtn.addEventListener('click', function () {
      confirmBox.style.display = 'none';
      // **確定の瞬間に、確認画面を開いたときと同じエリア・同じ画面かを再確認する。**
      // 2026-08-12 3回目独立監査への対応。apply()の定期チェックを待たず、
      // この場でその場で確認することで「apply()がまだ呼ばれていない一瞬」の
      // 隙間を無くす
      if (!isPortsListPath() || getSelectedAreaId() !== confirmAreaId) {
        clearNode(confirmBox);
        if (toolbar) toolbar.style.display = '';
        if (tableWrap) tableWrap.style.display = '';
        setStatus(panel, 'エリアまたは画面が変わったため実行を取り消しました。選び直してください。', 'error');
        return;
      }
      startExecution(panel, targetIds, byId, serviceValue, publishValue);
    });
    btnRow.appendChild(confirmBtn);

    confirmBox.appendChild(btnRow);

    confirmBox.style.display = '';
    if (toolbar) toolbar.style.display = 'none';
    if (tableWrap) tableWrap.style.display = 'none';
  }

  // ---------------------------------------------------------------------------
  // 逐次実行エンジン
  // ---------------------------------------------------------------------------

  /**
   * `beaconIdsOverride`: `record`に`beaconIds`が無い場合に補う配列。
   * `fetchPortBeaconIds()`で復元した実際の紐付けID配列（`portBeaconId`の配列。
   * ビーコン無しなら`[]`）を渡すこと。配列でない場合（復元できなかった/未実施）は、
   * 推測で埋めず例外を投げる（安全側優先。呼び出し側`processIndex`はこれをキャッチし、
   * その行を失敗扱いにしてPUTしない）。
   * `record`に既に`beaconIds`が配列で含まれる場合はこの判定自体を通らない
   * （そのまま保持されるため呼ばなくてよい。分岐は`processIndex`側にある）。
   */
  function buildUpdatedRecord(record, serviceValue, publishValue, beaconIdsOverride) {
    // **レコード全体を保つ。** 変更したいフィールドだけを上書きし、
    // それ以外は fetchPortDetail() で取得した値をそのまま残す
    var updated = {};
    for (var key in record) {
      if (Object.prototype.hasOwnProperty.call(record, key)) updated[key] = record[key];
    }
    // 2026-08-12 実機再テストで判明: `beaconIds`キーを含まないPUTはHTTP 503になる。
    // 2026-08-13 敦賀20ポート全数の非破壊調査で確定: `GET /api/ports/{id}`は
    // ビーコンの有無に関わらず常にこのキーを省略する（ビーコン紐付き済み5ポートの
    // サンプルすべてでキーが無かった。`investigation/out/beacon-linked-port-detail-shape.json`）。
    // 依頼者提供の実機PUTログとの突き合わせ（`fetchPortBeaconIds()`のコメント参照）で、
    // `GET /api/ports/{id}/beacons`の`portBeaconId`から正しい`beaconIds`値を復元できる
    // ことが確認できたため、その復元値（`beaconIdsOverride`）を使う。復元できなかった
    // 場合（`fetchPortBeaconIds()`が例外を投げた等）は推測で書き込まず、この行自体を失敗させる。
    if (!Array.isArray(updated.beaconIds)) {
      if (Array.isArray(beaconIdsOverride)) {
        updated.beaconIds = beaconIdsOverride;
      } else {
        throw new Error('ビーコン紐付けを安全に復元できないため書き込みを見送りました');
      }
    }
    if (serviceValue !== NO_CHANGE) updated.serviceState = serviceValue;
    if (publishValue !== NO_CHANGE) updated.publishFlag = publishValue === 'true';
    return updated;
  }

  function startExecution(panel, targetIds, byId, serviceValue, publishValue) {
    // **実行開始時点の画面・エリアを固定する。** 以後、各行の処理直前・直後に
    // これと食い違っていないかを確認する（2026-08-12 独立監査「画面・エリア
    // 切替後も一括書き込みが継続する」への対応）
    //
    // **重要**: 有効性判定は必ず `myToken`（このクロージャ自身のトークン）を
    // `activeRunToken` と比べる。グローバルな `runState.token` を見てはいけない
    // （2026-08-12 再監査で指摘: 旧実行の非同期コールバックが、その時点の
    // グローバル`runState`がたまたま自己無矛盾に見えることをもって
    // 「自分は現役」と誤判定し、新しい実行の状態を破壊しうる欠陥があった）。
    // 同様に、グローバル`runState`を書き換えるのも「自分がまだ現役の実行」の
    // ときだけに限る（`runState === myRunState` を確認してから）。
    var runAreaId = getSelectedAreaId();
    var myToken = ++activeRunToken;
    var myRunState = { aborted: false, results: [], total: targetIds.length, token: myToken };
    runState = myRunState;

    var resultsBox = panel.querySelector('.dbsext-port-bulk-results');
    if (!resultsBox) return;
    clearNode(resultsBox);
    resultsBox.style.display = '';

    var progressHeading = document.createElement('h3');
    progressHeading.className = 'dbsext-port-bulk-progress-heading';
    resultsBox.appendChild(progressHeading);

    var abortBtn = document.createElement('button');
    abortBtn.type = 'button';
    abortBtn.className = 'dbsext-btn dbsext-btn--plain dbsext-port-bulk-abort-btn';
    abortBtn.textContent = '中断';
    abortBtn.addEventListener('click', function () {
      myRunState.aborted = true;
      abortBtn.disabled = true;
      abortBtn.textContent = '中断を受け付けました（実行中の1件は完了します）';
    });
    resultsBox.appendChild(abortBtn);

    var resultList = document.createElement('ul');
    resultList.className = 'dbsext-port-bulk-result-list';
    resultsBox.appendChild(resultList);

    var closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'dbsext-btn dbsext-port-bulk-close-btn';
    closeBtn.textContent = '閉じる';
    closeBtn.style.display = 'none';
    closeBtn.addEventListener('click', function () {
      resultsBox.style.display = 'none';
      var toolbar = panel.querySelector('.dbsext-port-bulk-toolbar');
      var tableWrap = panel.querySelector('.dbsext-port-bulk-table-wrap');
      if (toolbar) toolbar.style.display = '';
      if (tableWrap) tableWrap.style.display = '';
      // 変更を反映するため一覧を再取得する
      var areaId = getSelectedAreaId();
      if (areaId) {
        delete cacheByArea[areaId];
        loadAndRender(panel, areaId, true);
      }
    });
    resultsBox.appendChild(closeBtn);

    function addResultRow(label, kind, detail) {
      var li = document.createElement('li');
      li.className = 'dbsext-port-bulk-result-item dbsext-port-bulk-result-item--' + kind;
      li.textContent = (kind === 'success' ? '✅ ' : kind === 'failed' ? '❌ ' : '⏭ ') +
        label + (detail ? '（' + detail + '）' : '');
      resultList.appendChild(li);
    }

    function updateProgressHeading(doneCount) {
      progressHeading.textContent = '実行中… ' + doneCount + ' / ' + targetIds.length + '件';
    }

    /**
     * 今もこの実行が「現役」か。
     * **必ず`myToken`と`activeRunToken`を比べる**（グローバル`runState.token`ではない）。
     */
    function isRunStillValid() {
      return activeRunToken === myToken && isPortsListPath() && getSelectedAreaId() === runAreaId;
    }

    function skipRemaining(fromIndex, reason) {
      for (var s = fromIndex; s < targetIds.length; s++) {
        var skippedRow = byId[targetIds[s]];
        var skippedLabel = skippedRow ? (skippedRow.portNameJa || targetIds[s]) : targetIds[s];
        myRunState.results.push({ portId: targetIds[s], kind: 'skipped' });
        addResultRow(skippedLabel, 'skipped', reason);
      }
      finish();
    }

    function finish() {
      abortBtn.style.display = 'none';
      closeBtn.style.display = '';
      progressHeading.textContent = '完了しました（' + targetIds.length + '件中 ' +
        myRunState.results.filter(function (r) { return r.kind === 'success'; }).length + '件成功）';
      // **自分がまだ現役の実行のときだけ**グローバル状態を書き換える。
      // 既に新しい実行に取って代わられている場合、その状態を壊してはいけない
      if (runState === myRunState) {
        runState = null;
        selectedIds = Object.create(null);
      }
    }

    function processIndex(index) {
      if (index >= targetIds.length) {
        finish();
        return;
      }

      updateProgressHeading(index);

      if (!isRunStillValid()) {
        skipRemaining(index, '画面またはエリアが変わったため中断');
        return;
      }

      if (myRunState.aborted) {
        skipRemaining(index, '中断のためスキップ');
        return;
      }

      var portId = targetIds[index];
      var row = byId[portId];
      var label = row ? (row.portNameJa || portId) : portId;

      fetchPortDetail(portId)
        .then(function (record) {
          // 取得完了までの間に画面/エリアが変わっていたら、このポートへは書き込まない
          if (!isRunStillValid()) throw new Error('画面またはエリアが変わったため中断');
          // `record`に`beaconIds`が既に配列で含まれる場合はそのまま保持されるだけなので、
          // 追加の復元（`fetchPortBeaconIds`）は不要。無い場合だけ、ビーコン紐付けを
          // 誤って消さないよう直前に正しい値を復元する（読み取り専用の追加GETが1回増える）
          if (Array.isArray(record.beaconIds)) {
            var updatedNoFetch = buildUpdatedRecord(record, serviceValue, publishValue, null);
            return putPortDetail(portId, updatedNoFetch);
          }
          return fetchPortBeaconIds(portId).then(function (beaconIds) {
            if (!isRunStillValid()) throw new Error('画面またはエリアが変わったため中断');
            var updated = buildUpdatedRecord(record, serviceValue, publishValue, beaconIds);
            return putPortDetail(portId, updated);
          });
        })
        .then(function () {
          myRunState.results.push({ portId: portId, kind: 'success' });
          addResultRow(label, 'success', null);
        })
        .catch(function (err) {
          var msg = err && err.message ? err.message : String(err);
          myRunState.results.push({ portId: portId, kind: 'failed', detail: msg });
          addResultRow(label, 'failed', msg);
        })
        .then(function () {
          // 行間に意図的な待機を入れる（タイトループにしない。setIntervalは使わない）
          global.setTimeout(function () {
            if (!isRunStillValid()) { skipRemaining(index + 1, '画面またはエリアが変わったため中断'); return; }
            processIndex(index + 1);
          }, PACE_MS);
        });
    }

    processIndex(0);
  }

  // ---------------------------------------------------------------------------
  // 取得と描画のとりまとめ
  // ---------------------------------------------------------------------------

  /**
   * 表示専用の「公開設定」列を埋めるため、一覧に出ている行のうち未取得/古いものだけ
   * `GET /api/ports/{id}`（読み取り専用）で個別に取得する。1件ずつのGETが直前で
   * 完結しないと次の書き込みに進まない実行エンジン（processIndex）とは無関係の、
   * 表示だけの並行フェッチ。失敗しても「不明」と表示するだけで実行系には影響しない。
   */
  /** 複数の一覧描画を跨いでも、公開設定プリフェッチの同時GET数を最大3件に保つ。
   * `platform-page.js`の`runWithBeaconPortSlot()`と同じ考え方 */
  function runWithPublishFlagSlot(task) {
    return new Promise(function (resolve, reject) {
      function release() {
        publishFlagSlotsActive--;
        var next = publishFlagSlotQueue.shift();
        if (next) next();
      }
      function start() {
        publishFlagSlotsActive++;
        Promise.resolve().then(task).then(function (value) {
          release();
          resolve(value);
        }, function (error) {
          release();
          reject(error);
        });
      }
      if (publishFlagSlotsActive < PUBLISH_FLAG_CONCURRENCY) {
        start();
      } else {
        publishFlagSlotQueue.push(start);
      }
    });
  }

  function ensurePublishFlags(panel, rows, areaId) {
    var now = Date.now();
    for (var i = 0; i < rows.length; i++) {
      (function (row) {
        if (!row || !isValidPortalId(row.portId)) return;
        var entry = publishFlagCache[row.portId];
        if (entry && (now - entry.timestamp < CACHE_TTL_MS)) return; // 十分新しい
        publishFlagCache[row.portId] = { value: entry ? entry.value : null, timestamp: now };
        runWithPublishFlagSlot(function () {
          return fetchPortDetail(row.portId);
        }).then(function (record) {
          publishFlagCache[row.portId] = { value: record.publishFlag, timestamp: Date.now() };
        }).catch(function () {
          publishFlagCache[row.portId] = { value: null, timestamp: Date.now() };
        }).then(function () {
          // 画面/エリアが変わっていたら、もう存在しないDOMに触らない
          if (!isPortsListPath() || getSelectedAreaId() !== areaId) return;
          var td = panel.querySelector('td[data-publish-cell-port-id="' + row.portId + '"]');
          if (!td) return;
          var e = publishFlagCache[row.portId];
          td.textContent = (e.value === null || e.value === undefined) ? '不明' : (e.value ? '公開' : '非公開');
        });
      })(rows[i]);
    }
  }

  function loadAndRender(panel, areaId, forceRefresh) {
    var now = Date.now();
    var cached = cacheByArea[areaId];
    if (!forceRefresh && cached && (now - cached.timestamp < CACHE_TTL_MS)) {
      renderIfNeeded(panel, areaId, cached.rows);
      setStatus(panel, '', null);
      ensurePublishFlags(panel, cached.rows, areaId);
      return;
    }

    // **フェッチを開始するたびに専用の通し番号を振る。**
    // 2026-08-12 再監査「同一世代で複数フェッチが走ると古い応答が上書きしうる」への対応。
    // `apply()`側の世代（currentGeneration）による早期無効化に加え、
    // 「このフェッチより後に始まったフェッチがあるか」を直接見る
    var seq = ++listFetchSeq;
    setStatus(panel, '読み込み中…', null);

    fetchPortsList(areaId).then(function (rows) {
      // 2026-08-12 再監査「エリア変更後、apply()が世代を進める前に旧応答が返る競合」への対応。
      // 世代番号だけに頼らず、**完了した時点の実際の画面状態**を直接確認する
      if (seq !== listFetchSeq) return; // 後発のフェッチに追い越された
      if (!isPortsListPath() || getSelectedAreaId() !== areaId) return; // 画面/エリアが変わった
      cacheByArea[areaId] = { rows: rows, timestamp: Date.now() };
      renderIfNeeded(panel, areaId, rows);
      setStatus(panel, '', null);
      ensurePublishFlags(panel, rows, areaId);
    }).catch(function (err) {
      if (seq !== listFetchSeq) return;
      if (!isPortsListPath() || getSelectedAreaId() !== areaId) return;
      var msg = err && err.message ? err.message : String(err);
      setStatus(panel, 'ポート一覧の取得に失敗しました: ' + msg, 'error');
    });
  }

  /** 開いている確認画面を強制的に閉じ、選択画面（ツールバー・表）へ戻す。
   * エリア切替・エリア未選択に戻ったときに呼ぶ（2026-08-12再監査「エリア切替後も
   * 古い確認画面が実行できる」への対応。確認画面のtargetIdsは旧エリアのポートを
   * 指したままになるため、切替後は無条件に破棄する） */
  function forceCloseConfirm(panel) {
    var confirmBox = panel.querySelector('.dbsext-port-bulk-confirm');
    if (!confirmBox || confirmBox.style.display === 'none') return;
    clearNode(confirmBox);
    confirmBox.style.display = 'none';
    var toolbar = panel.querySelector('.dbsext-port-bulk-toolbar');
    var tableWrap = panel.querySelector('.dbsext-port-bulk-table-wrap');
    if (toolbar) toolbar.style.display = '';
    if (tableWrap) tableWrap.style.display = '';
  }

  // ---------------------------------------------------------------------------
  D.portBulkActions = {
    apply: function () {
      if (typeof document === 'undefined' || !document.body) return;

      if (!isPortsListPath()) {
        var stale = document.querySelector('[' + PANEL_ATTR + ']');
        if (stale && stale.parentNode) {
          currentGeneration++;
          activeRunToken++; // 進行中の実行があれば次の行から自動的に中断扱いになる
          setNativeTableHidden(false); // 隠していたポータル純正表を必ず元に戻す
          stale.parentNode.removeChild(stale); // dbsext:own-ui
        }
        return;
      }

      var panel = ensurePanel();
      if (!panel) return;

      // **一括操作表を出している間は、同じ内容のポータル純正表を隠す（依頼1対応）。**
      // 削除・移動はしない。「オリジナル表示」トグルから peekShowAll/peekRestore 経由で
      // 一時的に戻せる（下記 D.portBulkActions 参照）。
      //
      // 2026-08-12独立監査で指摘・2026-08-13対応: 「オリジナル表示」中に`apply()`が
      // 再度呼ばれる（SPA再描画・エリア再選択等）と、`peekShowAll()`で戻したはずの
      // 純正表を無条件でまた隠してしまう回帰があった。`original-view.js`の
      // `isActive()`を見て、オリジナル表示中はここでの再非表示をスキップする
      // （`peekEachModule()`がトグル時に明示的に呼ぶ分だけで表示状態を決める）
      if (!D.originalView || !D.originalView.isActive || !D.originalView.isActive()) {
        setNativeTableHidden(true);
      }

      var areaId = getSelectedAreaId();
      if (!areaId) {
        // エリア未選択に戻った場合も、古い選択・実行・確認画面を持ち越さない
        currentGeneration++;
        activeRunToken++;
        selectedIds = Object.create(null);
        // 同じエリアを再選択したときも、解除前の表・チェック状態を再利用しない。
        // 描画マーカーを無効化して、再選択時に空の選択状態で表を作り直す。
        panel.__dbsextLastAreaId = null;
        panel.__dbsextPortBulkRenderedAreaId = null;
        panel.__dbsextPortBulkRenderedRows = null;
        panel.__dbsextPortBulkTableResult = null;
        forceCloseConfirm(panel);
        setStatus(panel, 'エリアを選択するとポート一覧が表示されます', null);
        return;
      }

      if (panel.__dbsextLastAreaId !== areaId) {
        panel.__dbsextLastAreaId = areaId;
        selectedIds = Object.create(null);
        panel.__dbsextPortBulkRenderedAreaId = null;
        panel.__dbsextPortBulkRenderedRows = null;
        panel.__dbsextPortBulkTableResult = null;
        currentGeneration++; // 前エリア向けの進行中フェッチを無効化する（早期無効化。完了時も別途直接確認する）
        activeRunToken++; // 前エリア向けの進行中実行を無効化する
        // **旧エリアのポートIDを指したままの確認画面は無条件に破棄する**
        // （2026-08-12再監査「エリア切替後も古い確認画面が実行できる」への対応）
        forceCloseConfirm(panel);
      }

      // 実行中・確認中は表を再取得して差し替えない
      var confirmBox = panel.querySelector('.dbsext-port-bulk-confirm');
      var resultsBox = panel.querySelector('.dbsext-port-bulk-results');
      if ((confirmBox && confirmBox.style.display !== 'none') ||
          (resultsBox && resultsBox.style.display !== 'none')) {
        return;
      }

      loadAndRender(panel, areaId, false);
    },

    /**
     * 「オリジナルに戻す」表示専用（`original-view.js`から呼ばれる）。
     * この機能が隠しているポータル純正表を一時的に見せる／戻す。
     */
    peekShowAll: function () {
      if (typeof document === 'undefined') return;
      setNativeTableHidden(false);
    },
    peekRestore: function () {
      if (typeof document === 'undefined') return;
      if (isPortsListPath() && document.querySelector('[' + PANEL_ATTR + ']')) {
        setNativeTableHidden(true);
      }
    },

    // テスト用
    _resetForTests: function () {
      cacheByArea = Object.create(null);
      selectedIds = Object.create(null);
      currentGeneration = 0;
      activeRunToken = 0;
      runState = null;
      setNativeTableHidden(false);
      var stale = (typeof document !== 'undefined') && document.querySelector('[' + PANEL_ATTR + ']');
      if (stale && stale.parentNode) stale.parentNode.removeChild(stale); // dbsext:own-ui
    },
    _getSelectedIds: function () { return selectedIds; },
    _buildUpdatedRecord: buildUpdatedRecord,
    _isValidPortalId: isValidPortalId,
    _isValidPortDetailRecord: isValidPortDetailRecord,
    NO_CHANGE: NO_CHANGE,
    SERVICE_STATE_OPTIONS: SERVICE_STATE_OPTIONS,
    PUBLISH_FLAG_OPTIONS: PUBLISH_FLAG_OPTIONS,
    PUBLISH_FLAG_VERIFIED: PUBLISH_FLAG_VERIFIED
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
